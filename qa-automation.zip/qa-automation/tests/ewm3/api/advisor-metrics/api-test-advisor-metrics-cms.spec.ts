import { expect, test } from '../../../../ewm3/fixtures/base-api-fixture'
import { AdvisorMetricsV2 } from '../../../../ewm3/api/advisormetrics/v2/endpoints'
import { EWM3ApiHelpers } from '../../../../ewm3/api/api-helpers'
import { DashboardConfig } from '../../../../ewm3/service-data/tile-config/dashboard.config'
import { Platforms } from '../../../../ewm3/service-data/config'

test.describe('Advisor metrics V2 tests. Group cms', {
  tag: ['@assetmark', '@stable', '@dashboard']
}, () => {
  const endpoint = new AdvisorMetricsV2().cms.ewmMetadata
  const pathParams = [
    ['menu_items', 'advisor-profile'],
  ]
  for (const param of pathParams) {
    test.describe('200 success', {
      tag: ['@6229']
    }, () => {
      test(`${endpoint.title}. Path params: ${param}`, async ({ requestContext }) => {
        const api = new EWM3ApiHelpers(requestContext)
        endpoint.pathParameters = param
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        api.validateJsonSchema(endpoint, await response.json())
      })
    })

    test.describe('401 fail. No token passed', () => {
      test(`${endpoint.title}. Path params: ${param}`, async ({ unauthorizedContext }) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        endpoint.pathParameters = param
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    })

    test.describe('401 fail. Token is expired', () => {
      test(`${endpoint.title}. Path params: ${param}`, async ({ expiredTokenContext }) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    })
  }

})

test.describe('Cheetah only tests', {
  tag: ['@cheetah', '@stable', '@dashboard']
}, () => {
  const endpoint = new AdvisorMetricsV2().cms

  test(`CMS response for advisor workstation doesn't contain assetmark only links`, {
    tag: ['@5115']
  }, async ({ requestContext }) => {
    const assetmarkOnlyLinks = Object.values(DashboardConfig.advisorWorkstationDropdownItems).filter(x => x.platforms.toLocaleString() === Platforms.ASSETMARK).map(x => x.name)
    const api = new EWM3ApiHelpers(requestContext)
    const response = await api.makeRequest(endpoint.advisorWorkstation)
    await api.responseIs200(response)

    const data = await response.json()
    const items = JSON.parse(data['data']).map(x => x.title)

    await test.step('Expecting api response to not contain non-cheetah advisor workstation links', async () => {
      for (const link of assetmarkOnlyLinks) {
        for (const item of items) {
          expect.soft(item, `Expect '${link}' not to be presented in actual array`).not.toEqual(link)
        }
      }
    })
  })

})

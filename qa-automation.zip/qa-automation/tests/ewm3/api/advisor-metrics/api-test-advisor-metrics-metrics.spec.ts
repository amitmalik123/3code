import { expect, test } from '../../../../ewm3/fixtures/base-api-fixture'
import { AdvisorMetricsV2, Periods } from '../../../../ewm3/api/advisormetrics/v2/endpoints'
import { BaseApiEndpoint } from '../../../../base/base-endpoint'
import { EWM3ApiHelpers } from '../../../../ewm3/api/api-helpers'
import { test as syncedTest } from '../../../../ewm3/fixtures/synced-api-fixture'
import { AdvisorBenefitResponseBody, ClientListResponse, FeeResponse, StatusAndTrackingResponse } from '../../../../ewm3/api/advisormetrics/v2/types'
import { GeneralUtils } from '../../../../utils/generalUtils'
import { FlagBody } from '../../../../ewm3/api/monitoring/v1/types'
import { FlagTypes, MonitoringV1 } from '../../../../ewm3/api/monitoring/v1/endpoints'
import { Platforms } from '../../../../ewm3/service-data/config'
import { AdvisorBenefitsConfig } from '../../../../ewm3/service-data/tile-config/advisor-benefits.config'
import { ParametersGenerator } from '../../../../ewm3/api/parametersGenerator'

test.describe('Advisor metrics V2 tests. Group metrics', {
  tag: ['@stable', '@dashboard', '@assetmark']
}, () => {

  const advisorMetricsEndpoints: BaseApiEndpoint[] = process.env.PLATFORM === Platforms.CHEETAH? 
    [
      new AdvisorMetricsV2().metrics.accounts,
      new AdvisorMetricsV2().metrics.clients,
      new AdvisorMetricsV2().metrics.investmentsStrategy,
      new AdvisorMetricsV2().metrics.investmentsApproach,
      new AdvisorMetricsV2().metrics.advisors
    ]:
    [
      new AdvisorMetricsV2().metrics.advisorBenefits,
      new AdvisorMetricsV2().metrics.accounts,
      new AdvisorMetricsV2().metrics.clients,
      new AdvisorMetricsV2().metrics.fees,
      new AdvisorMetricsV2().metrics.investmentsStrategy,
      new AdvisorMetricsV2().metrics.investmentsApproach,
      new AdvisorMetricsV2().metrics.advisors
    ]

  const advisorMetricsEndpointsWithPeriods: BaseApiEndpoint[] = [
    new AdvisorMetricsV2().metrics.aop,
    new AdvisorMetricsV2().metrics.netFlows(),
  ]

  test.describe('200 success', () => {

    for (const endpoint of advisorMetricsEndpoints) {
      test(`${endpoint.title}`, {
        tag: ['@830', '@6278', '@6279', '@6280', '@6281', '@6282', '@6283', '@6284', '@6285', '@6286', 
          '@6287', '@6288', '@6289', '@6290', '@6291', '@6292', '@6293', '@6294', '@6295']
      }, async ({ requestContext }) => {
        const api = new EWM3ApiHelpers(requestContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        api.validateJsonSchema(endpoint, await response.json())
      })
    }

    const endpoint = new AdvisorMetricsV2().metrics.advisorBenefits
    test(`Advisor benefits level`, {
      tag: ['@1047', '@1048', '@1049', '@1050', '@1051', '@1052']
    }, async ({ requestContext }) => {
      const api = new EWM3ApiHelpers(requestContext)
      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)

      const json: AdvisorBenefitResponseBody = await response.json()
      const assets = json.data.qualifyingAssets

      const target = AdvisorBenefitsConfig.programLevels.find(x => (assets >= x.rangeFrom) && (x.rangeTo == null || assets < x.rangeTo))
      expect(target!.name, `Assert level ${target!.name} matches asset: ${assets}`).toEqual(json.data.level)
    })

    for (const endpoint of advisorMetricsEndpointsWithPeriods) {
      for (const period of Object.values(Periods)) {
        test(`${endpoint.title}. Period: "${period}"`, {
          // Todo: Add database validation (check test tags on azure)
          tag: ['@cheetah', '@833', '@834', '@835']
        }, async ({ requestContext }) => {
          const api = new EWM3ApiHelpers(requestContext)
          endpoint.pathParameters = period
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          api.validateJsonSchema(endpoint, await response.json())

          const json = await response.json()
          expect(json['history'].length, 'Assert history shows past 12 months').toEqual(12)
        })
      }
    }

    for (const endpoint of advisorMetricsEndpointsWithPeriods) {
      for (const period of Object.values(Periods)) {
        test(`${endpoint.title} with advisor ID. Period: "${period}"`, {
          tag: ['@cheetah', '@1024', '@1015']
        }, async ({ requestContext }) => {
          const api = new EWM3ApiHelpers(requestContext)
          const advisorIdsArray: string[] = (await ParametersGenerator.advisorId(requestContext)).map(item => item.id)

          endpoint.pathParameters = period
          endpoint.queryParameters = { 'advisors': advisorIdsArray }

          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          api.validateJsonSchema(endpoint, await response.json())
 
        })
      }
    }

    // todo: replace math validation tests to schema math validation

    test.describe(`Math validation tests`, () => {
      for (const period of Object.values(Periods)) {
        test(`Assets on platform on a "${period}" basis`, {
          tag: ['@6296', '@6297', '@6298', '@cheetah']
        }, async ({ requestContext }) => {
          const endpoint = new AdvisorMetricsV2().metrics.aop
          endpoint.pathParameters = period

          const api = new EWM3ApiHelpers(requestContext)
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          const responseBody = await response.json()

          const currentMarketValue = responseBody.history[responseBody.history.length - 1].data?.marketValue ?
            responseBody.history[responseBody.history.length - 1].data.marketValue : 0
          const priorMarketValue = responseBody.history[responseBody.history.length - 2].data?.marketValue ?
            responseBody.history[responseBody.history.length - 2].data.marketValue : 0

          await api.mathValidation(
            responseBody.aum,
            responseBody.compareValue,
            responseBody.comparePercentage,
            currentMarketValue,
            priorMarketValue,
          )
        })

        test(`Net Flows on a "${period}" basis`, {
          tag: ['@cheetah', '@1023', '@6299', '@6300', '@6301', '@6302']
        }, async ({ requestContext }) => {
          const endpoint = new AdvisorMetricsV2().metrics.netFlows()
          endpoint.pathParameters = period

          const api = new EWM3ApiHelpers(requestContext)
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          const responseBody = await response.json()

          const startDate = responseBody.startDate
          // EWMPM-4316 Net Flows: $0 Scenario (Amended Requirement)
          function defineIndex(startDate: string, history:any[]){
            const index = history.length - 1
            if (history[index].startDate === startDate) return index
            else if (history[index-1].startDate === startDate) return index - 1
            else throw new Error(`Start date "${startDate}" != current and prior period`)
          }
          const index = defineIndex(startDate, responseBody.history)
          const currentNetFlow = responseBody.history[index].data?.netFlow ?
            responseBody.history[index].data.netFlow : 0 
          const  priorNetFlow = responseBody.history[index - 1].data?.netFlow ?
            responseBody.history[index - 1].data.netFlow : 0 
          await api.mathValidation(
            responseBody.currentNetFlow,
            responseBody.compareValue,
            responseBody.comparePercentage,
            currentNetFlow,
            priorNetFlow,
          )
        })
      }

      test('Fees', {
        tag: ['@6303', '@6304', '@6305', '@6306', '@6307', '@6308', '@6309']
      }, async ({ requestContext }) => {
        const endpoint = new AdvisorMetricsV2().metrics.fees

        const api = new EWM3ApiHelpers(requestContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        const responseBody: FeeResponse = await response.json()

        if (responseBody?.trendValue?.revenue && responseBody?.trendValue?.compareValue && responseBody?.trendValue?.comparePercentage){
          const lastItemIndex = responseBody.history.length-1
          // Handle null recent revenueTotal. See EWMPM-4027
          const recentPeriodWithRevenueIndex = responseBody.history[lastItemIndex].data?.revenueTotal ?
            lastItemIndex : lastItemIndex - 1

          const currentRevenue = responseBody.history[recentPeriodWithRevenueIndex].data.revenueTotal
          const priorRevenue = responseBody.history[recentPeriodWithRevenueIndex-1].data.revenueTotal
          await api.mathValidation(
            responseBody.trendValue.revenue,
            responseBody.trendValue.compareValue,
            responseBody.trendValue.comparePercentage,
            currentRevenue,
            priorRevenue
          )
          await test.step(`Then I validate that Total revenue by every quarter is correct`, async () => {

            for (const history of responseBody.history) {
              if (history.data){
                let amountOfRevenues = 0
                for (const details of history.data.details) {
                  amountOfRevenues += details.revenue
                  let amountOfFees = 0
                  for (const byBilledDate of details.byBilledDate) {
                    amountOfFees += byBilledDate.fees
                  }
                  expect(amountOfFees.toFixed(2),
                    `I expect that revenue by quarter = all fees that included in quarter`
                  ).toEqual(details.revenue.toFixed(2))
                }
                expect(amountOfRevenues.toFixed(2),
                  `I expect that revenueTotal = amount of all revenue types`
                ).toEqual(history.data.revenueTotal.toFixed(2))
              }
            }
          })

          await test.step(`Then I validate that Total revenue by name is correct`, async () => {
            for (const totalsByName of responseBody.totalsByName) {
              totalsByName.name
              totalsByName.revenue
              let amountOfRevenuesByDate = 0 
              for (const history of responseBody.history) {
                if (history.data) {
                  const revenueByName = history.data.details.find(d => d.name === totalsByName.name)?.revenue
                  amountOfRevenuesByDate += revenueByName ? revenueByName : 0
                }
              }
              expect(amountOfRevenuesByDate.toFixed(2),
                `I expect that "${totalsByName.name}" total revenue = amount of all quarters for this revenue name`
              ).toEqual(totalsByName.revenue.toFixed(2))
            }
          })
        } else throw new Error(`There is no trend value in API response. I can't execute current test.`)
      })

    })

    test.describe('Single thread', {
      tag: ['@cheetah']
    }, () => {
      test.describe.configure({ mode: 'default' })
      const endpoint = new AdvisorMetricsV2().metrics.clients
      test(`Adding item from ${endpoint.title} to following tab`, async ({ noClientFlagsContext }) => {
        const api = new EWM3ApiHelpers(noClientFlagsContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        const responseBody: ClientListResponse = await response.json()
        const randomIndex = GeneralUtils.getRandomNumber(responseBody.data.length)
        const randomItem = responseBody.data[randomIndex]
        randomItem.flagged = true

        const body: FlagBody = {
          entityId: randomItem.id,
          entityType: FlagTypes.CLIENT,
          userId: ''
        }
        await api.makeRequest(new MonitoringV1().flag.postFlags(body))

        const followingEndpoint = new AdvisorMetricsV2().metrics.clientsFlagged
        const followingResponse = await api.makeRequest(followingEndpoint)
        await api.responseIs200(response)
        const followingResponseBody: StatusAndTrackingResponse = await followingResponse.json()

        api.validateJsonSchema(endpoint, followingResponseBody)
        api.jsonsAreEqual(followingResponseBody.data[0], randomItem)
      })
    })
  })

  test.describe('401 fail. No token passed', {
    tag: ['@cheetah', '@6312', '@6314', '@6316', '@6318', '@6320', '@6364', '@6366', '@6368', '@6370']
  }, () => {

    for (const endpoint of advisorMetricsEndpoints) {
      test(`${endpoint.title}`, async ({ unauthorizedContext }) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }

    for (const endpoint of advisorMetricsEndpointsWithPeriods) {
      for (const period of Object.values(Periods)) {
        test(`${endpoint.title}. Period: "${period}"`, async ({ unauthorizedContext }) => {
          const api = new EWM3ApiHelpers(unauthorizedContext)
          const response = await api.makeRequest(endpoint)
          await api.responseIs401(response)
          await api.responseBodyIsEmpty(response)
        })
      }
    }
  })

  test.describe('401 fail. Token is expired', {
    tag: ['@cheetah', '@6313', '@6315', '@6317', '@6319', '@6321', '@6365', '@6367', '@6369', '@6371']
  }, () => {

    for (const endpoint of advisorMetricsEndpoints) {
      test(`${endpoint.title}`, async ({ expiredTokenContext }) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }

    for (const endpoint of advisorMetricsEndpointsWithPeriods) {
      for (const period of Object.values(Periods)) {
        test(`${endpoint.title}. Period: "${period}"`, async ({ expiredTokenContext }) => {
          const api = new EWM3ApiHelpers(expiredTokenContext)
          const response = await api.makeRequest(endpoint)
          await api.responseIs401(response)
          await api.responseBodyIsEmpty(response)
        })
      }
    }
  })

  test.describe('404 fail. Invalid period', {
    tag: ['@cheetah', '@836', '@846']
  }, () => {
    const invalidPeriods = ['', '###', '///']

    for (const endpoint of advisorMetricsEndpointsWithPeriods) {
      for (const period of invalidPeriods) {
        test(`${endpoint.title}. Invalid period: "${period}"`, {
          tag: ['@cheetah']
        }, async ({ requestContext }) => {
          const api = new EWM3ApiHelpers(requestContext)
          endpoint.pathParameters = period
          const response = await api.makeRequest(endpoint)
          await api.responseIs404(response)
          await api.responseBodyIsEmpty(response)
        })
      }
    }
  })

  test.describe('400 fail. Period does not exist', {
    tag: ['@cheetah', '@836', '@846']
  }, () => {
    const invalidPeriods = ['YEAR', 'INVALIDSTR1NG', '部落格']

    for (const endpoint of advisorMetricsEndpointsWithPeriods) {
      for (const period of invalidPeriods) {
        test(`${endpoint.title}. Invalid period: "${period}"`, {
          tag: ['@cheetah']
        }, async ({ requestContext }) => {
          const api = new EWM3ApiHelpers(requestContext)
          endpoint.pathParameters = period
          const response = await api.makeRequest(endpoint)
          await api.responseIs400(response)
        })
      }
    }
  })

})

syncedTest.describe('Advisor metrics V2 tests. Group metrics', {
  tag: ['@assetmark', '@stable', '@dashboard']
}, () => {
  syncedTest.describe('204 No Content', () => {
    const endpoint = new AdvisorMetricsV2().metrics.clientsFlagged
    syncedTest(`${endpoint.title}`, async ({ noClientFlagsContext }) => {
      const api = new EWM3ApiHelpers(noClientFlagsContext)
      const response = await api.makeRequest(endpoint)
      await api.responseIs204(response)
    })
  })

})

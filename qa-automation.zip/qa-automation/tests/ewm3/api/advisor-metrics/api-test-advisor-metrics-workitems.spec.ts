import { test } from '../../../../ewm3/fixtures/base-api-fixture'
import { AdvisorMetricsV2 } from '../../../../ewm3/api/advisormetrics/v2/endpoints'
import { BaseApiEndpoint } from '../../../../base/base-endpoint'
import { EWM3ApiHelpers } from '../../../../ewm3/api/api-helpers'
import { FlagTypes, MonitoringV1 } from '../../../../ewm3/api/monitoring/v1/endpoints'
import { StatusAndTrackingResponse } from '../../../../ewm3/api/advisormetrics/v2/types'
import { GeneralUtils } from '../../../../utils/generalUtils'
import { FlagBody } from '../../../../ewm3/api/monitoring/v1/types'
import { test as syncedTest } from '../../../../ewm3/fixtures/synced-api-fixture'

test.describe('Advisor metrics V2 tests. Group workitems', {
  tag: ['@assetmark', '@cheetah', '@stable', '@dashboard']
}, () => {

  const advisorMetricsEndpoints: BaseApiEndpoint[] = [
    new AdvisorMetricsV2().workItems.all,
    new AdvisorMetricsV2().workItems.open,
    new AdvisorMetricsV2().workItems.needAttention,
    new AdvisorMetricsV2().workItems.completed
  ]

  test.describe('200 success', () => {
    for (const endpoint of advisorMetricsEndpoints) {
      test(`${endpoint.title}`, {
        tag: ['@1160', '@1161', '@1163', '@1164']
      }, async ({ requestContext }) => {
        const api = new EWM3ApiHelpers(requestContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        api.validateJsonSchema(endpoint, await response.json())
      })
    }

    test.describe('Single thread', () => {

      test.describe.configure({ mode: 'default' })
      for (const endpoint of advisorMetricsEndpoints) {
        test(`Adding item from ${endpoint.title} to following tab`, async ({ noStatusAndTrackingFlagsContext }) => {
          const api = new EWM3ApiHelpers(noStatusAndTrackingFlagsContext)
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          const responseBody: StatusAndTrackingResponse = await response.json()
          const randomIndex = GeneralUtils.getRandomNumber(responseBody.data.length)
          const randomItem = responseBody.data[randomIndex]
          randomItem.flagged = true

          const body: FlagBody = {
            entityId: randomItem.id,
            entityType: FlagTypes.WORK_ITEM,
            userId: ''
          }
          await api.makeRequest(new MonitoringV1().flag.postFlags(body))

          const followingEndpoint = new AdvisorMetricsV2().workItems.following
          const followingResponse = await api.makeRequest(followingEndpoint)
          await api.responseIs200(response)
          const followingResponseBody: StatusAndTrackingResponse = await followingResponse.json()

          api.validateJsonSchema(endpoint, followingResponseBody)
          api.jsonsAreEqual(followingResponseBody.data[0], randomItem)
        })
      }
    })
  })

  for (const endpoint of advisorMetricsEndpoints) {
    test.describe('401 fail. No token passed', () => {
      test(`${endpoint.title}`, async ({ unauthorizedContext }) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    })

    test.describe('401 fail. Token is expired', () => {
      test(`${endpoint.title}`, async ({ expiredTokenContext }) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    })
  }
})

syncedTest.describe('Advisor metrics V2 tests. Group workitems', {
  tag: ['@assetmark', '@stable', '@dashboard']
}, () => {

  syncedTest.describe('204 No Content', () => {
    const endpoint = new AdvisorMetricsV2().workItems.following
    syncedTest(`${endpoint.title}`, async ({ noStatusAndTrackingFlagsContext }) => {
      const api = new EWM3ApiHelpers(noStatusAndTrackingFlagsContext)
      const response = await api.makeRequest(endpoint)
      await api.responseIs204(response)
    })
  })

})

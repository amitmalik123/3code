import { test } from '../../../../../ewm3/fixtures/base-api-fixture'
import { EWM3ApiHelpers } from '../../../../../ewm3/api/api-helpers'
import { FlagTypes, MonitoringV1 } from '../../../../../ewm3/api/monitoring/v1/endpoints'
import { AdvisorMetricsV2 } from '../../../../../ewm3/api/advisormetrics/v2/endpoints'
import { ClientListResponse, StatusAndTrackingResponse } from '../../../../../ewm3/api/advisormetrics/v2/types'
import { GeneralUtils } from '../../../../../utils/generalUtils'
import { FlagBody } from '../../../../../ewm3/api/monitoring/v1/types'

test.describe('Monitoring V1 tests. Group flag', {
  tag: ['@assetmark', '@cheetah', '@stable', '@dashboard']
}, () => {
  const endpointArray = [
    new MonitoringV1().flag.flagsByType(),
    new MonitoringV1().flag.flagsByClientType,
    new MonitoringV1().flag.deleteFlagsById(),
    new MonitoringV1().flag.deleteFlags(),
    new MonitoringV1().flag.postFlags()
  ]

  test.describe('200 success', () => {
    test(`Get flags by type: ${FlagTypes.ACCOUNT}`, async ({requestContext}) => {
      const api = new EWM3ApiHelpers(requestContext)
      const endpoint = new MonitoringV1().flag.flagsByType(FlagTypes.ACCOUNT)

      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)
      api.validateJsonSchema(endpoint, await response.json())
    })

    test.describe('Single thread', () => {
      test.describe.configure({ mode: 'default' })
      test(`Get flags by client`, async ({noFlagsContext}) => {
        const api = new EWM3ApiHelpers(noFlagsContext)
        await api.flagItems(FlagTypes.CLIENT, 1)
        const endpoint = new MonitoringV1().flag.flagsByClientType

        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        api.validateJsonSchema(endpoint, await response.json())
      })

      for (const param of [
        {
          itemListEndpoint: new AdvisorMetricsV2().metrics.clients,
          flagType: FlagTypes.CLIENT
        },
        {
          itemListEndpoint: new AdvisorMetricsV2().workItems.all,
          flagType: FlagTypes.WORK_ITEM
        }
      ]) {
        test(`Get flags by type: ${param.flagType}`, async ({noFlagsContext}) => {
          const api = new EWM3ApiHelpers(noFlagsContext)
          const endpoint = new MonitoringV1().flag.flagsByType(param.flagType)
          await api.flagItems(param.flagType, 1)

          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          api.validateJsonSchema(endpoint, await response.json())
        })

        test(`Add flags: ${param.flagType}`, {
          tag: ['@6636']
        }, async ({noFlagsContext}) => {
          const api = new EWM3ApiHelpers(noFlagsContext)
          const getItems: StatusAndTrackingResponse | ClientListResponse = await (await api.makeRequest(param.itemListEndpoint)).json()
          const entityId = getItems.data[GeneralUtils.getRandomNumber(getItems.data.length)].id
          const body : FlagBody = { entityId: entityId, entityType: param.flagType, userId: '' }
          const endpoint = new MonitoringV1().flag.postFlags(body)

          const response = await api.makeRequest(endpoint)
          await api.responseIs201(response)
          api.validateJsonSchema(endpoint, await response.json())
        })

        test(`Delete flags items: ${param.flagType}`, async ({requestContext}) => {
          const api = new EWM3ApiHelpers(requestContext)
          await api.flagItems(param.flagType, 1)
          const endpoints = new MonitoringV1().flag

          const flagItemId: string = (await
          (await api.makeRequest(
            endpoints.flagsByType(
              param.flagType))).json()).data[0].id

          const response = await api.makeRequest(endpoints.deleteFlagsById(flagItemId))
          await api.responseIs200(response)
          const responseBody = await response.json()
          api.validateJsonSchema(endpoints.deleteFlagsById(flagItemId), responseBody)
        })
      }
    })

  })
  
  test.describe('404 Not Found', () => {
    const invalidIdArray = ['77t957f5-null--1E+02-部落格-$USER', 'bda7f8c5-5d40-489c-91cd-9a4e183735ac']
    for (const invalidId of invalidIdArray) {
      test(`Delete flag item by invalid id: ${invalidId}`, async ({requestContext}) => {
        const api = new EWM3ApiHelpers(requestContext)
        const endpoint = new MonitoringV1().flag.deleteFlagsById(invalidId)
        const response = await api.makeRequest(endpoint)
        await api.responseIs404(response)
      })

      for (const flagType of Object.values(FlagTypes)) {
        test(`Delete flag item by invalid entity id: ${invalidId} and flag type: ${flagType}`, async ({requestContext}) => {
          const api = new EWM3ApiHelpers(requestContext)
          const endpoint = new MonitoringV1()
            .flag
            .deleteFlags(
              {
                entityId: invalidId,
                entityType: flagType
              })
          const response = await api.makeRequest(endpoint)
          await api.responseIs404(response)
        })
      }
    }
  })

  test.describe('400 Bad request', () => {
    test(`Get flags by invalid type`, async ({requestContext}) => {
      const api = new EWM3ApiHelpers(requestContext)
      const endpoint = new MonitoringV1().flag.flagsByType()
      endpoint.pathParameters = 'invalidType'

      const response = await api.makeRequest(endpoint)
      await api.responseIs400(response)
    })

    for (const body of [
      {},
      {
        entityId: '1234',
        entityType: FlagTypes.CLIENT
      },
      {
        entityId: '1234',
        entityType: 'invalidType',
        userId: ''
      },
    ]) {
      test(`Add flags: invalid body ${JSON.stringify(body)}`, async ({requestContext}) => {
        const api = new EWM3ApiHelpers(requestContext)
        const endpoint = new MonitoringV1().flag.postFlags()
        endpoint.body = body

        const response = await api.makeRequest(endpoint)
        await api.responseIs400(response)
      })
    }
  })

  for (const endpoint of endpointArray) {
    test.describe('401 fail. No token passed', () => {
      test(`${endpoint.title}`, async ({unauthorizedContext}) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    })

    test.describe('401 fail. Token is expired', () => {
      test(`${endpoint.title}`, async ({expiredTokenContext}) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    })
  }
})

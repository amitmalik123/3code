import { expect, test } from '../../../../../ewm3/fixtures/base-api-fixture'
import { EWM3ApiHelpers } from '../../../../../ewm3/api/api-helpers'
import { MonitoringV1 } from '../../../../../ewm3/api/monitoring/v1/endpoints'
import { DashboardConfig } from '../../../../../ewm3/service-data/tile-config/dashboard.config'
import { EWM3Config, Platforms } from '../../../../../ewm3/service-data/config'
import { BaseApiEndpoint } from '../../../../../base/base-endpoint'

test.describe('Monitoring V1 tests. Group cms', {
  tag: ['@stable', '@dashboard']
}, () => { 

  const endpoints: BaseApiEndpoint[] = [
    new MonitoringV1().cms.metadata.advisorProfile,
    new MonitoringV1().cms.metadata.advisorWorkstation,
    new MonitoringV1().cms.metadata.headerItems,
    new MonitoringV1().cms.metadata.widgets,
    new MonitoringV1().cms.metadata.sidebar,
    new MonitoringV1().cms.resources.siteModals,
    new MonitoringV1().cms.resources.siteAlerts,
    new MonitoringV1().cms.resources.widgetsSettings,
    new MonitoringV1().cms.resources.ewmMarketing,
  ]  

  test.describe('200 success', () => {

    for (const endpoint of endpoints) {
      test(`${endpoint.title}.`, {
        tag: ['@assetmark', '@cheetah', '@6228', '@6229', '@6231', '@6232', '@6233', '@6234', 
          '@6237', '@6238', '@6242', '@6243', '@6244', '@6245', '@6246', '@6247', '@6248', '@6249']
      }, async ({ requestContext }) => {
        const api = new EWM3ApiHelpers(requestContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        api.validateJsonSchema(endpoint, await response.json())
      })
    }

    test.describe('Cheetah only tests', {
      tag: ['@cheetah']
    }, () => {
      const endpoint = new MonitoringV1().cms
      const envTiles = Object.values(DashboardConfig.tiles).filter(x => x.platforms.includes(EWM3Config.PLATFORM))
      const tileCmsIds = envTiles.map(x => x.cmsId)
    
      test(`CMS response for header items doesn't contain assetmark only links`, {
        tag: ['@5080', '@5081']
      }, async ({ requestContext }) => {
        const assetmarkOnlyHeaderLinks = Object.values(DashboardConfig.headerLinks).filter(x => x.platforms.toLocaleString() === Platforms.ASSETMARK)
        const api = new EWM3ApiHelpers(requestContext)
        const response = await api.makeRequest(endpoint.metadata.headerItems)
        await api.responseIs200(response)
    
        const data = await response.json()
        const items = JSON.parse(data['data']).map(x => x.title)
    
        await test.step('Expecting api response to not contain non-cheetah header links', async () => {
          for (const link of assetmarkOnlyHeaderLinks) {
            expect.soft(items, `Expect '${link}' not to be presented in actual array`).not.toContain(link)
          }
        })
      })
    
      test(`CMS response for widgets doesn't contain assetmark only widgets`, {
        tag: ['@5083', '@5084']
      }, async ({ requestContext }) => {
        const api = new EWM3ApiHelpers(requestContext)
        const response = await api.makeRequest(endpoint.metadata.widgets)
        await api.responseIs200(response)
    
        const data = await response.json()
        const items = JSON.parse(data['data'])
          // widgets have empty tab title because they are from the main home page, this filters out things in response that are not widgets
          .filter(x => x.default_tab_title.length == 0)
          .map(x => x.field_ewm_widget_id)
          
        await test.step('Expecting api response to not contain non-cheetah widgets', async () => {
          expect(items.sort()).toEqual(tileCmsIds.sort())
        })
      })
    
      test(`CMS response for sidebar doesn't contain assetmark only widgets`, {
        tag: ['@5083', '@5084']
      }, async ({ requestContext }) => {
        const assetmarkOnlyWidgets = Object.values(DashboardConfig.tiles).filter(x => x.platforms.toLocaleString() === Platforms.ASSETMARK).map(x => x.cmsId)
        const api = new EWM3ApiHelpers(requestContext)
        const response = await api.makeRequest(endpoint.metadata.sidebar)
        await api.responseIs200(response)
    
        const data = await response.json()
        const widgetItems = JSON.parse(data['data'])[0]['Widgets']
        const items = widgetItems.map(x => x.widget_id)
    
        await test.step('Expecting api response to not contain non-cheetah widgets', async () => {
          for (const widget of assetmarkOnlyWidgets) {
            expect.soft(items, `Expect '${widget}' not to be presented in actual array`).not.toEqual(widget)
          }
        })
      })
      
    })

  })

  test.describe('401 fail. No token passed', {
    tag: ['@assetmark', '@cheetah']
  }, () => {

    for (const endpoint of endpoints) {
      test(`${endpoint.title}`, {
        tag: ['@6269', '@6271', '@6273', '@6275']
      }, async ({ unauthorizedContext }) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }

  })

  test.describe('401 fail. Token is expired', {
    tag: ['@assetmark', '@cheetah']
  }, () => {

    for (const endpoint of endpoints) {
      test(`${endpoint.title}`, {
        tag: ['@6270', '@6272', '@6274', '@6276']
      }, async ({ expiredTokenContext }) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }

  })

})

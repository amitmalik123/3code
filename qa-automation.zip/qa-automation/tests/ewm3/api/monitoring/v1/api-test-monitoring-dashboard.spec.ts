import { test } from '../../../../../ewm3/fixtures/base-api-fixture'
import { test as syncedTest } from '../../../../../ewm3/fixtures/synced-api-fixture'
import { EWM3ApiHelpers } from '../../../../../ewm3/api/api-helpers'
import { MonitoringV1 } from '../../../../../ewm3/api/monitoring/v1/endpoints'
import { DashboardArrayResponse, DashboardData, DashboardResponse } from '../../../../../ewm3/api/monitoring/v1/types'
import { expect } from '@playwright/test'
import { BaseApiEndpoint } from '../../../../../base/base-endpoint'
import { GeneralUtils } from '../../../../../utils/generalUtils'
import { DashboardConfig } from '../../../../../ewm3/service-data/tile-config/dashboard.config'
import { EWM3Config } from '../../../../../ewm3/service-data/config'
const envTiles = Object.values(DashboardConfig.tiles).filter(x => x.platforms.includes(EWM3Config.PLATFORM))
const tileCmsIds = envTiles.map(x => x.cmsId)

const data: DashboardData = {
  name:'Test new dashboard',
  widgets:[]
}
test.describe('Monitoring V1 tests. Group dashboard', {
  tag: ['@assetmark', '@cheetah', '@stable', '@dashboard']
}, () => {

  test.describe('404 not found', () => {
    const invalidIdArray = ['77t957f5-null--1E+02-部落格-$USER', 'bda7f8c5-5d40-489c-91cd-9a4e183735ac']
    for (const invalidId of invalidIdArray) {
      test(`Get dashboard by invalid id: "${invalidId}"`, {
        tag: ['@857']
      }, async ({ preparedDashboardsContext }) => {
        const api = new EWM3ApiHelpers(preparedDashboardsContext)
        const endpoints = new MonitoringV1().dashboard
        endpoints.getDashboard.pathParameters = invalidId

        await api.responseIs404(
          await api.makeRequest(endpoints.getDashboard)
        )
      })

      test(`Set my default Dashboard. Id is invalid: "${invalidId}" `, {
        tag: ['@819']
      }, async ({ preparedDashboardsContext }) => {
        const api = new EWM3ApiHelpers(preparedDashboardsContext)
        const endpoints = new MonitoringV1().dashboard
        endpoints.setDefaultDashboard.body = `"${invalidId}"`

        const response = await api.makeRequest(endpoints.setDefaultDashboard)
        await api.responseIs404(response)
      })
    }

    test(`Set my default Dashboard. Id is empty `, {
      tag: ['@820']
    }, async ({ preparedDashboardsContext }) => {
      const api = new EWM3ApiHelpers(preparedDashboardsContext)
      const endpoints = new MonitoringV1().dashboard
      endpoints.setDefaultDashboard.body = '""'

      const response = await api.makeRequest(endpoints.setDefaultDashboard)
      await api.responseIs404(response)
    })

  })

  test.describe('400 bad request', () => {

    const paramsArray = [{name: ''}, {foo: 'boo'}, {}]
    for (const param of paramsArray) {
      test(`Create dashboard. Required property of dashboard is missing. Request body: "${JSON.stringify(param)}"`, async ({ preparedDashboardsContext }) => {
        const api = new EWM3ApiHelpers(preparedDashboardsContext)
        const endpoints = new MonitoringV1().dashboard
        endpoints.postCreateDashboard.body = param

        const response = await api.makeRequest(endpoints.postCreateDashboard)
        const responseBody = await response.json()
        await api.responseIs400(response)
        expect(responseBody.errors.Name[0], 'Assert error massage').toEqual('The dashboard name is required.')
      })

      test(`Rename dashboard. Request body: "${JSON.stringify(param)}"`, async ({ preparedDashboardsContext }) => {
        const api = new EWM3ApiHelpers(preparedDashboardsContext)
        const endpoints = new MonitoringV1().dashboard
        endpoints.putChangeDashboard.body = param
        endpoints.putChangeDashboard.body.id = await api.firstDashboardId()
        const response = await api.makeRequest(endpoints.putChangeDashboard)
        const responseBody = await response.json()
        await api.responseIs400(response)
        expect(responseBody.errors.Name[0], 'Assert error massage').toEqual('The dashboard name is required.')
      })
    }

    test(`Set my default Dashboard. Id is null `, {
      tag: ['@821']
    }, async ({ preparedDashboardsContext }) => {
      const api = new EWM3ApiHelpers(preparedDashboardsContext)
      const endpoints = new MonitoringV1().dashboard
      endpoints.setDefaultDashboard.body = null

      const response = await api.makeRequest(endpoints.setDefaultDashboard)
      await api.responseIs400(response)
    })
  })

  const endpoints: BaseApiEndpoint[] = [
    new MonitoringV1().dashboard.getDashboard,
    new MonitoringV1().dashboard.dashboardsByUser,
    new MonitoringV1().dashboard.deleteDashboard,
    new MonitoringV1().dashboard.putChangeDashboard,
    new MonitoringV1().dashboard.postCreateDashboard,
    new MonitoringV1().dashboard.setDefaultDashboard,
  ]
  for (const endpoint of endpoints) {

    test.describe('401 fail. No token passed', {
      tag: ['@858']
    }, () => {
      test(`${endpoint.title}`, async ({ unauthorizedContext }) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    })

    test.describe('401 fail. Token is expired', {
      tag: ['@858']
    }, () => {
      test(`${endpoint.title}`, async ({ expiredTokenContext }) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    })
  }
})

syncedTest.describe('Monitoring V1 tests. Group dashboard', {
  tag: ['@assetmark', '@stable', '@dashboard']
}, () => {

  syncedTest.describe('200 success', () => {

    syncedTest('Create new dashboard', {
      tag: ['@850']
    }, async ({ preparedDashboardsContext }) => {
      const api = new EWM3ApiHelpers(preparedDashboardsContext)
      const endpoints = new MonitoringV1().dashboard
      endpoints.postCreateDashboard.body = data

      const response = await api.makeRequest(endpoints.postCreateDashboard)
      const responseBody: DashboardResponse = await response.json()

      await api.responseIs201(response)
      api.validateJsonSchema(endpoints.postCreateDashboard, responseBody)
      expect(responseBody.data.name).toEqual(data.name)
      expect(responseBody.data.widgets).toEqual(data.widgets)

      endpoints.getDashboard.pathParameters = responseBody.data.id
      const getDashboardResponse = await api.makeRequest(endpoints.getDashboard)
      const getDashboardResponseBody: DashboardResponse = await response.json()
      await api.responseIs200(getDashboardResponse)
      api.validateJsonSchema(endpoints.getDashboard, getDashboardResponseBody)
      api.jsonsAreEqual(getDashboardResponseBody, responseBody)
    })

    syncedTest('Delete new dashboard', {
      tag: ['@856']
    }, async ({ preparedDashboardsContext }) => {
      const api = new EWM3ApiHelpers(preparedDashboardsContext)
      const endpoints = new MonitoringV1().dashboard
      endpoints.postCreateDashboard.body = data

      const response = await api.makeRequest(endpoints.postCreateDashboard)
      await api.responseIs201(response)
      const responseBody: DashboardResponse = await response.json()

      endpoints.deleteDashboard.pathParameters = responseBody.data.id
      const deleteDashboardResponse = await api.makeRequest(endpoints.deleteDashboard)
      await api.responseIs200(deleteDashboardResponse)
      api.validateJsonSchema(endpoints.deleteDashboard, await deleteDashboardResponse.json())
    })

    syncedTest('Get dashboards by user', async ({ preparedDashboardsContext }) => {
      const api = new EWM3ApiHelpers(preparedDashboardsContext)
      const endpoints = new MonitoringV1().dashboard

      const response = await api.makeRequest(endpoints.dashboardsByUser)
      await api.responseIs200(response)
      const responseBody: DashboardArrayResponse = await response.json()
      api.validateJsonSchema(endpoints.dashboardsByUser, responseBody)

      await syncedTest.step(`Then: compare every dashboard from ${endpoints.dashboardsByUser.route} 
        with specific dashboard from ${endpoints.dashboardsByUser.route}${endpoints.dashboardsByUser.pathParameters}`, async () => {
        for (const dashboard of responseBody.data) {
          endpoints.getDashboard.pathParameters = dashboard.id
          const getDashboardResponse = await api.makeRequest(endpoints.getDashboard)
          await api.responseIs200(getDashboardResponse)
          const getDashboardResponseBody: DashboardResponse = await getDashboardResponse.json()
          api.validateJsonSchema(endpoints.getDashboard, getDashboardResponseBody)
          //sometimes widgets order can be different for get widgets by user and id endpoints
          // Validate that array contains all data that we expect
          await api.arrayContainsData(getDashboardResponseBody.data.widgets, dashboard.widgets)
          // make widgets array empty
          getDashboardResponseBody.data.widgets = []
          dashboard.widgets = []
          // validate that rest part of jsons are equal
          api.jsonsAreEqual(getDashboardResponseBody.data, dashboard)
        }
      })
    })

    syncedTest('Rename the dashboard', {
      tag: ['@853']
    }, async ({ preparedDashboardsContext }) => {
      const api = new EWM3ApiHelpers(preparedDashboardsContext)
      const endpoints = new MonitoringV1().dashboard
      const data: DashboardData = {
        name: `Dashboard ${GeneralUtils.generateRandomAlphanumericString(15)}`,
        id: `${await api.firstDashboardId()}`
      }
      endpoints.putChangeDashboard.body = data

      const response = await api.makeRequest(endpoints.putChangeDashboard)
      const responseBody: DashboardResponse = await response.json()
      await api.responseIs200(response)
      api.validateJsonSchema(endpoints.putChangeDashboard, responseBody)
      expect(responseBody.data.id).toEqual(data.id)
      expect(responseBody.data.name).toEqual(data.name)

      endpoints.getDashboard.pathParameters = data.id
      const getDashboardResponse = await api.makeRequest(endpoints.getDashboard)
      await api.responseIs200(getDashboardResponse)
      api.jsonsAreEqual(responseBody, await getDashboardResponse.json())

    })

    syncedTest('Set my default Dashboard', {
      tag: ['@650', '@817', '@818', '@822']
    }, async ({ preparedDashboardsContext }) => {
      const api = new EWM3ApiHelpers(preparedDashboardsContext)
      const endpoints = new MonitoringV1().dashboard

      endpoints.postCreateDashboard.body = data
      let newDashboardResponseBody: DashboardResponse = await (await api.makeRequest(endpoints.postCreateDashboard)).json()
      expect(newDashboardResponseBody.data.isDefault,
        `Expect that new dashboard id: "${newDashboardResponseBody.data.id}" is not default`).toBeFalsy()

      endpoints.setDefaultDashboard.body = `"${newDashboardResponseBody.data.id}"`
      const response = await api.makeRequest(endpoints.setDefaultDashboard)
      await api.responseIs200(response)
      api.validateJsonSchema(endpoints.setDefaultDashboard, await response.json())

      endpoints.getDashboard.pathParameters = newDashboardResponseBody.data.id
      newDashboardResponseBody = await (await api.makeRequest(endpoints.getDashboard)).json()
      expect(newDashboardResponseBody.data.isDefault,
        `Expect that new dashboard id: "${newDashboardResponseBody.data.id}" is default`).toBeTruthy()
    })

  })

  syncedTest.describe('404 not found', () => {
    syncedTest('Delete already deleted dashboard', async ({ preparedDashboardsContext }) => {
      const api = new EWM3ApiHelpers(preparedDashboardsContext)
      const endpoints = new MonitoringV1().dashboard
      endpoints.postCreateDashboard.body = data

      const response = await api.makeRequest(endpoints.postCreateDashboard)
      const responseBody: DashboardResponse = await response.json()

      endpoints.deleteDashboard.pathParameters = responseBody.data.id
      await api.responseIs200(await api.makeRequest(endpoints.deleteDashboard))
      await api.responseIs404(await api.makeRequest(endpoints.deleteDashboard))
    })
  })

})

test.describe('Cheetah only tests', {
  tag: ['@cheetah', '@stable', '@dashboard']
}, () => {
  const endpoints = new MonitoringV1().dashboard

  test(`Response for byuser doesn't contain assetmark only widgets`, {
    tag: ['@5083', '@5084']
  }, async ({ requestContext }) => {
    const api = new EWM3ApiHelpers(requestContext)
    const response = await api.makeRequest(endpoints.dashboardsByUser)
    await api.responseIs200(response)

    const data = await response.json()
    const widgetItems = data['data'][0]['widgets']
    const items = widgetItems.map(x => x.cmsId)

    await test.step('Expecting api response to not contain non-cheetah widgets', async () => {
      expect(items.sort()).toEqual(tileCmsIds.sort())
    })
  })

})
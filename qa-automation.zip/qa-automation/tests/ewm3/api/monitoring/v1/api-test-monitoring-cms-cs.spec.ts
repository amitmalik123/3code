import { test } from '../../../../../ewm3/fixtures/base-api-fixture'
import { EWM3ApiHelpers } from '../../../../../ewm3/api/api-helpers'
import { MonitoringV1 } from '../../../../../ewm3/api/monitoring/v1/endpoints'
import { ClientResourcesCmsResponse, CmsTableElement, LinkElement } from '../../../../../ewm3/api/monitoring/v1/types'
import { expect } from '@playwright/test'
import { HouseholdConfig } from '../../../../../ewm3/service-data/client-section-configs/household.config'
import { AccountsConfig } from '../../../../../ewm3/service-data/client-section-configs/accounts.config'
import { BaseApiEndpoint } from '../../../../../base/base-endpoint'
import { EWM3Config } from '../../../../../ewm3/service-data/config'
import { GeneralUtils } from '../../../../../utils/generalUtils'
import { MonitoringV2 } from '../../../../../ewm3/api/monitoring/v2/endpoints'
import { generateColumnFilters } from '../../../../../ewm3/api/monitoring/v2/test-data-generator'

test.describe('Monitoring data V1 tests. Group cms @client-section', () => {
  const clientEndpoint = new MonitoringV1().cms.resources.clients

  const endpointArray: BaseApiEndpoint[] = [
    clientEndpoint
  ]

  test.describe('200 success', () => {

    const uids = [
      'clients.households.table',
      'clients.accounts.table',
    ]
    for (const uid of uids) {
      test(`Check 'filter_selection_msg' value in the response body for uid: '${uid}'`, { tag: ['@3352'] }, async ({requestContext}) => {
        const api = new EWM3ApiHelpers(requestContext)
        const filtersEndpoint = new MonitoringV2().preferences

        await test.step('PUT Filter Preferences', async () => {
          const endpoint = filtersEndpoint.putPreferences(generateColumnFilters(uid))
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
        })
        await test.step(`Check 'filter_selection_msg' value`, async () => {
          const endpoint = new MonitoringV1().cms.resources.ewmMetadata
          const response = await api.makeRequest(endpoint)
          const responseBody = await response.json()
          await api.responseIs200(response)
          api.validateJsonSchema(endpoint, responseBody)

          const keyValue = responseBody.data.find(item => item.name === 'filter_selection_msg')
          expect(keyValue.field_metadata_value, 'Verify that field value is correct').toBe('{filteredRows} of {totalRows} rows will be shown')
        })
        await test.step('DELETE preferences', async () => {
          const endpoint = filtersEndpoint.deletePreferences(uid)
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
        })
      })
    }

    test(`Check response structure of ${clientEndpoint.title} - @2604, @2605, @2606, @2609, @2750, @2751, @2755`, async ({requestContext}) => {
      const api = new EWM3ApiHelpers(requestContext)
      const response = await api.makeRequest(clientEndpoint)
      await api.responseIs200(response)
      api.validateJsonSchema(clientEndpoint, await response.json())
    })

    test('Check cms settings for HH tab match specification @2607, @2608, @2610', async ({requestContext}) => {
      const api = new EWM3ApiHelpers(requestContext)
      const response = await api.makeRequest(clientEndpoint)
      await api.responseIs200(response)
      const responseBody: ClientResourcesCmsResponse | undefined = await response.json()
      const data = responseBody?.data

      if (data) {
        const selectedElement = data.find(item => item.uid === 'ap-clients')
        const selectedTab = selectedElement?.tabs.find(item => item.uid === 'ap-clients-hh')
        const selectedTable = selectedTab?.tables.find(item => item.uid === 'ap-clients-hh-hh-tbl')
        const headers = selectedTable?.headers
        const toolbarLabels = selectedTab?.labels
        const nestedTable = selectedTable?.nested_table?.find(item => item.uid === 'ap-clients-hh-hh-tbl-acc-tbl')
        const nestedHeaders = nestedTable?.headers

        await test.step(`Assert Household main table dafault sorting in cms settings @2607`, async () => {
          expect.soft(selectedTable?.sort_header, 'Assert default sort column for HH table in cms settings').toEqual(HouseholdConfig.TABLE_DATA_CONFIG.defaultSortingField.uid)
          expect.soft(selectedTable?.sort_direction.toUpperCase(), 'Assert default sort direction for for HH table in cms settings').toEqual(HouseholdConfig.TABLE_DATA_CONFIG.defaultSortingOrder.toUpperCase())
        })

        await test.step(`Assert Household main Table columns definition in cms settings @2607`, async () => {
          headers?.forEach(header =>{
            const houseHoldConfigField = HouseholdConfig.TABLE_DATA_CONFIG.fields
              .find(field => field.uid === header.uid)
            expect.soft(header.name, `Assert cms name setting for HH main table column: ${header.uid} - ${header.name}`).toEqual(houseHoldConfigField?.columnName)
            expect.soft(header.frozen, `Assert cms frozen setting for HH main table column: ${header.uid} - ${header.name}`).toEqual(houseHoldConfigField?.frozen_direction)
            expect.soft(header.hidden, `Assert cms hidden setting for HH main table column: ${header.uid} - ${header.name}`).toEqual(houseHoldConfigField?.hidden)
            expect.soft(header.enable_hiding, `Assert cms enable_hiding setting for HH main table column: ${header.uid} - ${header.name}`).toEqual(houseHoldConfigField?.enable_hiding)
            expect.soft(header.enable_sorting, `Assert cms enable_sorting setting for HH main table column: ${header.uid} - ${header.name}`).toEqual(houseHoldConfigField?.enable_sorting)
            expect.soft(header.enable_filtering, `Assert cms enable_filtering setting for HH main table column: ${header.uid} - ${header.name}`).toEqual(houseHoldConfigField?.enable_filtering)
            expect.soft(header.default_order, `Assert cms default_order setting for HH main table column: ${header.uid} - ${header.name}`).toEqual(houseHoldConfigField?.default_order)
          })
        })

        await test.step(`Assert Household nested table dafault sorting in cms settings @2608`, async () => {
          expect.soft(nestedTable?.sort_header, 'Assert default sort column for HH table in cms settings').toEqual(HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig?.defaultSortingField.uid)
          expect.soft(nestedTable?.sort_direction.toUpperCase(), 'Assert default sort direction for for HH table in cms settings').toEqual(HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig?.defaultSortingOrder.toUpperCase())
        })

        await test.step(`Assert Household nested Table columns definition in cms settings @2608`, async () => {
          nestedHeaders?.forEach(nestedHeader =>{
            const houseHoldConfigNestedField = HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig?.fields
              .find(nestedField => nestedField.uid === nestedHeader.uid)
            expect.soft(nestedHeader.name, `Assert cms name setting for HH nested table column: ${nestedHeader.uid} - ${nestedHeader.name}`).toEqual(houseHoldConfigNestedField?.columnName)
            expect.soft(nestedHeader.frozen, `Assert cms frozen setting for HH nested table column: ${nestedHeader.uid} - ${nestedHeader.name}`).toEqual(houseHoldConfigNestedField?.frozen_direction)
            expect.soft(nestedHeader.hidden, `Assert cms hidden setting for HH nested table column: ${nestedHeader.uid} - ${nestedHeader.name}`).toEqual(houseHoldConfigNestedField?.hidden)
            expect.soft(nestedHeader.enable_hiding, `Assert cms enable_hiding setting for HH nested table column: ${nestedHeader.uid} - ${nestedHeader.name}`).toEqual(houseHoldConfigNestedField?.enable_hiding)
            expect.soft(nestedHeader.enable_sorting, `Assert cms enable_sorting setting for HH nested table column: ${nestedHeader.uid} - ${nestedHeader.name}`).toEqual(houseHoldConfigNestedField?.enable_sorting)
            expect.soft(nestedHeader.enable_filtering, `Assert cms enable_filtering setting for HH nested table column: ${nestedHeader.uid} - ${nestedHeader.name}`).toEqual(houseHoldConfigNestedField?.enable_filtering)
            expect.soft(nestedHeader.default_order, `Assert cms default_order setting for HH nested table column: ${nestedHeader.uid} - ${nestedHeader.name}`).toEqual(houseHoldConfigNestedField?.default_order)
          })
        })

        await test.step(`Assert Household Toolbar labels in cms settings  @2610`, async () => {
          expect.soft(selectedTab?.title, `Assert cms tab title for HH tab`).toEqual(HouseholdConfig.TITLE)

          toolbarLabels?.forEach(cmslabel =>{
            const houseHoldConfigLabel = HouseholdConfig.TOOLBAR_METRICS_CONFIG
              .find(label => label.uid === cmslabel.uid)
            expect.soft(cmslabel.value, `Assert cms tab name for HH tab: ${cmslabel.value}`).toEqual(houseHoldConfigLabel?.name)
          })
        })
      } 
      else throw new Error('Test failed: endpoint /monitoring/api/v1/cms/resources/clients has responseBody.data is undefined.')
    }) 

    test(`Check cms settings for Accounts tab match specification @2753, @2756`, async ({requestContext}) => {
      const api = new EWM3ApiHelpers(requestContext)
      const response = await api.makeRequest(clientEndpoint)
      await api.responseIs200(response)
      const responseBody: ClientResourcesCmsResponse | undefined = await response.json()
      const data = responseBody?.data

      if (data) {
        const selectedElement = data.find(item => item.uid === 'ap-clients')
        const selectedTab = selectedElement?.tabs.find(item => item.uid === 'ap-clients-ac')
        const selectedTable = selectedTab?.tables.find(item => item.uid === 'ap-clients-ac-ac-tbl')
        const headers = selectedTable?.headers
        const toolbarLabels = selectedTab?.labels

        await test.step(`Assert Accounts table dafault sorting in cms settings @2753`, async () => {
          expect(selectedTable?.sort_header, 'Assert default sort column for Accounts table in cms settings').toEqual(AccountsConfig.TABLE_DATA_CONFIG.defaultSortingField.uid)
          expect(selectedTable?.sort_direction.toUpperCase(), 'Assert default sort direction for for Accounts table in cms settings').toEqual(AccountsConfig.TABLE_DATA_CONFIG.defaultSortingOrder.toUpperCase())
        })

        await test.step(`Assert Account Table columns definition in cms settings @2753`, async () => {
          headers?.forEach(header =>{
            const accountConfigField = AccountsConfig.TABLE_DATA_CONFIG.fields
              .find(field => field.uid === header.uid)
            expect.soft(header.name, `Assert cms name setting for Accounts table column: ${header.uid} - ${header.name}`).toEqual(accountConfigField?.columnName)
            expect.soft(header.frozen, `Assert cms frozen setting for Accounts table column: ${header.uid} - ${header.name}`).toEqual(accountConfigField?.frozen_direction)
            expect.soft(header.hidden, `Assert cms hidden setting for Accounts table column: ${header.uid} - ${header.name}`).toEqual(accountConfigField?.hidden)
            expect.soft(header.enable_hiding, `Assert cms enable_hiding setting for Accounts table column: ${header.uid} - ${header.name}`).toEqual(accountConfigField?.enable_hiding)
            expect.soft(header.enable_sorting, `Assert cms enable_sorting setting for Accounts table column: ${header.uid} - ${header.name}`).toEqual(accountConfigField?.enable_sorting)
            expect.soft(header.enable_filtering, `Assert cms enable_filtering setting for Accounts table column: ${header.uid} - ${header.name}`).toEqual(accountConfigField?.enable_filtering)
            expect.soft(header.default_order, `Assert cms default_order setting for Accounts table column: ${header.uid} - ${header.name}`).toEqual(accountConfigField?.default_order)
          })
        })

        await test.step(`Assert Accounts Toolbar labels in cms settings @2756`, async () => {
          expect.soft(selectedTab?.title, `Assert cms tab title for Accounts tab`).toEqual(AccountsConfig.TITLE)

          toolbarLabels?.forEach(cmslabel =>{
            const accountConfigLabel = AccountsConfig.TOOLBAR_METRICS_CONFIG
              .find(label => label.uid === cmslabel.uid)
            expect.soft(cmslabel.value, `Assert cms tab name for Accounts tab: ${cmslabel.value}`).toEqual(accountConfigLabel?.name)
          })
        })
      } 
      else throw new Error('Test failed: endpoint /monitoring/api/v1/cms/resources/clients has responseBody.data is undefined.')
    })

    test.describe('Check Action links cms settings match specification', () => {
      const testParams = [
        {
          testText: 'Assert Household tab ActionLinks cms settings @3260, @3261, @3262, @3263, @3264, @3265, @3266, @3267, @3268, @3269, @3270', config: HouseholdConfig, apiTabId: 'ap-clients-hh', apiTableId: 'ap-clients-hh-hh-tbl', apiNestedTableId: 'ap-clients-hh-hh-tbl-acc-tbl'
        },
        {
          testText: 'Assert Accounts tab ActionLinks cms settings @3262, @3263, @3267, @3268, @3269, @3270', config: AccountsConfig, apiTabId: 'ap-clients-ac', apiTableId: 'ap-clients-ac-ac-tbl', apiNestedTableId: null
        },
      ]

      for (const tabWithLinks of testParams) {
        test(`${tabWithLinks.testText}`, async ({requestContext}) => {
          const api = new EWM3ApiHelpers(requestContext)
          const response = await api.makeRequest(clientEndpoint)
          await api.responseIs200(response)
          const responseBody: ClientResourcesCmsResponse | undefined = await response.json()
          const data = responseBody?.data
          const selectedElement = data?.find(item => item.uid === 'ap-clients')
          const selectedTab = selectedElement?.tabs.find(item => item.uid === tabWithLinks.apiTabId)
          const selectedTable = selectedTab?.tables.find(item => item.uid === tabWithLinks.apiTableId)
          const toolbarActionLinks = selectedTab?.action_links
          const mainTableRecordActionLinks = selectedTable?.row_actions
              
          let nestedTable: CmsTableElement | undefined 
          let nestedRecordActionLinks: LinkElement[] | undefined 
    
          if (tabWithLinks.apiNestedTableId) {
            nestedTable = selectedTable?.nested_table?.find(item => item.uid === tabWithLinks.apiNestedTableId)
            nestedRecordActionLinks = nestedTable?.row_actions
          }
    
          const apiLinks = {toolbar: toolbarActionLinks, mainTable: mainTableRecordActionLinks, nestedTable: nestedRecordActionLinks}
      
          const parameterMap = {
            BASE_URL_20: EWM3Config.BASE_URL_2_0?? '',
          }
    
          const currentTabElement = Object.keys(tabWithLinks.config.LINKS_CONFIG)
          currentTabElement.forEach((configLinkGroup) => {
            const currentApiLinkArray:LinkElement[] = apiLinks?.[configLinkGroup]
            const currentConfigLinkArray = tabWithLinks.config.LINKS_CONFIG?.[configLinkGroup]
                
            currentConfigLinkArray.forEach((configLink) => {
              const currentApiLink = currentApiLinkArray.find(apiLink => apiLink.uid === configLink.uid)
              expect.soft(configLink.title, `Assert cms settings "title" for tab: ${tabWithLinks.apiTabId} element: ${currentTabElement} link: ${configLink.uid} - ${configLink.title}`).toEqual(currentApiLink?.title)
              expect.soft(configLink.order, `Assert cms settings "order" for tab: ${tabWithLinks.apiTabId} element: ${currentTabElement} link: ${configLink.uid} - ${configLink.title}`).toEqual(currentApiLink?.order)
              const configAltUrl = GeneralUtils.constructResultString(configLink.url?? '', parameterMap)
              expect.soft(configAltUrl, `Assert cms settings "url" for tab: ${tabWithLinks.apiTabId} element: ${currentTabElement} link: ${configLink.uid} - ${configLink.title}`).toEqual(currentApiLink?.parameter[0].url)
              expect.soft(configLink.target, `Assert cms settings "target" for tab: ${tabWithLinks.apiTabId} element: ${currentTabElement} link: ${configLink.uid} - ${configLink.title}`).toEqual(currentApiLink?.parameter[0].target)
            })
          })
        })
      }
    })    
  })

  test.describe('401 fail. Token is expired', () => {
    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, async ({expiredTokenContext}) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

  test.describe('401 fail. No token passed', () => {
    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, async ({unauthorizedContext}) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })
})
import { test } from '../../../../../ewm3/fixtures/base-api-fixture'
import { test as syncedTest } from '../../../../../ewm3/fixtures/synced-api-fixture'
import { BaseApiEndpoint } from '../../../../../base/base-endpoint'
import { MonitoringV1 } from '../../../../../ewm3/api/monitoring/v1/endpoints'
import { EWM3ApiHelpers } from '../../../../../ewm3/api/api-helpers'
import { Widgets } from '../../../../../ewm3/api/widgets'
import { Widget, WidgetArrayResponse, WidgetResponse } from '../../../../../ewm3/api/monitoring/v1/types'
import { GeneralUtils } from '../../../../../utils/generalUtils'
import { expect } from '@playwright/test'

test.describe('Monitoring V1 tests. Group widget', {
  tag: ['@assetmark', '@stable', '@dashboard']
}, () => {

  const endpoints: BaseApiEndpoint[] = [
    new MonitoringV1().widget.getWidgetsByDashboardId,
    new MonitoringV1().widget.deleteWidgetsByDashboardId,
    new MonitoringV1().widget.getWidgetById,
    new MonitoringV1().widget.deleteWidgetById,
    new MonitoringV1().widget.postWidget,
    new MonitoringV1().widget.putWidget,
    new MonitoringV1().widget.addToDashboard,
  ]

  test.describe('404 not found', () => {
    const endpointsWithPathParam: BaseApiEndpoint[] = [
      new MonitoringV1().widget.getWidgetById,
      new MonitoringV1().widget.deleteWidgetById,
      /*
            other endpoints can't return 404 status code:
            new MonitoringV1().widget.addToDashboard - returns 500 status code
            new MonitoringV1().widget.getWidgetsByDashboardId - returns 200 status code
            new MonitoringV1().widget.deleteWidgetsByDashboardId - returns 200 status code
             */
    ]
    const invalidIdArray = ['77t957f5-null--1E+02-部落格-$USER', 'bda7f8c5-5d40-489c-91cd-9a4e183735ac']
    for (const invalidId of invalidIdArray) {
      for (const endpoint of endpointsWithPathParam) {
        test(`${endpoint.title}. Invalid id: ${invalidId}`, async ({requestContext}) => {
          const api = new EWM3ApiHelpers(requestContext)
          endpoint.pathParameters = invalidId
          const response = await api.makeRequest(endpoint)
          await api.responseIs404(response)
        })
      }
    }
  })

  test.describe('400 bad request', () => {
    const paramsArray = [
      // empty property cmsId or dashboardId is counting as valid
      // if you pass array instead of object and vice versa - backend returns 500 status code
      {
        endpoint: new MonitoringV1().widget.postWidget,
        body: {
          cmsId: '1',
        },
        errors: {
          'DashboardId': [
            'The DashboardId field is required.'
          ]
        }
      },
      {   endpoint: new MonitoringV1().widget.postWidget,
        body: {
          dashboardId: '1'
        },
        errors: {
          'CmsId': [
            'The CmsId field is required.'
          ]
        }
      },
      {   endpoint: new MonitoringV1().widget.postWidget,
        body: {},
        errors: {
          'CmsId': [
            'The CmsId field is required.'
          ],
          'DashboardId': [
            'The DashboardId field is required.'
          ]
        }
      },
      {
        endpoint: new MonitoringV1().widget.postWidget,
        body: {
          foo: 'boo'
        },
        errors: {
          'CmsId': [
            'The CmsId field is required.'
          ],
          'DashboardId': [
            'The DashboardId field is required.'
          ]
        }
      },
      {   endpoint: new MonitoringV1().widget.addToDashboard,
        body: [{
          cmsId: '1',
        }],
        errors: {
          '[0].DashboardId': [
            'The DashboardId field is required.'
          ]
        }
      },
      {
        endpoint: new MonitoringV1().widget.addToDashboard,
        body: [{
          dashboardId: '1'
        }],
        errors: {
          '[0].CmsId': [
            'The CmsId field is required.'
          ]
        }
      },
      {
        endpoint: new MonitoringV1().widget.addToDashboard,
        body: [{}],
        errors: {
          '[0].CmsId': [
            'The CmsId field is required.'
          ],
          '[0].DashboardId': [
            'The DashboardId field is required.'
          ]
        }
      },
      {
        endpoint: new MonitoringV1().widget.addToDashboard,
        body: [{
          foo: 'boo'
        }],
        errors: {
          '[0].CmsId': [
            'The CmsId field is required.'
          ],
          '[0].DashboardId': [
            'The DashboardId field is required.'
          ]
        }
      },
    ]
    for (const param of paramsArray) {
      test(`${param.endpoint.title}. Invalid body: ${JSON.stringify(param.body)}`, async ({requestContext}) => {
        const api = new EWM3ApiHelpers(requestContext)
        param.endpoint.body = param.body
        const response = await api.makeRequest(param.endpoint)
        await api.responseIs400(response)
        const responseBody = await response.json()
        expect(responseBody.errors, 'Assert error massage').toEqual(param.errors)
      })
    }
  })

  for (const endpoint of endpoints) {

    test.describe('401 fail. No token passed', () => {
      test(`${endpoint.title}`, async ({unauthorizedContext}) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    })

    test.describe('401 fail. Token is expired', () => {
      test(`${endpoint.title}`, async ({expiredTokenContext}) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    })
  }

})

syncedTest.describe('Monitoring V1 tests. Group widget', {
  tag: ['@assetmark', '@stable', '@dashboard']
}, () => {

  syncedTest.describe('200 success', () => {
    const widgetArray: Widget[] = new Widgets().getAllWidgets()
    for (const widget of widgetArray) {
      syncedTest(`Add single widget with /addtodashboard route: "${widget.cmsId}"`, async ({widgetsContext}) => {
        const api = new EWM3ApiHelpers(widgetsContext)
        const endpoints = new MonitoringV1()
        widget.dashboardId = await api.firstDashboardId()
        const widgetArray: Widget[] = [widget]

        endpoints.widget.addToDashboard.pathParameters = widget.dashboardId
        endpoints.widget.addToDashboard.body = widgetArray
        let response = await api.makeRequest(endpoints.widget.addToDashboard)
        const responseBody = await response.json()
        await api.responseIs201(response)
        api.validateJsonSchema(endpoints.widget.addToDashboard, responseBody)
        await api.arrayContainsData(responseBody.data, widgetArray)

        const getDashboard = endpoints.dashboard.getDashboard
        getDashboard.pathParameters = widgetArray[0].dashboardId
        response = await api.makeRequest(getDashboard)
        await api.responseIs200(response)
        await api.arrayContainsData((await response.json()).data.widgets, widgetArray)
      })
    }

    syncedTest('Add all existing widgets with /addtodashboard route', async ({widgetsContext}) => {
      const api = new EWM3ApiHelpers(widgetsContext)
      const endpoints = new MonitoringV1()
      const widgetArray = new Widgets(await api.firstDashboardId()).getAllWidgets()

      endpoints.widget.addToDashboard.pathParameters = widgetArray[0].dashboardId
      endpoints.widget.addToDashboard.body = widgetArray
      let response = await api.makeRequest(endpoints.widget.addToDashboard)
      const responseBody = await response.json()
      await api.responseIs201(response)
      api.validateJsonSchema(endpoints.widget.addToDashboard, responseBody)
      await api.arrayContainsData(responseBody.data, widgetArray)

      endpoints.dashboard.getDashboard.pathParameters = widgetArray[0].dashboardId
      response = await api.makeRequest(endpoints.dashboard.getDashboard)
      await api.responseIs200(response)
      await api.arrayContainsData((await response.json()).data.widgets, widgetArray)
    })

    syncedTest(`Update widget`, async ({widgetsContext}) => {
      const api = new EWM3ApiHelpers(widgetsContext)
      const endpoints = new MonitoringV1().widget
      const defaultWidgetState = new Widgets(await api.firstDashboardId()).getRandomWidget()
      endpoints.addToDashboard.body = [defaultWidgetState]
      endpoints.putWidget.body = defaultWidgetState
      endpoints.putWidget.body.coordinateX = GeneralUtils.getRandomNumber(3)
      endpoints.putWidget.body.coordinateY = GeneralUtils.getRandomNumber(10)
      endpoints.putWidget.body.width = GeneralUtils.getRandomNumber(3)
      endpoints.putWidget.body.height = GeneralUtils.getRandomNumber(4)

      await api.makeRequest(endpoints.addToDashboard)

      const response = await api.makeRequest(endpoints.putWidget)
      await api.responseIs200(response)
      const responseBody: WidgetResponse = await response.json()
      api.validateJsonSchema(endpoints.putWidget, responseBody)
      api.jsonsAreEqual(responseBody.data, endpoints.putWidget.body)
    })

    syncedTest(`Create widget`, async ({widgetsContext}) => {
      const api = new EWM3ApiHelpers(widgetsContext)
      const endpoint = new MonitoringV1().widget.postWidget
      endpoint.body = new Widgets(await api.firstDashboardId()).getRandomWidget()

      const response = await api.makeRequest(endpoint)
      await api.responseIs201(response)
      const responseBody: WidgetResponse = await response.json()
      api.validateJsonSchema(endpoint, responseBody)
      api.jsonsAreEqual(responseBody.data, endpoint.body)
    })

    syncedTest(`Get widget by id`, async ({widgetsContext}) => {
      const api = new EWM3ApiHelpers(widgetsContext)
      const endpoints = new MonitoringV1().widget

      endpoints.postWidget.body = new Widgets(await api.firstDashboardId()).getRandomWidget()
      await api.makeRequest(endpoints.postWidget)

      endpoints.getWidgetById.pathParameters = endpoints.postWidget.body.id

      const response = await api.makeRequest(endpoints.getWidgetById)
      await api.responseIs200(response)
      const responseBody: WidgetResponse = await response.json()
      api.validateJsonSchema(endpoints.getWidgetById, responseBody)
      api.jsonsAreEqual(responseBody.data, endpoints.postWidget.body)
    })

    syncedTest(`Delete widget by id`, async ({widgetsContext}) => {
      const api = new EWM3ApiHelpers(widgetsContext)
      const endpoints = new MonitoringV1().widget

      endpoints.postWidget.body = new Widgets(await api.firstDashboardId()).getRandomWidget()
      await api.makeRequest(endpoints.postWidget)

      endpoints.deleteWidgetById.pathParameters = endpoints.postWidget.body.id

      const response = await api.makeRequest(endpoints.deleteWidgetById)
      await api.responseIs200(response)
      const responseBody: WidgetResponse = await response.json()
      api.validateJsonSchema(endpoints.deleteWidgetById, responseBody)
    })

    syncedTest(`Get widget by dashboard id`, async ({widgetsContext}) => {
      const api = new EWM3ApiHelpers(widgetsContext)
      const endpoints = new MonitoringV1().widget

      const dashboardId = await api.firstDashboardId()
      endpoints.addToDashboard.body = new Widgets(dashboardId).getAllWidgets()
      endpoints.addToDashboard.pathParameters = endpoints.addToDashboard.body[0].dashboardId
      await api.makeRequest(endpoints.addToDashboard)

      endpoints.getWidgetsByDashboardId.pathParameters = dashboardId

      const response = await api.makeRequest(endpoints.getWidgetsByDashboardId)
      await api.responseIs200(response)
      const responseBody: WidgetArrayResponse = await response.json()
      api.validateJsonSchema(endpoints.getWidgetsByDashboardId, responseBody)
      await api.arrayContainsData(responseBody.data, endpoints.addToDashboard.body)
    })

    syncedTest(`Delete widget by dashboard id`, async ({widgetsContext}) => {
      const api = new EWM3ApiHelpers(widgetsContext)
      const endpoints = new MonitoringV1().widget

      const dashboardId = await api.firstDashboardId()
      endpoints.addToDashboard.body = new Widgets(dashboardId).getAllWidgets()
      endpoints.addToDashboard.pathParameters = endpoints.addToDashboard.body[0].dashboardId
      await api.makeRequest(endpoints.addToDashboard)

      endpoints.deleteWidgetsByDashboardId.pathParameters = dashboardId

      let response = await api.makeRequest(endpoints.deleteWidgetsByDashboardId)
      await api.responseIs200(response)
      let responseBody: WidgetArrayResponse = await response.json()
      api.validateJsonSchema(endpoints.deleteWidgetsByDashboardId, responseBody)

      endpoints.getWidgetsByDashboardId.pathParameters = dashboardId
      response = await api.makeRequest(endpoints.getWidgetsByDashboardId)
      await api.responseIs200(response)
      responseBody = await response.json()
      expect(responseBody.data, 'Assert that widgets are deleted').toEqual([])

    })
  })
  
})

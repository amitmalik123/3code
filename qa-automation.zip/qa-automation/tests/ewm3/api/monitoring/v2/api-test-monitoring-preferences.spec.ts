import { MonitoringV2 } from '../../../../../ewm3/api/monitoring/v2/endpoints'
import { EWM3ApiHelpers } from '../../../../../ewm3/api/api-helpers'
import { expect, test } from '../../../../../ewm3/fixtures/base-api-fixture'
import { BaseApiEndpoint } from '../../../../../base/base-endpoint'
import { generateColumnFilters, generateToolbarPreferences } from '../../../../../ewm3/api/monitoring/v2/test-data-generator'
import { ClientsSectionPreferences } from '../../../../../ewm3/api/monitoring/v2/types'

test.describe('Monitoring V2 tests @client-section', () => {
  const endpoints: BaseApiEndpoint[] = [
    new MonitoringV2().preferences.putPreferences(),
    new MonitoringV2().preferences.getPreferences(),
    new MonitoringV2().preferences.deletePreferences()
  ]

  test.describe('Households/Accounts - User saves toolbar preferences', () => {
    test.describe('200 success', () => {
      const uids = [
        'clients.households.toolbar',
        'clients.accounts.toolbar',
        'clients.households.household.toolbar',
        'clients.accounts.account.toolbar'
      ]
      for (const uid of uids) {
        test(`Verify for Individual and Common view saved metrics visibility, order and deleting for uid: '${uid}'`, 
          { tag: ['@2507', '@2508', '@2681', '@2509', '@2683', '@2510', '@2682', '@2511', '@2684'] }, async ({ requestContext }) => {
            const api = new EWM3ApiHelpers(requestContext)
            const endpoints = new MonitoringV2().preferences
            let putResponseBody: ClientsSectionPreferences

            await test.step('PUT Preferences', async () => {
              const endpoint = endpoints.putPreferences(generateToolbarPreferences(uid))
              const response = await api.makeRequest(endpoint)
              await api.responseIs200(response)
              putResponseBody = await response.json()
              api.validateJsonSchema(endpoint, await response.json()) 
            })
            await test.step('GET Preferences and compare with previously PUTted', async () => {
              const endpoint = endpoints.getPreferences(uid)
              const response = await api.makeRequest(endpoint)
              await api.responseIs200(response)
              const getResponseBody = await response.json()
              api.validateJsonSchema(endpoint, await response.json()) 
              expect(getResponseBody, 'Verify GET response body is equal to previously PUTted').toEqual(putResponseBody)
            })
            await test.step('DELETE preferences', async () => {
              const endpoint = endpoints.deletePreferences(uid)
              const response = await api.makeRequest(endpoint)
              await api.responseIs200(response)
              api.validateJsonSchema(endpoint, await response.json()) 
            })
          })
      }
    })
   
    for (const endpoint of endpoints) {
      test.describe('401 fail. No token passed', () => {
        test(`${endpoint.title}`, async ({ unauthorizedContext }) => {
          const api = new EWM3ApiHelpers(unauthorizedContext)
          const response = await api.makeRequest(endpoint)
          await api.responseIs401(response)
        })
      })

      test.describe('401 fail. Token is expired', () => {
        test(`${endpoint.title}`, async ({ expiredTokenContext }) => {
          const api = new EWM3ApiHelpers(expiredTokenContext)
          const response = await api.makeRequest(endpoint)
          await api.responseIs401(response)
        })
      })
    }
  })

  test.describe('Households/Accounts - Saved Filter preferences', () => {
    test.describe('200 success', () => {
      const uids = [
        'clients.households.table',
        'clients.accounts.table',
      ]
      for (const uid of uids) {
        test(`Verify saved Filter preferences for uid: '${uid}'`, 
          { tag: ['@2519', '@2520'] }, async ({ requestContext }) => {
            const api = new EWM3ApiHelpers(requestContext)
            const endpoints = new MonitoringV2().preferences
            let putResponseBody: ClientsSectionPreferences

            await test.step('PUT Filter Preferences', async () => {
              const endpoint = endpoints.putPreferences(generateColumnFilters(uid))
              const response = await api.makeRequest(endpoint)
              await api.responseIs200(response)
              putResponseBody = await response.json()
              api.validateJsonSchema(endpoint, await response.json()) 
            })
            await test.step('GET Filter Preferences and compare with previously PUTted', async () => {
              const endpoint = endpoints.getPreferences(uid)
              const response = await api.makeRequest(endpoint)
              await api.responseIs200(response)
              const getResponseBody = await response.json()
              api.validateJsonSchema(endpoint, await response.json()) 
              expect(getResponseBody, 'Verify GET response body is equal to previously PUTted').toEqual(putResponseBody)
            })
            await test.step('DELETE preferences', async () => {
              const endpoint = endpoints.deletePreferences(uid)
              const response = await api.makeRequest(endpoint)
              await api.responseIs200(response)
              api.validateJsonSchema(endpoint, await response.json()) 
            })
          })
      }
    })
   
  })

})
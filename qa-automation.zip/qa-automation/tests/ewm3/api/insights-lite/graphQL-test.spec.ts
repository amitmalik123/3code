import {test} from '../../../../ewm3/fixtures/base-api-fixture'
import {Queries} from '../../../../ewm3/api/insights-lite/queries'
import {EWM3ApiHelpers} from '../../../../ewm3/api/api-helpers'
import {InsightsLite} from '../../../../ewm3/api/insights-lite/endpoints'

test.describe('Advisor Insights Light - GraphQL Requests @insights-lite', () => {

  const graphQL = new Queries()

  const validQueryArray = [
    graphQL.totalMarketValue,
    graphQL.aopCAGR,
    graphQL.aopByLOB,
    graphQL.aopByLOB1DrillDown_byInvestManager,
    graphQL.aopByInvestmentManager,
    graphQL.aopIM1DrillDown_byProductName,
    graphQL.aopByInvestmentApproach,
    graphQL.aopIA1DrillDown_byInvestManager,
    graphQL.feesByHouseHoldSize,
    graphQL.feesType,
    graphQL.feesYoYGrowth,
    graphQL.feesTotalAdvisory,
    graphQL.feesTab1DrillDown_byHouseholdName,
    graphQL.netFlowsDetails,
    graphQL.inflowsOutflows,
    graphQL.inflowsOutflowsDrillDown,
    graphQL.flowsYoYGrowth,
    graphQL.dimAdvisorRepCode,
    graphQL.dimClientHousehold,
    graphQL.dimProdAllocationWeight,
    graphQL.dimProduct,
    graphQL.dimVirtualAccount,
    graphQL.dimDate
  ]

  test.describe('[200 - Success] Test Cases', () =>{
    for (const query of validQueryArray) {
      test(query.title, async ({insightsLiteContext})=>{
        const api = new EWM3ApiHelpers(insightsLiteContext)
        if(query.dependency){
          query.queryBody = await query.dependency(api)
        }
        const endpoint = new InsightsLite().graphQL(query)
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        api.validateJsonSchema(endpoint, await response.json())
      })
    }
  })

  //Negative test cases
  const invalidQueryReq = graphQL.invalidQuery
  const validQuery = graphQL.totalMarketValue

  test.describe('[200 - Success] No EWM Advisors Codes Test Case', () => {
    test(validQuery.title, async ({requestContext}) => {
      const api = new EWM3ApiHelpers(requestContext)
      const endpoint = new InsightsLite().graphQL(validQuery)
      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)
      api.validateJsonSchema(endpoint, await response.json())
    })
  })

  test.describe('[400 - Bad Request] Test Cases', () => {
    test(invalidQueryReq.title, async ({insightsLiteContext}) => {
      const api = new EWM3ApiHelpers(insightsLiteContext)
      const endpoint = new InsightsLite().graphQL(graphQL.invalidQuery)
      const response = await api.makeRequest(endpoint)
      await api.responseIs400(response)
    })
  })

  test.describe('401 fail. No token passed', () => {
    //Test skipped. It will be correct on the scope of https://assetmark.atlassian.net/browse/EWMINS-448
    test.skip(validQuery.title, async ({unauthorizedContext}) => {
      const api = new EWM3ApiHelpers(unauthorizedContext)
      const endpoint = new InsightsLite().graphQL(validQuery)
      const response = await api.makeRequest(endpoint)
      await api.responseIs401(response)
    })
    
  })

  test.describe('401 fail. Token is expired', () => {
    //Test skipped. It will be correct on the scope of https://assetmark.atlassian.net/browse/EWMINS-448
    test.skip(validQuery.title, async ({expiredTokenContext}) => {
      const api = new EWM3ApiHelpers(expiredTokenContext)
      const endpoint = new InsightsLite().graphQL(validQuery)
      const response = await api.makeRequest(endpoint)
      await api.responseIs401(response)
    })
  })
})
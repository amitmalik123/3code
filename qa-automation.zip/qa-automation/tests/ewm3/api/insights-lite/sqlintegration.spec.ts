import * as sql from 'mssql'
import * as fs from 'fs'
import {Queries} from '../../../../ewm3/api/insights-lite/queries'
import {test} from '../../../../ewm3/fixtures/base-api-fixture'
import { EWM3ApiHelpers } from '../../../../ewm3/api/api-helpers'
import { InsightsLite } from '../../../../ewm3/api/insights-lite/endpoints'

test.describe('Advisor Insights Light - GraphQL vs SQL Requests @insights-lite', () => {
  const query = new Queries()

  test(query.dummyTotalMarketValue.title, async ({insightsLiteContext})=>{

    const config = {
      user: 'sqlserveradmin',
      password: 'zkmpGh8O6!Asd@',
      server: 'sqltenant1dev.database.windows.net',
      port: 1433,
      database: 'tenant1',
      connectionTimeout: 30 * 1000, //30s
      requestTimeout: 60 * 1000, //60s
      options: {
        trustServerCertificate: true,
        encrypt: true,
      }
    }
    let pool
    try {
      pool = await sql.connect(config)
      console.log('Connected to the database')
    } catch (error) {
      console.error('Error connecting to the database:', error)
    }

    const result = await pool?.request().query(query.dummyTotalMarketValue.sql)
    /*
    if (result!.recordset.length > 0) {
      for (const row of result!.recordset) {
        await fs.promises.appendFile('playwright/.sql/results.json', JSON.stringify(row) + '\n', 'utf-8')
      }
    } else {
      console.log('No records')
    }*/

    const api = new EWM3ApiHelpers(insightsLiteContext)
    const endpoint = new InsightsLite().graphQL(query.dummyTotalMarketValue)
    const response = await api.makeRequest(endpoint)
    await api.responseIs200(response)
    api.validateJsonSchema(endpoint, await response.json())

    console.log(`The SQL response is ${JSON.stringify(result)}`)
    console.log(`The GraphQL response is ${JSON.stringify(await response.json())}`)
  })
})

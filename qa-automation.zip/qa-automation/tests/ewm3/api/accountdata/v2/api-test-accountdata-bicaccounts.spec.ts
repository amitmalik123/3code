import { test } from '../../../../../ewm3/fixtures/base-api-fixture'
import { EWM3ApiHelpers } from '../../../../../ewm3/api/api-helpers'
import { AccountDataV2 } from '../../../../../ewm3/api/accountdata/v2/endpoints'
import { BaseApiEndpoint } from '../../../../../base/base-endpoint'
import { v4 as uuid } from 'uuid'
import { ParametersGenerator } from '../../../../../ewm3/api/parametersGenerator'

test.describe('Account data V2 tests', () => {

  const endpointArray: BaseApiEndpoint[] = [
    new AccountDataV2().bicAccounts.bicAccount(),
  ]

  test.describe('200 success @bic', () => {

    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, async ({requestContext}) => {
        const api = new EWM3ApiHelpers(requestContext)
        endpoint.queryParameters = {
          sourceProductId: (await ParametersGenerator.strategyId(requestContext))[0].strategyId, 
          targetProductId: ((await ParametersGenerator.productAndGroupId(requestContext))[0].products[0].id),
        }
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        api.validateJsonSchema(endpoint, await response.json())
      })
    }
  })

  test.describe('401 fail. No token passed', () => { // ToDO: Unskip when endpoint will be ready
    for (const endpoint of endpointArray) {
      test.skip(`${endpoint.title}`, async ({unauthorizedContext}) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        endpoint.queryParameters = {
          sourceProductId: uuid(),
          targetProductId: uuid()
        }
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response) 
        await api.responseBodyIsEmpty(response) 
      })
    }
  })

  test.describe('401 fail. Token is expired', () => { // ToDO: Unskip when endpoint will be ready
    for (const endpoint of endpointArray) {
      test.skip(`${endpoint.title}`, async ({expiredTokenContext}) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        endpoint.queryParameters = {
          sourceProductId: uuid(),
          targetProductId: uuid()
        }
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response) 
        await api.responseBodyIsEmpty(response) 
      })
    }
  })
})

test.describe('Account V2 tests', () => {
  const endpointArray: BaseApiEndpoint[] = [
    new AccountDataV2().bicAccounts.bicAccount(),
  ]
  for (const endpoint of endpointArray) {
    test.describe('204 No Content', () => {
      test.skip(`${endpoint.title}`, async ({requestContext}) => { // ToDO: Unskip when endpoint will be ready
        const api = new EWM3ApiHelpers(requestContext)
        endpoint.queryParameters = {
          sourceProductId: uuid(),
          targetProductId: uuid()
        }
        const response = await api.makeRequest(endpoint)
        await api.responseIs204(response) 
      })
    })
  }
})

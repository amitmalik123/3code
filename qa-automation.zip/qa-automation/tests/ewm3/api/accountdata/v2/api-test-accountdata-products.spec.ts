import { test } from '../../../../../ewm3/fixtures/base-api-fixture'
import { EWM3ApiHelpers } from '../../../../../ewm3/api/api-helpers'
import { AccountDataV2 } from '../../../../../ewm3/api/accountdata/v2/endpoints'
import { BaseApiEndpoint } from '../../../../../base/base-endpoint'

test.describe('Account data V2 tests', () => {

  const endpointArray: BaseApiEndpoint[] = [
    new AccountDataV2().products.products(),
  ]

  test.describe('200 success @bic', () => {

    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, async ({requestContext}) => {
        const api = new EWM3ApiHelpers(requestContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        api.validateJsonSchema(endpoint, await response.json())
      })
    }
  })

  test.describe('401 fail. No token passed', () => { // ToDO: Unskip when endpoint will be ready
    for (const endpoint of endpointArray) {
      test.skip(`${endpoint.title}`, async ({unauthorizedContext}) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response) 
        await api.responseBodyIsEmpty(response) 
      })
    }
  })

  test.describe('401 fail. Token is expired', () => { // ToDO: Unskip when endpoint will be ready
    for (const endpoint of endpointArray) {
      test.skip(`${endpoint.title}`, async ({expiredTokenContext}) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response) 
        await api.responseBodyIsEmpty(response) 
      })
    }
  })
})

import {test} from '../../../../../ewm3/fixtures/base-api-fixture'
import {BaseApiEndpoint} from '../../../../../base/base-endpoint'
import {EWM3ApiHelpers} from '../../../../../ewm3/api/api-helpers'
import {AccountDataV1} from '../../../../../ewm3/api/accountdata/v1/endpoints'
import { v4 as uuid } from 'uuid'
import {
  AccountsResponse,
  AdvisorMetricsResponse,
  ClientResponse
} from '../../../../../ewm3/api/accountdata/v1/types'
import {expect} from '@playwright/test'

test.describe('Account data V1 tests. Group clients', () => {

  const endpointArray: BaseApiEndpoint[] = [
    new AccountDataV1().advisorMetrics.getMetrics(),
  ]

  test.describe('200 success @client-section', () => {

    test(`Get advisor metrics`, async ({requestContext}) => {
      const endpoint = new AccountDataV1().clients.clientList()
      const api = new EWM3ApiHelpers(requestContext)
      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)
      api.validateJsonSchema(endpoint, await response.json())
    })

    //todo: we need more details about all metrics for Accounts tab depends on Account type: Accounts without sleeves, Accounts with sleeves, Sleeve account
    //as for now all 3 metrics: Pending Funds, Platform Assets, Number of Accounts don't match with the Account list in the table that provided by /accountdata/api/v1/accounts endpoint
    test.fixme(`Math validation for advisor metrics`, async ({requestContext}) => {
      const endpoint = new AccountDataV1()
      const api = new EWM3ApiHelpers(requestContext)
      const response = await api.makeRequest(endpoint.advisorMetrics.getMetrics())
      await api.responseIs200(response)
      const responseBody: AdvisorMetricsResponse = await response.json()
      await test.step(`Then: assert maths`, async () => {

        const clientsResponse = await api.makeRequest(endpoint.clients.clientList())
        await api.responseIs200(clientsResponse)
        const clientsResponseBody: ClientResponse = await clientsResponse.json()

        const accountsResponse = await api.makeRequest(endpoint.accounts.accountList())
        await api.responseIs200(accountsResponse)
        const accountsResponseBody: AccountsResponse = await accountsResponse.json()

        expect(responseBody.data.accounts).toEqual(accountsResponseBody.data.data?.length) 
        expect(responseBody.data.households).toEqual(clientsResponseBody.data.data?.length)
        //todo: need more details. How can we count pendingFunds
        // expect(responseBody.data.pendingFunds).toEqual(clientsResponseBody.data.data.reduce(
        //     (accumulator, client) => {
        //         return accumulator + client.pendingFunding;
        //     }, 0)
        // );
        expect(responseBody.data.platformAssets).toEqual(clientsResponseBody.data.data?.reduce(
          (accumulator, client) => {
            return accumulator + client.marketValue
          }, 0)
        )
      })
    })

  })

  test.describe('204 No Content', () => {

    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, { tag: ['@2528'] }, async ({requestContext}) => {
        const api = new EWM3ApiHelpers(requestContext)
        endpoint.queryParameters = {'advisors': [uuid()]}
        const response = await api.makeRequest(endpoint)
        await api.responseIs204(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

  test.describe('400 Bad request', () => {

  })

  test.describe('401 fail. No token passed @client-section', () => {

    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, async ({unauthorizedContext}) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

  //waiting for fix. As of now Returns 500 status code
  test.describe('401 fail. Token is expired @client-section', () => {

    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, async ({expiredTokenContext}) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })
})
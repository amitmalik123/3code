import {expect, test} from '../../../../../ewm3/fixtures/base-api-fixture'
import {BaseApiEndpoint} from '../../../../../base/base-endpoint'
import {EWM3ApiHelpers} from '../../../../../ewm3/api/api-helpers'
import {GeneralUtils} from '../../../../../utils/generalUtils'
import {AccountDataV1} from '../../../../../ewm3/api/accountdata/v1/endpoints'
import {
  ClientMetricResponse, ClientResponse
} from '../../../../../ewm3/api/accountdata/v1/types'
import { ParametersGenerator } from '../../../../../ewm3/api/parametersGenerator'
import { CSDbDataProvider } from '../../../../../ewm3/db-access/client-section/cs.db-data-provider'
import { CSClientsDbQueries } from '../../../../../ewm3/db-access/client-section/cs.clients-db-queries'
import { CSAccountsDbQueries } from '../../../../../ewm3/db-access/client-section/cs.accounts-db-queries'
import { EWM3Config } from '../../../../../ewm3/service-data/config'
import { ComparisonTools } from '../../../../../utils/comparison-tools'
import { CSDbInfoConfig } from '../../../../../ewm3/db-access/client-section/cs.base-db-queries'

test.describe('Account data V1 tests. Group clients @client-section', () => {

  const endpointArray: BaseApiEndpoint[] = [
    new AccountDataV1().clients.clientList(),
    new AccountDataV1().clients.metrics(),
  ]

  test.describe('200 success', () => {

    test(`Get client list. Empty body`, async ({requestContext}) => {
      const endpoint = new AccountDataV1().clients.clientList()
      const api = new EWM3ApiHelpers(requestContext)
      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)
      api.validateJsonSchema(endpoint, await response.json())
    })

    test(`Math validation for client list`, async ({requestContext}) => {
      const endpoint = new AccountDataV1().clients.clientList()
      const api = new EWM3ApiHelpers(requestContext)
      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)
      const responseBody: ClientResponse = await response.json()
      await test.step(`Then: assert maths`, async () => {

        responseBody.data.data?.forEach(data => {
          test.step(`Assert client: ${data.clientName}`, async () => {
            expect(data.numberOfAccounts, 'Assert number of accounts').toEqual(data.accounts?.length)
            const clientMarketValue = data.marketValue.toFixed(2)
            const accumulatedMarketValue = data.accounts?.reduce(
              (accumulator, account) => {
                return accumulator + account.marketValue
              }, 0
            ).toFixed(2)
            expect(clientMarketValue, 'Assert market value').toEqual(accumulatedMarketValue)
          })
        })
      })
    })

    /*
        As of now front end do not use pagination, filtering and sorting implement pagination and filters.
        We need to implement these tests later
        todo: add filters, sorting, pagination tests
         */

    test(`Get clients metrics`, async ({requestContext}) => {
      const endpoints = new AccountDataV1().clients
      const api = new EWM3ApiHelpers(requestContext)
      const responseClientList = await api.makeRequest(endpoints.clientList())
      await api.responseIs200(responseClientList)
      const responseBodyClientList: ClientResponse = await responseClientList.json()
      if (!responseBodyClientList.data.data) {
        throw new Error (`There is no Clients data in the response ${endpoints.clientList().route}`)
      }
      const randomIndex = GeneralUtils.getRandomNumber(responseBodyClientList.data.data.length)

      const accountId = responseBodyClientList.data.data[randomIndex].id

      const response = await api.makeRequest(endpoints.metrics(accountId))
      await api.responseIs200(response)
      const responseBody: ClientMetricResponse = await response.json()

      api.validateJsonSchema(endpoints.metrics(accountId), responseBody)

      await test.step(`Then: compare metrics and client list data`, async () => {
        //root client object assert
        expect(responseBody.data.id).toEqual(responseBodyClientList.data.data![randomIndex].id)
        expect(responseBody.data.name).toEqual(responseBodyClientList.data.data![randomIndex].clientName)
        expect(responseBody.data.applicationId).toEqual(responseBodyClientList.data.data![randomIndex].clientAplId)
        expect(responseBody.data.webId).toEqual(responseBodyClientList.data.data![randomIndex].clientWebId)
        expect(responseBody.data.portfolioValue).toEqual(responseBodyClientList.data.data![randomIndex].marketValue)
        expect(responseBody.data.accountsCount).toEqual(responseBodyClientList.data.data![randomIndex].numberOfAccounts)

        //client account list assert
        responseBody.data.accounts.forEach(account =>{
          const accountObjectFromList = responseBodyClientList.data.data![randomIndex].accounts!
            .find(data => data.id === account.id)
          expect(accountObjectFromList,
            'Expect that account object exists in client list response body')
            .toBeDefined()
          expect(account.bankAccountNumber).toEqual(accountObjectFromList!.bankAccountNumber)
          expect(account.applicationId).toEqual(accountObjectFromList!.applicationId)
          expect(account.title).toEqual(accountObjectFromList!.title)
        })
        expect(responseBody.data.accounts.length, 'Expect that number of accounts is the same')
          .toEqual(responseBodyClientList.data.data![randomIndex].accounts!.length)
      })
    })

    test(`Data exist for all Clients of a User with aggregation by AdvisorId @2387 @2537`, async ({requestContext}) => {
      const endpoint = new AccountDataV1().clients.clientList()
      const api = new EWM3ApiHelpers(requestContext)
      const dbQueries = new CSClientsDbQueries(CSDbInfoConfig.csDataBaseName)

      const initialAdvisorIdsArray: string[] = (await ParametersGenerator.advisorId(requestContext)).map(item => item.id)
      const  advisorIdsSet: string[][] = []

      // Check if the array is not empty
      if (initialAdvisorIdsArray.length === 0) {
        throw new Error('The List of Advisors is empty')
      }
      // 1st element in Set = 1st element of initialAdvisorIdsArray if it exists
      if (initialAdvisorIdsArray.length > 0) {
        advisorIdsSet.push([initialAdvisorIdsArray[0]])
      }
      // 2nd element in Set = 2nd element of initialAdvisorIdsArray if it exists
      if (initialAdvisorIdsArray.length > 1) {
        advisorIdsSet.push([initialAdvisorIdsArray[1]])
      }
      // 3rd element in Set = [1st element, 2nd element] if they both exist
      if (initialAdvisorIdsArray.length > 1) {
        advisorIdsSet.push([initialAdvisorIdsArray[0], initialAdvisorIdsArray[1]])
      }
      // 4th element in Set = all elements from initialAdvisorIdsArray
      if (initialAdvisorIdsArray.length > 2) {
        advisorIdsSet.push([...initialAdvisorIdsArray])
      }

      for (const advisorIdsArray of advisorIdsSet) {

        endpoint.queryParameters = {
          advisors:  advisorIdsArray
        }

        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        const responseBody: ClientResponse = await response.json()

        // Get advisorIDs array, then Map each advisor ID to a string enclosed in single quotes and then join the quoted advisor IDs into a single string with ', ' as the separator
        const advisorIds = advisorIdsArray.map(id => `'${id}'`).join(', ')

        const dbOutput = await dbQueries.returnAllClients(advisorIds)
        responseBody.data.data?.forEach(responseClientData => {
          const existingIndex = dbOutput.findIndex(dbClientData => dbClientData.organizationid === responseClientData.id && dbClientData.name === responseClientData.clientName)
          expect.soft(existingIndex > -1, `Assert client: ${responseClientData.clientName} exist in DB Response`).toBeTruthy()
        })
        const apiClientsTotal = responseBody.data.total
        const dbClientsTotal = dbOutput.length
        expect.soft(apiClientsTotal, `Assert total number of clients in api ${endpoint.route} match DB Response`).toEqual(dbClientsTotal)
      }

    })

    test.describe('Enpoint clients provide data that match DB', () => {
      const testParams = [
        {
          clientType: 'Client With Accounts', testId: '@2395, @6093, @6094, @6095, @6096, @6097', clientId: (advisorIds: string) => new CSClientsDbQueries(CSDbInfoConfig.csDataBaseName).returnClientWithAccounts(advisorIds)
        },
        {
          clientType: 'Client Without Accounts', testId: '@6087, @6093, @6094, @6095, @6096, @6097', clientId: (advisorIds: string) => new CSClientsDbQueries(CSDbInfoConfig.csDataBaseName).returnClientWithoutAccounts(advisorIds)
        },
        {
          clientType: 'Client With several closed Accounts', testId: '@6088, @6093, @6094, @6095, @6096, @6097', clientId: (advisorIds: string) => new CSClientsDbQueries(CSDbInfoConfig.csDataBaseName).returnClientWithClosedAccounts(advisorIds)
        },
        {
          clientType: 'Client With all closed Accounts', testId: '@6089, @6093, @6094, @6095, @6096, @6097', clientId: (advisorIds: string) => new CSClientsDbQueries(CSDbInfoConfig.csDataBaseName).returnClientWithOnlyClosedAccounts(advisorIds)
        },
        {
          clientType: 'Client With all active Accounts', testId: '@6090, @6093, @6094, @6095, @6096, @6097', clientId: (advisorIds: string) => new CSClientsDbQueries(CSDbInfoConfig.csDataBaseName).returnClientWithOnlyActiveAccounts(advisorIds)
        },
        {
          clientType: 'Client With Performance Indicators', testId: '@6091, @6093, @6094, @6095, @6096, @6097', clientId: (advisorIds: string) => new CSClientsDbQueries(CSDbInfoConfig.csDataBaseName).returnClientWithPerformanceIndicators(advisorIds)
        },
        {
          clientType: 'Client Without Performance Indicators', testId: '@6092, @6093, @6094, @6095, @6096, @6097', clientId: (advisorIds: string) => new CSClientsDbQueries(CSDbInfoConfig.csDataBaseName).returnClientWithoutPerformanceIndicators(advisorIds)
        },
      ]
  
      for (const client of testParams) {
        test(`Endpoint clients provide data that match DB for: ${client.clientType}`, {
          tag: [client.testId]
        }, async ({requestContext}) => {  
          const endpoint = new AccountDataV1().clients.clientList()
          const api = new EWM3ApiHelpers(requestContext)
          const dbDataProvider = new CSDbDataProvider()

          const advisorIdsArray: string[] = (await ParametersGenerator.advisorId(requestContext)).map(item => item.id)
          endpoint.queryParameters = {
            advisors:  advisorIdsArray
          }
  
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          const responseBody: ClientResponse = await response.json()

          const advisorIds = advisorIdsArray.map(id => `'${id}'`).join(', ')
          const dbClient = (await client.clientId(advisorIds))
          if (dbClient.length==0) {
            throw new Error(`Can't check response for api: ${endpoint.route} matches DB for Client type: ${client.clientType}. Such a Client is absent in the DB for user: ${EWM3Config.USERNAME_DEFAULT}`)
          }
          const dbClientId = dbClient[0].organizationid
          const dbClientData = await dbDataProvider.returnClientData(dbClientId)
          const apiClient = responseBody.data.data?.find(responseClientData => responseClientData.id === dbClientId)
          
          expect.soft(ComparisonTools.compareStrings(apiClient?.advisorIdentifier, dbClientData.advisorIdentifier), `Assert advisorIdentifier field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.advisorIdentifier}, DB val: ${dbClientData.advisorIdentifier}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiClient?.annualizedPerformance, dbClientData?.annualizedPerformance), `Assert annualizedPerformance field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.annualizedPerformance}, DB val: ${dbClientData?.annualizedPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiClient?.clientAplId, dbClientData.clientAplId), `Assert clientAplId field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.clientAplId}, DB val: ${dbClientData.clientAplId}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiClient?.clientName, dbClientData?.clientName), `Assert clientName field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.clientName}, DB val: ${dbClientData?.clientName}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiClient?.clientWebId, dbClientData.clientWebId), `Assert clientWebId field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.clientWebId}, DB val: ${dbClientData.clientWebId}`).toBeTruthy()
          expect.soft(apiClient?.id, `Assert id field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.id}, DB val: ${dbClientData.id}`).toEqual(dbClientData.id)
          expect.soft(ComparisonTools.compareNumbers(apiClient?.marketValue, dbClientData.marketValue), `Assert marketValue field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.marketValue}, DB val: ${dbClientData.marketValue}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiClient?.netInvestment, dbClientData.netInvestment), `Assert netInvestment field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.netInvestment}, DB val: ${dbClientData.netInvestment}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiClient?.numberOfAccounts, dbClientData.numberOfAccounts), `Assert numberOfAccounts field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.numberOfAccounts}, DB val: ${dbClientData.numberOfAccounts}`).toBeTruthy()
          expect.soft(apiClient?.webAccess, `Assert webAccess field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.webAccess}, DB val: ${dbClientData.webAccess}`).toEqual(dbClientData.webAccess)
          expect.soft(ComparisonTools.compareNumbers(apiClient?.ytdPerformance, dbClientData.ytdPerformance), `Assert ytdPerformance field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.ytdPerformance}, DB val: ${dbClientData.ytdPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiClient?.expectedAmount, dbClientData.expectedAmount), `Assert expectedAmount field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.expectedAmount}, DB val: ${dbClientData.expectedAmount}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiClient?.oneYearPerformance, dbClientData.oneYearPerformance), `Assert oneYearPerformance field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: $apiClient?.oneYearPerformance}, DB val: ${dbClientData.oneYearPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiClient?.threeYearPerformance, dbClientData.threeYearPerformance), `Assert threeYearPerformance field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.threeYearPerformance}, DB val: ${dbClientData.threeYearPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiClient?.fiveYearPerformance, dbClientData.fiveYearPerformance), `Assert fiveYearPerformance field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.fiveYearPerformance}, DB val: ${dbClientData.fiveYearPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiClient?.cumulativeReturn, dbClientData.cumulativeReturn), `Assert cumulativeReturn field in api ${endpoint.route} match DB Response. ClientId: ${apiClient?.id}, API val: ${apiClient?.cumulativeReturn}, DB val: ${dbClientData.cumulativeReturn}`).toBeTruthy()
        })

        test(`Endpoint clients return all Accounts for specific: ${client.clientType}`, {
          tag: '@6103'
        }, async ({requestContext}) => {  
          const endpoint = new AccountDataV1().clients.clientList()
          const api = new EWM3ApiHelpers(requestContext)
          const accountDbQueries = new CSAccountsDbQueries(CSDbInfoConfig.csDataBaseName)

          const advisorIdsArray: string[] = (await ParametersGenerator.advisorId(requestContext)).map(item => item.id)
          endpoint.queryParameters = {
            advisors:  advisorIdsArray
          }
  
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          const responseBody: ClientResponse = await response.json()

          const advisorIds = advisorIdsArray.map(id => `'${id}'`).join(', ')
          const dbClient = (await client.clientId(advisorIds))
          if (dbClient.length==0) {
            throw new Error(`Can't check response for api: ${endpoint.route} matches DB for Client type: ${client.clientType}. Such a Client is absent in the DB for user: ${EWM3Config.USERNAME_DEFAULT}`)
          }
          const dbClientId = dbClient[0].organizationid
          const apiClient = responseBody.data.data?.find(responseClientData => responseClientData.id === dbClientId)

          const dbOutput = await accountDbQueries.returnAllAccountsByClientId(dbClientId)
          apiClient?.accounts?.forEach(apiResponseAccountData => {
            const existingIndex = dbOutput.findIndex(dbAccountData => dbAccountData.virtualaccountid === apiResponseAccountData.id && dbAccountData.name === apiResponseAccountData.title)
            expect.soft(existingIndex > -1, `Assert account: ${apiResponseAccountData.title} exist in DB Response`).toBeTruthy()
          })
          
        })
      }
    })

    test.describe('Enpoint clients provide data for nested table that match DB', () => {
      const testParams = [
        {
          accountType: 'Not closed Account Without Sleeves', testId: '@2412, @6111, @6112, @6113, @6114, @6115', accountId: (advisorIds: string) => new CSAccountsDbQueries(CSDbInfoConfig.csDataBaseName).returnNotClosedAccountWithoutSleeves(advisorIds)
        },
        {
          accountType: 'AMRS Account', testId: '@3144, @6111, @6112, @6113, @6114, @6115', accountId: (advisorIds: string) => new CSAccountsDbQueries(CSDbInfoConfig.csDataBaseName).returnAMRSAccount(advisorIds)
        },
        {
          accountType: 'Terminated Account', testId: '@3143, @6111, @6112, @6113, @6114, @6115', accountId: (advisorIds: string) => new CSAccountsDbQueries(CSDbInfoConfig.csDataBaseName).returnTerminatedAccount(advisorIds)
        },
        {
          accountType: 'Account with Performance Indicators', testId: '@6104, @6111, @6112, @6113, @6114, @6115', accountId: (advisorIds: string) => new CSAccountsDbQueries(CSDbInfoConfig.csDataBaseName).returnAccountWithPerformanceIndicators(advisorIds)
        },
        {
          accountType: 'Account without Performance Indicators', testId: '@6105, @6111, @6112, @6113, @6114, @6115', accountId: (advisorIds: string) => new CSAccountsDbQueries(CSDbInfoConfig.csDataBaseName).returnAccountWithoutPerformanceIndicators(advisorIds)
        },
      ]
  
      for (const account of testParams) {
        test(`Endpoint clients provide data that match DB for nested table for: ${account.accountType}`, {
          tag: [account.testId]
        }, async ({requestContext}) => {  
          const endpoint = new AccountDataV1().clients.clientList()
          const api = new EWM3ApiHelpers(requestContext)
          const dbDataProvider = new CSDbDataProvider()

          const advisorIdsArray: string[] = (await ParametersGenerator.advisorId(requestContext)).map(item => item.id)
          endpoint.queryParameters = {
            advisors:  advisorIdsArray
          }
  
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          const responseBody: ClientResponse = await response.json()

          const advisorIds = advisorIdsArray.map(id => `'${id}'`).join(', ')

          const dbAccount = await account.accountId(advisorIds)
          if (dbAccount.length==0) {
            throw new Error(`Can't check response for api: ${endpoint.route} if nested Account data match DB for Account type: ${account.accountType}. Such an Account is absent in the DB for user: ${EWM3Config.USERNAME_DEFAULT}`)
          }
          const dbAccountId = dbAccount[0].virtualaccountid
          const dbClientId = (await dbDataProvider.accountsDbQueries.returnClientByAccountId(dbAccountId))[0].parentid
          const dbAccountData = await dbDataProvider.returnNestedAccountData(dbAccountId)
          const apiClient = responseBody.data.data?.find(responseClientData => responseClientData.id === dbClientId)
          const apiAccount = apiClient?.accounts?.find(responseAccountData => responseAccountData.id === dbAccountId)
          
          expect.soft(ComparisonTools.compareStrings(apiAccount?.id, dbAccountData.id), `Assert nested table - id field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.id}, DB val: ${dbAccountData.id}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.annualizedPerformance, dbAccountData?.annualizedPerformance), `Assert nested table - annualizedPerformance field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.annualizedPerformance}, DB val: ${dbAccountData?.annualizedPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.applicationId, dbAccountData.applicationId), `Assert nested table - applicationId field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.applicationId}, API val: ${apiAccount?.applicationId}, DB val: ${dbAccountData.applicationId}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.title, dbAccountData?.title), `Assert nested table - title field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.title}, DB val: ${dbAccountData?.title}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.bankAccountNumber, dbAccountData.bankAccountNumber), `Assert nested table - bankAccountNumber field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.bankAccountNumber}, DB val: ${dbAccountData.bankAccountNumber}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.status, dbAccountData.status), `Assert nested table - status field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.status}, DB val: ${dbAccountData.status}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.investmentProduct, dbAccountData.investmentProduct), `Assert nested table - investmentProduct field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.investmentProduct}, DB val: ${dbAccountData.investmentProduct}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.marketValue, dbAccountData.marketValue), `Assert nested table - marketValue field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.marketValue}, DB val: ${dbAccountData.marketValue}`).toBeTruthy()
          expect.soft(apiAccount?.alerts, `Assert nested table - alerts field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.alerts}, DB val: ${dbAccountData.alerts}`).toEqual(dbAccountData.alerts)
          expect.soft(ComparisonTools.compareDates(apiAccount?.inceptionDate, dbAccountData.inceptionDate), `Assert nested table - inceptionDate field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.inceptionDate}, DB val: ${dbAccountData.inceptionDate}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.ytdPerformance, dbAccountData.ytdPerformance), `Assert nested table - ytdPerformance field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.ytdPerformance}, DB val: ${dbAccountData.ytdPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.expectedAmount, dbAccountData.expectedAmount), `Assert nested table - expectedAmount field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.expectedAmount}, DB val: ${dbAccountData.expectedAmount}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.oneYearPerformance, dbAccountData.oneYearPerformance), `Assert nested table - oneYearPerformance field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: $apiClient?.oneYearPerformance}, DB val: ${dbAccountData.oneYearPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.threeYearPerformance, dbAccountData.threeYearPerformance), `Assert nested table - threeYearPerformance field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.threeYearPerformance}, DB val: ${dbAccountData.threeYearPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.fiveYearPerformance, dbAccountData.fiveYearPerformance), `Assert nested table - fiveYearPerformance field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.fiveYearPerformance}, DB val: ${dbAccountData.fiveYearPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.cumulativeReturn, dbAccountData.cumulativeReturn), `Assert nested table - cumulativeReturn field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.cumulativeReturn}, DB val: ${dbAccountData.cumulativeReturn}`).toBeTruthy()
        })
      }
    })
  })

  test.describe('400 Bad request', () => {

  })

  test.describe('401 fail. No token passed', () => {

    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, async ({unauthorizedContext}) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

  //waiting for fix. As of now Returns 500 status code
  test.describe('401 fail. Token is expired', () => {

    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, async ({expiredTokenContext}) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

  test.describe('404 Not Found', () => {

    for (const invalidId of ['77t957f5-null--1E+02-部落格-$USER', 'bda7f8c5-5d40-489c-91cd-9a4e183735ac']) {
      test(`Get account metrics. Invalid id: ${invalidId}`, { tag: ['@2529'] }, async ({requestContext}) => {
        const endpoints = new AccountDataV1().clients
        const api = new EWM3ApiHelpers(requestContext)

        const response = await api.makeRequest(endpoints.metrics(invalidId))
        await api.responseIs404(response)
        await api.responseBodyIsEmpty(response, '"Not Found!"')
      })
    }

  })
})
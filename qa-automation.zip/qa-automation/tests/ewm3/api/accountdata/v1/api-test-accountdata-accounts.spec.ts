import {expect, test} from '../../../../../ewm3/fixtures/base-api-fixture'
import {BaseApiEndpoint} from '../../../../../base/base-endpoint'
import {EWM3ApiHelpers} from '../../../../../ewm3/api/api-helpers'
import {GeneralUtils} from '../../../../../utils/generalUtils'
import {AccountDataV1} from '../../../../../ewm3/api/accountdata/v1/endpoints'
import {
  AccountMetricResponse,
  AccountsResponse
} from '../../../../../ewm3/api/accountdata/v1/types'
import { CSDbDataProvider } from '../../../../../ewm3/db-access/client-section/cs.db-data-provider'
import { ParametersGenerator } from '../../../../../ewm3/api/parametersGenerator'
import { CSAccountsDbQueries } from '../../../../../ewm3/db-access/client-section/cs.accounts-db-queries'
import { EWM3Config } from '../../../../../ewm3/service-data/config'
import { ComparisonTools } from '../../../../../utils/comparison-tools'
import { CSDbInfoConfig } from '../../../../../ewm3/db-access/client-section/cs.base-db-queries'

test.describe('Account data V1 tests. Group accounts @client-section', () => {

  const endpointArray: BaseApiEndpoint[] = [
    new AccountDataV1().accounts.accountList(),
    new AccountDataV1().accounts.metrics(),
  ]

  test.describe('200 success', () => {

    test(`Get account list. Empty body`, async ({requestContext}) => {
      const endpoint = new AccountDataV1().accounts.accountList()
      const api = new EWM3ApiHelpers(requestContext)
      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)
      api.validateJsonSchema(endpoint, await response.json())
    })

    /*
        As of now front end do not use pagination, filtering and sorting implement pagination and filters.
        We need to implement these tests later
        todo: add filters, sorting, pagination tests
         */

    test(`Get account metrics`, async ({requestContext}) => {
      const endpoints = new AccountDataV1().accounts
      const api = new EWM3ApiHelpers(requestContext)
      const responseAccountList = await api.makeRequest(endpoints.accountList())
      await api.responseIs200(responseAccountList)
      const responseBodyAccountList: AccountsResponse = await responseAccountList.json()
      if (!responseBodyAccountList.data.data) {
        throw new Error (`There is no Accounts data in the response ${endpoints.accountList().route}`)
      }
      const randomIndex = GeneralUtils.getRandomNumber(responseBodyAccountList.data.data.length)

      const accountId = responseBodyAccountList.data.data[randomIndex].id

      const response = await api.makeRequest(endpoints.metrics(accountId))
      await api.responseIs200(response)
      const responseBody: AccountMetricResponse = await response.json()

      api.validateJsonSchema(endpoints.metrics(accountId), responseBody)

      await test.step(`Then: compare metrics and account list data`, async () => {
        //root account object assert
        expect(responseBody.data.id).toEqual(responseBodyAccountList.data.data![randomIndex].id)
        expect(responseBody.data.title).toEqual(responseBodyAccountList.data.data![randomIndex].title)
        expect(responseBody.data.accountValue).toEqual(responseBodyAccountList.data.data![randomIndex].marketValue)
        expect(responseBody.data.applicationId).toEqual(responseBodyAccountList.data.data![randomIndex].applicationId)
        expect(responseBody.data.bankAccountNumber).toEqual(responseBodyAccountList.data.data![randomIndex].bankAccountNumber)

        //client object assert
        expect(responseBody.data.client.id).toEqual(responseBodyAccountList.data.data![randomIndex].clientId)
        expect(responseBody.data.client.applicationId).toEqual(responseBodyAccountList.data.data![randomIndex].clientAplId)
        expect(responseBody.data.client.name).toEqual(responseBodyAccountList.data.data![randomIndex].clientName)
        expect(responseBody.data.client.webId).toEqual(responseBodyAccountList.data.data![randomIndex].clientWebId)

        //client account list assert
        responseBody.data.client.accounts.forEach(account =>{
          const accountObjectFromList = responseBodyAccountList.data.data!
            .find(data => data.id === account.id)
            
          if (!accountObjectFromList) {
            throw new Error (`Account with accountId ${account.id} is absent in response for ${endpoints.accountList().route}`)
          }
          expect(accountObjectFromList,
            'Expect that account object exists in account list response body')
            .toBeDefined()
          expect(account.bankAccountNumber).toEqual(accountObjectFromList.bankAccountNumber)
          expect(account.applicationId).toEqual(accountObjectFromList.applicationId)
          expect(account.title).toEqual(accountObjectFromList.title)
        })
        expect(responseBody.data.client.accounts.length, 'Expect that number of accounts is the same')
          .toEqual(responseBodyAccountList.data.data!.filter(data =>
            data.clientId === responseBodyAccountList.data.data![randomIndex].clientId).length)
      })
    })

    test(`Data exist for all relevant Accounts of a User with aggregation by AdvisorId @2533, @2536`, async ({requestContext}) => {
      const endpoint = new AccountDataV1().accounts.accountList()
      const api = new EWM3ApiHelpers(requestContext)
      const dbDataProvider = new CSDbDataProvider()

      const initialAdvisorIdsArray: string[] = (await ParametersGenerator.advisorId(requestContext)).map(item => item.id)
      const  advisorIdsSet: string[][] = []

      // Check if the array is not empty
      if (initialAdvisorIdsArray.length === 0) {
        throw new Error('The List of Advisors is empty')
      }
      // 1st element in Set = 1st element of initialAdvisorIdsArray if it exists
      if (initialAdvisorIdsArray.length > 0) {
        advisorIdsSet.push([initialAdvisorIdsArray[0]])
      }
      // 2nd element in Set = 2nd element of initialAdvisorIdsArray if it exists
      if (initialAdvisorIdsArray.length > 1) {
        advisorIdsSet.push([initialAdvisorIdsArray[1]])
      }
      // 3rd element in Set = [1st element, 2nd element] if they both exist
      if (initialAdvisorIdsArray.length > 1) {
        advisorIdsSet.push([initialAdvisorIdsArray[0], initialAdvisorIdsArray[1]])
      }
      // 4th element in Set = all elements from initialAdvisorIdsArray
      if (initialAdvisorIdsArray.length > 2) {
        advisorIdsSet.push([...initialAdvisorIdsArray])
      }

      for (const advisorIdsArray of advisorIdsSet) {

        endpoint.queryParameters = {
          advisors:  advisorIdsArray
        }

        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        const responseBody: AccountsResponse = await response.json()

        // Get advisorIDs array, then Map each advisor ID to a string enclosed in single quotes and then join the quoted advisor IDs into a single string with ', ' as the separator
        const advisorIds = advisorIdsArray.map(id => `'${id}'`).join(', ')

        const dbOutput = await dbDataProvider.accountsDbQueries .returnAllAccounts(advisorIds)
        responseBody.data.data?.forEach(responseAccountData => {
          const existingIndex = dbOutput.findIndex(dbAccountData => dbAccountData.virtualaccountid === responseAccountData.id && dbAccountData.name === responseAccountData.title)
          expect.soft(existingIndex > -1, `Assert Account: ${responseAccountData.title} exist in DB Response`).toBeTruthy()
        })
        const apiAccountsTotal = responseBody.data.total
        const dbAccountsTotal = dbOutput.length
        expect.soft(apiAccountsTotal, `Assert total number of clients in api ${endpoint.route} match DB Response`).toEqual(dbAccountsTotal)
      }

    })

    test.describe('Enpoint accounts provide data that match DB', () => {
      const testParams = [
        {
          accountType: 'Not closed Account Without Sleeves', testId: '@2525, @2535, @2768, @2769, @2770, @2771, @2772', accountId: (advisorIds: string) => new CSAccountsDbQueries(CSDbInfoConfig.csDataBaseName).returnNotClosedAccountWithoutSleeves(advisorIds)
        },
        {
          accountType: 'AMRS Account', testId: '@2525, @6125, @2768, @2769, @2770, @2771, @2772', accountId: ( advisorIds: string) => new CSAccountsDbQueries(CSDbInfoConfig.csDataBaseName).returnAMRSAccount(advisorIds)
        },
        {
          accountType: 'Terminated Account', testId: '@2525, @6126, @2768, @2769, @2770, @2771, @2772', accountId: (advisorIds: string) => new CSAccountsDbQueries(CSDbInfoConfig.csDataBaseName).returnTerminatedAccount(advisorIds)
        },
        {
          accountType: 'Account with Performance Indicators', testId: '@2525, @6127, @2768, @2769, @2770, @2771, @2772', accountId: (advisorIds: string) => new CSAccountsDbQueries(CSDbInfoConfig.csDataBaseName).returnAccountWithPerformanceIndicators(advisorIds)
        },
        {
          accountType: 'Account without Performance Indicators', testId: '@2525, @6128, @2768, @2769, @2770, @2771, @2772', accountId: (advisorIds: string) => new CSAccountsDbQueries(CSDbInfoConfig.csDataBaseName).returnAccountWithoutPerformanceIndicators(advisorIds)
        },
      ]
  
      for (const account of testParams) {
        test(`Endpoint accounts provide data that match DB for: ${account.accountType}`, {
          tag: [account.testId]
        }, async ({requestContext}) => {  
          const endpoint = new AccountDataV1().accounts.accountList()
          const api = new EWM3ApiHelpers(requestContext)
          const dbDataProvider = new CSDbDataProvider()

          const advisorIdsArray: string[] = (await ParametersGenerator.advisorId(requestContext)).map(item => item.id)
          endpoint.queryParameters = {
            advisors:  advisorIdsArray
          }
  
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          const responseBody: AccountsResponse = await response.json()

          const advisorIds = advisorIdsArray.map(id => `'${id}'`).join(', ')
          const dbAccount = (await account.accountId(advisorIds))
          if (dbAccount.length==0) {
            throw new Error(`Can't check response for api: ${endpoint.route} matches DB for Account type: ${account.accountType}. Such an Account is absent in the DB for user: ${EWM3Config.USERNAME_DEFAULT}`)
          }
          const dbAccountId = dbAccount[0].virtualaccountid
          const dbAccountData = await dbDataProvider.returnAccountData(dbAccountId)
          const apiAccount = responseBody.data.data?.find(responseAccountData => responseAccountData.id === dbAccountId)

          expect.soft(ComparisonTools.compareStrings(apiAccount?.id, dbAccountData.id), `Assert id field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.id}, DB val: ${dbAccountData.id}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.annualizedPerformance, dbAccountData?.annualizedPerformance), `Assert annualizedPerformance field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.annualizedPerformance}, DB val: ${dbAccountData?.annualizedPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.applicationId, dbAccountData.applicationId), `Assert applicationId field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.applicationId}, API val: ${apiAccount?.applicationId}, DB val: ${dbAccountData.applicationId}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.title, dbAccountData?.title), `Assert title field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.title}, DB val: ${dbAccountData?.title}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.bankAccountNumber, dbAccountData.bankAccountNumber), `Assert bankAccountNumber field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.bankAccountNumber}, DB val: ${dbAccountData.bankAccountNumber}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.status, dbAccountData.status), `Assert status field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.status}, DB val: ${dbAccountData.status}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.investmentProduct, dbAccountData.investmentProduct), `Assert investmentProduct field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.investmentProduct}, DB val: ${dbAccountData.investmentProduct}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.marketValue, dbAccountData.marketValue), `Assert marketValue field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.marketValue}, DB val: ${dbAccountData.marketValue}`).toBeTruthy()
          expect.soft(apiAccount?.alerts, `Assert alerts field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.alerts}, DB val: ${dbAccountData.alerts}`).toEqual(dbAccountData.alerts)
          expect.soft(ComparisonTools.compareDates(apiAccount?.inceptionDate, dbAccountData.inceptionDate), `Assert inceptionDate field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.inceptionDate}, DB val: ${dbAccountData.inceptionDate}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.ytdPerformance, dbAccountData.ytdPerformance), `Assert ytdPerformance field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.ytdPerformance}, DB val: ${dbAccountData.ytdPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.expectedAmount, dbAccountData.expectedAmount), `Assert expectedAmount field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.expectedAmount}, DB val: ${dbAccountData.expectedAmount}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.oneYearPerformance, dbAccountData.oneYearPerformance), `Assert oneYearPerformance field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.oneYearPerformance}, DB val: ${dbAccountData.oneYearPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.threeYearPerformance, dbAccountData.threeYearPerformance), `Assert threeYearPerformance field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.threeYearPerformance}, DB val: ${dbAccountData.threeYearPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.fiveYearPerformance, dbAccountData.fiveYearPerformance), `Assert fiveYearPerformance field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.fiveYearPerformance}, DB val: ${dbAccountData.fiveYearPerformance}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.cumulativeReturn, dbAccountData.cumulativeReturn), `Assert cumulativeReturn field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.cumulativeReturn}, DB val: ${dbAccountData.cumulativeReturn}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.custodian, dbAccountData.custodian), `Assert custodian field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.custodian}, DB val: ${dbAccountData.custodian}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.registrationType, dbAccountData.registrationType), `Assert registrationType field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.registrationType}, DB val: ${dbAccountData.registrationType}`).toBeTruthy()
          expect.soft(ComparisonTools.compareNumbers(apiAccount?.netInvestment, dbAccountData.netInvestment), `Assert netInvestment field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.netInvestment}, DB val: ${dbAccountData.netInvestment}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.advisorIdentifier, dbAccountData.advisorIdentifier), `Assert advisorIdentifier field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.advisorIdentifier}, DB val: ${dbAccountData.advisorIdentifier}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.clientAplId, dbAccountData.clientAplId), `Assert clientAplId field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.clientAplId}, DB val: ${dbAccountData.clientAplId}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.clientName, dbAccountData?.clientName), `Assert clientName field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.clientName}, DB val: ${dbAccountData?.clientName}`).toBeTruthy()
          expect.soft(ComparisonTools.compareStrings(apiAccount?.clientWebId, dbAccountData.clientWebId), `Assert clientWebId field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.clientWebId}, DB val: ${dbAccountData.clientWebId}`).toBeTruthy()
          expect.soft(apiAccount?.clientId, `Assert clientId field in api ${endpoint.route} match DB Response. AccountId: ${apiAccount?.id}, API val: ${apiAccount?.clientId}, DB val: ${dbAccountData.clientId}`).toEqual(dbAccountData.clientId)
        })
      }
    })
  })

  test.describe('400 Bad request', () => {

  })

  test.describe('401 fail. No token passed', () => {

    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, async ({unauthorizedContext}) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

  //waiting for fix. As of now Returns 500 status code
  test.describe('401 fail. Token is expired', () => {

    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, async ({expiredTokenContext}) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

  test.describe('204 No Content', () => {

    for (const invalidId of ['77t957f5-null--1E+02-部落格-$USER', 'bda7f8c5-5d40-489c-91cd-9a4e183735ac']) {
      test(`Get account metrics. Invalid id: ${invalidId}`, {tag: '@2530'}, async ({requestContext}) => {
        const endpoints = new AccountDataV1().accounts
        const api = new EWM3ApiHelpers(requestContext)

        const response = await api.makeRequest(endpoints.metrics(invalidId))
        await api.responseIs204(response)
        await api.responseBodyIsEmpty(response)
      })
    }

    test(`Endpoint accounts doesn't return data for advisor_id of another user`, {
      tag: '@2541'
    }, async ({requestContext}) => {  
      const endpoint = new AccountDataV1().accounts.accountList()
      const api = new EWM3ApiHelpers(requestContext)
      const dbDataProvider = new CSDbDataProvider()

      const advisorIdsArray: string[] = (await ParametersGenerator.advisorId(requestContext)).map(item => item.id)
      const advisorIds = advisorIdsArray.map(id => `'${id}'`).join(', ')

      const advisorExternalId: string[] = [(await dbDataProvider.accountsDbQueries.returnExternalAdvisorByAdvisorsId(advisorIds))[0]?.organizationid]
      endpoint.queryParameters = {
        advisors:  advisorExternalId
      }

      const response = await api.makeRequest(endpoint)
      await api.responseIs204(response)
      await api.responseBodyIsEmpty(response)
    })

  })
})
import { EWM3ApiHelpers } from '../../../../../ewm3/api/api-helpers'
import { expect } from '@playwright/test'
import { GoalsV1 } from '../../../../../ewm3/api/goals/v1/endpoints'
import { GoalCreationRequest, GoalData, GoalParameters, GoalResponse, GoalType } from '../../../../../ewm3/api/goals/v1/types'
import { CSGoalDataProvider } from '../../../../../ewm3/api/goals/v1/cs.goal-data-provider'
import { ParametersGenerator } from '../../../../../ewm3/api/parametersGenerator'
import { ComparisonTools } from '../../../../../utils/comparison-tools'
import { test as syncedTest } from '../../../../../ewm3/fixtures/synced-api-fixture'
import { EWM3Config } from '../../../../../ewm3/service-data/config'
import { test } from '../../../../../ewm3/fixtures/base-api-fixture'

syncedTest.describe('Goals V1 tests. Create Goals', {
  tag: ['@client-section', '@stable']
}, () => {
  let advisorIds: string

  syncedTest.beforeEach(async ({requestContext}) => {
    const advisorIdsArray: string[] = (await ParametersGenerator.advisorId(requestContext)).map(item => item.id)

    if (advisorIdsArray.length === 0) {
      throw new Error (`Advisor Ids are absent for user: ${EWM3Config.USERNAMES_ARRAY[syncedTest.info().parallelIndex]}. Goal tests can not be run`)
    }

    advisorIds = advisorIdsArray.map(id => `'${id}'`).join(', ') 
  })

  syncedTest.describe('200 success', () => {

    syncedTest(`Create new Goal - Base scenario authorized user`, {
      tag: ['@5803']
    }, async ({requestContext}) => {
      const goalDataProvider = new CSGoalDataProvider()
      
      const goalData = await goalDataProvider.calculateGoalData({goalProgress:0.95, monthsFromTodayToStart: 5, goalDuration: 48, advisors: advisorIds})

      const requestBody: GoalCreationRequest = await goalDataProvider.returnRequestGoalBody(goalData)

      const api = new EWM3ApiHelpers(requestContext)
      const endpoint = new GoalsV1().goals.postCreateGoal(requestBody)
      const response = await api.makeRequest(endpoint)
      await api.responseIs201(response)
      const responseBody: GoalResponse = await response.json()

      api.validateJsonSchema(endpoint, responseBody)

      await goalDataProvider.deleteGoal(requestContext, responseBody.id)
    })

    const testParams = [
      {
        scenario: 'All data specified with more that 0 values. Target year greater than current year +1', testCaseIds: '@5819, @5820, @5821', goalParameters: (advisorIds: string):GoalParameters => ({goalProgress:0.95, monthsFromTodayToStart: 5, goalDuration: 48, advisors: advisorIds, periodicContribution: 300, numOfAcc: 3, goalType: GoalType.Retirement})
      },
      {
        scenario: 'Monthly contributions can equal zero', testCaseIds: '@5819, @5820, 5821', goalParameters: (advisorIds: string):GoalParameters => ({goalProgress: 0.95, monthsFromTodayToStart: 5, goalDuration: 48, advisors: advisorIds, periodicContribution: 0, numOfAcc: 2})
      },
      {
        scenario: 'Target year equal to current year +1', testCaseIds: '@5819, @5820, 5821', goalParameters: (advisorIds: string):GoalParameters => ({goalProgress: 1, monthsFromTodayToStart: 0, goalDuration: 12, advisors: advisorIds, periodicContribution: 0, goalType: GoalType.Retirement})
      },
      {
        scenario: 'Target year equal to current year +50', testCaseIds: '@5819, @5820, 5821', goalParameters: (advisorIds: string):GoalParameters => ({goalProgress: 1, monthsFromTodayToStart: 0, goalDuration: 600, advisors: advisorIds, periodicContribution: 0})
      },
      {
        scenario: 'Title maximum of 50 characters and special characters', testCaseIds: '@5814', goalParameters: (advisorIds: string):GoalParameters => ({goalProgress: 1, monthsFromTodayToStart: 0, goalDuration: 24, advisors: advisorIds, periodicContribution: 0, goalName: 'T 12345-6789-0--=! @#$%^ &*_+{}[]:";?,.%:,()!""№st'})
      },
      {
        scenario: 'Goal progress status is "On Track" when progress is 84.50% and one active account', testCaseIds: '@5518, @5521, @5917', goalParameters: (advisorIds: string):GoalParameters => ({goalProgress: 0.8451, monthsFromTodayToStart: 36, goalDuration: 120, advisors: advisorIds, periodicContribution: 0, numOfAcc: 1, goalProgressAutoadjustment: false})
      },
      {
        scenario: 'Goal progress status is "On Track" when progress is above 84.50% and 3 active account', testCaseIds: '@5518, @5521, @5918', goalParameters: (advisorIds: string):GoalParameters => ({goalProgress: 0.85, monthsFromTodayToStart: 36, goalDuration: 120, advisors: advisorIds, periodicContribution: 0, numOfAcc: 3, goalProgressAutoadjustment: false})
      },
      {
        scenario: 'Goal progress status is "At Risk" when progress is 84.49%', testCaseIds: '@5519, @5521, @5919', goalParameters: (advisorIds: string):GoalParameters => ({goalProgress: 0.8449, monthsFromTodayToStart: 36, goalDuration: 120, advisors: advisorIds, periodicContribution: 0, goalType: GoalType.Retirement, goalProgressAutoadjustment: false})
      },
      {
        scenario: 'Goal progress status is "At Risk" when progress is 69.50%', testCaseIds: '@5519, @5521, @5923', goalParameters: (advisorIds: string):GoalParameters => ({goalProgress: 0.6951, monthsFromTodayToStart: 36, goalDuration: 120, advisors: advisorIds, periodicContribution: 0, goalType: GoalType.Retirement, goalProgressAutoadjustment: false})
      },
      {
        scenario: 'Goal progress status is "Off Track" when progress is 69.49%', testCaseIds: '@5520, @5521', goalParameters: (advisorIds: string):GoalParameters => ({goalProgress: 0.69491, monthsFromTodayToStart: 36, goalDuration: 120, advisors: advisorIds, periodicContribution: 0, goalProgressAutoadjustment: false})
      },
    ]

    for (const positiveCase of testParams) {
      syncedTest(`Create new Goal for scenario: ${positiveCase.scenario}`, {
        tag: [positiveCase.testCaseIds]
      }, async ({requestContext}) => {
        const goalDataProvider = new CSGoalDataProvider()
        
        const goalCreationData = await goalDataProvider.createGoalAndAssertDb(requestContext, positiveCase.goalParameters(advisorIds)) 
        const goalData =  goalCreationData.goalData  
        const responseBody = goalCreationData.responseBody 
        const route = goalCreationData.route
        const calculatedResponse: GoalResponse = await goalDataProvider.returnResponseGoalBody(goalData)
  
        expect.soft(responseBody.name, `Assert Goal name in api response ${route} match initial request`).toEqual(calculatedResponse.name)
        expect.soft(responseBody.type, `Assert Goal type in api response ${route} match initial request`).toEqual(calculatedResponse.type)
        expect.soft(responseBody.status, `Assert Goal staus in api response ${route} match calculations`).toEqual(calculatedResponse.status)
  
        expect.soft(responseBody.planDetails.startDate, `Assert Goal planDetails.startDate in api response ${route} match calculations`).toEqual(calculatedResponse.planDetails.startDate)
        expect.soft(ComparisonTools.compareNumbersWithDeviation(responseBody.planDetails.startMarketValue, calculatedResponse.planDetails.startMarketValue, 0), `Assert Goal planDetails.startMarketValue in api response ${route} match calculations`).toBeTruthy()
        expect.soft(responseBody.planDetails.targetDate, `Assert Goal planDetails.targetDate in api response ${route} match calculations`).toEqual(calculatedResponse.planDetails.targetDate)
        expect.soft(ComparisonTools.compareNumbersWithDeviation(responseBody.planDetails.targetMarketValue, calculatedResponse.planDetails.targetMarketValue, 0), `Assert Goal planDetails.targetMarketValue in api response ${route} match calculations`).toBeTruthy()  
        expect.soft(ComparisonTools.compareNumbersWithDeviation(responseBody.planDetails.periodicContribution, calculatedResponse.planDetails.periodicContribution, 0), `Assert Goal planDetails.periodicContribution in api response ${route} match calculations`).toBeTruthy()
        expect.soft(responseBody.planDetails.periodicity, `Assert Goal planDetails.periodicity in api response ${route} match calculations`).toEqual(calculatedResponse.planDetails.periodicity)
        expect.soft(ComparisonTools.compareNumbersWithDeviation(responseBody.currentMarketValue, calculatedResponse.currentMarketValue, 0), `Assert Goal currentMarketValue in api response ${route} match calculations`).toBeTruthy()
        expect.soft(ComparisonTools.compareNumbersWithDeviation(responseBody.currentExpectedMarketValue, calculatedResponse.currentExpectedMarketValue, 0.02), `Assert Goal currentExpectedMarketValue in api response ${route} match calculations`).toBeTruthy()
        
        for (const goalAccountCalc of calculatedResponse.accounts){
          const accountFromResponse = responseBody.accounts.find(accResp => accResp.id === goalAccountCalc.id)
              
          if (!accountFromResponse) {
            throw new Error (`Account with accountId ${goalAccountCalc.id} is absent in response for ${route} in accounts structure`)
          }
  
          expect.soft(accountFromResponse.title, `Assert title for Goal's account ${accountFromResponse.id} in api response ${route} match calculations`).toEqual(goalAccountCalc.title) 
          expect.soft(ComparisonTools.compareStrings(accountFromResponse.bankAccountNumber, goalAccountCalc.bankAccountNumber), `Assert bankAccountNumber for Goal's account ${accountFromResponse.id} in api response ${route} match calculations`).toBeTruthy()    
          expect.soft(ComparisonTools.compareNumbersWithDeviation(accountFromResponse.marketValue, goalAccountCalc.marketValue, 0), `Assert marketValue for Goal's account ${accountFromResponse.id} in api response ${route} match calculations`).toBeTruthy()
          expect.soft(accountFromResponse.eligibleForGoalTypes, `Assert eligibleForGoalTypes for Goal's account ${accountFromResponse.id} in api response ${route} match calculations`).toEqual(goalAccountCalc.eligibleForGoalTypes) 
        }
        await goalDataProvider.deleteGoal(requestContext, responseBody.id)
      })
    }

    syncedTest(`Goal with householdId that already has other Goals should be created}`, {
      tag: ['@5818']
    }, async ({requestContext}) => {
      const goalDataProvider = new CSGoalDataProvider()
      const goalClientId = await goalDataProvider.goalsDbQueries.returnClientForGoalByAdvisorId(advisorIds, 2)

      if (!goalClientId) {
        throw new Error (`Can not find Client with Accounts appropriate for Goal creation for Advisors: ${advisorIds}`)
      }
      
      const firstGoalCreationData = await goalDataProvider.createGoalAndAssertDb(requestContext, {clientId: goalClientId, goalProgress:0.95, monthsFromTodayToStart: 5, goalDuration: 48, advisors: advisorIds, numOfAcc: 1})   
      const firstGoalId = firstGoalCreationData.responseBody.id

      const secondGoalCreationData = await goalDataProvider.createGoalAndAssertDb(requestContext, {clientId: goalClientId, goalProgress:0.90, monthsFromTodayToStart: 2, goalDuration: 48, advisors: advisorIds, numOfAcc: 1})   
      const secondGoalId = secondGoalCreationData.responseBody.id

      await goalDataProvider.deleteGoal(requestContext, firstGoalId)
      await goalDataProvider.deleteGoal(requestContext, secondGoalId)
    })
  })

  syncedTest.describe('400 bad request', () => {

    syncedTest(`Goal with Account already connected to other Goal can't be created`, {
      tag: ['@5815']
    }, async ({requestContext}) => {
      const goalDataProvider = new CSGoalDataProvider()
      const api = new EWM3ApiHelpers(requestContext)

      const goalClientId = await goalDataProvider.goalsDbQueries.returnClientForGoalByAdvisorId(advisorIds, 2)

      if (!goalClientId) {
        throw new Error (`Can not find Client with Accounts appropriate for Goal creation for Advisors: ${advisorIds}`)
      }
      
      const firstGoalCreationData = await goalDataProvider.createGoalAndAssertDb(requestContext, {clientId: goalClientId, goalProgress:0.95, monthsFromTodayToStart: 5, goalDuration: 48, advisors: advisorIds, numOfAcc: 1})   
      const firstGoalId = firstGoalCreationData.responseBody.id
      const firstGoalAccountId = firstGoalCreationData.goalData.accountIds[0]

      const goalData = await goalDataProvider.calculateGoalModifiedData(advisorIds,'accountIds', [firstGoalAccountId] )
      const calculatedRequest: GoalCreationRequest = await goalDataProvider.returnRequestGoalBody(goalData)
  
      const endpoint = new GoalsV1().goals.postCreateGoal(calculatedRequest)
      const response = await api.makeRequest(endpoint)
      await api.responseIs400(response)
      await api.responseBodyContainsText(response, 'One or more accounts are attached to the other goal')

      await goalDataProvider.deleteGoal(requestContext, firstGoalId)
    })
  })
})

test.describe('Goals V1 tests. Create Goals', {
  tag: ['@client-section', '@stable']
}, () => {

  let advisorIds: string

  test.beforeEach(async ({requestContext}) => {
    const advisorIdsArray: string[] = (await ParametersGenerator.advisorId(requestContext)).map(item => item.id)
    advisorIds = advisorIdsArray.map(id => `'${id}'`).join(', ') 
  })

  test.describe('401 fail. Token is expired', () => {
    test(`Endpoint POST goals`, {
      tag: ['@5805']
    }, async ({expiredTokenContext}) => {
      const api = new EWM3ApiHelpers(expiredTokenContext)
      const goalDataProvider = new CSGoalDataProvider()

      const goalData = await goalDataProvider.calculateGoalData({goalProgress:0.95, monthsFromTodayToStart: 5, goalDuration: 48, advisors: advisorIds})
      const calculatedRequest: GoalCreationRequest = await goalDataProvider.returnRequestGoalBody(goalData)

      const endpoint = new GoalsV1().goals.postCreateGoal(calculatedRequest)
      const response = await api.makeRequest(endpoint)
      await api.responseIs401(response)
      await api.responseBodyIsEmpty(response)
    })
  })

  test.describe('400 bad request', () => {
    const testParamsExternalAdvisor = [
      {
        scenario: 'External householdId could not be used for Goal creation', testCaseIds: '@5816', paramToChange: 'householdId', valueTochange: async (advisorIds: string) => await (new CSGoalDataProvider().goalsDbQueries.returnExternalClientByAdvisorsId(advisorIds))
      },
      {
        scenario: 'External account could not be used for Goal creation', testCaseIds: '@5810', paramToChange: 'accountIds', valueTochange: async (advisorIds: string) => [await (new CSGoalDataProvider().goalsDbQueries.returnExternalAccountByAdvisorsId(advisorIds))]
      }
    ]

    for (const negativeCase of testParamsExternalAdvisor) {
      test(`Try to create Goal for scenario: ${negativeCase.scenario}`, {
        tag: [negativeCase.testCaseIds]
      }, async ({requestContext}) => {
        const goalDataProvider = new CSGoalDataProvider()
        const api = new EWM3ApiHelpers(requestContext)
        
        const goalData = await goalDataProvider.calculateGoalModifiedData(advisorIds, negativeCase.paramToChange as keyof GoalData, await negativeCase.valueTochange(advisorIds) )
        const calculatedRequest: GoalCreationRequest = await goalDataProvider.returnRequestGoalBody(goalData)
    
        const endpoint = new GoalsV1().goals.postCreateGoal(calculatedRequest)
        const response = await api.makeRequest(endpoint)
        await api.responseIs400(response)
        await api.responseBodyContainsText(response, 'you have no permission to use it')
      })
    }

    const testParams = [
      {
        scenario: 'Not Active accounts could not be used for Goal creation', testCaseIds: '@5811', goalData: async (advisorIds: string) => await (new CSGoalDataProvider().calculateGoalDataClosedAccount(advisorIds)), errorMsg: 'accounts are not eligible'
      },
      {
        scenario: 'Goal without Accounts can not be created', testCaseIds: '@5812', goalData: async (advisorIds: string) => await (new CSGoalDataProvider().calculateGoalModifiedData(advisorIds, 'accountIds', [])), errorMsg: 'AccountIds must be a string or array type with a minimum length'
      },
      {
        scenario: 'Goal with empty AccountId can not be created', testCaseIds: '@5812', goalData: async (advisorIds: string) => await (new CSGoalDataProvider().calculateGoalModifiedData(advisorIds, 'accountIds', [''])), errorMsg: 'AccountIds must be a string or array type with a minimum length'
      },
      {
        scenario: 'Goal with empty title can not be created', testCaseIds: '@5813', goalData: async (advisorIds: string) => await (new CSGoalDataProvider().calculateGoalModifiedData(advisorIds, 'name', '')), errorMsg: 'Title must be a string with a minimum length of 1 and a maximum length of 50'
      },
      {
        scenario: 'Goal without householdId specified can not be created', testCaseIds: '@5817', goalData: async (advisorIds: string) => await (new CSGoalDataProvider().calculateGoalModifiedData(advisorIds, 'householdId', '')), errorMsg: 'HouseholdId field is required'
      },
    ]

    for (const negativeCase of testParams) {
      test(`Try to create Goal for scenario: ${negativeCase.scenario}`, {
        tag: [negativeCase.testCaseIds]
      }, async ({requestContext}) => {
        const goalDataProvider = new CSGoalDataProvider()
        const api = new EWM3ApiHelpers(requestContext)

        const goalData = await negativeCase.goalData(advisorIds)
        const calculatedRequest: GoalCreationRequest = await goalDataProvider.returnRequestGoalBody(goalData)
  
        const endpoint = new GoalsV1().goals.postCreateGoal(calculatedRequest)
        const response = await api.makeRequest(endpoint)
        await api.responseIs400(response)
        await api.responseBodyContainsText(response, negativeCase.errorMsg)
      })
    }
  })
})
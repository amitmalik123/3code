import { test } from '../../../../../ewm3/fixtures/base-api-fixture'
import { EWM3ApiHelpers } from '../../../../../ewm3/api/api-helpers'
import { BaseApiEndpoint } from '../../../../../base/base-endpoint'
import { ProposalV1 } from '../../../../../ewm3/api/proposal/v1/endpoints'
import { ParametersGenerator } from '../../../../../ewm3/api/parametersGenerator'
import { v4 as uuid } from 'uuid'

test.describe('Proposal account data V1 tests @bic', () => {

  const proposal = new ProposalV1()
  const endpointArray: BaseApiEndpoint[] = [
    proposal.accounts.accounts(),
    proposal.accounts.investmentChange(),
    proposal.accounts.suitabilityCheck(),
  ]

  test.describe('200 success', () => {
    test((new ProposalV1().accounts.accounts()).title, { tag: ['@5656'] }, async ({requestContext}) => {
      const endpoint = new ProposalV1().accounts.accounts()
      const api = new EWM3ApiHelpers(requestContext)
      endpoint.body = {
        'sourceProductId': (await ParametersGenerator.strategyId(requestContext))[0].strategyId, 
        'targetProductId': ((await ParametersGenerator.productAndGroupId(requestContext))[0].products[0].id),
        'advisorIds':  (await ParametersGenerator.advisorId(requestContext)).map(item => item.id)
      }
      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)
      api.validateJsonSchema(endpoint, await response.json())
    })

    test((new ProposalV1().accounts.suitabilityCheck()).title, { tag: ['@5926'] }, async ({requestContext}) => {
      const endpoint = new ProposalV1().accounts.suitabilityCheck()
      const api = new EWM3ApiHelpers(requestContext)
      endpoint.body = {
        'sourceProductId': (await ParametersGenerator.strategyId(requestContext))[0].strategyId, 
        'targetProductId': ((await ParametersGenerator.productAndGroupId(requestContext))[0].products[0].id),
        'accounts':  (await ParametersGenerator.accountsId(requestContext)).map(item => item.id)
      }
      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)
      api.validateJsonSchema(endpoint, await response.json())
    })

    test((new ProposalV1().accounts.investmentChange()).title, { tag: ['@5664'] }, async ({requestContext}) => {
      const endpoint = new ProposalV1().accounts.investmentChange()
      const api = new EWM3ApiHelpers(requestContext)
      endpoint.body = {
        'sourceProductId': (await ParametersGenerator.strategyId(requestContext))[0].strategyId, 
        'targetProductId': ((await ParametersGenerator.productAndGroupId(requestContext))[0].products[0].id),
        'accounts': (await ParametersGenerator.suitabilityCheckedAccountsId(requestContext)).map(item => item.accountId),
        'advisorIds':  (await ParametersGenerator.advisorId(requestContext)).map(item => item.id) 
      }
      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)
      api.validateJsonSchema(endpoint, await response.json()) 
    })
    
  })

  test.describe('401 fail. No token passed', () => {
    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, { tag: ['@5658', '@5928', '@5666'] }, async ({unauthorizedContext}) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

  test.describe('401 fail. Token is expired', () => {
    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, { tag: ['@5658', '@5928', '@5666'] }, async ({expiredTokenContext}) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })
})

test.describe('Accounts V1 tests. 204 No Content @bic', () => {
  test.describe('204 No Content', () => {

    test((new ProposalV1().accounts.accounts()).title, { tag: ['@5657'] }, async ({requestContext}) => { 
      const endpoint = new ProposalV1().accounts.accounts()
      const api = new EWM3ApiHelpers(requestContext)
      endpoint.body = {
        'sourceProductId': uuid(), 
        'targetProductId': uuid(),
        'advisorIds': [uuid()]
      }
      const response = await api.makeRequest(endpoint)
      await api.responseIs204(response) 
    })

    test((new ProposalV1().accounts.suitabilityCheck()).title, { tag: ['@5627'] }, async ({requestContext}) => { 
      const endpoint = new ProposalV1().accounts.suitabilityCheck()
      const api = new EWM3ApiHelpers(requestContext)
      endpoint.body = {
        'sourceProductId': uuid(), 
        'targetProductId': uuid(),
        'accounts': [uuid()]
      }
      const response = await api.makeRequest(endpoint)
      await api.responseIs204(response) 
    })

    test((new ProposalV1().accounts.investmentChange()).title, { tag: ['@5665'] }, async ({requestContext}) => {
      const endpoint = new ProposalV1().accounts.investmentChange()
      const api = new EWM3ApiHelpers(requestContext)
      endpoint.body = {
        'sourceProductId': uuid(),  
        'targetProductId': uuid(), 
        'accounts': [uuid()],
        'advisorIds':  [uuid()]
      }
      const response = await api.makeRequest(endpoint)
      await api.responseIs204(response)
    })
  })
})

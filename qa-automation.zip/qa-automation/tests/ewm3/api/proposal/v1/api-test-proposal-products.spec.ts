import { test } from '../../../../../ewm3/fixtures/base-api-fixture'
import { EWM3ApiHelpers } from '../../../../../ewm3/api/api-helpers'
import { BaseApiEndpoint } from '../../../../../base/base-endpoint'
import { ProposalV1 } from '../../../../../ewm3/api/proposal/v1/endpoints' 
import { ParametersGenerator } from '../../../../../ewm3/api/parametersGenerator'
import { v4 as uuid } from 'uuid'

test.describe('Proposal V1 tests @bic', () => {

  const endpointArray: BaseApiEndpoint[] = [
    new ProposalV1().products.products(),
    new ProposalV1().products.getProduct(),
    new ProposalV1().products.patchProduct(),
    new ProposalV1().products.deleteProduct(),  
  ]

  test.describe('200 success', () => {

    test((new ProposalV1().products.products()).title, { tag: ['@5105', '@5640'] }, async ({requestContext}) => {
      const endpoint = new ProposalV1().products.products()
      const api = new EWM3ApiHelpers(requestContext)
      endpoint.body = {'sourceProductId': (await ParametersGenerator.strategyId(requestContext))[0].strategyId , 'advisorIds': (await ParametersGenerator.advisorId(requestContext)).map(item => item.id)}
      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)
      api.validateJsonSchema(endpoint, await response.json()) 
    })

    test((new ProposalV1().products.getProduct()).title, { tag: ['@4994'] }, async ({requestContext}) => {
      const endpoint = new ProposalV1().products.getProduct()
      const api = new EWM3ApiHelpers(requestContext)
      endpoint.pathParameters = ((await ParametersGenerator.productAndGroupId(requestContext))[0].products[0].id)
      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)
      api.validateJsonSchema(endpoint, await response.json()) 
    })

    test((new ProposalV1().products.patchProduct()).title, { tag: ['@5102'] }, async ({requestContext}) => {
      const endpoint = new ProposalV1().products.patchProduct()
      const api = new EWM3ApiHelpers(requestContext)
      endpoint.pathParameters = (await ParametersGenerator.productAndGroupId(requestContext))[0].id
      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)
      await api.responseBodyIsEmpty(response)
    })

    test((new ProposalV1().products.deleteProduct()).title, { tag: ['@5453'] }, async ({requestContext}) => {
      const endpoint = new ProposalV1().products.deleteProduct()
      const api = new EWM3ApiHelpers(requestContext)
      endpoint.pathParameters = (await ParametersGenerator.productAndGroupId(requestContext))[0].id
      endpoint.queryParameters = { id: ((await ParametersGenerator.productAndGroupId(requestContext))[0].id) }
      const response = await api.makeRequest(endpoint)
      await api.responseIs200(response)
      await api.responseBodyIsEmpty(response)
    }) 
  })

  test.describe('401 fail. No token passed', () => {
    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, { tag: ['@4996', '@5103', '@5642', '@5457'] }, async ({unauthorizedContext}) => {
        const api = new EWM3ApiHelpers(unauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

  test.describe('401 fail. Token is expired', () => {
    for (const endpoint of endpointArray) {
      test(`${endpoint.title}`, { tag: ['@4996', '@5103', '@5642', '@5457'] }, async ({expiredTokenContext}) => {
        const api = new EWM3ApiHelpers(expiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

}) 

test.describe('Proposal products V1. 204 No Content tests @bic', () => { 
  test.describe('204 No Content', () => {
    test((new ProposalV1().products.products()).title, { tag: ['@5641'] }, async ({requestContext}) => {
      const endpoint = new ProposalV1().products.products()
      const api = new EWM3ApiHelpers(requestContext)
      endpoint.body = {'sourceProductId': uuid(), 'advisorIds': [uuid()]}
      const response = await api.makeRequest(endpoint)
      await api.responseIs204(response) 
    })

    test((new ProposalV1().products.getProduct()).title, { tag: ['@4995'] }, async ({requestContext}) => {
      const endpoint = new ProposalV1().products.getProduct()
      const api = new EWM3ApiHelpers(requestContext)
      endpoint.pathParameters = uuid()
      const response = await api.makeRequest(endpoint)
      await api.responseIs204(response) 
    })

  })
})

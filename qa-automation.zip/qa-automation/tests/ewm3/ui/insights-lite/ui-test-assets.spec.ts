import { EWM3Config } from '../../../../ewm3/service-data/config'
import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { InsightsAssetsPage } from '../../../../ewm3/ui/pages/insightsAssets-page'
import { InsightsLiteBaseTile } from '../../../../ewm3/ui/tiles/insights-lite/insights-base-tile'
import { InsightsConfig } from '../../../../ewm3/service-data/tile-config/insights.config'
import { DashboardConfig } from '../../../../ewm3/service-data/tile-config/dashboard.config'

test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

test.describe('Advisor Insights Light - Assets tab - UI Tests @stable', () => {
  test.describe('Common Assets Tile Tests - Basic widget functionalities', () => {

    test.beforeEach(async ({ insightsAssetsPage }) => {
      await insightsAssetsPage.openTileManager()
      await insightsAssetsPage.enableAllTilesTogglesOneByOne() 
      await insightsAssetsPage.closeTileManager()
    })
  
    for(const widget of InsightsConfig.assetsTilesInfoArray) {

      test(`Widget ${widget.name} is Visible`, async ({insightsAssetsPage}) => {
        const tile = new InsightsLiteBaseTile(insightsAssetsPage.page, widget.name)
        await tile.tileIsVisible()
      })
      test(`Resize ${widget.name} Widget`, async ({insightsAssetsPage}) => {
        const tile = new InsightsLiteBaseTile(insightsAssetsPage.page, widget.name)
        await tile.resize()

      })
      test(`Expand and Collapse ${widget.name} Widget`, async ({insightsAssetsPage}) => {
        const tile = new InsightsLiteBaseTile(insightsAssetsPage.page, widget.name)
        await tile.expandCollapse()
      })

      test(`Drag and Drop ${widget.name} Widget`, async ({insightsAssetsPage}) => {
        const tile = new InsightsLiteBaseTile(insightsAssetsPage.page, widget.name)
        const tileSize = await tile.tile.boundingBox()
        if (tileSize!.width > InsightsConfig.minimumTileSize) {
          await tile.decreaseSize()
        }
        await tile.dragAndDrop()
      })

      test(`Remove ${widget.name} Widget`, async ({insightsAssetsPage}) => {
        const tile = new InsightsLiteBaseTile(insightsAssetsPage.page, widget.name)
        await tile.removeTile()
      })
    }
  })

  test.describe('AOP Total Market Value', () => {
    test('Data Mapping Asset API -> UI',async({page})=>{
      const insightsAssetsPage = new InsightsAssetsPage(page)
      await insightsAssetsPage.goto()
      await page.waitForRequest(
        request => request.url().includes('/graphql'),
        { timeout: EWM3Config.ACTION_TIMEOUT_LONG })
        .then(async response => {
          // eslint-disable-next-line @typescript-eslint/ban-ts-comment
          // @ts-expect-error
          if (response.postData().match(/"operationName":"GET_YEARLY_MARKETVALUES"/g)) {
            await insightsAssetsPage.waitPageIsReady()
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            await insightsAssetsPage.aopTotalMktValue.assertDataMapping(await (await response.response()).json())
          }
        })
    })

    test('Visualization for account with more than 10 years of historical data',async({insightsAssetsPage})=>{
      await insightsAssetsPage.openTileManager()
      await insightsAssetsPage.enableAllTilesTogglesOneByOne()
      await insightsAssetsPage.closeTileManager()
      const xValueCount = await  insightsAssetsPage.aopTotalMktValue.xScaleValues.count()
      expect(xValueCount,'Visualization of last 10 years of his/hers data').toBeLessThanOrEqual(10)
    })
  })

  test.describe('Tiles details drilling down and returning back', () => {
    test.beforeEach(async ({ insightsAssetsPage }) => {
      await insightsAssetsPage.openTileManager()
      await insightsAssetsPage.enableAllTilesTogglesOneByOne() 
      await insightsAssetsPage.closeTileManager()
    })

    for(const widget  of InsightsConfig.assetsTilesInfoArray) {
      if(widget.tooltip){
        test(`Drilling down at "${widget.name}" Widget`,async({insightsAssetsPage})=>{
          const tile = new InsightsLiteBaseTile(insightsAssetsPage.page, widget.name)

          await test.step('Remove all tiles except the drilling one', async () => {
            for(const thisWidget of InsightsConfig.assetsTilesInfoArray) {
              if(widget !== thisWidget) {
                await new InsightsLiteBaseTile(insightsAssetsPage.page, thisWidget.name).removeTile()
              }
            }
          })
          await test.step('Drill down to all Chart Details one by one', async () => {
            await tile.tile.scrollIntoViewIfNeeded({ timeout: 2000 })
            await tile.drillDownToAllChartDetails(widget.tooltip)
          })
        })
      }
    }
  })

  test.describe('Manage tiles tests @stable', () => {
  
    test.describe('Close manage tiles menu tests', () => {
      test.beforeEach(async ({ insightsAssetsPage }) => {
        await insightsAssetsPage.openTileManager()
        await insightsAssetsPage.enableAllTilesTogglesOneByOne() 
        await expect(insightsAssetsPage.tileManager.manageTilesTitle, 'Validates CMS text received matches expectation').toHaveText('Select tiles to add or remove')
      })
      test('Manage Tiles. Clicking the "Close" button closes the tile menu', async ({ insightsAssetsPage }) => {
        await insightsAssetsPage.tileManager.closeManageTilesMenuButton.click()
        await expect(insightsAssetsPage.tileManager.manageTilesWholeModule, 'Expecting for side tile menu not to be visible').toBeHidden()
      })
      test('Manage Tiles. Click outside the tile menu has no effect and closes tile menu', async ({ insightsAssetsPage }) => {
        // Even if most items will not respond to a click with the tile menu open, items on the header still will respond
        await insightsAssetsPage.advisorInsightsTitle.click({force: true})
        await expect(insightsAssetsPage.allAdvisorIdsButton, 'Expecting that the click had no effect').toBeVisible()
        await expect(insightsAssetsPage.tileManager.manageTilesWholeModule, 'Expecting for side tile menu not to be visible').toBeHidden()
      })
      test('Manage Tiles. Click header profile menu still opens menu options with tile manager opened', async ({ insightsAssetsPage }) => {
        // Even if most items will not respond to a click with the tile menu open, items on the header still will respond
        await insightsAssetsPage.header.openProfileMenu()
        await insightsAssetsPage.header.validateDropdownItems(Object.values(DashboardConfig.userMenuDropdownItems))
        await expect(insightsAssetsPage.tileManager.manageTilesWholeModule, 'Expecting for side tile menu not to be visible').toBeHidden()
      })
      test('Manage Tiles. Pressing escape key closes tile menu', async ({ homePage, insightsAssetsPage }) => {
        await homePage.pressKey('Escape')
        await expect(insightsAssetsPage.tileManager.manageTilesWholeModule, 'Expecting for side tile menu not to be visible').toBeHidden()
      })
    })
  
    test.describe('Select tiles from tile menu', () => {
      const tileNames = InsightsConfig.assetsTilesInfoArray.map(item => item.name)
      test.beforeEach(async ({ insightsAssetsPage }) => {
        await expect(insightsAssetsPage.manageTilesMenuButton, 'Validating manage tiles button tooltip').toHaveAttribute('aria-label', 'Open Tile Manager', {ignoreCase: true})
        await insightsAssetsPage.openTileManager()
      })
      test('Manage Tiles. Clicking areas that are not tiles inside tile menu keeps it open', async ({ insightsAssetsPage }) => {
        await insightsAssetsPage.tileManager.manageTilesTitle.click()
        await expect(insightsAssetsPage.tileManager.openedManageTilesMenu, 'Expecting for side tile menu to be visible').toBeVisible()
      })
      test('Manage Tiles. Toggle all one by one (enabling)', async ({ insightsAssetsPage }) => {
        await insightsAssetsPage.disableAllTilesTogglesOneByOne()
        await insightsAssetsPage.toggleAllTilesOneByOne() 
        await insightsAssetsPage.validateTileVisibleInInsightsLight(true, tileNames)
      })
  
      test('Manage Tiles. Toggle all one by one (disabling)', async ({ insightsAssetsPage }) => {
        await insightsAssetsPage.enableAllTilesTogglesOneByOne()
        await insightsAssetsPage.toggleAllTilesOneByOne() 
        await insightsAssetsPage.validateTileVisibleInInsightsLight(false, tileNames)
        await expect(insightsAssetsPage.emptyDashboardMessage, 'Expecting empty dashboard message to appear').toContainText('This Dashboard is Empty', {useInnerText: true, ignoreCase: true})
      })
  
      for (const tile of tileNames) {
        test(`Manage Tiles. ${tile} shows when toggled, disappears when untoggled`, async ({ insightsAssetsPage }) => {
          await test.step(`Tile "${tile}" is enabled (checked)`, async () => {
            await insightsAssetsPage.checkToggleByName(true, tile)
            await insightsAssetsPage.validateTileVisibleInInsightsLight(true, tile)
          })
          await test.step(`Tile "${tile}" is disabled (unchecked)`, async () => {
            await insightsAssetsPage.checkToggleByName(false, tile)
            await insightsAssetsPage.validateTileVisibleInInsightsLight(false, tile)
          })
        })
      }
    })
  
    test.describe('Delete tiles in tab', () => {
      test.beforeEach(async ({ insightsAssetsPage }) => {
        await insightsAssetsPage.openTileManager()
        await insightsAssetsPage.enableAllTilesTogglesOneByOne() 
        await insightsAssetsPage.closeTileManager()
      })
      test('Manage Tiles. Should be able to delete any tile in tab', async ({ insightsAssetsPage }) => { 
        await test.step('Remove all tiles through tile action menu', async () => {
          for(const widget of InsightsConfig.assetsTilesInfoArray) {
            await new InsightsLiteBaseTile(insightsAssetsPage.page, widget.name).removeTile()
          }
        })
        await expect(insightsAssetsPage.emptyDashboardMessage, 'Expecting empty dashboard message to appear').toContainText('This Dashboard is Empty', {useInnerText: true, ignoreCase: true})
      })
    })
  
  })

})

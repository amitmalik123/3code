import { EWM3Config } from '../../../../ewm3/service-data/config'
import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { InsightsLiteBaseTile } from '../../../../ewm3/ui/tiles/insights-lite/insights-base-tile'
import { InsightsConfig } from '../../../../ewm3/service-data/tile-config/insights.config'
import { DashboardConfig } from '../../../../ewm3/service-data/tile-config/dashboard.config'

test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

test.describe('Advisor Insights Light - Fees tab - UI Tests @stable', () => {
  test.describe('Common Fees Tile Tests - Basic widget functionalities', () => {
    test.beforeEach(async ({ insightsFeesPage }) => {
      await insightsFeesPage.openTileManager()
      await insightsFeesPage.enableAllTilesTogglesOneByOne() 
      await insightsFeesPage.closeTileManager()
    })
    
    for(const widget of InsightsConfig.feesTilesInfoArray) {
      test(`Widget ${widget.name} is Visible`, async ({insightsFeesPage}) => {
        const tile = new InsightsLiteBaseTile(insightsFeesPage.page, widget.name)
        await tile.tileIsVisible()
      })
      test(`Resize ${widget.name} Widget`, async ({insightsFeesPage}) => {
        const tile = new InsightsLiteBaseTile(insightsFeesPage.page, widget.name)
        await tile.resize()
      })
      test(`Expand and Collapse ${widget.name} Widget`, async ({insightsFeesPage}) => {
        const tile = new InsightsLiteBaseTile(insightsFeesPage.page, widget.name)
        await tile.expandCollapse()
      })

      test(`Drag and Drop ${widget.name} Widget`, async ({insightsFeesPage}) => {
        const tile = new InsightsLiteBaseTile(insightsFeesPage.page, widget.name)
        const tileSize = await tile.tile.boundingBox()
        if (tileSize!.width > InsightsConfig.minimumTileSize) {
          await tile.decreaseSize()
        }
        await tile.dragAndDrop()
      })

      test(`Remove ${widget.name} Widget`, async ({insightsFeesPage}) => {
        const tile = new InsightsLiteBaseTile(insightsFeesPage.page, widget.name)
        await tile.removeTile()
      })
    }
  })

  test.describe('Tiles details drilling down and returning back', () => {
    test.beforeEach(async ({ insightsFeesPage }) => {
      await insightsFeesPage.openTileManager()
      await insightsFeesPage.enableAllTilesTogglesOneByOne() 
      await insightsFeesPage.closeTileManager()
    })

    for(const widget  of InsightsConfig.feesTilesInfoArray) {
      if(widget.tooltip){
        test(`Drilling down at "${widget.name}" Widget`,async({insightsFeesPage})=>{
          const tile = new InsightsLiteBaseTile(insightsFeesPage.page, widget.name)

          await test.step('Remove all tiles except the drilling one', async () => {
            for(const thisWidget of InsightsConfig.feesTilesInfoArray) {
              if(widget !== thisWidget) {
                await new InsightsLiteBaseTile(insightsFeesPage.page, thisWidget.name).removeTile()
              }
            }
          })
          await test.step('Drill down to all Chart Details one by one', async () => {
            await tile.tile.scrollIntoViewIfNeeded({ timeout: 2000 })
            await tile.drillDownToAllChartDetails(widget.tooltip)
          })
        })
      }
    }
  })

  test.describe('Manage tiles tests @stable', () => {
    test.describe('Close manage tiles menu tests', () => {
      test.beforeEach(async ({ insightsFeesPage }) => {
        await insightsFeesPage.openTileManager()
        await insightsFeesPage.enableAllTilesTogglesOneByOne() 
        await expect(insightsFeesPage.tileManager.manageTilesTitle, 'Validates CMS text received matches expectation').toHaveText('Select tiles to add or remove')
      })
      test('Manage Tiles. Clicking the "Close" button closes the tile menu', async ({ insightsFeesPage }) => {
        await insightsFeesPage.tileManager.closeManageTilesMenuButton.click()
        await expect(insightsFeesPage.tileManager.manageTilesWholeModule, 'Expecting for side tile menu not to be visible').toBeHidden()
      })
      test('Manage Tiles. Click outside the tile menu has no effect and closes tile menu', async ({ insightsFeesPage }) => {
        // Even if most items will not respond to a click with the tile menu open, items on the header still will respond
        await insightsFeesPage.advisorInsightsTitle.click({force: true})
        await expect(insightsFeesPage.allAdvisorIdsButton, 'Expecting that the click had no effect').toBeVisible()
        await expect(insightsFeesPage.tileManager.manageTilesWholeModule, 'Expecting for side tile menu not to be visible').toBeHidden()
      })
      test('Manage Tiles. Click header profile menu still opens menu options with tile manager opened', async ({ insightsFeesPage }) => {
        // Even if most items will not respond to a click with the tile menu open, items on the header still will respond
        await insightsFeesPage.header.openProfileMenu()
        await insightsFeesPage.header.validateDropdownItems(Object.values(DashboardConfig.userMenuDropdownItems))
        await expect(insightsFeesPage.tileManager.manageTilesWholeModule, 'Expecting for side tile menu not to be visible').toBeHidden()
      })
      test('Manage Tiles. Pressing escape key closes tile menu', async ({ homePage, insightsFeesPage }) => {
        await homePage.pressKey('Escape')
        await expect(insightsFeesPage.tileManager.manageTilesWholeModule, 'Expecting for side tile menu not to be visible').toBeHidden()
      })
    })
  
    test.describe('Select tiles from tile menu', () => {
      const tileNames = InsightsConfig.feesTilesInfoArray.map(item => item.name)
      test.beforeEach(async ({ insightsFeesPage }) => {
        await expect(insightsFeesPage.manageTilesMenuButton, 'Validating manage tiles button tooltip').toHaveAttribute('aria-label', 'Open Tile Manager', {ignoreCase: true})
        await insightsFeesPage.openTileManager()
      })
      test('Manage Tiles. Clicking areas that are not tiles inside tile menu keeps it open', async ({ insightsFeesPage }) => {
        await insightsFeesPage.tileManager.manageTilesTitle.click()
        await expect(insightsFeesPage.tileManager.openedManageTilesMenu, 'Expecting for side tile menu to be visible').toBeVisible()
      })
      test('Manage Tiles. Toggle all one by one (enabling)', async ({ insightsFeesPage }) => {
        await insightsFeesPage.disableAllTilesTogglesOneByOne()
        await insightsFeesPage.toggleAllTilesOneByOne() 
        await insightsFeesPage.validateTileVisibleInInsightsLight(true, tileNames)
      })
  
      test('Manage Tiles. Toggle all one by one (disabling)', async ({ insightsFeesPage }) => {
        await insightsFeesPage.enableAllTilesTogglesOneByOne()
        await insightsFeesPage.toggleAllTilesOneByOne() 
        await insightsFeesPage.validateTileVisibleInInsightsLight(false, tileNames)
        await expect(insightsFeesPage.emptyDashboardMessage, 'Expecting empty dashboard message to appear').toContainText('This Dashboard is Empty', {useInnerText: true, ignoreCase: true})
      })
  
      for (const tile of tileNames) {
        test(`Manage Tiles. ${tile} shows when toggled, disappears when untoggled`, async ({ insightsFeesPage }) => {
          await test.step(`Tile "${tile}" is enabled (checked)`, async () => {
            await insightsFeesPage.checkToggleByName(true, tile)
            await insightsFeesPage.validateTileVisibleInInsightsLight(true, tile)
          })
          await test.step(`Tile "${tile}" is disabled (unchecked)`, async () => {
            await insightsFeesPage.checkToggleByName(false, tile)
            await insightsFeesPage.validateTileVisibleInInsightsLight(false, tile)
          })
        })
      }
    })
  
    test.describe('Delete tiles in tab', () => {
      test.beforeEach(async ({ insightsFeesPage }) => {
        await insightsFeesPage.openTileManager()
        await insightsFeesPage.enableAllTilesTogglesOneByOne() 
        await insightsFeesPage.closeTileManager()
      })
      test('Manage Tiles. Should be able to delete any tile in tab', async ({ insightsFeesPage }) => { // Skiping test until a defect with tiles titles will be fixed
        await test.step('Remove all tiles through tile action menu', async () => {
          for(const widget of InsightsConfig.feesTilesInfoArray) {
            await new InsightsLiteBaseTile(insightsFeesPage.page, widget.name).removeTile()
          }
        })
        await expect(insightsFeesPage.emptyDashboardMessage, 'Expecting empty dashboard message to appear').toContainText('This Dashboard is Empty', {useInnerText: true, ignoreCase: true})
      })
    })
  
  })

})


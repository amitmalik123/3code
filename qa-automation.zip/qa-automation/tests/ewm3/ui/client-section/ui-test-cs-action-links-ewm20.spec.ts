import {Page, expect} from '@playwright/test'
import {test} from '../../../../ewm3/fixtures/base-ui-fixture'
import {EWM3Config} from '../../../../ewm3/service-data/config'
import {HouseholdConfig} from '../../../../ewm3/service-data/client-section-configs/household.config'
import {AccountsConfig} from '../../../../ewm3/service-data/client-section-configs/accounts.config'
import {AccountsActionLinksFeature, MainTableActionLinksFeature, NestedAccountActionLinksFeature, ToolbarActionLinksFeature} from '../../../../ewm3/ui/features/action-links.feature'
import {BaseClientSectionPage} from '../../../../ewm3/ui/pages/base-client-section-page'
import { ClientSectionHouseholdPage } from '../../../../ewm3/ui/pages/client-section-household-page'
import { ClientSectionAccountsPage } from '../../../../ewm3/ui/pages/client-section-accounts-page'
import { ClientSectionIndividualHouseholdPage } from '../../../../ewm3/ui/pages/client-section-individual-household-page'
import { ClientSectionIndividualAccountPage } from '../../../../ewm3/ui/pages/client-section-individual-account-page'

test.describe('Client section. Action Links tests @stable', () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_ACTION_LINKS)})

  test.describe('Action links  ewm 2.0 in HH tab', () => {
    const testParams = [
      {
        tabName: 'Household tab', linksGroupName: 'Toolbar', testCaseIds: '@2561, @2739, @2740, @2741, @3577', config: HouseholdConfig.LINKS_CONFIG.toolbar, uiLinkClass: (page:Page, currentWebPage: BaseClientSectionPage) => new ToolbarActionLinksFeature(page, currentWebPage)
      },
      {
        tabName: 'Household tab', linksGroupName: 'Main Table', testCaseIds: '@2550, @2555, @2556, @2730, @2731, @2732',config: HouseholdConfig.LINKS_CONFIG.mainTable, uiLinkClass: (page:Page, currentWebPage: BaseClientSectionPage) => new MainTableActionLinksFeature(page, currentWebPage)
      },
      {
        tabName: 'Household tab', linksGroupName: 'Nested Table', testCaseIds: '@2551, @2557, @2559, @2734, ',config: HouseholdConfig.LINKS_CONFIG.nestedTable, uiLinkClass: (page:Page, currentWebPage: BaseClientSectionPage) => new NestedAccountActionLinksFeature(page, currentWebPage)
      },
    ]
    for (const linksGroup of testParams) {
      const linksFromConfig = linksGroup.config
      for (const linkItem of linksFromConfig) {
        test(`Check link correctness for: ${linksGroup.tabName} -> ${linksGroup.linksGroupName} element, item: ${linkItem.title}, TC Ids: ${linksGroup.testCaseIds}`, async ({page, houseHoldPage}) => {
          await houseHoldPage.pagination.switchRowsPerPage(50)
          await linksGroup.uiLinkClass(page, houseHoldPage)?.clickAndCompareConfigLinks(linkItem)
        })
      }
    }
  })

  test.describe('Action links  ewm 2.0 in Accounts tab', () => {
    const testParams = [
      {
        tabName: 'Accounts tab', linksGroupName: 'Toolbar', testCaseIds: '@2561, @2739, @2740, @2741, 3577', config: AccountsConfig.LINKS_CONFIG.toolbar, uiLinkClass: (page:Page, currentWebPage: BaseClientSectionPage) => new ToolbarActionLinksFeature(page, currentWebPage)
      },
      {
        tabName: 'Accounts tab', linksGroupName: 'Main Table', testCaseIds: '@3586, @2736, @2737, @2738, ',config: AccountsConfig.LINKS_CONFIG.mainTable, uiLinkClass: (page:Page, currentWebPage: BaseClientSectionPage) => new AccountsActionLinksFeature(page, currentWebPage)
      },
    ]
    for (const linksGroup of testParams) {
      const linksFromConfig = linksGroup.config
      for (const linkItem of linksFromConfig) {
        test(`Check link correctness for: ${linksGroup.tabName} -> ${linksGroup.linksGroupName} element, item: ${linkItem.title}, TC Ids: ${linksGroup.testCaseIds}`, async ({page, accountsPage}) => {
          await accountsPage.pagination.switchRowsPerPage(50)
          await linksGroup.uiLinkClass(page, accountsPage)?.clickAndCompareConfigLinks(linkItem)
        })
      }
    }
  })

  test.describe('Action links menu is closed by clicking outside', () => {
    const testParams = [
      {
        tabName: 'Household tab', linksGroupName: 'Toolbar', testCaseIds: '@2563', uiLinkClass: (page:Page, currentWebPage: BaseClientSectionPage) => new ToolbarActionLinksFeature(page, currentWebPage), currentWebPage: (page:Page) => new ClientSectionHouseholdPage(page)
      },
      {
        tabName: 'Household tab', linksGroupName: 'Main Table', testCaseIds: '@2554', uiLinkClass: (page:Page, currentWebPage: BaseClientSectionPage) => new MainTableActionLinksFeature(page, currentWebPage), currentWebPage: (page:Page) => new ClientSectionHouseholdPage(page)
      },
      {
        tabName: 'Household tab', linksGroupName: 'Nested Table', testCaseIds: '@2554', uiLinkClass: (page:Page, currentWebPage: BaseClientSectionPage) => new NestedAccountActionLinksFeature(page, currentWebPage), currentWebPage: (page:Page) => new ClientSectionHouseholdPage(page)
      },
      {
        tabName: 'Accounts tab', linksGroupName: 'Toolbar', testCaseIds: '@2563', uiLinkClass: (page:Page, currentWebPage: BaseClientSectionPage) => new ToolbarActionLinksFeature(page, currentWebPage), currentWebPage: (page:Page) => new ClientSectionAccountsPage(page)
      },
      {
        tabName: 'Accounts tab', linksGroupName: 'Main Table', testCaseIds: '@2554', uiLinkClass: (page:Page, currentWebPage: BaseClientSectionPage) => new AccountsActionLinksFeature(page, currentWebPage), currentWebPage: (page:Page) => new ClientSectionAccountsPage(page)
      },
      {
        tabName: 'Individual HH', linksGroupName: 'Toolbar', testCaseIds: '@2563', uiLinkClass: (page:Page, currentWebPage: BaseClientSectionPage) => new ToolbarActionLinksFeature(page, currentWebPage), currentWebPage: (page:Page) => new ClientSectionIndividualHouseholdPage(page)
      },
      {
        tabName: 'Individual Account', linksGroupName: 'Toolbar', testCaseIds: '@2563', uiLinkClass: (page:Page, currentWebPage: BaseClientSectionPage) => new ToolbarActionLinksFeature(page, currentWebPage), currentWebPage: (page:Page) => new ClientSectionIndividualAccountPage(page)
      },
    ]
    for (const linksGroup of testParams) {
      test(`Action links menu is closed by clicking outside for: ${linksGroup.tabName} -> ${linksGroup.linksGroupName} element, TC Ids: ${linksGroup.testCaseIds}`, async ({page, houseHoldPage, accountsPage}) => {
        const currentPage = linksGroup.currentWebPage(page)
        const currentLinkGroup = linksGroup.uiLinkClass(page, currentPage)

        if (currentPage && currentLinkGroup) {
          await currentPage.goto()
          await currentPage.waitPageIsReady()
          await linksGroup.uiLinkClass(page, currentPage)?.clickOnActionButton()
          await currentPage.footer.clickAssetMarkLogo()
          await expect(currentLinkGroup.locators.actionMenu).toBeHidden()
        } else {
          console.error('Current page is undefined for links group:', linksGroup.tabName)
        }
      })
    }
  })
})


import {test} from '../../../../ewm3/fixtures/base-ui-fixture'
import {EWM3Config} from '../../../../ewm3/service-data/config'
import {SearchTrigger} from '../../../../ewm3/ui/features/search.feature'
import {PageSwitchTrigger} from '../../../../ewm3/ui/features/pagination.feature'
import {TableRow} from '../../../../ewm3/ui/features/table.feature'
import {SortingOrder} from '../../../../ewm3/ui/features/sorting.feature'
import {AccountsConfig} from '../../../../ewm3/service-data/client-section-configs/accounts.config'
import {ClientSectionAccountsPage} from '../../../../ewm3/ui/pages/client-section-accounts-page'
import { faker } from '@faker-js/faker'
import {expect} from '@playwright/test'
import { FewAccountsMock } from '../../../../ewm3/ui/mocks/accounts-list-few-clients-mock'
import { LongAccountsMock } from '../../../../ewm3/ui/mocks/accounts-list-long-clients-mock'

test.describe('Client section. Accounts tests @stable', () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

  test.describe('Search', () => {
    type Param = {
      fieldForSearchQuery: string,
      searchTrigger: SearchTrigger,
      textFormatting: (text: string) => string,
      testId: string
    };
    test.describe('Search - Common logic', () => {
      const testParamsArray: Param[] = [
        {
          fieldForSearchQuery: AccountsConfig.SEARCHABLE_FIELDS[0],
          searchTrigger: SearchTrigger.KEYBOARD_NAVIGATION_CHOOSE_SUGGEST_OPTION,
          textFormatting: (text: string) => text.toLowerCase(),
          testId: '@2791 - with Lower Case'
        },
        {
          fieldForSearchQuery: AccountsConfig.SEARCHABLE_FIELDS[1],
          searchTrigger: SearchTrigger.ENTER_KEY,
          textFormatting: (text: string) => text.toUpperCase(),
          testId: '@2792 - with Upper Case'
        },
        {
          fieldForSearchQuery: AccountsConfig.SEARCHABLE_FIELDS[0],
          searchTrigger: SearchTrigger.CLICK_ON_SUGGEST_OPTION,
          textFormatting: (text: string) => text.substring(0, 2),
          testId: '@2791 - with first 2 symbols'
        },
        {
          fieldForSearchQuery: AccountsConfig.SEARCHABLE_FIELDS[1],
          searchTrigger: SearchTrigger.MAGNIFYING_GLASS_BUTTON,
          textFormatting: (text: string) => text,
          testId: '@2792 -  - full Account Number'
        },
      ]
      for (const param of testParamsArray) {
        test.describe('Search by different criteria', () => {
          let searchQuery: string
          test.beforeEach(`Get the search Query for field ${param.fieldForSearchQuery} and Trigger ${param.searchTrigger}`, async ({accountsPage}) => {
            await accountsPage.customizeColumns.selectAllColumns()
            await accountsPage.table.expandNestedTable()
            const tableData = await accountsPage.table.data()

            const initialSearchQuery = accountsPage.table.getRandomValueByColumnName(
              tableData, param.fieldForSearchQuery
            )
            searchQuery = param.textFormatting(initialSearchQuery)
          })

          test(`Searching ${param.fieldForSearchQuery} using ${param.searchTrigger}, testID: ${param.testId}`, async ({accountsPage}) => {
            await accountsPage.search.makeSearch(searchQuery, param.searchTrigger)
            await accountsPage.search.verifySearchResult(searchQuery, AccountsConfig.SEARCHABLE_FIELDS)
          })

          test(`Search by ${param.fieldForSearchQuery} displays the Search predictive results , testID: ${param.testId}`, async ({accountsPage}) => {
            await accountsPage.search.checkSearchDropdown(searchQuery)
          })
        })
      }
    })

    test.describe('Search - Account number in search results', () => {
      const testParamsArray = [
        {
          fieldForSearchQuery: AccountsConfig.SEARCHABLE_FIELDS[0],
          searchTrigger: SearchTrigger.ENTER_KEY,
          testId: '@2793'
        },
        {
          fieldForSearchQuery: AccountsConfig.SEARCHABLE_FIELDS[1],
          searchTrigger: SearchTrigger.CLICK_ON_SUGGEST_OPTION,
          testId: '@2793'
        },
      ]

      for (const param of testParamsArray) {
        test(`Positioning of Account title and Account number when search by ${param.fieldForSearchQuery}, testID: ${param.testId}`, async ({accountsPage}) => {
          await accountsPage.customizeColumns.selectAllColumns()
          await accountsPage.table.expandNestedTable()
          const tableData = await accountsPage.table.data()
          const searchQuery = accountsPage.table.getRandomValueByColumnName(
            tableData, param.fieldForSearchQuery
          )
          if (searchQuery) {
            const accountData = await accountsPage.getAccountList()
            await accountsPage.search.checkAccountNumberInSearchResultMatchApi(accountData, searchQuery)
            await accountsPage.search.checkAccountTitleAndNumberPosition(searchQuery)
          } else throw new Error(`Could not generate search query for field ${searchQuery}`)
        })

        test(`Account Number is fully visible in Search Result when search by ${param.fieldForSearchQuery}, testID: @3413`, async ({accountsPage}) => {
          await accountsPage.customizeColumns.selectAllColumns()
          const tableData = await accountsPage.table.data()

          const searchQuery = accountsPage.table.getRandomValueByColumnName(
            tableData, param.fieldForSearchQuery)

          if (!searchQuery){
            throw new Error(`Search - Could not generate search query for field ${searchQuery}`)
          }
          await accountsPage.search.checkAccountNumberIsFullyVisiable(searchQuery)
        })
      }
    })

    test.describe('Search - Common visual behavior', () => {
      test(`Click Cross button @1472`, async ({accountsPage}) => {
        const initialTableData = await accountsPage.table.data()
        await test.step(`Check search empty state and fill Search Field with random value`, async () => {
          const randomAlphanumeric: string = faker.string.alphanumeric(5)
          await accountsPage.search.assertSearchCrossButtonAbsent()
          await accountsPage.search.fillSearchField(randomAlphanumeric)
        })
        await test.step(`Verifying cross button appearance after filling in search field`, async () => {
          await accountsPage.search.assertSearchCrossButtonAvailable()
        })
        await test.step(`Make search and verify cross button appearance`, async () => {
          await accountsPage.search.locators.magnifyingGlassButton.click()
          await accountsPage.search.assertSearchCrossButtonAvailable()
        })
        await test.step(`Clicking on the cross button and Checking that then it is absent`, async () => {
          await accountsPage.search.locators.crossButton.click()
          await accountsPage.search.assertSearchCrossButtonAbsent()
          await accountsPage.search.assertSearchFieldIsEmpty()
          const finalTableData = await accountsPage.table.data()
          expect(initialTableData,
            `Assert that Search results are restored to default state`).toEqual(finalTableData)
        })
      })

      test(`Showing '...' for long Title in Search Results @2794`, async ({accountsPage}) => {
        await accountsPage.replaceResponseWithLongValues()
        await accountsPage.goto()
        await accountsPage.waitPageIsReady()
        const tableData = await accountsPage.table.data()

        const searchQuery = accountsPage.table.getRandomValueByColumnName(
          tableData, AccountsConfig.SEARCHABLE_FIELDS[0]).substring(0, 2)
        await accountsPage.search.locators.searchInput.fill(searchQuery)
        await accountsPage.search.ellipsisExistForSearchResult()
      })
    })

  })

  test.describe('Pagination', () => {

    for (const trigger of Object.values(PageSwitchTrigger)) {
      test(`Switching to the last/first pages using ${trigger}`, async ({accountsPage}) => {
        await accountsPage.pagination.switchRowsPerPage(25)
        await accountsPage.pagination.lastPage(trigger, true)
        await accountsPage.pagination.firstPage(trigger, true)
      })

      test(`Switching to the next/previous pages using ${trigger}`, async ({accountsPage}) => {
        await accountsPage.pagination.switchRowsPerPage(25)
        await accountsPage.pagination.nextPage(trigger, true)
        await accountsPage.pagination.prevPage(trigger, true)
      })
    }

    for (const rowsPerPage of [25,50,100]) {
      test(`I assert rows per page. Set ${rowsPerPage} rows per page`, async ({accountsPage}) => {
        await accountsPage.pagination.switchRowsPerPage(rowsPerPage, true)
      })
    }

  })

  test.describe('Data Mapping API->UI', () => {

    test(`Data Mapping`, async ({page}) => {
      const responsePromise = page.waitForResponse(response =>
        response.url().includes(AccountsConfig.ENDPOINTS.accounts) && response.status() === 200,
      { timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM }
      )
      const accountsPage = new ClientSectionAccountsPage(page)
      await accountsPage.goto()
      await accountsPage.waitPageIsReady()
      await accountsPage.customizeColumns.selectAllColumns()
      const responseBody = await (await responsePromise).json()
      const tableData = await accountsPage.table.data()
      await accountsPage.table.assertDataMapping(
        responseBody,
        tableData,
        AccountsConfig.TABLE_DATA_CONFIG
      )
    })
  })

  test.describe('Sorting', () => {
    for (const fieldConfig of AccountsConfig.TABLE_DATA_CONFIG.fields.filter(field => field.enable_sorting && !(field.hidden && !field.enable_hiding))) {
      for (const sortingOrder of Object.values(SortingOrder)) {
        test(`Column: "${fieldConfig.columnName}"; ${sortingOrder}`, async ({accountsPage}) => {
          await accountsPage.customizeColumns.selectAllColumns()

          await accountsPage.table.sorting.sortBy({
            columnName: fieldConfig.columnName,
            sortingOrder: sortingOrder
          })

          const tableRowArray: TableRow[] = await accountsPage.table.data()
          if(await accountsPage.pagination.lastPageNumber()>1){
            await accountsPage.pagination.lastPage()
            tableRowArray.push(...await accountsPage.table.data())
          }

          await accountsPage.table.sorting.assertSorting(
            AccountsConfig.TABLE_DATA_CONFIG,
            tableRowArray,
            {
              columnName: fieldConfig.columnName,
              sortingOrder: sortingOrder
            },
          )
        })
      }
    }
  })

  test.describe('Customize columns form', () => {
    test(`Default`, async ({accountsPage}) => {
      await accountsPage.customizeColumns.resetToDefault()

      const tableData = await accountsPage.table.data()

      await accountsPage.customizeColumns.compareCustomizeColumnsAndTable({tableRowArray: tableData})
      await accountsPage.table.assertMainTableDefaultState(AccountsConfig.TABLE_DATA_CONFIG, tableData)
    })

    test(`All selected`, async ({accountsPage}) => {
      await accountsPage.customizeColumns.selectAllColumns()
      await accountsPage.customizeColumns.compareCustomizeColumnsAndTable()
    })

    test(`All deselected`, async ({accountsPage}) => {
      await accountsPage.customizeColumns.deselectAllColumns()
      await accountsPage.customizeColumns.compareCustomizeColumnsAndTable()
    })

    test(`Selecting/deselecting some of options`, async ({accountsPage}) => {
      const customizeColumnOptions = await accountsPage.customizeColumns.data()
      await accountsPage.customizeColumns.selectAllColumns()
      await accountsPage.customizeColumns.compareCustomizeColumnsAndTable()
      await accountsPage.customizeColumns.deselectItemsByName([
        customizeColumnOptions[1].itemText,
        customizeColumnOptions[5].itemText,
      ])
      await accountsPage.customizeColumns.compareCustomizeColumnsAndTable()
    })
  })

  test(`Assert table's columns capabilities`, async ({accountsPage}) => {
    await accountsPage.customizeColumns.selectAllColumns()
    const tableData = await accountsPage.table.data()
    await accountsPage.table.assertTableColumnCapabilities(AccountsConfig.TABLE_DATA_CONFIG, tableData)
  })

  test.describe('Table scroll', () => { 

    test.describe('Tests with predifined mock data for vertical scrolling', () => {
      test.beforeEach(async ({page}) => { 
        await page.route((url: URL) => url.toString().includes('/accountdata/api/v1/accounts'), async route => {
          await route.fulfill({ json: LongAccountsMock.data })
        })
      })
      test(`Four-way scrolling`, { tag: ['@2168', '@1969'] }, async ({accountsPage}) => {

        await test.step(`Verify that table scroll down. Header and footer of the table does not scroll`, async () => {
          await accountsPage.customizeColumns.selectAllColumns()
          await accountsPage.scroll.scrollElement(accountsPage.table.locators.tableScrollContainer, 'down', true, 
            [accountsPage.table.locators.tableHeader, accountsPage.pagination.locators.paginationModule]) 
        })
        await test.step(`Verify that table scroll up. Header and footer of the table does not scroll`, async () => {
          await accountsPage.scroll.scrollElement(accountsPage.table.locators.tableScrollContainer, 'up', true, 
            [accountsPage.table.locators.tableHeader, accountsPage.pagination.locators.paginationModule]) 
        })
        await test.step(`Verify that table scroll right. Header and footer of the table does not scroll`, async () => {
          await accountsPage.scroll.scrollElement(accountsPage.table.locators.tableScrollContainer, 'right', true, 
            [accountsPage.table.locators.tableHeader, accountsPage.pagination.locators.paginationModule]) 
        })
        await test.step(`Verify that table scroll left. Header and footer of the table does not scroll`, async () => {
          await accountsPage.scroll.scrollElement(accountsPage.table.locators.tableScrollContainer, 'left', true, 
            [accountsPage.table.locators.tableHeader, accountsPage.pagination.locators.paginationModule]) 
        })
      })
      test.describe('Test with view the page at a lower resolution ', () => {
        test.use({ viewport: { width: 1024, height: 600 } })
        test(`Horizontal and Vertical scroll bars are present`, { tag: ['@3525'] }, async ({accountsPage}) => {

          await test.step(`Reset to default columns in the table and Verify that Horizontal and Vertical scroll bars are present`, async () => {
            await accountsPage.customizeColumns.resetToDefault()
            await accountsPage.scroll.checkScrollbar(accountsPage.table.locators.tableScrollContainer, 'horizontal')
            await accountsPage.scroll.checkScrollbar(accountsPage.table.locators.tableScrollContainer, 'vertical')
          })
        })
      })
    })
    
    test.describe('Tests with predifined mock data for no vertical scrolling. 5 accounts are available in the table', () => {
      test.beforeEach(async ({page}) => { 
        await page.route((url: URL) => url.toString().includes('/accountdata/api/v1/accounts'), async route => {
          await route.fulfill({ json: FewAccountsMock.data })
        })
      })
      test(`Horizontal and Vertical scroll bars do not appear`, { tag: ['@2172', '@2171'] }, async ({accountsPage}) => {

        await test.step(`Unselect all columns in the table`, async () => {
          await accountsPage.customizeColumns.selectAllColumns()
          await accountsPage.customizeColumns.unSelectAllColumns()
        })
        await test.step(`Verify that Horizontal and Vertical scroll bars are absent`, async () => {
          await accountsPage.scroll.checkScrollbar(accountsPage.table.locators.tableScrollContainer, 'horizontal', false)
          await accountsPage.scroll.checkScrollbar(accountsPage.table.locators.tableScrollContainer, 'vertical', false)
        })
        
      })
    })
  })

})


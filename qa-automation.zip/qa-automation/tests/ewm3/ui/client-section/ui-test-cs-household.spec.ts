import {test} from '../../../../ewm3/fixtures/base-ui-fixture'
import {EWM3Config} from '../../../../ewm3/service-data/config'
import {SearchTrigger} from '../../../../ewm3/ui/features/search.feature'
import {PageSwitchTrigger} from '../../../../ewm3/ui/features/pagination.feature'
import {TableRow} from '../../../../ewm3/ui/features/table.feature'
import {SortingOrder} from '../../../../ewm3/ui/features/sorting.feature'
import {HouseholdConfig, houseHoldColumnNames} from '../../../../ewm3/service-data/client-section-configs/household.config'
import {ClientSectionHouseholdPage} from '../../../../ewm3/ui/pages/client-section-household-page'
import { faker } from '@faker-js/faker'
import {expect} from '@playwright/test'
import { FewClientsMock } from '../../../../ewm3/ui/mocks/clients-list-few-clients-mock'
import { LongClientsMock } from '../../../../ewm3/ui/mocks/clients-list-long-clients-mock'

test.describe('Client section. Household tests', () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

  test.describe('Search @stable', () => {
    type Param = {
      fieldForSearchQuery: string,
      searchTrigger: SearchTrigger,
      textFormatting: (text: string) => string,
      testId: string
    };
    test.describe('Search - Search logic using different criteria', () => {
      const testParamsArray: Param[] = [
        {
          fieldForSearchQuery: HouseholdConfig.SEARCHABLE_FIELDS[0],
          searchTrigger: SearchTrigger.KEYBOARD_NAVIGATION_CHOOSE_SUGGEST_OPTION,
          textFormatting: (text: string) => text.toLowerCase(),
          testId: '@2790 - with Lower Case'
        },
        {
          fieldForSearchQuery: HouseholdConfig.SEARCHABLE_FIELDS[1],
          searchTrigger: SearchTrigger.ENTER_KEY,
          textFormatting: (text: string) => text.toUpperCase(),
          testId: '@2791 - with Upper Case'
        },
        {
          fieldForSearchQuery: HouseholdConfig.SEARCHABLE_FIELDS[2],
          searchTrigger: SearchTrigger.CLICK_ON_SUGGEST_OPTION,
          textFormatting: (text: string) => text.substring(0, 2),
          testId: '@2792 - with first 2 symbols'
        },
        {
          fieldForSearchQuery: HouseholdConfig.SEARCHABLE_FIELDS[0],
          searchTrigger: SearchTrigger.MAGNIFYING_GLASS_BUTTON,
          textFormatting: (text: string) => text,
          testId: '@2790 - full Title'
        },
      ]
      for (const param of testParamsArray) {
        test.describe('Search by different criteria', () => {
          let searchQuery: string
          test.beforeEach(`Get the search Query for field ${param.fieldForSearchQuery} and Trigger ${param.searchTrigger}`, async ({houseHoldPage}) => {
            await houseHoldPage.customizeColumns.selectAllColumns()
            await houseHoldPage.table.expandNestedTable()
            const tableData = await houseHoldPage.table.data()

            const initialSearchQuery = houseHoldPage.table.getRandomValueByColumnName(
              tableData, param.fieldForSearchQuery
            )
            searchQuery = param.textFormatting(initialSearchQuery)
          })

          test(`Searching ${param.fieldForSearchQuery} using ${param.searchTrigger}, testID: ${param.testId}`, async ({houseHoldPage}) => {
            await houseHoldPage.search.makeSearch(searchQuery, param.searchTrigger)
            await houseHoldPage.search.verifySearchResult(searchQuery, HouseholdConfig.SEARCHABLE_FIELDS)
          })

          test(`Search by ${param.fieldForSearchQuery} displays the Search predictive results , testID: ${param.testId}`, async ({houseHoldPage}) => {
            await houseHoldPage.search.checkSearchDropdown(searchQuery)
          })
        })
      }
    })

    test.describe('Search - Account number in search results', () => {
      const testParamsArray = [
        {
          fieldForSearchQuery: HouseholdConfig.SEARCHABLE_FIELDS[1],
          searchTrigger: SearchTrigger.ENTER_KEY,
        },
        {
          fieldForSearchQuery: HouseholdConfig.SEARCHABLE_FIELDS[2],
          searchTrigger: SearchTrigger.CLICK_ON_SUGGEST_OPTION,
        },
      ]

      for (const param of testParamsArray) {
        test(`Positioning of Account title and Account number when search by ${param.fieldForSearchQuery}, testID: @2793, @1486`, async ({houseHoldPage}) => {
          await houseHoldPage.customizeColumns.selectAllColumns()
          await houseHoldPage.table.expandNestedTable()
          const tableData = await houseHoldPage.table.data()

          const searchQuery = houseHoldPage.table.getRandomValueByColumnName(
            tableData, param.fieldForSearchQuery)

          if (!searchQuery){
            throw new Error(`Search - Could not generate search query for field ${searchQuery}`)
          }
          const accountData = await houseHoldPage.getAccountList()
          await houseHoldPage.search.checkAccountNumberInSearchResultMatchApi(accountData, searchQuery)
          await houseHoldPage.search.checkAccountTitleAndNumberPosition(searchQuery)
        })

        test(`Account Number is fully visible in Search Result when search by ${param.fieldForSearchQuery}, testID: @3413`, async ({houseHoldPage}) => {
          await houseHoldPage.customizeColumns.selectAllColumns()
          await houseHoldPage.table.expandNestedTable()
          const tableData = await houseHoldPage.table.data()

          const searchQuery = houseHoldPage.table.getRandomValueByColumnName(
            tableData, param.fieldForSearchQuery)

          if (!searchQuery){
            throw new Error(`Search - Could not generate search query for field ${searchQuery}`)
          }
          await houseHoldPage.search.checkAccountNumberIsFullyVisiable(searchQuery)
        })
      }
    })

    test.describe('Search - Common visual behavior', () => {
      test(`Click Cross button @1472`, async ({houseHoldPage}) => {
        const initialTableData = await houseHoldPage.table.data()
        await test.step(`Check search empty state and fill Search Field with random value`, async () => {
          const randomAlphanumeric: string = faker.string.alphanumeric(5)
          await houseHoldPage.search.assertSearchCrossButtonAbsent()
          await houseHoldPage.search.fillSearchField(randomAlphanumeric)
        })
        await test.step(`Verifying cross button appearance after filling in search field`, async () => {
          await houseHoldPage.search.assertSearchCrossButtonAvailable()
        })
        await test.step(`Make search and verify cross button appearance`, async () => {
          await houseHoldPage.search.locators.magnifyingGlassButton.click()
          await houseHoldPage.search.assertSearchCrossButtonAvailable()
        })
        await test.step(`Clicking on the cross button and Checking that then it is absent`, async () => {
          await houseHoldPage.search.locators.crossButton.click()
          await houseHoldPage.search.assertSearchCrossButtonAbsent()
          await houseHoldPage.search.assertSearchFieldIsEmpty()
          const finalTableData = await houseHoldPage.table.data()
          expect(initialTableData,
            `Assert that Search results are restored to default state`).toEqual(finalTableData)
        })
      })

      test(`Showing '...' for long Title in Search Results @2794`, async ({houseHoldPage}) => {
        await houseHoldPage.replaceResponseWithLongValues()
        await houseHoldPage.goto()
        await houseHoldPage.waitPageIsReady()
        const tableData = await houseHoldPage.table.data()

        const searchQuery = houseHoldPage.table.getRandomValueByColumnName(
          tableData, HouseholdConfig.SEARCHABLE_FIELDS[0]).substring(0, 2)
        await houseHoldPage.search.locators.searchInput.fill(searchQuery)
        await houseHoldPage.search.ellipsisExistForSearchResult()
      })

    })
  })

  test.describe('Pagination @WIP', () => {

    for (const trigger of Object.values(PageSwitchTrigger)) {
      test(`Switching to the last/first pages using ${trigger}`, async ({houseHoldPage}) => {
        await houseHoldPage.pagination.switchRowsPerPage(25)
        await houseHoldPage.pagination.lastPage(trigger, true)
        await houseHoldPage.pagination.firstPage(trigger, true)
      })

      test(`Switching to the next/previous pages using ${trigger}`, async ({houseHoldPage}) => {
        await houseHoldPage.pagination.switchRowsPerPage(25)
        await houseHoldPage.pagination.nextPage(trigger, true)
        await houseHoldPage.pagination.prevPage(trigger, true)
      })
    }

    for (const rowsPerPage of [25, 50, 100]) {
      test(`I assert rows per page. Set ${rowsPerPage} rows per page`, async ({houseHoldPage}) => {
        await houseHoldPage.pagination.switchRowsPerPage(rowsPerPage, true)
      })
    }

  })

  test.describe('Data Mapping API->UI @WIP', () => {

    test(`Data Mapping`, async ({page}) => {
      const responsePromise = page.waitForResponse(response =>
        response.url().includes(HouseholdConfig.ENDPOINTS.clients) && response.status() === 200,
      {timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM}
      )
      const householdPage = new ClientSectionHouseholdPage(page)
      await householdPage.goto()
      await householdPage.waitPageIsReady()
      await householdPage.customizeColumns.selectAllColumns()
      const responseBody = await (await responsePromise).json()
      await householdPage.table.expandNestedTable()
      const tableData = await householdPage.table.data()
      await householdPage.table.assertDataMapping(
        responseBody,
        tableData,
        HouseholdConfig.TABLE_DATA_CONFIG
      )
    })
  })

  test.describe('Sorting Main Table @stable', () => {
    for (const fieldConfig of HouseholdConfig.TABLE_DATA_CONFIG.fields.filter(field => field.enable_sorting && !(field.hidden && !field.enable_hiding))) {
      for (const sortingOrder of Object.values(SortingOrder)) {
        test(`Column: "${fieldConfig.columnName}"; ${sortingOrder}`, async ({houseHoldPage}) => {
          await houseHoldPage.customizeColumns.selectAllColumns()

          await houseHoldPage.table.sorting.sortBy({
            columnName: fieldConfig.columnName,
            sortingOrder: sortingOrder
          })

          const pagesCount = await houseHoldPage.pagination.lastPageNumber()
          const tableRowArray: TableRow[] = await houseHoldPage.table.data()
          for (let i = 1; i < pagesCount; i++) {
            await houseHoldPage.pagination.nextPage()
            tableRowArray.push(...await houseHoldPage.table.data())
          }
          await houseHoldPage.table.sorting.assertSorting(
            HouseholdConfig.TABLE_DATA_CONFIG,
            tableRowArray,
            {
              columnName: fieldConfig.columnName,
              sortingOrder: sortingOrder
            },
          )
        })
      }
    }
  })

  test.describe('Sorting HH nested table @stable', () => {
    if (!HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig){
      console.error('Cant perform tests: Sorting HH nested table - nestedTableDataConfig is not defined')
      return
    }
    for (const fieldConfig of HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig.fields.filter(field => field.enable_sorting && !(field.hidden && !field.enable_hiding))) {
      test(`Nested Column: "${fieldConfig.columnName} - @2100, @2099, @2098"`, async ({houseHoldPage}) => {
        await houseHoldPage.customizeColumns.selectAllColumns()
          
        await houseHoldPage.table.sorting.sortBy({
          columnName: houseHoldColumnNames.number_of_accounts,
          sortingOrder: SortingOrder.DESCENDING
        })
        await houseHoldPage.table.expandNestedTable(10)

        for (const sortingOrder of Object.values(SortingOrder)) {
          await houseHoldPage.table.sorting.sortAllNestedTeblesOnCurrentPageBy({
            columnName: fieldConfig.columnName,
            sortingOrder: sortingOrder
          })
          const tableRowArray: TableRow[] = await houseHoldPage.table.data()

          await houseHoldPage.table.sorting.assertNestedSorting(
            HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig!,
            tableRowArray,
            {
              columnName: fieldConfig.columnName,
              sortingOrder: sortingOrder
            },
          )
        }
      })
    }
  })

  test.describe('Customize columns form @stable', () => {
    test(`Default`, async ({houseHoldPage}) => {
      await houseHoldPage.customizeColumns.resetToDefault()

      await houseHoldPage.table.expandNestedTable(1)
      const tableData = await houseHoldPage.table.data()
      const nestedTableData = tableData.find(row => row.nestedTableRow != undefined)?.nestedTableRow

      await houseHoldPage.customizeColumns.compareCustomizeColumnsAndTable({tableRowArray: tableData})
      await houseHoldPage.table.assertMainTableDefaultState(HouseholdConfig.TABLE_DATA_CONFIG, tableData)
      if (!HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig){
        console.error('Cant perform tests: Customize columns form HH - nestedTableDataConfig is not defined')
        return
      }
    })

    test(`All selected`, async ({houseHoldPage}) => {
      await houseHoldPage.customizeColumns.selectAllColumns()
      await houseHoldPage.customizeColumns.compareCustomizeColumnsAndTable()
    })

    test(`All deselected`, async ({houseHoldPage}) => {
      await houseHoldPage.customizeColumns.deselectAllColumns()
      await houseHoldPage.customizeColumns.compareCustomizeColumnsAndTable()
    })

    test(`Selecting/deselecting some of options`, async ({houseHoldPage}) => {
      const customizeColumnOptions = await houseHoldPage.customizeColumns.data()
      await houseHoldPage.customizeColumns.selectAllColumns()
      await houseHoldPage.customizeColumns.compareCustomizeColumnsAndTable()
      await houseHoldPage.customizeColumns.deselectItemsByName([
        customizeColumnOptions[1].itemText,
        customizeColumnOptions[5].itemText,
      ])
      await houseHoldPage.customizeColumns.compareCustomizeColumnsAndTable()
    })
  })

  test(`Assert table's columns capabilities @stable`, async ({houseHoldPage}) => {
    await houseHoldPage.customizeColumns.selectAllColumns()

    await houseHoldPage.table.expandNestedTable(1)
    const tableData = await houseHoldPage.table.data()
    const nestedTableData = tableData.find(row => row.nestedTableRow != undefined)?.nestedTableRow

    await houseHoldPage.table.assertTableColumnCapabilities(HouseholdConfig.TABLE_DATA_CONFIG, tableData)
    if(HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig && nestedTableData) {
      await houseHoldPage.table.assertTableColumnCapabilities( HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig, nestedTableData, true)
    } 
  })

  test.describe('Table scroll', () => {

    test.describe('Tests with predifined mock data for vertical scrolling', () => {
      test.beforeEach(async ({page}) => { 
        await page.route((url: URL) => url.toString().includes('/accountdata/api/v1/clients'), async route => {
          await route.fulfill({ json: LongClientsMock.data })
        })
      })
      test(`Four-way scrolling. Header and footer of the table does not scroll`, { tag: ['@2168', '@1969'] }, async ({houseHoldPage}) => {

        await test.step(`Verify that table scroll down. Header and footer of the table does not scroll`, async () => {
          await houseHoldPage.customizeColumns.selectAllColumns()
          await houseHoldPage.scroll.scrollElement(houseHoldPage.table.locators.tableScrollContainer, 'down', true, 
            [houseHoldPage.table.locators.tableHeader, houseHoldPage.pagination.locators.paginationModule]) 
        })
        await test.step(`Verify that table scroll up. Header and footer of the table does not scroll`, async () => {
          await houseHoldPage.scroll.scrollElement(houseHoldPage.table.locators.tableScrollContainer, 'up', true, 
            [houseHoldPage.table.locators.tableHeader, houseHoldPage.pagination.locators.paginationModule]) 
        })
        await test.step(`Verify that table scroll right. Header and footer of the table does not scroll`, async () => {
          await houseHoldPage.scroll.scrollElement(houseHoldPage.table.locators.tableScrollContainer, 'right', true, 
            [houseHoldPage.table.locators.tableHeader, houseHoldPage.pagination.locators.paginationModule]) 
        })
        await test.step(`Verify that table scroll left. Header and footer of the table does not scroll`, async () => {
          await houseHoldPage.scroll.scrollElement(houseHoldPage.table.locators.tableScrollContainer, 'left', true, 
            [houseHoldPage.table.locators.tableHeader, houseHoldPage.pagination.locators.paginationModule]) 
        }) 
      })
      test.describe('Test with view the page at a lower resolution ', () => {
        test.use({ viewport: { width: 1024, height: 600 } })
        test(`Horizontal and Vertical scroll bars are present`, { tag: ['@3525'] }, async ({houseHoldPage}) => {
  
          await test.step(`Reset to default columns in the table and Verify that Horizontal and Vertical scroll bars are present`, async () => {
            await houseHoldPage.customizeColumns.resetToDefault()
            await houseHoldPage.scroll.checkScrollbar(houseHoldPage.table.locators.tableScrollContainer, 'horizontal')
            await houseHoldPage.scroll.checkScrollbar(houseHoldPage.table.locators.tableScrollContainer, 'vertical')
          })
        })
      })

    })

    test.describe('Tests with predifined mock data for no vertical scrolling. 5 clients are available in the table', () => {
      test.beforeEach(async ({page}) => { 
        await page.route((url: URL) => url.toString().includes('/accountdata/api/v1/clients'), async route => {
          await route.fulfill({ json: FewClientsMock.data })
        })
      })
      test(`Horizontal and Vertical scroll bars do not appear`, { tag: ['@2172', '@2171'] }, async ({houseHoldPage}) => {

        await test.step(`Unselect all columns in the table`, async () => {
          await houseHoldPage.customizeColumns.selectAllColumns()
          await houseHoldPage.customizeColumns.unSelectAllColumns()
        })
        await test.step(`Verify that Horizontal and Vertical scroll bars are absent`, async () => {
          await houseHoldPage.scroll.checkScrollbar(houseHoldPage.table.locators.tableScrollContainer, 'horizontal', false)
          await houseHoldPage.scroll.checkScrollbar(houseHoldPage.table.locators.tableScrollContainer, 'vertical', false)
        })
      })
      test(`Horizontal and Vertical scroll bars do not appear when nested table is expanded`, { tag: ['@2175', '@2176'] }, async ({houseHoldPage}) => {

        await test.step(`Unselect all columns in the table`, async () => {
          await houseHoldPage.customizeColumns.selectAllColumns()
          await houseHoldPage.customizeColumns.unSelectAllColumns()
        })
        await test.step(`Verify that Horizontal and Vertical scroll bars are absent when nested table is expanded`, async () => {
          await houseHoldPage.table.expandNestedTable(1)
          await houseHoldPage.scroll.checkScrollbar(houseHoldPage.table.locators.tableScrollContainer, 'horizontal', false)
          await houseHoldPage.scroll.checkScrollbar(houseHoldPage.table.locators.tableScrollContainer, 'vertical', false)
        })
      })
    })

  })

})

import { test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { EWM3Config } from '../../../../ewm3/service-data/config'
import { expect } from '../../../../ewm3/fixtures/synced-ui-fixtures'
import {CustomizeMenuItem} from '../../../../ewm3/ui/features/base-customize-menu.feature'
import { Page } from '@playwright/test'
import {ClientSectionHouseholdPage} from '../../../../ewm3/ui/pages/client-section-household-page'
import {ClientSectionAccountsPage} from '../../../../ewm3/ui/pages/client-section-accounts-page'
import { ClientSectionIndividualHouseholdPage } from '../../../../ewm3/ui/pages/client-section-individual-household-page'
import { ClientSectionIndividualAccountPage } from '../../../../ewm3/ui/pages/client-section-individual-account-page'
import {BaseClientSectionPage} from '../../../../ewm3/ui/pages/base-client-section-page'
import {CSTablePageConfig} from '../../../../ewm3/service-data/client-section-configs/types' 

test.describe('Customize columns', () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})
  const testParams = [
    {
      tabName: 'Household tab', currentWebPage: (page:Page) =>  new ClientSectionHouseholdPage(page), childPage: (page:Page) => new ClientSectionIndividualHouseholdPage(page)
    },
    {
      tabName: 'Accounts tab', currentWebPage: (page:Page) => new ClientSectionAccountsPage(page), childPage: (page:Page) => new ClientSectionIndividualAccountPage(page)
    },
  ]

  for (const tab of testParams) {
    test.describe('Customize columns. Common behavior  @stable', () => {
      let currentPage: BaseClientSectionPage
      test.beforeEach(`Open current tab: ${tab.tabName}`, async ({ page }) => {
        currentPage = tab.currentWebPage(page)
        await currentPage.goto()
        await currentPage.navbar.waitNavbarIsReady()
        await currentPage.filter.reset()
        await currentPage.waitPageIsReady()
      })
      
      test(`Visible components for tab: ${tab.tabName} @1281`, async () => {
        const tableColumns = await currentPage.customizeColumns.data()
        await currentPage.customizeColumns.openMenu()
        await currentPage.customizeColumns.validateCustomizeColumnsTitle('Customize Columns')
        // AND the instructional text reads: "Add, remove or reorder columns".) (CMS Driven)
        await currentPage.customizeColumns.validateCustomizeColumnsDescription('Select and reorder columns for display')
        // AND the frozen columns will not be included as a selection
        for (const field of (currentPage.pageConfig as CSTablePageConfig).TABLE_DATA_CONFIG.fields) { 
          if (field.frozen) {
            expect(tableColumns, 'Expect frozen columns not to be customizable').not.toContain(field.columnName)
          }
        }
        // AND the form will have button with the following text (CMS Driven):  Cancel
        await expect(currentPage.customizeColumns.locators.cancel).toContainText('Cancel', {ignoreCase: true, useInnerText: true})
        // AND the form has "Restore to default order" button
        await expect(currentPage.customizeColumns.locators.resetToDefault).toContainText('Restore to Default', {useInnerText: true})
        // AND an elevation (drop shadow) will be added to the dropdown above the footer
        await expect(currentPage.customizeColumns.locators.footerActions).toHaveClass(/withBorderTop/)
      })
    
      test(`Reordering columns by dragging Up changes the order in Form and Table for tab: ${tab.tabName} @1284`, async () => {
        const toolbarDataBefore: CustomizeMenuItem[] = []
        const toolbarDataAfter: CustomizeMenuItem[] = []
    
        toolbarDataBefore.push(...await currentPage.customizeColumns.data())
        await currentPage.customizeColumns.openMenu()
        await currentPage.customizeColumns.dragAndDropMenuItemsByName(toolbarDataBefore[toolbarDataBefore.length-1].itemText, toolbarDataBefore[0].itemText)
        toolbarDataAfter.push(... await currentPage.customizeColumns.data())
        // Change the initial state according to the performed changes: move the latest element to the very beginning
        if (toolbarDataBefore.length >= 2) {
          const lastElement = toolbarDataBefore.pop()
          toolbarDataBefore.unshift(lastElement!)
        }
        // Check if Initial state with applied changes match Final state
        expect.soft(toolbarDataAfter,`Assert columns order changed after dragging in Customize Columns form`).toEqual(toolbarDataBefore)
        await currentPage.customizeColumns.compareCustomizeColumnsAndTable()
      })
    
      test(`Reordering columns by dragging Down changes the order in Form and Table for tab: ${tab.tabName} @1284`, async () => {
        const toolbarDataBefore: CustomizeMenuItem[] = []
        const toolbarDataAfter: CustomizeMenuItem[] = []
    
        toolbarDataBefore.push(...await currentPage.customizeColumns.data())
        await currentPage.customizeColumns.openMenu()
        await currentPage.customizeColumns.dragAndDropMenuItemsByName(toolbarDataBefore[0].itemText, toolbarDataBefore[toolbarDataBefore.length-1].itemText)
        toolbarDataAfter.push(... await currentPage.customizeColumns.data())
        if (toolbarDataBefore.length >= 2) {
          const firstElement = toolbarDataBefore.shift()
          toolbarDataBefore.push(firstElement!)
        }
        expect.soft(toolbarDataAfter,`Assert columns order changed after dragging in Customize Columns form`).toEqual(toolbarDataBefore)
        await currentPage.customizeColumns.compareCustomizeColumnsAndTable()
      })
    
      test(`Blue line indicator is displayed while dragging Up for tab: ${tab.tabName} @1284`, async () => {
        const toolbarData = await currentPage.customizeColumns.data()
        await currentPage.customizeColumns.openMenu()
        await currentPage.customizeColumns.dragItemByName(toolbarData[toolbarData.length-1].itemText, toolbarData[0].itemText)
        await expect(currentPage.customizeColumns.locators.menuDropSeparator,`Blue line indicator is displayed while dragging Up`).toBeVisible()
        await expect(currentPage.customizeColumns.locators.menuItemAfterSeparator,`I view a blue line indicator at the bottom edge of the upper column`).toContainText(toolbarData[0].itemText)
      })
    
      test(`Blue line indicator is displayed while dragging Down for tab: ${tab.tabName} @1284`, async () => {
        const toolbarData = await currentPage.customizeColumns.data()
        await currentPage.customizeColumns.openMenu()
        await currentPage.customizeColumns.dragItemByName(toolbarData[0].itemText, toolbarData[toolbarData.length-1].itemText)
        await expect(currentPage.customizeColumns.locators.menuDropSeparator,`Blue line indicator is displayed while dragging Up`).toBeVisible()
        await expect(currentPage.customizeColumns.locators.menuItemBeforeSeparator,`I view a blue line indicator at the bottom edge of the lower column`).toContainText(toolbarData[toolbarData.length-1].itemText)
      })
    })
  
    test.describe('Save Customize columns preferences @singleThreadOnly @2433', () => {
      const toolbarDataBefore: CustomizeMenuItem[] = []
      const toolbarDataAfter: CustomizeMenuItem[] = []

      test(`Compare Customize columns form when Openinig other page for tab: ${tab.tabName}`,async ({page, context}) => { 
        const currentPage = tab.currentWebPage(page)
        await currentPage.goto()
        await currentPage.waitPageIsReady()
        await currentPage.filter.reset()
        await currentPage.customizeColumns.selectAllColumns()
        await currentPage.customizeColumns.deselectItemsByIndex(0)
        // todo:for some reasons frontend makes save request with 1 second delayremove that delay after fix EWM30CS-743 
        await currentPage.page.waitForTimeout(1000)
  
        await test.step(`Get toolbar and toolbar metrics menu data before page refresh`, async () => {
          toolbarDataBefore.push(...await currentPage.customizeColumns.data())
        })
        await currentPage.customizeColumns.compareCustomizeColumnsAndTable()
        
        const page2 = await context.newPage()
  
        // Open another tab with a URL prefix
        await page2.goto('https://www.google.com/', {waitUntil: 'networkidle'})
    
        // Switch back to the tab with the specific URL prefix
        const pages = context.pages()
        let targetPage: Page| null = null
        for (const page of pages) {
          if (page.url().startsWith(EWM3Config.BASE_URL + '/clients/')) {
            targetPage = page
            break
          }
        }
        
        if (targetPage) {
          await targetPage.bringToFront()
        } else {
          throw new Error ('No tab with the Client Section opened')
        }
        
        await test.step(`Get toolbar and toolbar metrics menu data after page refresh`, async () => {
          toolbarDataAfter.push(...await currentPage.customizeColumns.data())
        })
  
        await test.step(`Compare toolbar and toolbar metrics menu data before and after page refresh`, async () => {
          expect.soft(toolbarDataAfter,
            `Assert toolbar data`).toEqual(toolbarDataBefore)
          await currentPage.customizeColumns.compareCustomizeColumnsAndTable()
        })
      })
      
      test(`Compare Customize columns form when Reload the page for tab: ${tab.tabName}`,async ({page}) => {  
        const currentPage = tab.currentWebPage(page)
        await currentPage.goto()
        await currentPage.waitPageIsReady()
        await currentPage.filter.reset()
        await currentPage.customizeColumns.selectAllColumns()
        await currentPage.customizeColumns.deselectItemsByIndex(0)
        // todo:for some reasons frontend makes save request with 1 second delayremove that delay after fix EWM30CS-743 
        await currentPage.page.waitForTimeout(1000)
  
        await test.step(`Get toolbar and toolbar metrics menu data before page refresh`, async () => {
          toolbarDataBefore.push(...await currentPage.customizeColumns.data())
        })
        await currentPage.customizeColumns.compareCustomizeColumnsAndTable()

        await currentPage.page.reload()
        await currentPage.waitPageIsReady()

        await test.step(`Get toolbar and toolbar metrics menu data after page refresh`, async () => {
          toolbarDataAfter.push(...await currentPage.customizeColumns.data())
        })
  
        await test.step(`Compare toolbar and toolbar metrics menu data before and after page refresh`, async () => {
          expect.soft(toolbarDataAfter,
            `Assert toolbar data`).toEqual(toolbarDataBefore)
          await currentPage.customizeColumns.compareCustomizeColumnsAndTable()
        })
      })

      test(`Compare Customize columns form when Open Individual page for tab: ${tab.tabName}`,async ({page}) => {  
        const currentPage = tab.currentWebPage(page)
        const childPage = tab.childPage(page)
        await currentPage.goto()
        await currentPage.waitPageIsReady()
        await currentPage.filter.reset()
        await currentPage.customizeColumns.selectAllColumns()
        await currentPage.customizeColumns.deselectItemsByIndex(0)
        // todo:for some reasons frontend makes save request with 1 second delayremove that delay after fix EWM30CS-743 
        await currentPage.page.waitForTimeout(1000)
  
        await test.step(`Get toolbar and toolbar metrics menu data before page refresh`, async () => {
          toolbarDataBefore.push(...await currentPage.customizeColumns.data())
        })
        await currentPage.customizeColumns.compareCustomizeColumnsAndTable()

        const firstTableRow = currentPage.table.locators.rowsMainOnly.nth(0)
        const firstRowTitle = await currentPage.table.getContentLocatorByColumnName(firstTableRow, currentPage.returnColumnNameToOpenIndividualPage(),  await currentPage.table.getMainHeadersArray())
        await firstRowTitle?.click()
        await childPage.waitPageIsReady()
        await childPage.page.goBack()
        await currentPage.waitPageIsReady()

        await test.step(`Get toolbar and toolbar metrics menu data after page refresh`, async () => {
          toolbarDataAfter.push(...await currentPage.customizeColumns.data())
        })
  
        await test.step(`Compare toolbar and toolbar metrics menu data before and after page refresh`, async () => {
          expect.soft(toolbarDataAfter,
            `Assert toolbar data`).toEqual(toolbarDataBefore)
          await currentPage.customizeColumns.compareCustomizeColumnsAndTable()
        })
      })
    })
  }
})

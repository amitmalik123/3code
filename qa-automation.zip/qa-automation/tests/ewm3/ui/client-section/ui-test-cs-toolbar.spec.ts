import {test} from '../../../../ewm3/fixtures/base-ui-fixture'
import {EWM3Config} from '../../../../ewm3/service-data/config'
import {ToolbarMetricItem} from '../../../../ewm3/ui/features/client-section/cs.toolbar.feature'
import {CustomizeMenuItem} from '../../../../ewm3/ui/features/base-customize-menu.feature'
import {Page, expect} from '@playwright/test'
import {ClientSectionHouseholdPage} from '../../../../ewm3/ui/pages/client-section-household-page'
import {AccountMetricResponse} from '../../../../ewm3/api/accountdata/v1/types'
import {ClientSectionAccountsPage} from '../../../../ewm3/ui/pages/client-section-accounts-page'
import {BaseClientSectionPage} from '../../../../ewm3/ui/pages/base-client-section-page'
import { ClientSectionIndividualHouseholdPage } from '../../../../ewm3/ui/pages/client-section-individual-household-page'
import { ClientSectionIndividualAccountPage } from '../../../../ewm3/ui/pages/client-section-individual-account-page'

test.describe('Client section. Toolbar tests', () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

  test.describe('Client section. Toolbar tests for all tabs', () => {
    const testParams = [
      {
        tabName: 'Household tab', currentWebPage: (page:Page) => new ClientSectionHouseholdPage(page)
      },
      {
        tabName: 'Accounts tab', currentWebPage: (page:Page) => new ClientSectionAccountsPage(page)
      },
      {
        tabName: 'Individual HH', currentWebPage: (page:Page) => new ClientSectionIndividualHouseholdPage(page)
      },
      {
        tabName: 'Individual Account',  currentWebPage: (page:Page) => new ClientSectionIndividualAccountPage(page)
      },
    ]

    for (const tab of testParams) {

      test.describe('Data mapping API->UI @stable', () => {
        test(`Data mapping API->UI for Toolbar tab: ${tab.tabName} @2415 @2419`, async ({page}) => {
          const currentPage = tab.currentWebPage(page)
          const endpoint = currentPage.pageConfig.ENDPOINTS.toolbar

          const toolbarResponsePromise = page.waitForResponse(response =>
            response.url().includes(endpoint), { timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM }
          )
      
          await currentPage.goto()
          await currentPage.waitPageIsReady()
          await currentPage.toolbar.metricsMenu.selectAllColumns()

          const response = await toolbarResponsePromise
          expect(response.status(), 'Assert advisor metrics response status code is 200').toEqual(200)
          const responseBody: AccountMetricResponse = await response.json()
          const toolbarData = await currentPage.toolbar.metricsData()

          await currentPage.toolbar.assertDataMapping(toolbarData, responseBody, currentPage.pageConfig.TOOLBAR_METRICS_CONFIG)

        })
      })

      test.describe('Ellipsis and Tooltip for Long Metric Values - Mock Data @stable', () => {
        test(`Metrics display Ellipsis and Tooltip for Long Values on tab: ${tab.tabName} @2430`, async ({page}) => {
          const currentPage = tab.currentWebPage(page)
          const endpoint = currentPage.pageConfig.ENDPOINTS.toolbar

          await currentPage.replaceToolbarMetricsWithMockLongValues()

          const toolbarResponsePromise = page.waitForResponse(response =>
            response.url().includes(endpoint), { timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM }
          )
      
          await currentPage.goto()
          await currentPage.waitPageIsReady()
          await currentPage.toolbar.metricsMenu.selectAllColumns()

          const response = await toolbarResponsePromise
          expect(response.status(), 'Assert advisor metrics response status code is 200').toEqual(200)
          const responseBody: AccountMetricResponse = await response.json()

          const metricsWithTooltip  = currentPage.returnToolbarMetricsWithEllipsis()
          await currentPage.toolbar.ellipsisExistForMetrics(metricsWithTooltip)
          await currentPage.toolbar.metricsFromTooltipMatchApi(metricsWithTooltip, responseBody, currentPage.pageConfig.TOOLBAR_METRICS_CONFIG)
        })
      })

      test.describe('Toolbar metrics menu @stable', () => {
        let currentPage: BaseClientSectionPage
        test.beforeEach(`Open current tab: ${tab.tabName}`, async ({page}) => {
          currentPage = tab.currentWebPage(page)
          await currentPage.goto()
          await currentPage.waitPageIsReady()
        })

        test.describe('Common behaviour', () => {

          test(`Toolbar behavior when window resizing in tab: ${tab.tabName} @2426`, async ({page}) => {
            await currentPage.toolbar.metricsMenu.openMenu()
            await currentPage.toolbar.metricsMenu.selectAllColumns()
            
            await page.setViewportSize({ width: 1440, height: 900 })
            await currentPage.toolbar.visibleMetricsAreCorrectAligned(1)
            await page.setViewportSize({ width: 1280, height:700 })
            await currentPage.toolbar.visibleMetricsAreCorrectAligned(2)
          })
        })

        test.describe('Close toolbar metrics menu', () => {
          test.beforeEach(`Assert that Toolbar menu is opened for tab: ${tab.tabName}`, async () => {
            await currentPage.toolbar.metricsMenu.openMenu()
            await expect(currentPage.toolbar.metricsMenu.locators.menu,
              `Assert that menu is visible`).toBeVisible()
          })

          test(`Push apply button for tab: ${tab.tabName}`, async () => {
            await currentPage.toolbar.metricsMenu.locators.applyButton.click()
          })

          test(`Push close button for tab: ${tab.tabName}`, async () => {
            await currentPage.toolbar.metricsMenu.locators.closeButton.click()
          })

          test(`Click at area outside the menu area for tab: ${tab.tabName}`, async () => {
            await currentPage.toolbar.locators.title.click()
          })

          test.afterEach(`Assert that menu is closed for tab: ${tab.tabName}`, async () => {
            await expect(currentPage.toolbar.metricsMenu.locators.menu,
              `Assert that menu is not visible`).not.toBeVisible()
          })
        })

        test.describe('Show/hide items feature @2423, @2424', () => {

          test(`All deselected for tab: ${tab.tabName}`, async () => {
            await currentPage.toolbar.metricsMenu.deselectAllColumns()
          })

          test(`All selected for tab: ${tab.tabName}`, async () => {
            await currentPage.toolbar.metricsMenu.selectAllColumns()
          })

          test(`First item deselected others selected for tab: ${tab.tabName}`, async () => {
            await currentPage.toolbar.metricsMenu.selectAllColumns()
            await currentPage.toolbar.metricsMenu.deselectItemsByIndex(0 )
          })

          test.afterEach(`Compare toolbar metrics with toolbar metrics menu for tab: ${tab.tabName}`, async () => {
            const toolbarData = await currentPage.toolbar.metricsData()
            const toolbarMetricsMenuData = await currentPage.toolbar.metricsMenu.data()
            await currentPage.toolbar.metricsMenu.compareWithToolbarItems(toolbarMetricsMenuData, toolbarData)
          })

        })

        test.describe('Changing Metrics', () => {
      
          test(`Add Key Indicators to the Toolbar for tab: ${tab.tabName} @2674 `, async () => {
            await currentPage.toolbar.metricsMenu.deselectAllColumns()
            const metricsNames: string[] = currentPage.pageConfig.TOOLBAR_METRICS_CONFIG.map(metric => metric.name)
            for (let i = 0; i < metricsNames.length; i++) {
              await currentPage.toolbar.metricsMenu.selectItemsByName(metricsNames[i])
              const toolbarData = await currentPage.toolbar.metricsData()
              const toolbarMetricsMenuData = await currentPage.toolbar.metricsMenu.data()
              await currentPage.toolbar.metricsMenu.compareWithToolbarItems(toolbarMetricsMenuData, toolbarData)
            }
          })

          test(`Cross button discards changes in Toolbar Metrics form for tab: ${tab.tabName} @2425`, async () => {
            const toolbarDataBefore: ToolbarMetricItem[] = []
            const toolbarDataAfter: ToolbarMetricItem[] = []

            await currentPage.toolbar.metricsMenu.selectAllColumns()
            toolbarDataBefore.push(...await currentPage.toolbar.metricsData())
            await currentPage.toolbar.metricsMenu.deselectItemsByIndexWithoutApplying(0)
            await currentPage.toolbar.metricsMenu.locators.closeButton.click()
            toolbarDataAfter.push(...await currentPage.toolbar.metricsData())
            expect.soft(toolbarDataAfter,`Assert toolbar data`).toEqual(toolbarDataBefore)
          })

          test(`Change Metrics order by dragging for tab: ${tab.tabName} @3030`, async () => {
            const toolbarDataBefore: ToolbarMetricItem[] = []
            const toolbarDataAfter: ToolbarMetricItem[] = []

            await currentPage.toolbar.metricsMenu.selectAllColumns()
            toolbarDataBefore.push(...await currentPage.toolbar.metricsData())
 
            await currentPage.toolbar.metricsMenu.openMenu()
            await currentPage.toolbar.metricsMenu.dragAndDropMenuItemsByName(toolbarDataBefore[toolbarDataBefore.length-1].name, toolbarDataBefore[0].name)
            await currentPage.toolbar.metricsMenu.locators.applyButton.click()
            toolbarDataAfter.push(...await currentPage.toolbar.metricsData())
            if (toolbarDataBefore.length >= 2) {
              const lastElement = toolbarDataBefore.pop()
              toolbarDataBefore.unshift(lastElement!)
            }
            expect.soft(toolbarDataAfter,`Assert toolbar data changed after dragging`).toEqual(toolbarDataBefore)
          })
        })
      })

      test.describe('Save toolbar preferences and refresh the page @singleThreadOnly @2429', () => {
        let currentPage: BaseClientSectionPage
        test.beforeEach(`Open current tab: ${tab.tabName}`, async ({page}) => {
          currentPage = tab.currentWebPage(page)
          await currentPage.goto()
          await currentPage.waitPageIsReady()
        })

        test(`All deselected for tab: ${tab.tabName}`, async () => {
          await currentPage.toolbar.metricsMenu.deselectAllColumns()
        })

        test(`All selected for tab: ${tab.tabName}`, async () => {
          await currentPage.toolbar.metricsMenu.selectAllColumns()
        })

        test(`First item deselected others selected for tab: ${tab.tabName}`, async () => {
          await currentPage.toolbar.metricsMenu.selectAllColumns()
          await currentPage.toolbar.metricsMenu.deselectItemsByIndex(0)
        })

        test.afterEach(`Compare toolbar and toolbar menu before and after page refresh for tab: ${tab.tabName}`,async () => {
          /* todo:for some reasons frontend makes save request with 1 second delayremove that delay after fix EWM30CS-743 */
          await currentPage.page.waitForTimeout(1000)

          const toolbarDataBefore: ToolbarMetricItem[] = []
          const toolbarMetricsMenuDataBefore: CustomizeMenuItem[] = []
          const toolbarDataAfter: ToolbarMetricItem[] = []
          const toolbarMetricsMenuDataAfter: CustomizeMenuItem[] = []

          await test.step(`Get toolbar and toolbar metrics menu data before page refresh`, async () => {
            toolbarDataBefore.push(...await currentPage.toolbar.metricsData())
            toolbarMetricsMenuDataBefore.push(...await currentPage.toolbar.metricsMenu.data())
          })

          await currentPage.page.reload()
          await currentPage.waitPageIsReady()

          await test.step(`Get toolbar and toolbar metrics menu data after page refresh`, async () => {
            toolbarDataAfter.push(...await currentPage.toolbar.metricsData())
            toolbarMetricsMenuDataAfter.push(...await currentPage.toolbar.metricsMenu.data())
          })

          await test.step(`Compare toolbar and toolbar metrics menu data before and after page refresh`, async () => {
            expect.soft(toolbarDataAfter,
              `Assert toolbar data`).toEqual(toolbarDataBefore)
            expect.soft(toolbarMetricsMenuDataAfter,
              `Assert toolbar menu data`).toEqual(toolbarMetricsMenuDataBefore)
          })
        })
      })
    }
  })

  test.describe('Client section. Toolbar - Metrics labels consumed from CMS', () => {
    const testParams = [
      {
        tabName: 'Household tab', currentWebPage: (page:Page) => new ClientSectionHouseholdPage(page)
      },
      {
        tabName: 'Accounts tab', currentWebPage: (page:Page) => new ClientSectionAccountsPage(page)
      },
    ]

    for (const tab of testParams) {
      test(`Metrics labels for tab: ${tab.tabName} consumed from CMS @stable @26519`, async ({page}) => {  
        const toolbarUi: string[] = []
        let toolbarCms: string[] = []
        
        const currentPage = tab.currentWebPage(page)
        await currentPage.goto()
        await currentPage.waitPageIsReady()
        await currentPage.toolbar.metricsMenu.selectAllColumns()

        toolbarUi.push(...await (await currentPage.toolbar.metricsData()).map(item => item.name))
        toolbarCms = await currentPage.returnCmsMetricLabels()
        expect(toolbarUi.slice().sort(), 'Compare UI toolbar metrics with values from CMS').toEqual(toolbarCms.slice().sort())
      })
    }
  })

})
import {expect, test} from '../../../../ewm3/fixtures/base-ui-fixture'
import {EWM3Config} from '../../../../ewm3/service-data/config'
import {HouseholdConfig} from '../../../../ewm3/service-data/client-section-configs/household.config'
import {Filter, FilterType} from '../../../../ewm3/ui/features/client-section/filter/cs.base-filter.feature'

test.describe('Client section. Household filters tests @2378 @stable', () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

  test.beforeEach(async ({ houseHoldPage }) => {
    await houseHoldPage.customizeColumns.selectAllColumns()
    await houseHoldPage.filter.reset()
  })

  test.describe('Table column heading @2370 @4964 @4970', () => {
    for (const field of HouseholdConfig.TABLE_DATA_CONFIG.fields) {
      if (field.enable_filtering && !(field.hidden && !field.enable_hiding)) {
        test(`Single filter: ${field.columnName}`, async ({houseHoldPage}) => {
          const valuesList = await houseHoldPage.returnFromAndToValuesByApiParam(field.apiField)
          const filter = await houseHoldPage.filter.generateFilterValues(field, valuesList)
          await houseHoldPage.table.filter(field).apply(filter)
          const rowsCount = await houseHoldPage.table.getAllMainTableRows().count()
          if (HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig?.fields.find(nestedField => nestedField.columnName === filter.name)!== undefined){
            await houseHoldPage.table.expandNestedTable(rowsCount)
          }
          const table = await houseHoldPage.table.data()
          await houseHoldPage.filter.assertTableIsFiltered(filter, table)
          expect(await houseHoldPage.table.filter(field).locators.openButton.isVisible(), `Expect filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
          expect(await houseHoldPage.filter.locators.openButton.isVisible(), `Expect Multi filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
          await houseHoldPage.filter.checkFilterAmountBadge(1)
        })
      }
    }
    
    for (const field of HouseholdConfig.TABLE_DATA_CONFIG.fields) {
      if (field.enable_filtering && !(field.hidden && !field.enable_hiding)&& field.filterType === FilterType.RANGE) {
        test(`Filter for field: ${field.columnName} doesn't match record value @4971`, async ({houseHoldPage}) => {
          let valuesList
          const nestedFilters = HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig!.fields.filter(field => field.enable_filtering && !(field.hidden && !field.enable_hiding))
          const existingIndex = nestedFilters.findIndex(nestedFilter => nestedFilter.columnName === field.columnName)
          if (existingIndex !== -1) {
            valuesList = await houseHoldPage.returnFromAndToValuesByApiParam(field.apiField, false, true, true)
          } else {
            valuesList = await houseHoldPage.returnFromAndToValuesByApiParam(field.apiField, false, true)
          }
          const filter = await houseHoldPage.filter.generateFilterValues(field, valuesList)
          await houseHoldPage.table.filter(field).apply(filter)
          const rowsCount = await houseHoldPage.table.getAllMainTableRows().count()
          expect(rowsCount===0, `Expect Clients and nested accounts are not displayed for Filter with not existing values`).toBeTruthy()
          await houseHoldPage.filter.validateEmptyState()
          expect(await houseHoldPage.filter.locators.openButton.isVisible(), `Expect Multi filter button is visable after filtering with empty state"`).toBeTruthy()
          await houseHoldPage.filter.checkFilterAmountBadge(1)
        })
      }
    }

    test('All filters @2372 @4972', async ({houseHoldPage}) => {
      await houseHoldPage.replaceResponseWithFilterValues()
      await houseHoldPage.goto()
      await houseHoldPage.waitPageIsReady()
      await houseHoldPage.customizeColumns.selectAllColumns()
      await houseHoldPage.filter.reset()
      let filterAmount = 1
      const filters: Filter[] = []
      for (const field of HouseholdConfig.TABLE_DATA_CONFIG.fields) {
        if (field.enable_filtering && !(field.hidden && !field.enable_hiding)) {
          const valuesList = await houseHoldPage.returnFromAndToValuesByApiParam(field.apiField, true)
          const filter = await houseHoldPage.filter.generateFilterValues(field, valuesList)
          filters.push(filter)
          await houseHoldPage.table.filter(field).apply(filter)
          await houseHoldPage.filter.checkFilterAmountBadge(filterAmount)
          filterAmount ++
        }
      }
      // Check that filter icon is displayed for each filtered column after applying all filters
      for (const field of HouseholdConfig.TABLE_DATA_CONFIG.fields) {
        if (field.enable_filtering && !(field.hidden && !field.enable_hiding)) {
          expect(await houseHoldPage.table.filter(field).locators.openButton.isVisible(), `Expecting filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
        }
      }
      expect(await houseHoldPage.filter.locators.openButton.isVisible(), `Expect Multi filter button is visable after applying All filters`).toBeTruthy()
      const rowsCount = await houseHoldPage.table.getAllMainTableRows().count()
      await houseHoldPage.table.expandNestedTable(rowsCount)
      const nestedRowsCount = await houseHoldPage.table.getAllNestedTableRows().count()
      const table = await houseHoldPage.table.data()
      await houseHoldPage.filter.assertTableIsFiltered(filters, table)
      expect(rowsCount===1, `Expect Client with appropriate data is displayed in filter results`).toBeTruthy()
      expect(nestedRowsCount===1, `Expect nested Account with appropriate data is displayed in filter results`).toBeTruthy()
    })

  })

  test.describe('Multi filter tooltip @2341 @2342 @2346', () => {
    for (const field of HouseholdConfig.TABLE_DATA_CONFIG.fields) {
      if (field.enable_filtering  && !field.hidden  && field.enable_hiding) {
        test(`Single filter: ${field.columnName} @4964 @4970`, async ({houseHoldPage}) => {
          const valuesList = await houseHoldPage.returnFromAndToValuesByApiParam(field.apiField)
          const filter = await houseHoldPage.filter.generateFilterValues(field, valuesList)
          await houseHoldPage.filter.apply(filter)
          const rowsCount = await houseHoldPage.table.getAllMainTableRows().count()
          if (HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig?.fields.find(nestedField => nestedField.columnName === filter.name)!== undefined){
            await houseHoldPage.table.expandNestedTable(rowsCount)
          }
          const table = await houseHoldPage.table.data()
          await houseHoldPage.filter.assertTableIsFiltered(filter, table)
          expect(await houseHoldPage.table.filter(field).locators.openButton.isVisible(), `Expect filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
          expect(await houseHoldPage.filter.locators.openButton.isVisible(), `Expect Multi filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
        })
      }
    }

    for (const field of HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig!.fields) {
      if (field.enable_filtering  && !field.hidden) {
        test(`Single filter Nested table: ${field.columnName} @2343`, async ({houseHoldPage}) => {
          const valuesList = await houseHoldPage.returnFromAndToValuesByApiParam(field.apiField, false, false, true)
          const filter = await houseHoldPage.filter.generateFilterValues(field, valuesList)
          await houseHoldPage.filter.apply(filter)
          const rowsCount = await houseHoldPage.table.getAllMainTableRows().count()
          await houseHoldPage.table.expandNestedTable(rowsCount)
          const table = await houseHoldPage.table.data()
          await houseHoldPage.filter.assertTableIsFiltered(filter, table)
          expect(await houseHoldPage.table.filter(field).locators.openButton.isVisible(), `Expect filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
          expect(await houseHoldPage.filter.locators.openButton.isVisible(), `Expect Multi filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
        })
      }
    }

    test('All filters @4972', async ({houseHoldPage}) => {
      const allFilters: Filter[] = []
      const mainTableFilters: Filter[] = []
      const nestedTableFilters: Filter[] = []
      await houseHoldPage.replaceResponseWithFilterValues()
      await houseHoldPage.goto()
      await houseHoldPage.waitPageIsReady()
      await houseHoldPage.customizeColumns.selectAllColumns()
      await houseHoldPage.filter.reset()
      for (const field of HouseholdConfig.TABLE_DATA_CONFIG.fields) {
        if (field.enable_filtering && !(field.hidden && !field.enable_hiding)) {
          const valuesList = await houseHoldPage.returnFromAndToValuesByApiParam(field.apiField, true, false)
          const filter = await houseHoldPage.filter.generateFilterValues(field, valuesList)
          mainTableFilters.push(filter)
        }
      }
      allFilters.push(...mainTableFilters)
      for (const field of HouseholdConfig.TABLE_DATA_CONFIG.nestedTableDataConfig!.fields) {
        if (field.enable_filtering && !(field.hidden && !field.enable_hiding)) {
          const valuesList = await houseHoldPage.returnFromAndToValuesByApiParam(field.apiField, true, false, true)
          const filter = await houseHoldPage.filter.generateFilterValues(field, valuesList)
          nestedTableFilters.push(filter)
          
          const existingIndex = allFilters.findIndex(existFilter => existFilter.name === filter.name)
          if (existingIndex !== -1) {
            allFilters[existingIndex] = filter
          } else {
            allFilters.push(filter)
          }
        }
      }

      await houseHoldPage.filter.apply(allFilters)
      const rowsCount = await houseHoldPage.table.getAllMainTableRows().count()
      await houseHoldPage.table.expandNestedTable(rowsCount)
      const nestedRowsCount = await houseHoldPage.table.getAllNestedTableRows().count()
      const table = await houseHoldPage.table.data()
      await houseHoldPage.filter.assertTableIsFiltered(mainTableFilters, table)
      // Check that filter icon is displayed for each filtered column after applying all filters
      for (const field of HouseholdConfig.TABLE_DATA_CONFIG.fields) {
        if (field.enable_filtering && !(field.hidden && !field.enable_hiding)) {
          expect(await houseHoldPage.table.filter(field).locators.openButton.isVisible(), `Expecting filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
        }
      }
      expect(await houseHoldPage.filter.locators.openButton.isVisible(), `Expect Multi filter button is visable after after applying All filters`).toBeTruthy()
      expect(rowsCount===1, `Expect Client with appropriate data is displayed in filter results`).toBeTruthy()
      expect(nestedRowsCount===1, `Expect nested Account with appropriate data is displayed in filter results`).toBeTruthy()
    })
  })

  test.describe('Header + multifilter tests @2376', () => {
    for (const field of HouseholdConfig.TABLE_DATA_CONFIG.fields) {
      if (field.enable_filtering && !(field.hidden && !field.enable_hiding)) {
        test(`Header. Closing panel without saving for filter: ${field.columnName}`, async ({houseHoldPage}) => {
          const initialTable = await houseHoldPage.table.data()
          const valuesList = await houseHoldPage.returnFromAndToValuesByApiParam(field.apiField)
          const filter = await houseHoldPage.filter.generateFilterValues(field, valuesList)
          // Sets filter through header but does not click apply
          await houseHoldPage.table.filter(field).setFilter(filter)
          await houseHoldPage.footer.clickAssetMarkLogo()
          const afterTable = await houseHoldPage.table.data()
          await houseHoldPage.table.assertTableMatches(initialTable, afterTable)
          await expect(houseHoldPage.filter.locators.filterCountBadge).not.toBeVisible()
        })
        
        test(`Multifilter. Closing panel without saving for filter: ${field.columnName}`, async ({houseHoldPage}) => {
          const initialTable = await houseHoldPage.table.data()
          const valuesList = await houseHoldPage.returnFromAndToValuesByApiParam(field.apiField)
          const filter = await houseHoldPage.filter.generateFilterValues(field, valuesList)
          // Sets filter though multifilter tooltip but does not click apply
          await houseHoldPage.filter.setFilter(filter)
          await houseHoldPage.footer.clickAssetMarkLogo()
          const afterTable = await houseHoldPage.table.data()
          await houseHoldPage.table.assertTableMatches(initialTable, afterTable)
          await expect(houseHoldPage.filter.locators.filterCountBadge).not.toBeVisible()
        })
      }
    }

    test(`Add column filter to applied multifilter @2373`, async ({houseHoldPage}) => {
      const filters: Filter[] = []
      const filterFields = HouseholdConfig.TABLE_DATA_CONFIG.fields.filter(field => field.enable_filtering && !(field.hidden && !field.enable_hiding))

      const firstFilterField = filterFields.find(field => field.columnName === HouseholdConfig.COLUMN_NAMES.advisor_id)??filterFields[0]
      const firstIndex = filterFields.indexOf(firstFilterField)
      const secondIndex = firstIndex===(filterFields.length-1)?0:firstIndex + 1
      const secondFilterField = filterFields.find(field => field.columnName === HouseholdConfig.COLUMN_NAMES.market_value)??filterFields[secondIndex]
     
      let valuesList = await houseHoldPage.returnFromAndToValuesByApiParam(firstFilterField.apiField)
      let filter = await houseHoldPage.filter.generateFilterValues(firstFilterField, valuesList)
      filters.push(filter)
      await houseHoldPage.filter.apply(filter)

      valuesList = await houseHoldPage.returnFromAndToValuesByApiParam(secondFilterField.apiField)
      filter = await houseHoldPage.filter.generateFilterValues(secondFilterField, valuesList)
      filters.push(filter)
      await houseHoldPage.table.filter(secondFilterField).apply(filter)

      const rowsCount = await houseHoldPage.table.getAllMainTableRows().count()
      await houseHoldPage.table.expandNestedTable(rowsCount)
      const table = await houseHoldPage.table.data()
      await houseHoldPage.filter.assertTableIsFiltered(filters, table)
      await houseHoldPage.filter.checkFilterAmountBadge(2)
      // Check that filter icon is displayed for each filtered column after applying all filters
      for (const field of [firstFilterField, secondFilterField]) {
        expect(await houseHoldPage.table.filter(field).locators.openButton.isVisible(), `Expecting filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
      }
    })
  })

})

import {expect, test} from '../../../../ewm3/fixtures/base-ui-fixture'
import {EWM3Config} from '../../../../ewm3/service-data/config'
import {Filter, FilterType} from '../../../../ewm3/ui/features/client-section/filter/cs.base-filter.feature'
import {AccountsConfig} from '../../../../ewm3/service-data/client-section-configs/accounts.config'

test.describe('Client section. Accounts filters tests @stable', () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

  test.beforeEach(async ({ accountsPage }) => {
    await accountsPage.customizeColumns.selectAllColumns()
    await accountsPage.filter.reset()
  })

  test.describe('Table column heading @2371', () => {
    for (const field of AccountsConfig.TABLE_DATA_CONFIG.fields) {
      if (field.enable_filtering && !(field.hidden && !field.enable_hiding)) {
        test(`Single filter: ${field.columnName}`, async ({accountsPage}) => {
          const valuesList = await accountsPage.returnFromAndToValuesByApiParam(field.apiField)
          const filter = await accountsPage.filter.generateFilterValues(field, valuesList)
          await accountsPage.table.filter(field).apply(filter)
          const table = await accountsPage.table.data()
          await accountsPage.filter.assertTableIsFiltered(filter, table)
          expect(await accountsPage.table.filter(field).locators.openButton.isVisible(), `Expect filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
          expect(await accountsPage.filter.locators.openButton.isVisible(), `Expect Multi filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
          await accountsPage.filter.checkFilterAmountBadge(1)
        })
      }
    }

    for (const field of AccountsConfig.TABLE_DATA_CONFIG.fields) {
      if (field.enable_filtering && !(field.hidden && !field.enable_hiding)&& field.filterType === FilterType.RANGE) {
        test(`Filter for field: ${field.columnName} doesn't match record value @4971`, async ({accountsPage}) => {
          const valuesList = await accountsPage.returnFromAndToValuesByApiParam(field.apiField, false, true)
          const filter = await accountsPage.filter.generateFilterValues(field, valuesList)
          await accountsPage.table.filter(field).apply(filter)
          const rowsCount = await accountsPage.table.getAllMainTableRows().count()
          expect(rowsCount===0, `Expect Accounts are not displayed for Filter with not existing values`).toBeTruthy()
          await accountsPage.filter.validateEmptyState()
          expect(await accountsPage.filter.locators.openButton.isVisible(), `Expect Multi filter button is visable after filtering with empty state"`).toBeTruthy()
          await accountsPage.filter.checkFilterAmountBadge(1)
        })
      }
    }
  
    test('All filters @2372', async ({accountsPage}) => {
      await accountsPage.replaceResponseWithFilterValues()
      await accountsPage.goto()
      await accountsPage.waitPageIsReady()
      await accountsPage.customizeColumns.selectAllColumns()
      await accountsPage.filter.reset()
      let filterAmount = 1
      const filters: Filter[] = []
      for (const field of AccountsConfig.TABLE_DATA_CONFIG.fields) {
        if (field.enable_filtering && !(field.hidden && !field.enable_hiding)) {
          const valuesList = await accountsPage.returnFromAndToValuesByApiParam(field.apiField, true)
          const filter = await accountsPage.filter.generateFilterValues(field, valuesList)
          filters.push(filter)
          await accountsPage.table.filter(field).apply(filter)
          await accountsPage.filter.checkFilterAmountBadge(filterAmount)
          filterAmount ++
        }
      }
      // Check that filter icon is displayed for each filtered column after applying all filters
      for (const field of AccountsConfig.TABLE_DATA_CONFIG.fields) {
        if (field.enable_filtering && !(field.hidden && !field.enable_hiding)) {
          expect(await accountsPage.table.filter(field).locators.openButton.isVisible(), `Expecting filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
        }
      }
      expect(await accountsPage.filter.locators.openButton.isVisible(), `Expect Multi filter button is visable after applying All filters`).toBeTruthy()
      const table = await accountsPage.table.data()
      const rowsCount = table.length
      await accountsPage.filter.assertTableIsFiltered(filters, table)
      expect(rowsCount===1, `Expect Account with appropriate data is displayed in filter results`).toBeTruthy()
    })
  })

  test.describe('All filters tooltip @2341 @2342 @2346', () => {
    for (const field of AccountsConfig.TABLE_DATA_CONFIG.fields) {
      if (field.enable_filtering  && !(field.hidden && !field.enable_hiding)) {
        test(`Single filter: ${field.columnName} @2343`, async ({accountsPage}) => {
          const valuesList = await accountsPage.returnFromAndToValuesByApiParam(field.apiField)
          const filter = await accountsPage.filter.generateFilterValues(field, valuesList)
          await accountsPage.filter.apply(filter)
          const table = await accountsPage.table.data()
          await accountsPage.filter.assertTableIsFiltered(filter, table)
          expect(await accountsPage.table.filter(field).locators.openButton.isVisible(), `Expect filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
          expect(await accountsPage.filter.locators.openButton.isVisible(), `Expect Multi filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
        })
      }
    }

    test('All filters', async ({accountsPage}) => {
      await accountsPage.replaceResponseWithFilterValues()
      await accountsPage.goto()
      await accountsPage.waitPageIsReady()
      await accountsPage.customizeColumns.selectAllColumns()
      await accountsPage.filter.reset()
      const filters: Filter[] = []
      for (const field of AccountsConfig.TABLE_DATA_CONFIG.fields) {
        if (field.enable_filtering && !(field.hidden && !field.enable_hiding)) {
          const valuesList = await accountsPage.returnFromAndToValuesByApiParam(field.apiField, true)
          const filter = await accountsPage.filter.generateFilterValues(field,valuesList)
          filters.push(filter)
        }
      }
      await accountsPage.filter.apply(filters)
      const table = await accountsPage.table.data()
      const rowsCount = table.length
      await accountsPage.filter.assertTableIsFiltered(filters, table)
      // Check that filter icon is displayed for each filtered column after applying all filters
      for (const field of AccountsConfig.TABLE_DATA_CONFIG.fields) {
        if (field.enable_filtering && !(field.hidden && !field.enable_hiding)) {
          expect(await accountsPage.table.filter(field).locators.openButton.isVisible(), `Expecting filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
        }
      }
      expect(await accountsPage.filter.locators.openButton.isVisible(), `Expect Multi filter button is visable after after applying All filters`).toBeTruthy()
      expect(rowsCount===1, `Expect Account with appropriate data is displayed in filter results`).toBeTruthy()
    })
  })

  test.describe('Header + multifilter tests @2376', () => {
    for (const field of AccountsConfig.TABLE_DATA_CONFIG.fields) {
      if (field.enable_filtering && !(field.hidden && !field.enable_hiding)) {
        test(`Header. Closing panel without saving for filter: ${field.columnName}`, async ({accountsPage}) => {
          const initialTable = await accountsPage.table.data()
          const valuesList = await accountsPage.returnFromAndToValuesByApiParam(field.apiField)
          const filter = await accountsPage.filter.generateFilterValues(field, valuesList)
          // Sets filter through header but does not click apply
          await accountsPage.table.filter(field).setFilter(filter)
          await accountsPage.footer.clickAssetMarkLogo()
          const afterTable = await accountsPage.table.data()
          await accountsPage.table.assertTableMatches(initialTable, afterTable)
          await expect(accountsPage.filter.locators.filterCountBadge).not.toBeVisible()
        })
        
        test(`Multifilter. Closing panel without saving for filter: ${field.columnName}`, async ({accountsPage}) => {
          const initialTable = await accountsPage.table.data()
          const valuesList = await accountsPage.returnFromAndToValuesByApiParam(field.apiField)
          const filter = await accountsPage.filter.generateFilterValues(field, valuesList)
          // Sets filter though multifilter tooltip but does not click apply
          await accountsPage.filter.setFilter(filter)
          await accountsPage.footer.clickAssetMarkLogo()
          const afterTable = await accountsPage.table.data()
          await accountsPage.table.assertTableMatches(initialTable, afterTable)
          await expect(accountsPage.filter.locators.filterCountBadge).not.toBeVisible()
        })
      }
    }

    test(`Add column filter to applied multifilter @2373`, async ({accountsPage}) => {
      const filters: Filter[] = []
      const filterFields = AccountsConfig.TABLE_DATA_CONFIG.fields.filter(field => field.enable_filtering && !(field.hidden && !field.enable_hiding))

      const firstFilterField = filterFields.find(field => field.columnName === AccountsConfig.COLUMN_NAMES.advisor_id)??filterFields[0]
      const firstIndex = filterFields.indexOf(firstFilterField)
      const secondIndex = firstIndex===(filterFields.length-1)?0:firstIndex + 1
      const secondFilterField = filterFields.find(field => field.columnName === AccountsConfig.COLUMN_NAMES.market_value)??filterFields[secondIndex]
     
      let valuesList = await accountsPage.returnFromAndToValuesByApiParam(firstFilterField.apiField)
      let filter = await accountsPage.filter.generateFilterValues(firstFilterField, valuesList)
      filters.push(filter)
      await accountsPage.filter.apply(filter)
      valuesList = await accountsPage.returnFromAndToValuesByApiParam(secondFilterField.apiField)
      filter = await accountsPage.filter.generateFilterValues(secondFilterField, valuesList)
      filters.push(filter)
      await accountsPage.table.filter(secondFilterField).apply(filter)
      const table = await accountsPage.table.data()
      await accountsPage.filter.assertTableIsFiltered(filters, table)
      await accountsPage.filter.checkFilterAmountBadge(2)
      // Check that filter icon is displayed for each filtered column after applying all filters
      for (const field of [firstFilterField, secondFilterField]) {
        expect(await accountsPage.table.filter(field).locators.openButton.isVisible(), `Expecting filter button is visable after filtering for column "${field.columnName}"`).toBeTruthy()
      }
    })
  })

})
import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { EWM3Config } from '../../../../ewm3/service-data/config'
import { BicConfig } from '../../../../ewm3/service-data/tile-config/bic.config'
import { BicAccountsForSuitabilityMock } from '../../../../ewm3/ui/mocks/bic-accounts-for-suitability-mock'
import { BicAdvisorsMock } from '../../../../ewm3/ui/mocks/bic-advisors-mock'
import { BicInvestmentChangeMock } from '../../../../ewm3/ui/mocks/bic-investmentchange-mock'
import { BicInvestmentsStrategyMock } from '../../../../ewm3/ui/mocks/bic-investments-strategy-mock'
import { BicProductsForSuitabilityMock } from '../../../../ewm3/ui/mocks/bic-products-for-suitability-mock'
import { BicSuitabilityCheckMock } from '../../../../ewm3/ui/mocks/bic-suitabilitycheck-mock'

test.describe('BIC tests', 
  { tag: [ '@stable' ] }, () => { 
    test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})
    test.use({ viewport: { width: 1440, height: 885 } })

    test.describe('Suitability Check modal window with part of a mock data', () => {

      test.beforeEach(async ({page}) => { 
        await page.route('**/advisormetrics/api/v2/metrics/advisors', async route => {
          await route.fulfill({ json: BicAdvisorsMock.data })
        })
        await page.route((url: URL) => url.toString().includes('/advisormetrics/api/v2/metrics/investments/strategy'), async route => {
          await route.fulfill({ json: BicInvestmentsStrategyMock.data })
        })
        await page.route((url: URL) => url.toString().includes('/proposal/api/v1/bic/products'), async route => {
          await route.fulfill({ json: BicProductsForSuitabilityMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts', async route => {
          await route.fulfill({ json: BicAccountsForSuitabilityMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts/suitabilitycheck', async route => {
          await route.fulfill({ json: BicSuitabilityCheckMock.data })
        })
      })
      test.beforeEach(async ({bicPage}) => { 
        await test.step(`Choosing first strategy in main table and moving to the next window up to Suitability Check modal`, async () => {
          await bicPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTable()
        }) 
      })
      test(`Suitability Check modal`, 
        { tag: ['@3821', '@3829', '@3830'] }, async ({bicPage}) => {  
          let accountsNameFromAccountsTabData: string[]

          await test.step(`Selecting up to 4 eligible accounts, saving accounts names from table and starting Review then`, async () => { 
            const tableDataOnAccountsTab = await bicPage.accountsToChangeWidget.table.data()
            const selectedAccountsIndexes = await bicPage.accountsToChangeWidget.table.accountsCheckboxes(1, 'check')
            accountsNameFromAccountsTabData = await bicPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataOnAccountsTab, BicConfig.accountsToChangeColumnNames.accountTitle, selectedAccountsIndexes)

            await bicPage.accountsToChangeWidget.reviewButton.click()
          })
          await test.step(`Suitability Check modal elements visibility`, async () => {
            await expect(bicPage.suitabilityCheckWidget.title).toHaveText('Suitability Check In Progress')
            await expect(bicPage.suitabilityCheckWidget.description).toHaveText('Checking Client Suitability based on the New Investment Risk Profile. This may take a few moments.')
            await expect(bicPage.suitabilityCheckWidget.xButton).toBeVisible()
            await expect(bicPage.suitabilityCheckWidget.progressBar).toBeVisible()
            await expect(bicPage.suitabilityCheckWidget.cancelButton).toBeVisible()
          }) 
          await test.step(`Close Suitability Check modal window by X botton and check visibility of the Accounts to Change window title`, async () => {
            await bicPage.suitabilityCheckWidget.xButton.click()
            await expect(bicPage.accountsToChangeWidget.title).toBeVisible()
          })
          await test.step(`Assert that all previously selected Accounts on the page are selected after closing Suitability Check window`, async () => { 
            await bicPage.accountsToChangeWidget.movingToSpecificTab(bicPage.accountsToChangeWidget.selectedAccountsTab)
            const tableDataOfAllSelectedAccounts = await bicPage.accountsToChangeWidget.table.data()
            const accontsNameDataOfAllSelectedAccounts = await bicPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataOfAllSelectedAccounts, BicConfig.accountsToChangeColumnNames.accountTitle)
        
            expect(accountsNameFromAccountsTabData, 'Verify that all previously selected Accounts on the page are selected').toEqual(accontsNameDataOfAllSelectedAccounts)
          })
        })
      test(`Suitability Check modal - Canceling Suitability`, 
        { tag: ['@3828'] }, async ({bicPage}) => {

          await test.step(`Canceling Suitability and returning to Accounts to Change window`, async () => { 
            await bicPage.accountsToChangeWidget.table.accountsCheckboxes(10, 'check')
            await bicPage.accountsToChangeWidget.reviewButton.click()
            await expect(bicPage.suitabilityCheckWidget.title).toHaveText('Suitability Check In Progress')
            await bicPage.suitabilityCheckWidget.cancelButton.click()
            await bicPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady()
          })
        })
   
    })

    test.describe('Suitability Check modal window with full mock data', () => {
      test.beforeEach(async ({page}) => { 
        await page.route('**/advisormetrics/api/v2/metrics/advisors', async route => {
          await route.fulfill({ json: BicAdvisorsMock.data })
        })
        await page.route((url: URL) => url.toString().includes('/advisormetrics/api/v2/metrics/investments/strategy'), async route => {
          await route.fulfill({ json: BicInvestmentsStrategyMock.data })
        })
        await page.route((url: URL) => url.toString().includes('/proposal/api/v1/bic/products'), async route => {
          await route.fulfill({ json: BicProductsForSuitabilityMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts', async route => {
          await route.fulfill({ json: BicAccountsForSuitabilityMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts/suitabilitycheck', async route => {
          await route.fulfill({ json: BicSuitabilityCheckMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts/investmentchange', async route => {
          await route.fulfill({ json: BicInvestmentChangeMock.data })
        })
      })
      test.beforeEach(async ({bicPage}) => { 
        await test.step(`Choosing first strategy in main table and moving to the next window up to Suitability Check modal`, async () => {
          await bicPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTable()
        }) 
      })

      test(`Suitability Check modal - Progress bar. Verifing accounts statuses after Suitability fails`, 
        { tag: ['@3822', '@3823', '@5511'] }, async ({bicPage}) => {

          await test.step(`Selecting some accounts, starting Review and verifying Progress Bar increment and remaining it for 3 sec on the screen after check is finished`, async () => { 
            await bicPage.accountsToChangeWidget.table.accountsCheckboxes(10, 'check')
            await bicPage.accountsToChangeWidget.reviewButton.click()
            await expect(bicPage.suitabilityCheckWidget.title).toHaveText('Suitability Check In Progress')
            await bicPage.suitabilityCheckWidget.verifyProgressBarIncrement() 
          })
          await test.step(`Verify accounts statuses after Suitability fails`, async () => { 
            const tableDataAfterSuitability = await bicPage.accountsToChangeWidget.table.data() 
            const ineligibleAccountsIndexes = await bicPage.accountsToChangeWidget.table.ineligibleAccountsIndexes()
            await bicPage.accountsToChangeWidget.table.verifyAccountsStatuses(tableDataAfterSuitability, ineligibleAccountsIndexes, `Not suitable for client's risk profile`)
          })
        })
    })

  })
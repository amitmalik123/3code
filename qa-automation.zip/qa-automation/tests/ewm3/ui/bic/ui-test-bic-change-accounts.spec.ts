import { faker } from '@faker-js/faker'
import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { EWM3Config } from '../../../../ewm3/service-data/config'
import { GeneralStyles } from '../../../../ewm3/service-data/generalStyles'
import { BicConfig } from '../../../../ewm3/service-data/tile-config/bic.config'
import { TableRow } from '../../../../ewm3/ui/features/table.feature'
import { BicAccountsForExportMock } from '../../../../ewm3/ui/mocks/bic-accounts-for-export-mock'
import { BicAccountsForSuitabilityMock } from '../../../../ewm3/ui/mocks/bic-accounts-for-suitability-mock'
import { BicAdvisorsMock } from '../../../../ewm3/ui/mocks/bic-advisors-mock'
import { BicChangeAccountsMock } from '../../../../ewm3/ui/mocks/bic-change-accounts-mock'
import { BicChangeAccountsNoSuitabilityMock } from '../../../../ewm3/ui/mocks/bic-change-accounts-no-suitability-mock'
import { BicInvestmentChangeMock } from '../../../../ewm3/ui/mocks/bic-investmentchange-mock'
import { BicInvestmentsStrategyMock } from '../../../../ewm3/ui/mocks/bic-investments-strategy-mock'
import { BicProductsForSuitabilityMock } from '../../../../ewm3/ui/mocks/bic-products-for-suitability-mock'
import { BicSelectInvestmentMock } from '../../../../ewm3/ui/mocks/bic-select-investment-mock'
import { BicSuitabilityCheckMock } from '../../../../ewm3/ui/mocks/bic-suitabilitycheck-mock'
import { BicSuitabilityCheckNoSuitabilityMock } from '../../../../ewm3/ui/mocks/bic-suitabilitycheck-no-suitability-mock'
import { UiElementsStylesAssert, UiTextStylesAssert } from '../../../../utils/UIComponentsStateAssert'
import { SearchTrigger } from '../../../../ewm3/ui/features/search.feature'
import { BicChangeAccountsStatusesMock } from '../../../../ewm3/ui/mocks/bic-change-accounts-statuses-mock'

test.describe('BIC tests', 
  { tag: [ '@stable' ] }, () => { 
    test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})
    test.use({ viewport: { width: 1440, height: 885 } })

    test.describe('Opening Accounts to Change modal window', () => {

      test.describe('Opening Accounts to Change modal window via choosing first strategy in the main table', () => {
        test.beforeEach(async ({page}) => {
          await page.route('**/proposal/api/v1/bic/products', async route => {
            await route.fulfill({ json: BicSelectInvestmentMock.data })
          })
          await page.route('**/proposal/api/v1/bic/accounts', async route => {
            await route.fulfill({ json: BicChangeAccountsMock.data })
          })
        })

        test.beforeEach(async ({bicPage}) => {
          await test.step(`Choosing first strategy in main table and moving to the next window`, async () => {
            await bicPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTable()
          })
        })
        test(`Opening Accounts to Change modal window and returning to previous window`,
          { tag: ['@3126', '@3335'] }, async ({bicPage}) => {

            await test.step(`Returning to Destination Investment window and asserting strategy selection`, async () => {
              await bicPage.accountsToChangeWidget.backButton.click() 
              await bicPage.destinationInvestmentWidget.table.assertRadioButtonOnMainTableIsChecked(0)
            })
            await test.step(`Changing strategy selection and asserting the new name on Accounts to Change window @3338`, async () => {
              await bicPage.destinationInvestmentWidget.table.checkRadioButtonOnMainTable(1) 
              const headerToStrategyNameOnDestinationInvestmentWindow = await bicPage.getHeaderToStrategyName()
  
              await bicPage.destinationInvestmentWidget.nextButton.click()
              await bicPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady()
  
              const headerToStrategyNameOnChangeAccountsWindow = await bicPage.getHeaderToStrategyName()
              expect(headerToStrategyNameOnChangeAccountsWindow).toEqual(headerToStrategyNameOnDestinationInvestmentWindow)
            })
          })
        test(`Save selecting of accounts without strategy changing. Unselected state - Error notification `, 
          { tag: ['@3340', '@5227'] }, async ({bicPage}) => {
            let selectedAccountsIndexes: number[]
    
            await test.step(`Verify Error notification text, design and animation time`, async () => {
              await bicPage.accountsToChangeWidget.reviewButton.click({ force: true }) 

              await expect(bicPage.accountsToChangeWidget.errorTooltipIcon, 'Verify error notification icon visibility').toBeVisible()
              await expect(bicPage.accountsToChangeWidget.errorTooltip, 'Verify error notification text').toHaveText('Select an Account to proceed.')
              
              await UiElementsStylesAssert.backgroundColor(GeneralStyles.colorNeutral800, bicPage.accountsToChangeWidget.errorTooltip) 
  
              await UiTextStylesAssert.fontSize(bicPage.accountsToChangeWidget.errorTooltipText, GeneralStyles.fontSize14)  
              await UiTextStylesAssert.fontName(bicPage.accountsToChangeWidget.errorTooltipText, GeneralStyles.fontFamilyRobotoSansSerif)
              await UiTextStylesAssert.fontWeight(bicPage.accountsToChangeWidget.errorTooltipText, GeneralStyles.fontLightBold)   
              await UiTextStylesAssert.fontColor(bicPage.accountsToChangeWidget.errorTooltipText, GeneralStyles.colorWhite)
  
              await expect(bicPage.accountsToChangeWidget.errorTooltip, 'Assert that error notification is visible').toBeVisible()
              await expect(bicPage.accountsToChangeWidget.errorTooltip, 'Assert that error notification is hidden after 3 seconds of visibility (approximately)').toBeHidden({timeout: 4000}) //Notification is 3 sec on the screen, additional 1 sec goes on animation
            
            })
            await test.step(`Selecting two first eligible accounts and returning back to Destination Investment window`, async () => {
              selectedAccountsIndexes = await bicPage.accountsToChangeWidget.table.accountsCheckboxes(2, 'check')
              await bicPage.accountsToChangeWidget.backButton.click()
            })
            await test.step(`Returning to Accounts to Change window and asserting selected accounts`, async () => {
              await bicPage.destinationInvestmentWidget.nextButton.click()
              await bicPage.accountsToChangeWidget.table.assertAccountsSelection('check', selectedAccountsIndexes) 
            })
          })
        test(`Ineligible accounts saved when strategy isn't changed`, 
          { tag: ['@3341'] }, async ({bicPage}) => {
            let ineligibleAccountsIndexesFirstTimeWindowOpening: number[]
       
            await test.step(`Saving row indexes of Ineligible accounts and returning back to Destination Investment window`, async () => {
              ineligibleAccountsIndexesFirstTimeWindowOpening = await bicPage.accountsToChangeWidget.table.ineligibleAccountsIndexes()
              await bicPage.accountsToChangeWidget.backButton.click()
            })
            await test.step(`Returning to Accounts to Change window and asserting Ineligible accounts indexes`, async () => {
              await bicPage.destinationInvestmentWidget.nextButton.click()
              expect(await bicPage.accountsToChangeWidget.table.ineligibleAccountsIndexes()).
                toEqual(ineligibleAccountsIndexesFirstTimeWindowOpening)
            })
          })
        test(`Select Accounts to Change - Visible components`, 
          { tag: ['@3975'] }, async ({bicPage}) => {
    
            await test.step(`Assert title text and X button visibility`, async () => {
              await expect(bicPage.accountsToChangeWidget.title).toHaveText('Select Your Accounts to Change')
              await expect(bicPage.accountsToChangeWidget.xButton).toBeVisible()
            })
            await test.step(`Assert static text in left part of header`, async () => {
              await expect(bicPage.accountsToChangeWidget.header.getByText('From:')).toBeVisible()
              await expect(bicPage.accountsToChangeWidget.header.getByText('Current Platform Fee:')).toBeVisible()
            })
            await test.step(`Assert static text in right part of header`, async () => {
              await expect(bicPage.accountsToChangeWidget.header.getByText('To:')).toBeVisible()
              await expect(bicPage.accountsToChangeWidget.header.getByText('New Platform Fee:')).toBeVisible() 
            })
            await test.step(`Assert accounts counters background color`, async () => {
              await UiElementsStylesAssert.backgroundColor(GeneralStyles.colorPrimaryDark, bicPage.accountsToChangeWidget.accountsCounters.first()) 
              await UiElementsStylesAssert.backgroundColor(GeneralStyles.colorPrimaryDark, bicPage.accountsToChangeWidget.accountsCounters.nth(1))
              await UiElementsStylesAssert.backgroundColor(GeneralStyles.colorWarningMain, bicPage.accountsToChangeWidget.accountsCounters.nth(2))
            })
            await test.step(`Assert search field and export button visibility`, async () => {
              await expect(bicPage.accountsToChangeWidget.search.locators.searchBox).toBeVisible()
              await expect(bicPage.accountsToChangeWidget.search.locators.magnifyingGlassButton).toBeVisible()
              await expect(bicPage.accountsToChangeWidget.exportButton).toBeVisible() 
            })
            await test.step(`Assert table header titles text`, async () => {
              await expect(bicPage.accountsToChangeWidget.accountTitle).toHaveText(BicConfig.accountsToChangeColumnNames.accountTitle)
              await expect(bicPage.accountsToChangeWidget.status).toHaveText(BicConfig.accountsToChangeColumnNames.status)
              await expect(bicPage.accountsToChangeWidget.regType).toHaveText(BicConfig.accountsToChangeColumnNames.regType)
              await expect(bicPage.accountsToChangeWidget.accountNumber).toHaveText(BicConfig.accountsToChangeColumnNames.accountNumber)
              await expect(bicPage.accountsToChangeWidget.tms).toHaveText(BicConfig.accountsToChangeColumnNames.tms)
              await expect(bicPage.accountsToChangeWidget.amountAllocated).toHaveText(BicConfig.accountsToChangeColumnNames.amountAllocated)
              await expect(bicPage.accountsToChangeWidget.allocated).toHaveText(BicConfig.accountsToChangeColumnNames.allocated)
            })
            await test.step(`Assert Pagination panel visibility`, async () => {
              await expect(bicPage.accountsToChangeWidget.pagination.locators.amount).toBeVisible() 
              await expect(bicPage.accountsToChangeWidget.pagination.locators.currentPageNumberButton).toBeVisible() 
            })
          })
      })
      test(`Nested strategy selection remains in Accounts to Change modal window after returning`, 
        { tag: ['@3336'] }, async ({bicPage}) => {

          await test.step(`Choosing first strategy in nested table and moving to next window`, async () => {
            await bicPage.accountsToChangeWidget.openAccountsToChangeWindowViaNestedTable()
          })
          await test.step(`Returning to Destination Investment window and asserting nested strategy selection`, async () => {
            await bicPage.accountsToChangeWidget.backButton.click()
            await bicPage.destinationInvestmentWidget.table.assertNestedTableClosed(0) 
            await bicPage.destinationInvestmentWidget.table.expandNestedTable() 
            await bicPage.destinationInvestmentWidget.table.assertRadioButtonOnNestedTableIsChecked(0, 0)
          })
        })
      
    })
    test.describe('Tests with predifined mock data on Destination Investment window', () => {
      test.beforeEach(async ({page}) => {
        await page.route('**/proposal/api/v1/bic/products', async route => {
          await route.fulfill({ json: BicSelectInvestmentMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts', async route => {
          await route.fulfill({ json: BicChangeAccountsMock.data })
        })
      })
      test(`Selecting Strategy on second page and retaining it after returning from Accounts to Change window`, 
        { tag: ['@3337'] }, async ({bicPage}) => {
          let headerToStrategyNameOnChangeAccountsWindow: string

          await test.step(`Choosing first strategy in main table on second page, saving it name from header and moving to next window`, async () => {
            await bicPage.destinationInvestmentWidget.pagination.nextPage()
            await bicPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTable()
            headerToStrategyNameOnChangeAccountsWindow = await bicPage.getHeaderToStrategyName()
          })
          await test.step(`Returning to Destination Investment window and asserting strategy name selection and first page location`, async () => {
            await bicPage.accountsToChangeWidget.backButton.click() 
            await bicPage.destinationInvestmentWidget.pagination.assertCurrentPageNumber(1)
            expect(headerToStrategyNameOnChangeAccountsWindow).toEqual(await bicPage.getHeaderToStrategyName())
          })
        })
      test(`Unselected accounts in Selected Accounts tab should no longer display in Selected tab`, 
        { tag: ['@3568'] }, async ({bicPage}) => {  
          let unselectAccountsNameFromSelectedAccountsTab: string[]

          await test.step(`Choosing first strategy in main table and moving to the next window`, async () => {
            await bicPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTable()
          })
          await test.step(`Selecting up to 10 eligible accounts and going to Selected Accounts tab`, async () => {
            await bicPage.accountsToChangeWidget.table.accountsCheckboxes(10, 'check')
            await bicPage.accountsToChangeWidget.movingToSpecificTab(bicPage.accountsToChangeWidget.selectedAccountsTab)
          }) 
          await test.step(`Assert that Accounts should display as unselected, but remain in the table after unselecting`, async () => {
            const tableDataBeforeUnselecting = await bicPage.accountsToChangeWidget.table.data()
            const unselectAccountsIndexes = await bicPage.accountsToChangeWidget.table.accountsCheckboxes(3, 'uncheck')
            const tableDataAfterUnselecting = await bicPage.accountsToChangeWidget.table.data()
            unselectAccountsNameFromSelectedAccountsTab = await bicPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataAfterUnselecting, BicConfig.accountsToChangeColumnNames.accountTitle, unselectAccountsIndexes)
  
            expect(tableDataBeforeUnselecting, 'Verify that Accounts should display as unselected, but remain in the table after unselecting').toEqual(tableDataAfterUnselecting)
          })
          await test.step(`Returning to Accounts tab and assert that unselected previously accounts is not selected in this tab as well`, async () => {
            await bicPage.accountsToChangeWidget.movingToSpecificTab(bicPage.accountsToChangeWidget.accountsTab)
  
            const tableDataOnAccountsTab = await bicPage.accountsToChangeWidget.table.data() 
            const unselectAccountsNameFromSelectedAccountsTabIndexes = await bicPage.accountsToChangeWidget.table.getIndexesByColumnValue(tableDataOnAccountsTab, BicConfig.accountsToChangeColumnNames.accountTitle, unselectAccountsNameFromSelectedAccountsTab)
            await bicPage.accountsToChangeWidget.table.assertAccountsSelection('uncheck', unselectAccountsNameFromSelectedAccountsTabIndexes) 
          })
          await test.step(`Returning to Selected Accounts tab and assert that Unselected accounts should no longer be listed in the table`, async () => {
            await bicPage.accountsToChangeWidget.movingToSpecificTab(bicPage.accountsToChangeWidget.selectedAccountsTab)
  
            const tableDataOnSelectedAccountsTab = await bicPage.accountsToChangeWidget.table.data()
            const allAccountsNameFromSelectedAccountsTabData = await bicPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataOnSelectedAccountsTab, BicConfig.accountsToChangeColumnNames.accountTitle)
            expect(unselectAccountsNameFromSelectedAccountsTab).not.toContain(allAccountsNameFromSelectedAccountsTabData)
          })
        })
    })
    test.describe('Tests with predifined mock data on Change Accounts window', () => {
      test.beforeEach(async ({page}) => { 
        await page.route((url: URL) => url.toString().includes('/proposal/api/v1/bic/products'), async route => {
          await route.fulfill({ json: BicProductsForSuitabilityMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts', async route => {
          await route.fulfill({ json: BicAccountsForSuitabilityMock.data })
        })
      })
      test.beforeEach(async ({bicPage}) => { 
        await test.step(`Choosing first strategy in main table and moving to the next window`, async () => {
          await bicPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTable()
        })
      })
      test(`Unselected accounts in Accounts tab become unselected in Selected Accounts tab`,  
        { tag: ['@3564'] }, async ({bicPage}) => { 
          let accountsNameFromAccountsTabData: string[], unselectAccountsNameFromAccountsTabData: string[]
  
          await test.step(`Selecting up to 10 eligible accounts, saving accounts names from table and going to Selected Accounts tab`, async () => {
            const tableDataOnAccountsTab = await bicPage.accountsToChangeWidget.table.data()
    
            const selectedAccountsIndexes = await bicPage.accountsToChangeWidget.table.accountsCheckboxes(10, 'check')
            accountsNameFromAccountsTabData = await bicPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataOnAccountsTab, BicConfig.accountsToChangeColumnNames.accountTitle, selectedAccountsIndexes)

            await bicPage.accountsToChangeWidget.movingToSpecificTab(bicPage.accountsToChangeWidget.selectedAccountsTab)
          }) 
          await test.step(`Assert that all Accounts on the page are Selected and selected Accounts Name are the same on Accounts and Selected Accounts tabs`, async () => { 
            const tableDataOnSelectedAccountsTab = await bicPage.accountsToChangeWidget.table.data()

            const accontsNameDataFromSelectedAccountsTab = await bicPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataOnSelectedAccountsTab, BicConfig.accountsToChangeColumnNames.accountTitle)
            await bicPage.accountsToChangeWidget.table.assertAccountsSelection('check')

            expect(accountsNameFromAccountsTabData, 'Verify that selected Accounts Name are the same on Accounts and Selected Accounts tabs').toEqual(accontsNameDataFromSelectedAccountsTab)
          })
          await test.step(`Returning to Accounts tab and unselecting some previously selected accounts`, async () => {
            await bicPage.accountsToChangeWidget.movingToSpecificTab(bicPage.accountsToChangeWidget.accountsTab)

            const tableDataOnAccountsTab = await bicPage.accountsToChangeWidget.table.data()

            const unselectAccountsIndexes = await bicPage.accountsToChangeWidget.table.accountsCheckboxes(3, 'uncheck')
            unselectAccountsNameFromAccountsTabData = await bicPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataOnAccountsTab, BicConfig.accountsToChangeColumnNames.accountTitle, unselectAccountsIndexes)
          })
          await test.step(`Returning to Selected Accounts tab and assert that previously unselected accounts are NOT displayed in the tab`, async () => {
            await bicPage.accountsToChangeWidget.movingToSpecificTab(bicPage.accountsToChangeWidget.selectedAccountsTab)

            const tableDataOnSelectedAccountsTab = await bicPage.accountsToChangeWidget.table.data()
            const allAccountsNameFromSelectedAccountsTabData = await bicPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataOnSelectedAccountsTab, BicConfig.accountsToChangeColumnNames.accountTitle)
            expect(unselectAccountsNameFromAccountsTabData).not.toContain(allAccountsNameFromSelectedAccountsTabData)
          })
        })
     
      test(`Empty state in Selected Accounts tab`, 
        { tag: ['@3569'] }, async ({bicPage}) => {

          await test.step(`Moving to Selected Accounts tab without selection of any account`, async () => {
            await bicPage.accountsToChangeWidget.movingToSpecificTab(bicPage.accountsToChangeWidget.selectedAccountsTab) 
            await bicPage.accountsToChangeWidget.verifyEmptyStateSelectedTabElementsVisibility()
          }) 
        })

      test('Select all eligible accounts', 
        { tag: ['@4293'] }, async ({bicPage}) => {  
  
          await test.step(`Select All Accounts Checkbox and verify that the number of accounts in the counters in the header converge`, async () => {
            await bicPage.accountsToChangeWidget.table.allAccountsCheckbox('check')
            await bicPage.accountsToChangeWidget.verifyConvergingAccountsCounters() 
          })
          await test.step(`Verify all eligible accounts are selected on all pages`, async () => {
            await bicPage.accountsToChangeWidget.table.assertAccountsSelection('check')
            await bicPage.accountsToChangeWidget.pagination.nextPage()
            await bicPage.accountsToChangeWidget.table.assertAccountsSelection('check')
          })
        })

      test('Display the % Allocated as a link. Display the % Allocated of single and sleeve strategy accounts. Verify Amount Allocated Market values', 
        { tag: ['@4453', '@5779', '@5780', '@6020'] }, async ({bicPage}) => {  
          const tableData = await bicPage.accountsToChangeWidget.table.data()

          await test.step(`Verify design of the Allocated % link`, async () => {
            await UiTextStylesAssert.fontSize(bicPage.accountsToChangeWidget.table.locators.allocatedPercentLocator('50.00%'), GeneralStyles.fontSize14)  
            await UiTextStylesAssert.fontName(bicPage.accountsToChangeWidget.table.locators.allocatedPercentLocator('50.00%'), GeneralStyles.fontFamilyRobotoSansSerif)
            await UiTextStylesAssert.fontWeight(bicPage.accountsToChangeWidget.table.locators.allocatedPercentLocator('50.00%'), GeneralStyles.fontLight)   
            await UiTextStylesAssert.fontColor(bicPage.accountsToChangeWidget.table.locators.allocatedPercentLocator('50.00%'), GeneralStyles.colorPrimaryMain)
          })
          await test.step(`Verify title text of the Allocated % tooltip`, async () => {
            await bicPage.accountsToChangeWidget.table.locators.allocatedPercentLocator('50.00%').click()
          
            await expect(bicPage.accountsToChangeWidget.allocationTooltipRow.first().locator('//p').first()).toHaveText('Investment Strategy')
            await expect(bicPage.accountsToChangeWidget.allocationTooltipRow.first().locator('//p').nth(1)).toHaveText('Target %')
          })
          await test.step(`Verify that % Allocated of a single strategy account is 100% and sleeve account is less than 100%. Verify tooltip allocation details`, async () => {
            await expect(bicPage.accountsToChangeWidget.table.locators.allocatedPercentLocator('100.00%'), 'Verify that single strategy account allocation is not a link').toBeHidden()
            
            bicPage.accountsToChangeWidget.table.verifyAllocationAndSleevesAvailability(tableData, BicAccountsForSuitabilityMock.data) 
            await bicPage.accountsToChangeWidget.verifySleevesDetails('50.00%', BicAccountsForSuitabilityMock.data)
          })
          await test.step(`Verify that Market Value of the investment strategy selected for each account is displayed in Amount Allocated column`, async () => {
            await bicPage.accountsToChangeWidget.table.locators.allocatedPercentLocator('50.00%').click()
         
            await bicPage.accountsToChangeWidget.table.verifyAmountAllocatedValues(tableData, BicAccountsForSuitabilityMock.data) 
          })
        })
      
      const searchableFields = [
        BicConfig.accountsToChangeColumnNames.accountTitle,
        BicConfig.accountsToChangeColumnNames.status,
        BicConfig.accountsToChangeColumnNames.accountNumber,
        BicConfig.accountsToChangeColumnNames.tms
      ]

        type Param = {
            fieldForSearchQuery?: string,
            searchTrigger: SearchTrigger 
        };
        const testParamsArray: Param[] = [
          {
            fieldForSearchQuery: searchableFields[1],
            searchTrigger: SearchTrigger.KEYBOARD_NAVIGATION_CHOOSE_SUGGEST_OPTION
          },
          {
            fieldForSearchQuery: searchableFields[3],
            searchTrigger: SearchTrigger.ENTER_KEY
          },
          {
            fieldForSearchQuery: searchableFields[2],
            searchTrigger: SearchTrigger.CLICK_ON_SUGGEST_OPTION
          },
          {
            fieldForSearchQuery: searchableFields[0],
            searchTrigger: SearchTrigger.MAGNIFYING_GLASS_BUTTON
          },
        ]
        const withoutSuggestionsTestParams: Param[] = [
          {
            searchTrigger: SearchTrigger.ENTER_KEY
          },
          {
            searchTrigger: SearchTrigger.MAGNIFYING_GLASS_BUTTON
          },
        ]
       
        for (const param of testParamsArray) {
          test(`Searching ${param.fieldForSearchQuery} using ${param.searchTrigger}`,  // Test catch the defect EWMBIC-687
            { tag: ['@7003'] }, async ({bicPage}) => {  
              await test.step(`Select suggested Account Title, Status, Account # or TMS fields values`, async () => {
                const tableData = await bicPage.accountsToChangeWidget.table.data()
    
                const searchQuery = bicPage.accountsToChangeWidget.table.getRandomValueByColumnName(
                  tableData, param.fieldForSearchQuery!)
                await bicPage.accountsToChangeWidget.search.makeSearch(searchQuery, param.searchTrigger)
                await bicPage.accountsToChangeWidget.search.verifySearchResult(searchQuery, searchableFields)
              })
            })
        }

        for (const param of withoutSuggestionsTestParams) { 
          test(`Verify no Matching Results using trigger: ${param.searchTrigger}`,
            { tag: ['@6174'] }, async ({bicPage}) => {  
              const randomAlphanumeric: string = faker.string.alphanumeric(5)
              await bicPage.accountsToChangeWidget.search.makeSearch(randomAlphanumeric, param.searchTrigger) 
              await bicPage.accountsToChangeWidget.verifyEmptyStateElementsVisibility()
            }) 
        }

    })

    test.describe('Tests with predifined mock data for Export account data', () => {
      test.beforeEach(async ({page}) => { 
        await page.route((url: URL) => url.toString().includes('/proposal/api/v1/bic/products'), async route => {
          await route.fulfill({ json: BicProductsForSuitabilityMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts', async route => {
          await route.fulfill({ json: BicAccountsForExportMock.data })
        })
      })
      test.beforeEach(async ({bicPage}) => { 
        await test.step(`Choosing first strategy in main table and moving to the next window`, async () => {
          await bicPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTable()
        })
      })
      
      test('Export from Selected Accounts tab and Ineligible Accounts tab', 
        { tag: ['@5604', '@5605'] }, async ({ bicPage }) => {  
        
          await test.step(`Verify export CSV file from Selected Accounts tab`, async () => {
            await bicPage.accountsToChangeWidget.table.allAccountsCheckbox('check')
            await bicPage.accountsToChangeWidget.movingToSpecificTab(bicPage.accountsToChangeWidget.selectedAccountsTab)
  
            await bicPage.accountsToChangeWidget.table.compareCsvFileWithTable()
          })
          await test.step(`Verify export CSV file from Ineligible Accounts tab`, async () => {
            await bicPage.accountsToChangeWidget.movingToSpecificTab(bicPage.accountsToChangeWidget.inelegibleAccountsTab)
  
            await bicPage.accountsToChangeWidget.table.compareCsvFileWithTable()
          })
        })
    
    })

    test.describe('Tests without predifined mock data', () => {

      let investmentMinValue: string
      test.beforeEach(async ({bicPage}) => {
        await test.step(`Choosing first strategy in main table and moving to the next window`, async () => {
          investmentMinValue = await bicPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTable() ?? '0'
        })
      })
      test(`Back navigation - List of accounts is changed after strategy changing`, 
        { tag: ['@3339'] }, async ({bicPage, homePage}) => {
          let accountsNameFromFirstStrategy: string[]
  
          await test.step(`Saving accounts titles from table when first Strategy was selected on the Investment tile and returning to dashboard`, async () => {
            const tableDataFromFirstStrategy = await bicPage.accountsToChangeWidget.table.data()
            accountsNameFromFirstStrategy = await bicPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataFromFirstStrategy, BicConfig.accountsToChangeColumnNames.accountTitle)

            await bicPage.accountsToChangeWidget.xButton.click()
            await homePage.tileInvestments.assertBicClosed() 
          }) 
          await test.step(`Selecting second eligible Strategy on the Investment tile, going to 'Select Accounts to Change' window and comparing the list of accounts`, async () => {
            await homePage.tileInvestments.openBic(2) 
            await bicPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTable()

            const tableDataFromSecondStrategy = await bicPage.accountsToChangeWidget.table.data()
            const accountsNameFromSecondStrategy = await bicPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataFromSecondStrategy, BicConfig.accountsToChangeColumnNames.accountTitle)
        
            expect(accountsNameFromFirstStrategy).not.toContain(accountsNameFromSecondStrategy)
          }) 
        })
      test(`List of displaying accounts and Amount Allocated in BIC is the same that in Investment tile`, 
        { tag: ['@3388', '@6175'] }, async ({bicPage, homePage}) => {
          let tableDataFromFirstStrategy: TableRow[]
  
          await test.step(`Saving table data from BIC table when first Strategy was selected on the Investment tile and returning to dashboard`, async () => {
            tableDataFromFirstStrategy = await bicPage.accountsToChangeWidget.table.data()
       
            await bicPage.accountsToChangeWidget.xButton.click()
            await homePage.tileInvestments.assertBicClosed() 
          }) 
          await test.step(`Expanding previously selected strategy in the Investment tile and comparing the list of account titles and Amount Allocated values`, async () => {
            await homePage.tileInvestments.table.expandNestedTable(bicPage.openedStrategyIndex + 1)
        
            const tableDataFromInvestmentTile = await homePage.tileInvestments.table.data()
     
            await bicPage.accountsToChangeWidget.table.compareTablesData(tableDataFromInvestmentTile, tableDataFromFirstStrategy)
         
          }) 
        })
      test('Displaing tooltip for "Allocated" column', 
        { tag: ['@4183'] }, async ({bicPage}) => {  

          await test.step(`Verify Allocated tooltip text on the Accounts tab`, async () => {
            await bicPage.accountsToChangeWidget.verifyAllocatedTooltipText()
          })
          await test.step(`Verify Allocated tooltip text on the Selected Accounts tab`, async () => {
            await bicPage.accountsToChangeWidget.table.allAccountsCheckbox('check')
            await bicPage.accountsToChangeWidget.movingToSpecificTab(bicPage.accountsToChangeWidget.selectedAccountsTab)
            await bicPage.accountsToChangeWidget.verifyAllocatedTooltipText()
          })
          await test.step(`Verify Allocated tooltip text on the Ineligible Accounts tab`, async () => {
            await bicPage.accountsToChangeWidget.movingToSpecificTab(bicPage.accountsToChangeWidget.inelegibleAccountsTab)
            await bicPage.accountsToChangeWidget.verifyAllocatedTooltipText()
          })
        })
      test('Suitability Check Re-run. Ability to check additional accounts', 
        { tag: ['@4507'] }, async ({bicPage}) => {  
  
          await test.step(`Choose one account and make a Suitability Check`, async () => {
            await bicPage.accountsToChangeWidget.table.accountsCheckboxes(1, 'check')
            await bicPage.accountsToChangeWidget.reviewButton.click()
            await expect(bicPage.suitabilityCheckWidget.title).toHaveText('Suitability Check In Progress')
            await bicPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady()
          })
          await test.step(`Choose other accounts and make additional Suitability Check`, async () => {
            await bicPage.accountsToChangeWidget.table.allAccountsCheckbox('check')
            await bicPage.accountsToChangeWidget.reviewButton.click()
            await expect(bicPage.suitabilityCheckWidget.title).toHaveText('Suitability Check In Progress')
            await bicPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady()
          })
        })
        
      test('Investment Minimum is based off the Market Value of the Allocation on each sleeve and has Below Investment Minimum status', 
        { tag: ['@6027', '@5506'] }, async ({bicPage}) => {  
    
          await test.step(`Verify that investment minimum value accounts are marked as ineligible and have Below Investment Minimum statuses`, async () => {
            const tableData = await bicPage.accountsToChangeWidget.table.data() 
            const ineligibleAccountsIndexes = await bicPage.accountsToChangeWidget.table.ineligibleAccountsIndexes()
            await bicPage.accountsToChangeWidget.table.verifyBelowInvestmentMinIneligibleAccounts(tableData, investmentMinValue, ineligibleAccountsIndexes)
          })
        })

      test('Status is not displayed for the eligible accounts ', 
        { tag: ['@5507'] }, async ({bicPage}) => {  
      
          await test.step(`Verify that status is not displayed for the eligible accounts`, async () => {
            const tableData = await bicPage.accountsToChangeWidget.table.data() 
            const ineligibleAccountsIndexes = await bicPage.accountsToChangeWidget.table.ineligibleAccountsIndexes()
            await bicPage.accountsToChangeWidget.table.verifyEligibleAccountsStatuses(tableData, ineligibleAccountsIndexes)
          })
        })

      test('Export from Accounts tab', 
        { tag: ['@5603'] }, async ({ bicPage }) => {  
          
          await test.step(`Verify export CSV file from Accounts tab`, async () => {
           
            await bicPage.accountsToChangeWidget.table.compareCsvFileWithTable()
          })
        })
     
    })

    test.describe('Opening Accounts to Change modal window without BIC fixture', () => {
      
      test.beforeEach(async ({page}) => { 
        await page.route('**/advisormetrics/api/v2/metrics/advisors', async route => {
          await route.fulfill({ json: BicAdvisorsMock.data })
        })
        await page.route((url: URL) => url.toString().includes('/advisormetrics/api/v2/metrics/investments/strategy'), async route => {
          await route.fulfill({ json: BicInvestmentsStrategyMock.data })
        })
        await page.route((url: URL) => url.toString().includes('/proposal/api/v1/bic/products'), async route => {
          await route.fulfill({ json: BicProductsForSuitabilityMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts', async route => {
          await route.fulfill({ json: BicAccountsForSuitabilityMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts/suitabilitycheck', async route => {
          await route.fulfill({ json: BicSuitabilityCheckMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts/investmentchange', async route => {
          await route.fulfill({ json: BicInvestmentChangeMock.data })
        })
      })
      test.beforeEach(async ({homePage, bicDashboardPage}) => { 
  
        await test.step(`Openeing BIC for Strategy with largest amount of accounts`, async () => {
          const tableDataFromInvestmentTile = await homePage.tileInvestments.table.data() 
          const totalAccountsValuesFromInvestmentTileWithIndexes = await homePage.tileInvestments.table.totalAccountsValues(tableDataFromInvestmentTile)
          await homePage.tileInvestments.openBicForStrategyWithLargestAmountOfAccounts(totalAccountsValuesFromInvestmentTileWithIndexes)
          await bicDashboardPage.waitPageIsReady()
        }) 
        await test.step(`Choosing the most Conservative strategy from a main row, going to accounts to change window`, async () => { 
          const tableData = await bicDashboardPage.destinationInvestmentWidget.table.data() 
          await bicDashboardPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTableWithLowestRiskProfile(tableData)
        }) 
      })

      test(`Only accounts that are ineligible for submission and review are listed in the ineligible tab`, 
        { tag: ['@3845', '@3894'] }, async ({bicDashboardPage}) => {
        
          await test.step(`Selecting up to 10 eligible accounts and starting a suitability check`, async () => {
            await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(10, 'check')
            await bicDashboardPage.accountsToChangeWidget.reviewButton.click()
            await expect(bicDashboardPage.suitabilityCheckWidget.title).toHaveText('Suitability Check In Progress')
          }) 
          await test.step(`Returning to Accounts to Change window after suitability check and move to Ineligible Accounts tab`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady()
            await bicDashboardPage.accountsToChangeWidget.movingToSpecificTab(bicDashboardPage.accountsToChangeWidget.inelegibleAccountsTab)
          })
          await test.step(`Verifying that all Ineligible statuses in the tab are correct`, async () => { 
            const tableDataOnIneligibleAccountsTab = await bicDashboardPage.confirmAndSubmitWidget.confirmAndSubmitTable.data()
            const ineligibleAccountsTabStatuses  = await bicDashboardPage.confirmAndSubmitWidget.confirmAndSubmitTable.getFilteredTableDataViaColumnName(tableDataOnIneligibleAccountsTab, BicConfig.accountsToChangeColumnNames.status)
            
            expect(expect.arrayContaining(ineligibleAccountsTabStatuses) , 'Verifying that all Ineligible statuses in the tab are containing in whole list of Ineligible 3.0 statuses').toEqual(BicConfig.ineligibleStatuses)
          })
        })

      test(`Notification about failed ineligible accounts`, 
        { tag: ['@3847'] }, async ({bicDashboardPage}) => {

          await test.step(`Selecting up to 10 eligible accounts and starting a suitability check`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(10, 'check')
            await bicDashboardPage.accountsToChangeWidget.reviewButton.click()
            await expect(bicDashboardPage.suitabilityCheckWidget.title).toHaveText('Suitability Check In Progress')
          }) 
          await test.step(`Returning to Accounts to Change window after suitability check and Verify ineligible accounts notification text and design`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady() 

            await expect(bicDashboardPage.accountsToChangeWidget.notificationBar).toBeVisible() 
            await UiElementsStylesAssert.backgroundColor(GeneralStyles.accountsToChangeNotificationBackgroundColor, bicDashboardPage.accountsToChangeWidget.notificationBar) 

            await expect(bicDashboardPage.accountsToChangeWidget.wholeTextInNotificationBar).toContainText('was found ineligible for submission due to failed client suitability. Please see details in the ineligible tab.')
            await UiTextStylesAssert.fontSize(bicDashboardPage.accountsToChangeWidget.wholeTextInNotificationBar, GeneralStyles.fontSize14)  
            await UiTextStylesAssert.fontName(bicDashboardPage.accountsToChangeWidget.wholeTextInNotificationBar, GeneralStyles.fontFamilyRobotoSansSerif)
            await UiTextStylesAssert.fontWeight(bicDashboardPage.accountsToChangeWidget.ineligibleAccountQuantityTextInNotificationBar, GeneralStyles.fontSemibold)  
          })
        })
      test(`Failed suitability check accounts are added to the list of Ineligible accounts tab`, 
        { tag: ['@3849', '@3894', '@3895', '@3896', '@3975'] }, async ({bicDashboardPage}) => {

          let ineligibleAccountsIndexesFirstTimeWindowOpening: number[] 
          let ineligibleAccountsIndexesAfterSuitabilityCheck: number[]
          let ineligibleAccountsNamesFromAccountsTab: string[]

          await test.step(`Selecting up to 10 eligible accounts, saving ineligible accounts quantity and starting a suitability check`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(10, 'check')
            ineligibleAccountsIndexesFirstTimeWindowOpening = await bicDashboardPage.accountsToChangeWidget.table.ineligibleAccountsIndexes()
            await bicDashboardPage.accountsToChangeWidget.reviewButton.click()
            await expect(bicDashboardPage.suitabilityCheckWidget.title).toHaveText('Suitability Check In Progress')
          }) 
       
          await test.step(`Returning to Accounts to Change window after suitability check and Verify number of ineligible accounts are growing up and ineligible accounts title font style`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady() 
            await expect(bicDashboardPage.accountsToChangeWidget.notificationBar).toBeVisible() 
            ineligibleAccountsIndexesAfterSuitabilityCheck = await bicDashboardPage.accountsToChangeWidget.table.ineligibleAccountsIndexes()
            await bicDashboardPage.accountsToChangeWidget.ineligibleAccountsTitleStyle(ineligibleAccountsIndexesAfterSuitabilityCheck)

            expect(ineligibleAccountsIndexesAfterSuitabilityCheck.length, 'Verify that quantity of ineligible accounts has increased after suitability check').toBeGreaterThan(ineligibleAccountsIndexesFirstTimeWindowOpening.length)
          })
          await test.step(`Verifying ineligible accounts are added to the list of Ineligible accounts tab and ineligible accounts title font style`, async () => { 
            const tableDataOnAccountsTab = await bicDashboardPage.accountsToChangeWidget.table.data()
            ineligibleAccountsNamesFromAccountsTab  = await bicDashboardPage.confirmAndSubmitWidget.confirmAndSubmitTable.getFilteredTableDataViaColumnName(tableDataOnAccountsTab, BicConfig.accountsToChangeColumnNames.accountTitle, ineligibleAccountsIndexesAfterSuitabilityCheck)
            
            await bicDashboardPage.accountsToChangeWidget.movingToSpecificTab(bicDashboardPage.accountsToChangeWidget.inelegibleAccountsTab)
            const tableDataOnIneligibleAccountsTab = await bicDashboardPage.accountsToChangeWidget.table.data()
            const ineligibleAccountsNamesFromIneligibleAccountsTab  = await bicDashboardPage.confirmAndSubmitWidget.confirmAndSubmitTable.getFilteredTableDataViaColumnName(tableDataOnIneligibleAccountsTab, BicConfig.accountsToChangeColumnNames.accountTitle)

            expect(ineligibleAccountsNamesFromIneligibleAccountsTab, 'Verify ineligible accounts from Accounts tab are also in Ineligible Accounts tab').toEqual(ineligibleAccountsNamesFromAccountsTab)
            await bicDashboardPage.accountsToChangeWidget.ineligibleAccountsTitleStyle()
          })
          await test.step(`Moving to Selected Accounts tab and verify that there are no ineligible accounts`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.movingToSpecificTab(bicDashboardPage.accountsToChangeWidget.selectedAccountsTab)

            const tableDataOnSelectedAccountsTab = await bicDashboardPage.accountsToChangeWidget.table.data()
            const accountsNamesFromSelectedAccountsTab = await bicDashboardPage.confirmAndSubmitWidget.confirmAndSubmitTable.getFilteredTableDataViaColumnName(tableDataOnSelectedAccountsTab, BicConfig.accountsToChangeColumnNames.accountTitle)
       
            expect(accountsNamesFromSelectedAccountsTab , 'Verify that there are no ineligible accounts on Selected Accounts tab').not.toEqual(expect.arrayContaining(ineligibleAccountsNamesFromAccountsTab))
          })
        })
      test(`TMS Enrolled account, TMS notification get by selecting one Enrolled account`, 
        { tag: ['@4082', '@4083', '@4113', '@4116'] }, async ({bicDashboardPage}) => {

          await test.step(`Verify Enrolled and Unenrolled TMS account status`, async () => { 
            const tableDataOnAccountsTab = await bicDashboardPage.accountsToChangeWidget.table.data()
    
            const tmsEnrolledStatus = await bicDashboardPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataOnAccountsTab, BicConfig.accountsToChangeColumnNames.tms, [0])
            const tmsUnenrolledStatus = await bicDashboardPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataOnAccountsTab, BicConfig.accountsToChangeColumnNames.tms, [2])

            expect(tmsEnrolledStatus[0], 'Verify Enrolled TMS account status in the table').toBe('Enrolled')
            expect(tmsUnenrolledStatus[0], 'Verify Unenrolled TMS account status in the table').toBe('')
          }) 
          await test.step(`Choosing one eligible Enrolled account and verifying message text`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(1, 'check') 

            await expect(bicDashboardPage.accountsToChangeWidget.tmsNotificationText, 'Verify TMS disclosure popup text').toHaveText('Tax Management Services will be removed if investment changing to an Ineligible strategy.')
            await expect(bicDashboardPage.accountsToChangeWidget.tmsNotificationBar, 'Assert that notification is visible').toBeVisible()
            await expect(bicDashboardPage.accountsToChangeWidget.tmsNotificationBar, 'Assert that notification is hidden after 7 seconds of visibility (approximately)').toBeHidden({timeout: 8000}) //Notification is 7 sec on the screen, additional 1 sec goes on animation
          }) 
          await test.step(`Unselecting previously selected Enrolled account, selecting again, selecting new Enrolled account and verifying that TMS notification is Not appeared`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(1, 'uncheck') 
            await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(1, 'check') 
            await expect(bicDashboardPage.accountsToChangeWidget.tmsNotificationBar, 'Assert that TMS notification is Not visible').toBeHidden()

            await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(1, 'uncheck') 
            await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(2, 'check') 
            await expect(bicDashboardPage.accountsToChangeWidget.tmsNotificationBar, 'Assert that TMS notification is Not visible').toBeHidden()
          }) 
        })
      test(`TMS notification get by selecting All accounts checkbox. TMS notification design`, 
        { tag: ['@4114', '@4115'] }, async ({bicDashboardPage}) => {

          await test.step(`Selecting All accounts checkbox and verifying notification design`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.table.allAccountsCheckbox('check')

            await UiElementsStylesAssert.backgroundColor(GeneralStyles.colorNeutral800, bicDashboardPage.accountsToChangeWidget.tmsNotificationBar) 
            await expect(bicDashboardPage.accountsToChangeWidget.tmsNotificationBarIcon, 'Assert that notification icon is visible').toBeVisible()

            await UiTextStylesAssert.fontSize(bicDashboardPage.accountsToChangeWidget.tmsNotificationText, GeneralStyles.fontSize14)  
            await UiTextStylesAssert.fontName(bicDashboardPage.accountsToChangeWidget.tmsNotificationText, GeneralStyles.fontFamilyRobotoSansSerif)
            await UiTextStylesAssert.fontWeight(bicDashboardPage.accountsToChangeWidget.tmsNotificationText, GeneralStyles.fontLightBold)   
            await UiTextStylesAssert.fontColor(bicDashboardPage.accountsToChangeWidget.tmsNotificationText, GeneralStyles.colorWhite)

            await expect(bicDashboardPage.accountsToChangeWidget.tmsNotificationBar, 'Assert that notification is visible').toBeVisible()
            await expect(bicDashboardPage.accountsToChangeWidget.tmsNotificationBar, 'Assert that notification is hidden after 7 seconds of visibility (approximately)').toBeHidden({timeout: 8000}) //Notification is 7 sec on the screen, additional 1 sec goes on animation
          }) 
        })
      test(`Selected accounts are present after suitability check`, 
        { tag: ['@3834'] }, async ({bicDashboardPage}) => {
          let accountsNameFromAccountsTabData: string[], selectedAccountsNamesAfterSuitabilityCheck: string[]
  
          await test.step(`Selecting up to 6 eligible accounts, saving accounts names from table and starting a suitability check`, async () => {
            const tableDataOnAccountsTab = await bicDashboardPage.accountsToChangeWidget.table.data()
           
            const selectedAccountsIndexes = await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(6, 'check')
            accountsNameFromAccountsTabData = await bicDashboardPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataOnAccountsTab, BicConfig.accountsToChangeColumnNames.accountTitle, selectedAccountsIndexes)

            await bicDashboardPage.accountsToChangeWidget.reviewButton.click()
            await expect(bicDashboardPage.suitabilityCheckWidget.title).toHaveText('Suitability Check In Progress')
          }) 
          await test.step(`Returning to Accounts to Change window after suitability check and get checked accounts idexes`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady()
            const tableDataOnSelectedAccountsTab = await bicDashboardPage.accountsToChangeWidget.table.data()
            const selectedAccountsIndexesAfterSuitabilityCheck = (await bicDashboardPage.accountsToChangeWidget.table.getCheckedAndUncheckedIndexes())[0]
            selectedAccountsNamesAfterSuitabilityCheck = await bicDashboardPage.accountsToChangeWidget.table.getFilteredTableDataViaColumnName(tableDataOnSelectedAccountsTab, BicConfig.accountsToChangeColumnNames.accountTitle, selectedAccountsIndexesAfterSuitabilityCheck)

            expect(accountsNameFromAccountsTabData, 'Verify that selected Accounts are containing in the list of previously selected accounts').toEqual(expect.arrayContaining(selectedAccountsNamesAfterSuitabilityCheck))
          })
          await test.step(`Mooving to Confirm and Submit window and verify that list of accounts is equal to selected Accounts names after Suitability Check`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.nextButton.click() 
            await bicDashboardPage.confirmAndSubmitWidget.waitConfirmAndSubmitWidgetIsReady()

            const tableDataOnConfirmAndSubmitWindow = await bicDashboardPage.confirmAndSubmitWidget.confirmAndSubmitTable.data()
            const confirmAndSubmitWindowAccountsNames = await bicDashboardPage.confirmAndSubmitWidget.confirmAndSubmitTable.getFilteredTableDataViaColumnName(tableDataOnConfirmAndSubmitWindow, BicConfig.accountsToChangeColumnNames.accountTitle)

            expect(confirmAndSubmitWindowAccountsNames, 'Verify that Accounts in Confirm and Submit window are the same that were after Suitability Check').toEqual(selectedAccountsNamesAfterSuitabilityCheck)
          })
        })

    })

    test.describe('No Suitbility check', () => {
      test.beforeEach(async ({page}) => {
        await page.route('**/proposal/api/v1/bic/products', async route => {
          await route.fulfill({ json: BicSelectInvestmentMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts', async route => {
          await route.fulfill({ json: BicChangeAccountsNoSuitabilityMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts/suitabilitycheck', async route => {
          await route.fulfill({ json: BicSuitabilityCheckNoSuitabilityMock.data })
        })
      })

      test.beforeEach(async ({bicPage}) => {
        await test.step(`Choosing first strategy in main table and moving to the next window`, async () => {
          await bicPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTable()
        })
      })
      test(`Ability to bypass suitability when account isn't require checking`,
        { tag: ['@5687'] }, async ({bicPage}) => {

          await test.step(`Selecting first three accounts without requiring suitability check and bypassing suitability`, async () => {
            await bicPage.accountsToChangeWidget.table.accountsCheckboxes(3, 'check')
            await bicPage.accountsToChangeWidget.nextButton.click()
            await expect(bicPage.suitabilityCheckWidget.progressBar).toBeHidden()
            await bicPage.confirmAndSubmitWidget.waitConfirmAndSubmitWidgetIsReady()
          })
        })
      test(`Suitability Check. Re-run. Ability to bypass accounts check`,
        { tag: ['@4508'] }, async ({bicPage}) => {
  
          await test.step(`Selecting accounts that require suitability check and make a Suitability Check`, async () => {
            await bicPage.accountsToChangeWidget.table.accountsCheckboxes(6, 'check')
            await bicPage.accountsToChangeWidget.table.accountsCheckboxes(3, 'uncheck')
            await bicPage.accountsToChangeWidget.reviewButton.click()
            await expect(bicPage.suitabilityCheckWidget.progressBar).toBeVisible()
            await bicPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady()
          })
          await test.step(`Selecting first three accounts without requiring suitability check and bypassing suitability`, async () => {
            await bicPage.accountsToChangeWidget.table.accountsCheckboxes(3, 'check')
            await bicPage.accountsToChangeWidget.nextButton.click()
            await expect(bicPage.suitabilityCheckWidget.progressBar).toBeHidden()
            await bicPage.confirmAndSubmitWidget.waitConfirmAndSubmitWidgetIsReady()
          })
        })

    })

    test.describe('Tests with predifined mock data on Destination Investment window', () => {
      test.beforeEach(async ({page}) => {
        await page.route('**/proposal/api/v1/bic/products', async route => {
          await route.fulfill({ json: BicSelectInvestmentMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts', async route => {
          await route.fulfill({ json: BicChangeAccountsStatusesMock.data })
        })
      })
      test.beforeEach(async ({bicPage}) => {
        await test.step(`Choosing first strategy in main table and moving to the next window`, async () => {
          await bicPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTable()
        })
      })
      test(`Verify ineligible accounts Statuses. UI part`, 
        { tag: ['@5509', '@5510', '@5512', '@5677',] }, async ({bicPage}) => {
         
          await test.step(`Verify accounts ineligible statuses`, async () => { 
            const tableData = await bicPage.accountsToChangeWidget.table.data() 
            await bicPage.accountsToChangeWidget.table.verifyAccountsStatuses(tableData, [0], `Ineligible due to Tax Management Services enrollment`)
            await bicPage.accountsToChangeWidget.table.verifyAccountsStatuses(tableData, [2], `Model Not Eligible`)
            await bicPage.accountsToChangeWidget.table.verifyAccountsStatuses(tableData, [4], `Account already holds the selected investment strategy`)
            await bicPage.accountsToChangeWidget.table.verifyAccountsStatuses(tableData, [5], `Not suitable for client's risk profile`)
          })
        })
      
    })
  })
import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { EWM3Config } from '../../../../ewm3/service-data/config'
import { GeneralStyles } from '../../../../ewm3/service-data/generalStyles'
import { BicConfig } from '../../../../ewm3/service-data/tile-config/bic.config'
import { BicAccountsForSuitabilityMock } from '../../../../ewm3/ui/mocks/bic-accounts-for-suitability-mock'
import { BicAdvisorsMock } from '../../../../ewm3/ui/mocks/bic-advisors-mock'
import { BicInvestmentChangeMock } from '../../../../ewm3/ui/mocks/bic-investmentchange-mock'
import { BicInvestmentsStrategyMock } from '../../../../ewm3/ui/mocks/bic-investments-strategy-mock'
import { BicProductsForSuitabilityMock } from '../../../../ewm3/ui/mocks/bic-products-for-suitability-mock'
import { BicSuitabilityCheckMock } from '../../../../ewm3/ui/mocks/bic-suitabilitycheck-mock'
import { UiElementsStylesAssert } from '../../../../utils/UIComponentsStateAssert'

test.describe('BIC tests', 
  { tag: [ '@stable' ] }, () => { 
    test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})
    test.use({ viewport: { width: 1440, height: 885 } })

    test.describe('Successful Submission modal window', () => {

      test.beforeEach(async ({page}) => { 
        await page.route('**/advisormetrics/api/v2/metrics/advisors', async route => {
          await route.fulfill({ json: BicAdvisorsMock.data })
        })
        await page.route((url: URL) => url.toString().includes('/advisormetrics/api/v2/metrics/investments/strategy'), async route => {
          await route.fulfill({ json: BicInvestmentsStrategyMock.data })
        })
        await page.route((url: URL) => url.toString().includes('/proposal/api/v1/bic/products'), async route => {
          await route.fulfill({ json: BicProductsForSuitabilityMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts', async route => {
          await route.fulfill({ json: BicAccountsForSuitabilityMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts/suitabilitycheck', async route => {
          await route.fulfill({ json: BicSuitabilityCheckMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts/investmentchange', async route => {
          await route.fulfill({ json: BicInvestmentChangeMock.data })
        })
      })

      let indecesOfSelectedAccountsAfterSuitability: number[]

      test.beforeEach(async ({homePage, bicDashboardPage}) => { 
        await test.step(`Openeing BIC for Strategy with largest amount of accounts`, async () => {
          await expect(homePage.tileInvestments.table.locators.table, 'Waiting Investment tile table is visible').toBeVisible()
          const tableDataFromInvestmentTile = await homePage.tileInvestments.table.data() 
          const totalAccountsValuesFromInvestmentTileWithIndexes = await homePage.tileInvestments.table.totalAccountsValues(tableDataFromInvestmentTile)
          await homePage.tileInvestments.openBicForStrategyWithLargestAmountOfAccounts(totalAccountsValuesFromInvestmentTileWithIndexes)
          await bicDashboardPage.waitPageIsReady()
        }) 
        await test.step(`Choosing the most Conservative strategy from a main row, going to accounts to change window`, async () => { 
          const tableData = await bicDashboardPage.destinationInvestmentWidget.table.data() 
          await bicDashboardPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTableWithLowestRiskProfile(tableData)
        }) 
        await test.step(`Selecting up to 10 accounts, make a Suitability Check and moving to the Confirm and Submit window`, async () => {
          await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(10, 'check')
          await bicDashboardPage.accountsToChangeWidget.reviewButton.click()

          await expect(bicDashboardPage.suitabilityCheckWidget.title).toHaveText('Suitability Check In Progress')
          await bicDashboardPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady()
          await bicDashboardPage.accountsToChangeWidget.movingToSpecificTab(bicDashboardPage.accountsToChangeWidget.selectedAccountsTab)

          indecesOfSelectedAccountsAfterSuitability =  (await bicDashboardPage.accountsToChangeWidget.table.getCheckedAndUncheckedIndexes())[0]

          await bicDashboardPage.accountsToChangeWidget.nextButton.click() 
          await bicDashboardPage.confirmAndSubmitWidget.waitConfirmAndSubmitWidgetIsReady() 
        }) 
      })
   
      test(`Verifying Submission window message,link to Tracking Center. Ability to close modal window by X button`, 
        { tag: ['@3969', '@4180'] }, async ({bicDashboardPage, homePage}) => {

          await test.step(`Submitting strategy change request and moving to Submission Successful window`, async () => { 
            await bicDashboardPage.confirmAndSubmitWidget.checkBox.check()
            await bicDashboardPage.confirmAndSubmitWidget.submitButton.click()
            await expect(bicDashboardPage.submissionSuccessfulWidget.title).toHaveText('Submission Successful')
          })
          await test.step(`Verifying Successful Submission window message`, async () => { 
            await bicDashboardPage.submissionSuccessfulWidget.assertSubmissionMessageText(indecesOfSelectedAccountsAfterSuitability.length)
          })
          await test.step(`Closing the window by “x” button`, async () => { 
            await bicDashboardPage.submissionSuccessfulWidget.xButton.click()
            await homePage.tileInvestments.assertBicClosed()
          })
        })

      test(`Navigate to Tracking Center via link from Successful Submission window`,
        { tag: ['@4191', '@4189'] }, async ({bicDashboardPage}) => {
          await test.step(`Submitting strategy change request and moving to Submission Successful window`, async () => { 
            await bicDashboardPage.confirmAndSubmitWidget.checkBox.check()
            await bicDashboardPage.confirmAndSubmitWidget.submitButton.click()
            await expect(bicDashboardPage.submissionSuccessfulWidget.title).toHaveText('Submission Successful')
          })
          await test.step(`Verifying link to Tracking Center`, async () => { 
            expect(await bicDashboardPage.submissionSuccessfulWidget.trackingCenterLink.getAttribute('href'))
              .toEqual(`${EWM3Config.BASE_URL_2_0}/AccountsAnalysis/TrackingCenter/TrackingCenter`)
          })
          await test.step(`Verifying that clicking on link opens new window with correct URL`, async () => {
           
            await bicDashboardPage.submissionSuccessfulWidget.trackingCenterLink.click() 

            await expect(async () => {
              expect(bicDashboardPage.page.context().pages().length).toEqual(2), 'Verifying that second tab is opened'}).toPass({timeout: 3000})

            // ToDo: Uncomment after 2.0 URL wil be resolved on the executing test machine
            // await expect(allPages[1]).toHaveURL(`${EWM3Config.BASE_URL_2_0}/AccountsAnalysis/TrackingCenter/TrackingCenter`) // This line is commented because 2.0 URL is not resolved 
          })
        })

      test(`Closing modal window by Close button. Reopening window after closing. Verification radio buttons are unchecked. Verifying Loading icon during accounts submission process. Nested table verification`, 
        { tag: ['@3970', '@3971', '@4451'] }, async ({bicDashboardPage, homePage}) => {
         
          await test.step(`Submitting strategy change request, verifying Loading icon during accounts submission process and moving to Submission Successful window`, async () => { 
            await test.step(`Slow down network request by 2000 milliseconds`, async () => { 
              await bicDashboardPage.page.route('**', (route) => {
                setTimeout(() => { route.continue() }, 2000)
              })
            })
            await bicDashboardPage.confirmAndSubmitWidget.checkBox.check()
            await Promise.all([
              bicDashboardPage.confirmAndSubmitWidget.submitButton.click(),
              expect(bicDashboardPage.confirmAndSubmitWidget.circularLoaderIcon).toBeVisible()
            ])
            await expect(bicDashboardPage.submissionSuccessfulWidget.title).toHaveText('Submission Successful')
          })
          await test.step(`Closing the window by “Close” button`, async () => { 
            await bicDashboardPage.submissionSuccessfulWidget.closeButton.click()
            await homePage.tileInvestments.assertBicClosed()
          })
          await test.step(`Reopening window after closing. Verify radio buttons are unchecked on main table`, async () => { 
            await homePage.tileInvestments.openBic()
            await bicDashboardPage.destinationInvestmentWidget.table.assertRadioButtonOnMainTableNotChecked()
          })
          await test.step(`Assert nested tables are closed`, async () => { 
            await bicDashboardPage.destinationInvestmentWidget.table.assertNestedTableClosed()
          })
          await test.step(`Expanding nested table. Assert radio buttons in nested tables are not checked`, async () => { 
            await bicDashboardPage.destinationInvestmentWidget.table.expandNestedTable(10)
            await bicDashboardPage.destinationInvestmentWidget.table.assertRadioButtonOnNestedTableNotChecked()
          })
        })

    })

    test.describe('Opening Confirm and Submit modal window with predefined mock data', () => {
      test.beforeEach(async ({page}) => { 
        await page.route('**/advisormetrics/api/v2/metrics/advisors', async route => {
          await route.fulfill({ json: BicAdvisorsMock.data })
        })
        await page.route((url: URL) => url.toString().includes('/advisormetrics/api/v2/metrics/investments/strategy'), async route => {
          await route.fulfill({ json: BicInvestmentsStrategyMock.data })
        })
        await page.route((url: URL) => url.toString().includes('/proposal/api/v1/bic/products'), async route => {
          await route.fulfill({ json: BicProductsForSuitabilityMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts', async route => {
          await route.fulfill({ json: BicAccountsForSuitabilityMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts/suitabilitycheck', async route => {
          await route.fulfill({ json: BicSuitabilityCheckMock.data })
        })
        await page.route('**/proposal/api/v1/bic/accounts/investmentchange', async route => {
          await route.fulfill({ json: BicInvestmentChangeMock.data })
        })
      })
      test.beforeEach(async ({bicDashboardPage, homePage}) => { 
        await test.step(`Openeing BIC for Strategy with largest amount of accounts`, async () => {
          await expect(homePage.tileInvestments.table.locators.table, 'Waiting Investment tile table is visible').toBeVisible()
          const tableDataFromInvestmentTile = await homePage.tileInvestments.table.data() 
          const totalAccountsValuesFromInvestmentTileWithIndexes = await homePage.tileInvestments.table.totalAccountsValues(tableDataFromInvestmentTile)
          await homePage.tileInvestments.openBicForStrategyWithLargestAmountOfAccounts(totalAccountsValuesFromInvestmentTileWithIndexes)
          await bicDashboardPage.waitPageIsReady()
        }) 
        await test.step(`Choosing the most Conservative strategy from a main row, going to accounts to change window`, async () => { 
          const tableData = await bicDashboardPage.destinationInvestmentWidget.table.data() 
          await bicDashboardPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTableWithLowestRiskProfile(tableData)
        }) 
      })
  
      test(`Previously selected accounts selections retained after returning to Accounts to Change window`, 
        { tag: ['@3880', '@3885'] }, async ({bicDashboardPage}) => {
  
          let checkedAccountsIndexes: number[] 
          let uncheckedAccountsIndexes: number[]
          let ineligibleAccountsIndexes: number[]
  
          await test.step(`Selecting up to 9 eligible accounts and starting a suitability Check`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(9, 'check')

            await bicDashboardPage.accountsToChangeWidget.reviewButton.click()
            await expect(bicDashboardPage.suitabilityCheckWidget.title).toHaveText('Suitability Check In Progress')
          }) 
          await test.step(`Returning to Accounts to Change window after suitability check and saving checked, unchecked, ineligible accounts idexes`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady() 
            await expect(bicDashboardPage.accountsToChangeWidget.notificationBar).toBeVisible() 

            checkedAccountsIndexes = (await bicDashboardPage.accountsToChangeWidget.table.getCheckedAndUncheckedIndexes())[0]
            uncheckedAccountsIndexes = (await bicDashboardPage.accountsToChangeWidget.table.getCheckedAndUncheckedIndexes())[1]
            ineligibleAccountsIndexes = await bicDashboardPage.accountsToChangeWidget.table.ineligibleAccountsIndexes()
          })
          await test.step(`Going to Confirm and Submit window then returning and verifying checked, unchecked, ineligible accounts idexes`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.nextButton.click() 
            await bicDashboardPage.confirmAndSubmitWidget.waitConfirmAndSubmitWidgetIsReady() 

            await bicDashboardPage.confirmAndSubmitWidget.backButton.click()
            await bicDashboardPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady() 

            const checkedAccountsIndexesAfterReturning = (await bicDashboardPage.accountsToChangeWidget.table.getCheckedAndUncheckedIndexes())[0]
            const uncheckedAccountsIndexesAfterReturning = (await bicDashboardPage.accountsToChangeWidget.table.getCheckedAndUncheckedIndexes())[1]
            const ineligibleAccountsIndexesAfterReturning = await bicDashboardPage.accountsToChangeWidget.table.ineligibleAccountsIndexes()

            expect(checkedAccountsIndexesAfterReturning, 'Verify checked accounts indexes are not changed after returning from Confirm and Submit window').toEqual(checkedAccountsIndexes)
            expect(uncheckedAccountsIndexesAfterReturning, 'Verify unchecked accounts indexes are not changed after returning from Confirm and Submit window').toEqual(uncheckedAccountsIndexes)
            expect(ineligibleAccountsIndexesAfterReturning, 'Verify ineligible accounts indexes are not changed after returning from Confirm and Submit window').toEqual(ineligibleAccountsIndexes)
          })
          await test.step(`Unchecking some accounts on Change Accounts window and verifying account list on Confirm and Submit window`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(2, 'uncheck')
            const checkedAccountsIndexesAfterUnselectingAccounts = (await bicDashboardPage.accountsToChangeWidget.table.getCheckedAndUncheckedIndexes())[0]

            const tableDataOnChangeAccountsWindow = await bicDashboardPage.accountsToChangeWidget.table.data()
            const selectedAccountsNamesFromChangeAccountsWindow  = await bicDashboardPage.confirmAndSubmitWidget.confirmAndSubmitTable.getFilteredTableDataViaColumnName(tableDataOnChangeAccountsWindow, BicConfig.accountsToChangeColumnNames.accountTitle, checkedAccountsIndexesAfterUnselectingAccounts)

            await bicDashboardPage.accountsToChangeWidget.nextButton.click() 
            await bicDashboardPage.confirmAndSubmitWidget.waitConfirmAndSubmitWidgetIsReady() 

            const tableDataOnConfirmAndSubmitWindow = await bicDashboardPage.confirmAndSubmitWidget.confirmAndSubmitTable.data() 
            const accountsNamesFromConfirmAndSubmitWindow = await bicDashboardPage.confirmAndSubmitWidget.confirmAndSubmitTable.getFilteredTableDataViaColumnName(tableDataOnConfirmAndSubmitWindow, BicConfig.accountsToChangeColumnNames.accountTitle)
            expect(accountsNamesFromConfirmAndSubmitWindow, 'Verify that accounts on Confirm and Submit window are the same that were selected in Accounts to Change widget').toEqual(selectedAccountsNamesFromChangeAccountsWindow)
          })
        })

      test(`Verify window some elements availability and ability to close the window`, 
        { tag: ['@3848', '@3851', '@3868', '@3870'] }, async ({bicDashboardPage, homePage}) => {

          await test.step(`Choosing first strategy, selecting up to 10 accounts, make a Suitability Check and moving to the Confirm and Submit window`, async () => {
            await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(10, 'check')
            await bicDashboardPage.accountsToChangeWidget.reviewButton.click()
  
            await expect(bicDashboardPage.suitabilityCheckWidget.title).toHaveText('Suitability Check In Progress')
            await bicDashboardPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady()
           
            await bicDashboardPage.accountsToChangeWidget.nextButton.click() 
            await bicDashboardPage.confirmAndSubmitWidget.waitConfirmAndSubmitWidgetIsReady() 
          }) 
          await test.step(`Verify TMS tooltip text`, async () => { 
            await bicDashboardPage.confirmAndSubmitWidget.tmsIcon.hover()
            expect(await bicDashboardPage.confirmAndSubmitWidget.tmsTooltip.textContent(), `Verify that tooltip text is correct`)
              .toEqual('To enroll in TMS, access the Account Wizard for the intended account.')  // Catch the defect EWMBIC-618
          })
          await test.step(`Verifying Submit Request button and checkbox elements before clicking the button`, async () => { 
            await expect(bicDashboardPage.confirmAndSubmitWidget.submitButton).toBeDisabled() 
            await UiElementsStylesAssert.backgroundColor(GeneralStyles.colorNeutral200, bicDashboardPage.confirmAndSubmitWidget.submitButton) 

            await expect(bicDashboardPage.confirmAndSubmitWidget.checkBox).not.toBeChecked()
            await UiElementsStylesAssert.borderBottomColor(GeneralStyles.colorNeutral700, bicDashboardPage.confirmAndSubmitWidget.checkBox) 
          })
          await test.step(`Clicking on Submit Request button in disable state and checkbox color changing`, async () => { 
            await bicDashboardPage.confirmAndSubmitWidget.submitButton.click({ force: true })
            await expect(bicDashboardPage.confirmAndSubmitWidget.submitButton).toBeDisabled() 
            await UiElementsStylesAssert.backgroundColor(GeneralStyles.colorNeutral200, bicDashboardPage.confirmAndSubmitWidget.submitButton) 
      
            await UiElementsStylesAssert.borderBottomColor(GeneralStyles.colorErrorMain, bicDashboardPage.confirmAndSubmitWidget.checkBox) 
          })
          await test.step(`Check the agreement checkbox and verifying Submit Request button and checkbox elements design changing`, async () => { 
            await bicDashboardPage.confirmAndSubmitWidget.checkBox.check()
            await expect(bicDashboardPage.confirmAndSubmitWidget.checkBox).toBeChecked()

            await expect(bicDashboardPage.confirmAndSubmitWidget.submitButton).toBeEnabled()
            await UiElementsStylesAssert.backgroundColor(GeneralStyles.colorPrimaryMain, bicDashboardPage.confirmAndSubmitWidget.submitButton, {timeout: 300}) 
          })
          await test.step(`Uncheck the agreement checkbox and verifying Submit Request button and checkbox elements design changing`, async () => { 
            await bicDashboardPage.confirmAndSubmitWidget.checkBox.uncheck()
            await expect(bicDashboardPage.confirmAndSubmitWidget.checkBox).not.toBeChecked()

            await expect(bicDashboardPage.confirmAndSubmitWidget.submitButton).toBeDisabled() 
            await UiElementsStylesAssert.backgroundColor(GeneralStyles.colorNeutral200, bicDashboardPage.confirmAndSubmitWidget.submitButton, {timeout: 300}) 
          })
          await test.step(`Closing the window by “x” button`, async () => { 
            await bicDashboardPage.confirmAndSubmitWidget.xButton.click()
            await homePage.tileInvestments.assertBicClosed()
          })
        })

    })

    test.describe('Opening Confirm and Submit modal window without BIC fixture', () => {

      test.beforeEach(async ({bicDashboardPage, homePage}) => { 
        await test.step(`Openeing BIC for Strategy with largest amount of accounts`, async () => {
          await expect(homePage.tileInvestments.table.locators.table, 'Waiting Investment tile table is visible').toBeVisible()
          const tableDataFromInvestmentTile = await homePage.tileInvestments.table.data() 
          const totalAccountsValuesFromInvestmentTileWithIndexes = await homePage.tileInvestments.table.totalAccountsValues(tableDataFromInvestmentTile)
          await homePage.tileInvestments.openBicForStrategyWithLargestAmountOfAccounts(totalAccountsValuesFromInvestmentTileWithIndexes)
          await bicDashboardPage.waitPageIsReady()
        }) 
        await test.step(`Choosing the most Conservative strategy from a main row, going to Accounts to Change window`, async () => { 
          const tableData = await bicDashboardPage.destinationInvestmentWidget.table.data() 
          await bicDashboardPage.accountsToChangeWidget.openAccountsToChangeWindowViaMainTableWithLowestRiskProfile(tableData)
        }) 
      })
  
      test(`Select additional accounts in Accounts to Change window again`, 
        { tag: ['@3886'] }, async ({bicDashboardPage}) => {

          await test.step(`Selecting up to 3 eligible accounts and starting a Suitability Check`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(3, 'check')

            await bicDashboardPage.accountsToChangeWidget.reviewButton.click()
            await expect(bicDashboardPage.suitabilityCheckWidget.title).toHaveText('Suitability Check In Progress')
          }) 
          await test.step(`Returning to Accounts to Change window after suitability check and then going to Confirm and Submit window`, async () => { 
            await bicDashboardPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady() 

            await bicDashboardPage.accountsToChangeWidget.nextButton.click() 
            await bicDashboardPage.confirmAndSubmitWidget.waitConfirmAndSubmitWidgetIsReady()           
          })
          await test.step(`Returning to Accounts to Change window, selecting few new accounts and then verifying their availability in Confirm and Submit window`, async () => { 
          
            await bicDashboardPage.confirmAndSubmitWidget.backButton.click()
            await bicDashboardPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady() 

            await bicDashboardPage.accountsToChangeWidget.table.allAccountsCheckbox('check')
            await bicDashboardPage.accountsToChangeWidget.table.allAccountsCheckbox('uncheck')
            await bicDashboardPage.accountsToChangeWidget.table.accountsCheckboxes(6, 'check')

            await bicDashboardPage.accountsToChangeWidget.reviewButton.click() 
            await bicDashboardPage.accountsToChangeWidget.waitAccountsToChangeWindowIsReady()  

            const checkedAccountsIndexesOnConfirmAndSubmitWindow = (await bicDashboardPage.accountsToChangeWidget.table.getCheckedAndUncheckedIndexes())[0]
            const tableDataOnChangeAccountsWindow = await bicDashboardPage.accountsToChangeWidget.table.data()
            const selectedAccountsNamesFromChangeAccountsWindow  = await bicDashboardPage.confirmAndSubmitWidget.confirmAndSubmitTable.getFilteredTableDataViaColumnName(tableDataOnChangeAccountsWindow, BicConfig.accountsToChangeColumnNames.accountTitle, checkedAccountsIndexesOnConfirmAndSubmitWindow)

            await bicDashboardPage.accountsToChangeWidget.nextButton.click() 
            await bicDashboardPage.confirmAndSubmitWidget.waitConfirmAndSubmitWidgetIsReady()   

            const tableDataOnConfirmAndSubmitWindow = await bicDashboardPage.confirmAndSubmitWidget.confirmAndSubmitTable.data()
            const selectedAccountsNamesFromConfirmAndSubmitWindow = await bicDashboardPage.confirmAndSubmitWidget.confirmAndSubmitTable.getFilteredTableDataViaColumnName(tableDataOnConfirmAndSubmitWindow, BicConfig.accountsToChangeColumnNames.accountTitle)

            expect(selectedAccountsNamesFromConfirmAndSubmitWindow, 'Verify that accounts on Confirm and Submit window are the same that were selected in Accounts to Change widget').toEqual(selectedAccountsNamesFromChangeAccountsWindow)
          })
        })

    })

  })
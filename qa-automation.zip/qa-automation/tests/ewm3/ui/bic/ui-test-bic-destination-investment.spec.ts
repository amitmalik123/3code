import { faker } from '@faker-js/faker'
import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { EWM3Config } from '../../../../ewm3/service-data/config'
import { CloseTrigger, SearchTrigger } from '../../../../ewm3/ui/features/search.feature'
import { PageSwitchTrigger } from '../../../../ewm3/ui/features/pagination.feature'
import { BicSelectInvestmentMock } from '../../../../ewm3/ui/mocks/bic-select-investment-mock'
import { BicConfig } from '../../../../ewm3/service-data/tile-config/bic.config'
import { ProposalProductsResponseBody } from '../../../../ewm3/api/proposal/v1/types'
import { BicInvestmentsStrategyForBicIneligibilityMock } from '../../../../ewm3/ui/mocks/bic-investments-strategy-for-bic-ineligibility-mock'
import { TableRow } from '../../../../ewm3/ui/features/table.feature'

test.describe('BIC tests', 
  { tag: [ '@stable' ] }, () => { 
    test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})
    test.use({ viewport: { width: 1440, height: 885 } })

    test.describe('Closing Destination Investment modal window', () => {
      test.beforeEach(async ({page}) => { 
        await page.route('**/proposal/api/v1/bic/products', async route => {
          await route.fulfill({ json: BicSelectInvestmentMock.data })
        })
      })

      test(`Closing window by Cancel button`, 
        { tag: ['@3078', '@3092'] }, async ({bicPage}) => {  
          await bicPage.destinationInvestmentWidget.cancelButton.click()
        })
      test(`Closing window by X button`, 
        { tag: ['@3093', '@3094'] }, async ({bicPage}) => {  
          await bicPage.destinationInvestmentWidget.xButton.click()
        })
      test.afterEach('Assert that Investment Widget is visible', async ({homePage}) => {
        await homePage.tileInvestments.assertBicClosed()
      })
    })

    test.describe('Reopening Destination Investment modal window', () => {
      test.beforeEach(async ({page}) => { 
        await page.route('**/proposal/api/v1/bic/products', async route => {
          await route.fulfill({ json: BicSelectInvestmentMock.data })
        })
      })
      test('Reopening window after closing. Checking main table', 
        { tag: ['@3095', '@3328', '@3125'] }, async ({bicPage, homePage}) => {  
          await bicPage.destinationInvestmentWidget.table.checkRadioButtonOnMainTable(0) 

          await bicPage.destinationInvestmentWidget.xButton.click()
          await homePage.tileInvestments.assertBicClosed()

          await homePage.tileInvestments.openBic()
          await bicPage.destinationInvestmentWidget.table.assertRadioButtonOnMainTableNotChecked(0)

          await test.step(`Strategy stays selected after checking twice a radio button`, async () => {
            await bicPage.destinationInvestmentWidget.table.checkRadioButtonOnMainTable(0) 
            await bicPage.destinationInvestmentWidget.table.checkRadioButtonOnMainTable(0) 
          })
        })

      test('Reopening window after closing. Nested table verification', 
        { tag: ['@3095', '@3170'] }, async ({bicPage, homePage}) => {  
          await bicPage.destinationInvestmentWidget.table.expandNestedTable()
          await bicPage.destinationInvestmentWidget.table.checkRadioButtonOnNestedTable(0, 0)

          await bicPage.destinationInvestmentWidget.xButton.click()
          await homePage.tileInvestments.assertBicClosed()

          await homePage.tileInvestments.openBic()
          await bicPage.destinationInvestmentWidget.table.assertNestedTableClosed(0)

          await bicPage.destinationInvestmentWidget.table.expandNestedTable()
          await bicPage.destinationInvestmentWidget.table.assertRadioButtonOnNestedTableNotChecked(0, 0)
        })
    })

    test.describe('Select Destination menu composition', () => {

      test.beforeEach(async ({page}) => {
        await page.route('**/proposal/api/v1/bic/products', async route => {
          await route.fulfill({ json: BicSelectInvestmentMock.data })
        })
      })
      test('Header - Default view', 
        { tag: ['@3086', '@3117'] }, async ({bicPage, homePage}) => {  

          await test.step(`Assert static text in left part of header`, async () => {
            await expect(bicPage.destinationInvestmentWidget.header.getByText('From:')).toBeVisible()
            await expect(bicPage.destinationInvestmentWidget.header.getByText('Current Platform Fee:')).toBeVisible()
          })
          await test.step(`Assert elements in right part of header is absent`, async () => {
            await expect(bicPage.destinationInvestmentWidget.header.getByText('To:')).toBeHidden()
            await expect(bicPage.destinationInvestmentWidget.header.getByText('New Platform Fee:')).toBeHidden()
          })
          await test.step(`Assert header From Strategy name in left part of header`, async () => {
            const fromStrategyNameText = await bicPage.destinationInvestmentWidget.headerFromStrategyName.innerText()
            await expect(homePage.tileInvestments.strategyNames.first()).toContainText(fromStrategyNameText) 
          })
        })
      test('Header - View after chosing new Strategies', 
        { tag: ['@3089', '@3119', '@3124', '@3478'] }, async ({bicPage}) => {  
          const responseBody: ProposalProductsResponseBody = await (await bicPage.productsResponsePromise)!.json()
          let firstStrategyNameFromMainRow

          await test.step(`Parsing table data and Receiving first Strategy name from main row`, async () => {
            firstStrategyNameFromMainRow = await bicPage.destinationInvestmentWidget.table.locators.
              columns(bicPage.destinationInvestmentWidget.table.locators.rowsWithoutNestedTable).nth(0).textContent()
          })
          await test.step(`Assert Strategy name in right part of header after choosing Strategy name from main table row`, async () => {
            await bicPage.destinationInvestmentWidget.table.checkRadioButtonOnMainTable(0)  
            expect(await firstStrategyNameFromMainRow).toContain(await bicPage.getHeaderToStrategyName()) 
          })
          await test.step(`Assert to check 'New Platform Fee' has the format "X.XX%" after choosing Strategy name from main table row`, async () => {
            expect(await bicPage.getHeaderNewPlatformFeeValue()).toMatch(/^\d+\.\d{2}%$/)
          })
          await test.step(`Assert static text in right part of header`, async () => {
            await expect(bicPage.destinationInvestmentWidget.header.getByText('To:')).toBeVisible()
            await expect(bicPage.destinationInvestmentWidget.header.getByText('New Platform Fee:')).toBeVisible()
          })
          await test.step(`Assert Strategy name in right part of header after choosing Strategy name from nested table row`, async () => {
            await bicPage.destinationInvestmentWidget.table.expandNestedTable()
            const firstStrategyNameAfterSelectingNestedRow =  await bicPage.destinationInvestmentWidget.table.getStrategyNameFromApiWhenNestedElementSelected(responseBody, 0, 0)

            await bicPage.destinationInvestmentWidget.table.checkRadioButtonOnNestedTable(0, 0)
            expect(firstStrategyNameAfterSelectingNestedRow).toContain(await bicPage.getHeaderToStrategyName()) 
        
            await test.step(`Assert Strategy name remains selected in Header and Nested table after collapsing it`, async () => {
              await bicPage.destinationInvestmentWidget.table.collapseNestedTable()
              expect(firstStrategyNameAfterSelectingNestedRow).toContain(await bicPage.getHeaderToStrategyName()) 
       
              await bicPage.destinationInvestmentWidget.table.expandNestedTable()
              await expect(bicPage.destinationInvestmentWidget.table.locators.radioButton(bicPage.destinationInvestmentWidget.table.locators.nestedTable(
                bicPage.destinationInvestmentWidget.table.locators.rowsWithNestedTable.nth(0))).nth(0), 'Expect that first nested Strategy is checked').toBeChecked()
              expect(firstStrategyNameAfterSelectingNestedRow).toContain(await bicPage.getHeaderToStrategyName()) 
            })
          })
          await test.step(`Assert to check 'New Platform Fee' has the format "X.XX%" after choosing Strategy name from nested table row`, async () => {
            expect(await bicPage.getHeaderNewPlatformFeeValue()).toMatch(/^\d+\.\d{2}%$/)
          })
        })
      test('Table - Set of available Columns', 
        { tag: ['@3090'] }, async ({bicPage}) => {  
          const tableData = await bicPage.destinationInvestmentWidget.table.data()

          await test.step(`Assert columns names and images`, async () => {
            expect(tableData[0].cell[0].columnName).toEqual(BicConfig.destinationInvestmentColumnNames.strategyName)
            expect(tableData[0].cell[1].columnName).toEqual(BicConfig.destinationInvestmentColumnNames.riskProfile)
            expect(tableData[0].cell[2].columnName).toEqual(BicConfig.destinationInvestmentColumnNames.tms)
            await expect(bicPage.destinationInvestmentWidget.tmsTableHeaderImage).toHaveAttribute('xmlns', 'http://www.w3.org/2000/svg') //ToDO: to replace with screenshot test
            expect(tableData[0].cell[3].columnName).toEqual(BicConfig.destinationInvestmentColumnNames.investmentMin)
            await expect(bicPage.destinationInvestmentWidget.favoriteImages).toHaveAttribute('xmlns', 'http://www.w3.org/2000/svg') //ToDO: to replace with screenshot test
          })
        })
      test('Unselected Strategy state - Error notification visibility', 
        { tag: ['@3128', '@3129'] }, async ({bicPage}) => {  
          await test.step(`Assert that notification is visible for 3 seconds (approximately)`, async () => {
            await bicPage.destinationInvestmentWidget.nextButton.click({ force: true })
            await expect(bicPage.destinationInvestmentWidget.unselectStrategyNotification).toBeVisible()
            await expect(bicPage.destinationInvestmentWidget.unselectStrategyNotification).toBeHidden({timeout: 5000}) //Notification is 3 sec on the screen, additional 2 sec goes on animation
          })
          await test.step(`Assert that notification is Not appeared after clicking Next button second time`, async () => {
            await bicPage.destinationInvestmentWidget.nextButton.click({ force: true })
            await expect(bicPage.destinationInvestmentWidget.unselectStrategyNotification).toBeHidden({timeout: 100}) 
          })
        })
      test('Unselected Strategy state - Error notification content', 
        { tag: ['@3127', '@3128'] }, async ({bicPage}) => {  
          await expect(bicPage.destinationInvestmentWidget.nextButton, 'Assert that Next button is disabled').toBeDisabled()

          await test.step(`Assert that notification has icon and text inside`, async () => {
            await bicPage.destinationInvestmentWidget.nextButton.click({ force: true })
            await expect(bicPage.destinationInvestmentWidget.unselectStrategyNotification).toBeVisible()
            await expect(bicPage.destinationInvestmentWidget.unselectStrategyNotification.getByRole('img')).toHaveAttribute('xmlns', 'http://www.w3.org/2000/svg') //ToDO: to replace with screenshot test
            await expect(bicPage.destinationInvestmentWidget.unselectStrategyNotification.getByText('Select'))
              .toHaveText('Select a Destination Investment to proceed.')
          })
          await expect(bicPage.destinationInvestmentWidget.nextButton, 'Assert that Next button is disabled after clickig on it').toBeDisabled()
        })
      test('Unselected Strategy state - Error popup is available after BIC reopening', 
        { tag: ['@3130'] }, async ({bicPage, homePage}) => {  
          await test.step(`Assert that notification is appeared after clicking Next button`, async () => {
            await bicPage.destinationInvestmentWidget.nextButton.click({ force: true })
            expect(await bicPage.destinationInvestmentWidget.unselectStrategyNotification.isVisible()).toBeTruthy() 
          })
          await test.step(`Reopening BIC and Assert that notification is appeared after clicking Next button`, async () => {
            await bicPage.destinationInvestmentWidget.xButton.click()
            await homePage.tileInvestments.openBic()
            await bicPage.waitPageIsReady()
            await bicPage.destinationInvestmentWidget.nextButton.click({ force: true })
            expect(await bicPage.destinationInvestmentWidget.unselectStrategyNotification.isVisible()).toBeTruthy()  
          })
        })
      test('All Nested Tables Elements Distribution',
        { tag: ['@3171', '@3383', '@3332'] }, async ({bicPage}) => {  
          await bicPage.destinationInvestmentWidget.table.assertNestedTableElementsDistribution()  
        })
      test('Risk profile column format and range', 
        { tag: ['@3109'] }, async ({bicPage}) => { 
          await test.step(`Parsing table data and Verifying valid Risk Profile cells format`, async () => {
            const tableData = await bicPage.destinationInvestmentWidget.table.data() 
            await bicPage.destinationInvestmentWidget.table.validateRiskProfileRanges(tableData)
          })
        })
      test('Strategy name maximum field length and ellipsis style availability', 
        { tag: ['@3108'] }, async ({bicPage}) => {  
      
          await bicPage.destinationInvestmentWidget.table.verifyStrategyNameEllipsisStyleAvailability()
          await bicPage.destinationInvestmentWidget.table.verifyHoverGivesWholeNameOfLongStrategyName()
        })
      test('Verify Eligible and Ineligible font styles and TMS tooltip text', 
        { tag: ['@3111', '@3887'] }, async ({bicPage}) => {  
          await test.step(`Verify Eligible and Ineligible font styles`, async () => {
            await bicPage.destinationInvestmentWidget.table.tmsValuesAssert()
          })
          await test.step(`Verify TMS tooltip text`, async () => {
            await bicPage.destinationInvestmentWidget.tmsIcon.hover()
            await expect(bicPage.destinationInvestmentWidget.infoTooltip, `Verify that tooltip text is correct`)
              .toHaveText('To enroll in TMS, access the Account Wizard for the intended account.')
          })
        })
    })
    test.describe('Search', () => {
      test.beforeEach(async ({page}) => {
        await page.route('**/proposal/api/v1/bic/products', async route => {
          await route.fulfill({ json: BicSelectInvestmentMock.data })
        })
      })

      const searchableFields = ['Strategy Name']
    type Param = {
        fieldForSearchQuery: string,
        searchTrigger: SearchTrigger 
    };
    const testParamsArray: Param[] = [
      {
        fieldForSearchQuery: searchableFields[0],
        searchTrigger: SearchTrigger.KEYBOARD_NAVIGATION_CHOOSE_SUGGEST_OPTION
      },
      {
        fieldForSearchQuery: searchableFields[0],
        searchTrigger: SearchTrigger.ENTER_KEY
      },
      {
        fieldForSearchQuery: searchableFields[0],
        searchTrigger: SearchTrigger.CLICK_ON_SUGGEST_OPTION
      },
      {
        fieldForSearchQuery: searchableFields[0],
        searchTrigger: SearchTrigger.MAGNIFYING_GLASS_BUTTON
      },
    ]
    const withoutSuggestionsTestParams: Param[] = [
      {
        fieldForSearchQuery: searchableFields[0],
        searchTrigger: SearchTrigger.ENTER_KEY
      },
      {
        fieldForSearchQuery: searchableFields[0],
        searchTrigger: SearchTrigger.MAGNIFYING_GLASS_BUTTON
      },
    ]
    for (const param of testParamsArray) {
      test(`Searching ${param.fieldForSearchQuery} using ${param.searchTrigger}`, 
        { tag: ['@3382', '@3375'] }, async ({bicPage}) => {  
          await test.step(`Select suggested strategy`, async () => {
            await bicPage.destinationInvestmentWidget.table.expandNestedTable()
            const tableData = await bicPage.destinationInvestmentWidget.table.data()

            const searchQuery = bicPage.destinationInvestmentWidget.table.getRandomValueByColumnName(
              tableData, param.fieldForSearchQuery)
            await bicPage.destinationInvestmentWidget.search.makeSearch(searchQuery, param.searchTrigger)
            await bicPage.destinationInvestmentWidget.search.verifySearchResult(searchQuery, searchableFields)
          })
        })
    }

    for (const param of withoutSuggestionsTestParams) { 
      test(`Verify Blank search using ${param.searchTrigger}`, async ({bicPage}) => {
        const randomOneSymbol = faker.string.alpha()

        await test.step(`Filling in input field with one char and starting search`, async () => {
          await bicPage.destinationInvestmentWidget.search.makeSearch(randomOneSymbol, param.searchTrigger)
        }) 
        await test.step(`Verifying that tooltip will appear and will has appropriate text`, async () => {
          await bicPage.destinationInvestmentWidget.search.verifyTooltipAndBackgroundColorAppearance()
        })
      })
    }
    test(`Verify input field text maximum boundary condition @3367`, 
      { tag: ['@3367'] }, async ({bicPage}) => {  
        const random50Alphanumeric = faker.string.alphanumeric(50)
        const random51Symbols = faker.string.symbol(51)

        await test.step(`Verifying that filled 50 alphanumerics are accepted by the input field`, async () => {
          await bicPage.destinationInvestmentWidget.search.fillSearchField(random50Alphanumeric) 
          await bicPage.destinationInvestmentWidget.search.locators.searchInput.clear()
        }) 
        await test.step(`Filling in search field with 51 symbols and verifying that only 50 symbols remain in the field`, async () => {
          await bicPage.destinationInvestmentWidget.search.fillSearchField(random51Symbols, random51Symbols.slice(0, -1))
        })
      })
    test(`Verify Suggested result - Auto Complete`, 
      { tag: ['@3357'] }, async ({bicPage}) => {  
        const tableData = await bicPage.destinationInvestmentWidget.table.data()
        const randomRowValue = bicPage.destinationInvestmentWidget.table.getRandomValueByColumnName(
          tableData, searchableFields[0]).split(' ')
        const searchQuery = randomRowValue[randomRowValue.length - 1]
        await bicPage.destinationInvestmentWidget.search.assertAutoComplete(searchQuery)
      })
    test(`Verify that pagination state was reset to 1st page after search`, 
      { tag: ['@3373'] }, async ({bicPage}) => {  
        const tableData = await bicPage.destinationInvestmentWidget.table.data()
        const randomRowValue = bicPage.destinationInvestmentWidget.table.getRandomValueByColumnName(
          tableData, searchableFields[0]).split(' ')
        const searchQuery = randomRowValue[randomRowValue.length - 1]

        await test.step(`Moving to a last page in the widget`, async () => {
          await bicPage.destinationInvestmentWidget.pagination.lastPage()
        }) 
        await test.step(`Making a search and assert that the first page is the current page`, async () => {
          await bicPage.destinationInvestmentWidget.search.makeSearch(searchQuery, SearchTrigger.ENTER_KEY) 
          await bicPage.destinationInvestmentWidget.pagination.assertCurrentPageNumber(1)
        })
      })

    test.describe('Tests with a search query that will return suggestions', () => {
      test.beforeEach(async ({page}) => { 
        await page.route('**/proposal/api/v1/bic/products', async route => {
          await route.fulfill({ json: BicSelectInvestmentMock.data })
        })
      })

      let searchQuery: string
      test.beforeEach('Creating search query and fill the input field', async ({bicPage}) => {
        const tableData = await bicPage.destinationInvestmentWidget.table.data()
        const randomRowValue = bicPage.destinationInvestmentWidget.table.getRandomValueByColumnName(
          tableData, searchableFields[0]).split(' ')
        searchQuery = randomRowValue[randomRowValue.length - 1]
        await bicPage.destinationInvestmentWidget.search.fillSearchField(searchQuery)
      })
      test(`Verify search Hover State, Suggested options background color`, 
        { tag: ['@3358'] }, async ({bicPage}) => {  
          await bicPage.destinationInvestmentWidget.search.verifyHighlights(searchQuery)
          await bicPage.destinationInvestmentWidget.search.verifyBackgroundColorOfHoveredSuggestion()
        })
      test(`Verify Keyboard Up and Down navigation through list of suggestions `, // Test catch a defect EWMBIC-605
        { tag: ['@3371'] }, async ({bicPage}) => {  
          await test.step(`Moving up through list of suggestions, starting from input field`, async () => {
            await bicPage.destinationInvestmentWidget.search.movingUpThroughSuggestions() 
          }) 
          await test.step(`Moving down through list of suggestions, starting from last suggestion`, async () => {
            await bicPage.page.keyboard.press('ArrowUp')
            await bicPage.destinationInvestmentWidget.search.movingDownThroughSuggestions() 
          })
        })

      for (const closeTrigger of Object.values(CloseTrigger)) {
        test(`Closing suggestion list with ${closeTrigger}`, 
          { tag: ['@3371'] }, async ({bicPage}) => {  
            await bicPage.destinationInvestmentWidget.search.closingSuggestion(searchQuery, closeTrigger)
          })
      }
    })
    test.describe('Tests with a search query that will Not return suggestions', () => {
      test.beforeEach(async ({page}) => { 
        await page.route('**/proposal/api/v1/bic/products', async route => {
          await route.fulfill({ json: BicSelectInvestmentMock.data })
        })
      })
      const randomAlphanumeric: string = faker.string.alphanumeric(5)
      
      test.beforeEach('Creating search query from random alphanumeric and verifying that cross button is absent', async ({bicPage}) => {
        await bicPage.destinationInvestmentWidget.search.assertSearchCrossButtonAbsent()
        await bicPage.destinationInvestmentWidget.search.fillSearchField(randomAlphanumeric)
      })
      test(`Verify Search box cross button and deleting text from input field`, 
        { tag: ['@3366'] }, async ({bicPage}) => {  
          await test.step(`Deleting text from input field and Checking that cross button is absent`, async () => {
            await bicPage.destinationInvestmentWidget.search.locators.searchInput.clear()
            await bicPage.destinationInvestmentWidget.search.assertSearchCrossButtonAbsent() 
            await bicPage.destinationInvestmentWidget.search.assertSearchFieldIsEmpty()
          })
        })
      test(`Verify input field text styles `, 
        { tag: ['@4177'] }, async ({bicPage}) => {  
          await test.step(`Verifying text font weight, name, size, color`, async () => {
            await bicPage.destinationInvestmentWidget.search.assertTextStylesInSearchInputField()
          })
        })
      test(`Verify misspelling behaviour `, 
        { tag: ['@3372'] }, async ({bicPage}) => {  
          await bicPage.destinationInvestmentWidget.search.assertNoSuggestions()
        }) 
      test(`Verify Search box cross button and clickig on it`, 
        { tag: ['@3366'] }, async ({bicPage}) => {  
          await test.step(`Verifying cross button appearance after filling in search field`, async () => {
            await bicPage.destinationInvestmentWidget.search.assertSearchCrossButtonAvailable()
          }) 
          await test.step(`Clicking on the cross button and Checking that then it is absent`, async () => {
            await bicPage.destinationInvestmentWidget.search.locators.crossButton.click()
            await bicPage.destinationInvestmentWidget.search.assertSearchCrossButtonAbsent() 
            await bicPage.destinationInvestmentWidget.search.assertSearchFieldIsEmpty()
          })
        })
      test(`No Matching Results `,
        { tag: ['@3374'] }, async ({bicPage}) => {  
          await bicPage.destinationInvestmentWidget.search.makeSearch(randomAlphanumeric, SearchTrigger.ENTER_KEY) 
          await bicPage.destinationInvestmentWidget.verifyEmptyStateElementsVisibility()
        }) 
    })
    })

    test.describe('Pagination', () => {

      test.beforeEach(async ({page}) => {
        await page.route('**/proposal/api/v1/bic/products', async route => {
          await route.fulfill({ json: BicSelectInvestmentMock.data })
        })
      })

      for (const trigger of Object.values(PageSwitchTrigger)) {
        test(`Switching to the last/first pages using ${trigger}`, 
          { tag: ['@3079'] }, async ({bicPage}) => {  
            await expect(bicPage.destinationInvestmentWidget.table.locators.table).toBeVisible()
            await bicPage.destinationInvestmentWidget.pagination.lastPage(trigger, true)
            await bicPage.destinationInvestmentWidget.pagination.firstPage(trigger, true)
          })

        test(`Switching to the next/previous pages using ${trigger}`,
          { tag: ['@3080', '@3081'] }, async ({bicPage}) => {  
            await expect(bicPage.destinationInvestmentWidget.table.locators.table).toBeVisible()
            await bicPage.destinationInvestmentWidget.pagination.nextPage(trigger, true)
            await bicPage.destinationInvestmentWidget.pagination.prevPage(trigger, true)
          })
      }
      test(`Default rows counting while nested strategies expanded `, 
        { tag: ['@3083'] }, async ({bicPage}) => {  
          await bicPage.destinationInvestmentWidget.table.expandNestedTable()
          await bicPage.destinationInvestmentWidget.pagination.assertAmountOfItemsInfo(1)
        })
    })

    test.describe('Data Mapping API->UI', () => {

      test(`Data Mapping`, 
        { tag: ['@3176', '@3111', '@3110', '@3175', '@3167', '@3168', '@3332'] }, async ({bicPage}) => {  
          const rowCount = await bicPage.destinationInvestmentWidget.table.locators.rowsWithNestedTable.count()
          await bicPage.destinationInvestmentWidget.table.expandNestedTable(rowCount)
          const tableData = await bicPage.destinationInvestmentWidget.table.data()
          const responseBody: ProposalProductsResponseBody = await (await bicPage.productsResponsePromise)!.json()
          await bicPage.destinationInvestmentWidget.table.assertDataMapping(responseBody, tableData)

        })
    })

    test.describe('Disabling BIC feature on Investments tile', () => {
      test.beforeEach(async ({page}) => { 
        await page.route((url: URL) => url.toString().includes('/advisormetrics/api/v2/metrics/investments/strategy'), async route => {
          await route.fulfill({ json: BicInvestmentsStrategyForBicIneligibilityMock.data })
        })
      })
  
      test(`Previously selected accounts selections retained after returning to Accounts to Change window`, 
        { tag: ['@4144', '@5114'] }, async ({homePage}) => {
  
          await test.step(`Verifying that BIC button is Not available in all Strategies`, async () => { 
            await expect(homePage.tileInvestments.table.locators.table, 'Waiting Investment tile table is visible').toBeVisible()
            await homePage.tileInvestments.assertAllStrategiesAreBicIneligible()
          }) 
          
        })

    })

    test.describe('Favorite Strategies', () => {
     
      test('Ability to favorite and unfavorite Strategies', 
        { tag: ['@4305', '@4310', '@5632'] }, async ({bicPage, homePage}) => {  
          let selectedFavoriteStrategiesIndexes: number[], unSelectedFavoriteStrategiesIndexes: number[]

          await test.step(`Making five Strategies favorite and verify their selection and then unfavorite one of them`, async () => {
            await bicPage.destinationInvestmentWidget.table.selectingFavoriteStrategies(10, 'unselect') 
            await bicPage.destinationInvestmentWidget.table.selectingFavoriteStrategies(5, 'select') 
            await bicPage.destinationInvestmentWidget.table.selectingFavoriteStrategies(1, 'unselect') 

            selectedFavoriteStrategiesIndexes = (await bicPage.destinationInvestmentWidget.table.getFavoriteStrategyIndexes())[0] 
            unSelectedFavoriteStrategiesIndexes = (await bicPage.destinationInvestmentWidget.table.getFavoriteStrategyIndexes())[1]
          })
          await test.step(`Reopening BIC and verifying retained Favorite and Unfavorite Strategies`, async () => {
            await bicPage.destinationInvestmentWidget.xButton.click()
            await homePage.tileInvestments.assertBicClosed()
            await homePage.tileInvestments.openBic()

            await bicPage.destinationInvestmentWidget.table.assertFavoriteStrategiesSelection('select', selectedFavoriteStrategiesIndexes) 
            await bicPage.destinationInvestmentWidget.table.assertFavoriteStrategiesSelection('unselect', unSelectedFavoriteStrategiesIndexes) 
          })
        })

      test('Default sorting verification', 
        { tag: ['@5223'] }, async ({bicPage}) => {  
        
          await test.step(`Verify default Strategies sorting`, async () => {
            await bicPage.destinationInvestmentWidget.table.selectingFavoriteStrategies(10, 'unselect') 
  
            const tableData = await bicPage.destinationInvestmentWidget.table.data()
            
            await bicPage.destinationInvestmentWidget.table.assertStrategyNamesSorted(tableData) 
          }) 
        })

      test('Ability to sort and discard sorting Strategies by Favorite', 
        { tag: ['@4307', '@4308', '@4309'] }, async ({bicPage}) => {  
          const tableDataDefaultState = await bicPage.destinationInvestmentWidget.table.data()
          let tableDataAfterSorting: TableRow[]
  
          await test.step(`Making last five Strategies favorite, pressing Sort favorite Strategies button and verify Strategies sorting`, async () => {
            await bicPage.destinationInvestmentWidget.table.selectingFavoriteStrategies(10, 'select') 
            await bicPage.destinationInvestmentWidget.table.selectingFavoriteStrategies(5, 'unselect') 

            await bicPage.destinationInvestmentWidget.table.locators.sortingFavoriteStrategyButton.click()

            const selectedFavoriteStrategiesIndexes = (await bicPage.destinationInvestmentWidget.table.getFavoriteStrategyIndexes())[0] 
            const unSelectedFavoriteStrategiesIndexes = (await bicPage.destinationInvestmentWidget.table.getFavoriteStrategyIndexes())[1]
            
            tableDataAfterSorting = await bicPage.destinationInvestmentWidget.table.data()
          
            await bicPage.destinationInvestmentWidget.table.assertStrategyNamesSorted(tableDataAfterSorting, selectedFavoriteStrategiesIndexes) 
            await bicPage.destinationInvestmentWidget.table.assertStrategyNamesSorted(tableDataAfterSorting, unSelectedFavoriteStrategiesIndexes) 
          }) 
          await test.step(`Unselect first of Strategy and verify it moves to unfavorite Strategies, and that favorite and unfavorite Strategies are sorted in Ascending order`, async () => {
            const unselectedFavoriteStrategyName = await bicPage.destinationInvestmentWidget.table.getStrategyNames(tableDataAfterSorting, [0]) 

            await bicPage.destinationInvestmentWidget.table.selectingFavoriteStrategies(1, 'unselect', false) 
            const tableDataAfterUnselecting = await bicPage.destinationInvestmentWidget.table.data()

            const selectedFavoriteStrategiesIndexesAfterUnselecting = (await bicPage.destinationInvestmentWidget.table.getFavoriteStrategyIndexes())[0] 
            const unSelectedFavoriteStrategiesIndexesAfterUnselecting = (await bicPage.destinationInvestmentWidget.table.getFavoriteStrategyIndexes())[1]
      
            const allUnselectedFavoriteStrategyNames = await bicPage.destinationInvestmentWidget.table.getStrategyNames(tableDataAfterUnselecting, unSelectedFavoriteStrategiesIndexesAfterUnselecting) 
         
            expect(allUnselectedFavoriteStrategyNames, 'Verifyng all unselected strategies contain previously unselected strategy').toEqual(expect.arrayContaining(unselectedFavoriteStrategyName))

            await bicPage.destinationInvestmentWidget.table.assertStrategyNamesSorted(tableDataAfterUnselecting, selectedFavoriteStrategiesIndexesAfterUnselecting) 
            await bicPage.destinationInvestmentWidget.table.assertStrategyNamesSorted(tableDataAfterUnselecting, unSelectedFavoriteStrategiesIndexesAfterUnselecting) 
          })
          await test.step(`Discard sorting Strategies by Favorite and verify Sorting of Strategy Names is revert to default `, async () => {
            await bicPage.destinationInvestmentWidget.table.locators.sortingFavoriteStrategyButton.click()
            const tableDataAfterSortingRevert = await bicPage.destinationInvestmentWidget.table.data()
  
            expect(tableDataAfterSortingRevert, 'Verifyng table data reverted to default state').toEqual(tableDataDefaultState)
          })
        })

    })

  })

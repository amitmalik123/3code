import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { EWM3Config } from '../../../../ewm3/service-data/config'

test.describe('Marketing carousel tests', {
  tag: ['@assetmark', '@cheetah', '@stable']
}, () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

  test.beforeEach(async ({ homePage }) => {
    await expect(homePage.marketing.marketingCarousel, 'Waiting for Marketing carousel to be visible').toBeVisible()
    await homePage.marketing.validateTilesAre('expanded')
  })

  test('Tiles should auto scroll', {
    tag: ['@1120', '@1141']
  }, async ({ homePage }) => {
    await homePage.marketing.validateTilesAutoscroll()
  })

  test('Tiles should auto scroll in collapsed mode', {
    tag: '@1135'
  }, async ({ homePage }) => {
    await homePage.marketing.showLessLink.click()
    await homePage.marketing.validateTilesAutoscroll()
  })

  test('Scroll between promotional tiles using left and right horizontal scroll arrows in expanded mode', {
    tag: '@1140'
  }, async ({ homePage }) => {
    await homePage.marketing.validateNextAndBackButtonsOnMarketingCarousel()
  })

  test('Scroll between promotional tiles using left and right horizontal scroll arrows in collapsed mode', {
    tag: '@1124'
  }, async ({ homePage }) => {
    await homePage.marketing.showLessLink.click()
    await homePage.marketing.validateNextAndBackButtonsOnMarketingCarousel()
    await expect(homePage.marketing.showMoreLink).toBeVisible()
  })

  test('Expand/Collapse the promotional tile with "Show more/Show less" link', {
    tag: ['@1123', '@1142']
  }, async ({ homePage }) => {
    // todo: Improve this to validate actual size of tile
    await homePage.marketing.showLessLink.click()
    await homePage.marketing.validateTilesAre('collapsed')
    await expect(homePage.marketing.showMoreLink).toBeVisible()
    await homePage.marketing.showMoreLink.click()
    await homePage.marketing.validateTilesAre('expanded')
    await expect(homePage.marketing.showLessLink).toBeVisible()
  })

  test('Scroll to the promotional tile using the carousel page indicator dots in expanded mode', {
    tag: '@1143'
  }, async ({ homePage }) => {
    //Tiles start with index 0. However, from tile 15 the index goes to -3 until it reaches 0 again. Keep this in mind when validating dot positioning
    const dotPosition = 2
    await homePage.marketing.validateTilesAre('expanded')
    await homePage.marketing.clickOnMarketingCarouselDotByPosition(dotPosition)
    await expect(homePage.marketing.marketingCarouselTilesDisplayed.first()).toHaveAttribute('data-index', `${dotPosition}`)
    await expect(homePage.marketing.showLessLink).toBeVisible()
  })

  test('Scroll to the promotional tile using the carousel page indicator dots in collapsed mode', {
    tag: '@1136'
  }, async ({ homePage }) => {
    //Tiles start with index 0. However, from tile 15 the index goes to -3 until it reaches 0 again. Keep this in mind when validating dot positioning
    const dotPosition = 3
    await homePage.marketing.showLessLink.click()
    await homePage.marketing.validateTilesAre('collapsed')
    await homePage.marketing.clickOnMarketingCarouselDotByPosition(dotPosition)
    await expect(homePage.marketing.marketingCarouselTilesDisplayed.first()).toHaveAttribute('data-index', `${dotPosition}`)
  })

})

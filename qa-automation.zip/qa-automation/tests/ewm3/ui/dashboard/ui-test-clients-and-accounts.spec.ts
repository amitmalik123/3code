import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { EWM3Config } from '../../../../ewm3/service-data/config'
import { ClientsConfig } from '../../../../ewm3/service-data/tile-config/clients.config'
import { PageSwitchTrigger } from '../../../../ewm3/ui/features/pagination.feature'
import { TableRow } from '../../../../ewm3/ui/features/table.feature'
import { HomePage } from '../../../../ewm3/ui/pages/home-page'
import { SortingOrder } from '../../../../ewm3/ui/features/sorting.feature'
import { syncedTest } from '../../../../ewm3/fixtures/synced-ui-fixtures'
import { DashboardConfig } from '../../../../ewm3/service-data/tile-config/dashboard.config'
import { CloseModalTrigger } from '../../../../ewm3/ui/elements/modal-screen.feature'
import { CustomizeMenuItem } from '../../../../ewm3/ui/features/base-customize-menu.feature'

test.describe('Clients Tile tests', {
  tag: ['@assetmark', '@cheetah', '@stable']
}, () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

  test.describe('Search', () => {
    for (const param of ClientsConfig.searchTestParamsArray) {
      test(`Tab ${param.tab}. Searching "${param.fieldForSearchQuery}" using ${param.searchTrigger}`, {
        tag: ['@1456', '@1458', '@1486', '@1534', '@1536', '@1929']
      }, async ({ apiHelpers, homePage }) => {
        if (param.tab === ClientsConfig.tabs.following) await apiHelpers.flagSomeClientsItemIfEmpty(3)
        await homePage.tileClientList.prepareTableForSearch(param)
        const tableData = await homePage.tileClientList.table.data()
        const searchQuery = homePage.tileClientList.table.getRandomValueByColumnName(
          tableData, param.fieldForSearchQuery
        )
        await homePage.tileClientList.search.makeSearch(searchQuery, param.searchTrigger)
        await homePage.tileClientList.search.verifySearchResult(searchQuery, param.searchableFieldArray)
      })

    }

    test.describe('Cancel search', () => {
      for (const param of ClientsConfig.cancelSearchParamsArray) {
        test(`Tab ${param.tab}. Fill search "${param.fieldForSearchQuery}" and delete all text by '${param.searchCancelTrigger}'`, {
          tag: ['@1471', '@1472']
        }, async ({ apiHelpers, homePage }) => {
          if (param.tab === ClientsConfig.tabs.following) await apiHelpers.flagSomeClientsItemIfEmpty(3)
          await homePage.tileClientList.prepareTableForSearch(param)
          const tableData = await homePage.tileClientList.table.data()
          await homePage.tileClientList.search.fillSearchField(tableData[0].cell[0].value)
          const tableDataAfterFill = await homePage.tileClientList.table.data()
          expect(tableData, 'Validating table has not changed after fill').toEqual(tableDataAfterFill)
          await homePage.tileClientList.search.cancelSearch(param.searchCancelTrigger)
          await homePage.tileClientList.search.assertSearchFieldIsEmpty()
          await homePage.tileClientList.search.assertSearchCrossButtonAbsent()
        })
      }
    })

  })

  test.describe('Pagination', () => {
    for (const tab of [ClientsConfig.tabs.clients, ClientsConfig.tabs.pending_funding]) {
      for (const trigger of Object.values(PageSwitchTrigger)) {
        test(`Tab: ${tab}. Switching to the last/first pages using ${trigger}`, {
          tag: '@1847'
        }, async ({ homePage }) => {
          await homePage.tileClientList.openTab(tab)
          await homePage.tileClientList.pagination.lastPage(trigger, true)
          await homePage.tileClientList.pagination.firstPage(trigger, true)
        })

        test(`Tab: ${tab}. Switching to the next/previous pages using ${trigger}`, {
          tag: '@662'
        }, async ({ homePage }) => {
          await homePage.tileClientList.openTab(tab)
          await homePage.tileClientList.pagination.nextPage(trigger, true)
          await homePage.tileClientList.pagination.prevPage(trigger, true)
        })
      }

      for (const rowsPerPage of [5,10,15]) {
        test(`Tab: ${tab}. Assert rows per page. Set ${rowsPerPage} rows per page`, {
          tag: ['@654', '@663', '@664', '@665', '@666']
        }, async ({ homePage }) => {
          await homePage.tileClientList.openTab(tab)
          await homePage.tileClientList.pagination.switchRowsPerPage(rowsPerPage, true)
        })
      }
    }
  })

  test.describe('Data Mapping API -> UI', () => {
    
    for (const param of ClientsConfig.mappingParamsArray) {
      test(`Tables mapping assert: Tab: "${param.tab}" endpoint: "${param.endpoint}"`, async ({ apiHelpers,page }) => {
        if(param.tab === ClientsConfig.tabs.following) await apiHelpers.flagSomeClientsItemIfEmpty(3)
        const responsePromise = page.waitForResponse(response =>
          response.url().includes(param.endpoint) && response.status() === 200, { timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM }
        )
        const homePage = new HomePage(page)
        await homePage.goto()
        await homePage.waitPageIsReady()
        await homePage.tileClientList.openTab(param.tab)
        const responseBody = await (await responsePromise).json()
        await homePage.tileClientList.customizeColumns.selectAllColumns()
        await expect(homePage.tileClientList.table.locators.table).toBeVisible()
        if (param.tab !== ClientsConfig.tabs.pending_funding) {
          await homePage.tileClientList.table.expandNestedTable()
        }
        const tableData = await homePage.tileClientList.table.data()
        await homePage.tileClientList.table.assertDataMapping(
          responseBody,
          tableData,
          param.mappingConfig
        )
      })
    }

  })

  test.describe('Sorting', () => {
    for (const param of ClientsConfig.sortingTestParamsArray) {
      for (const fieldConfig of param.tableConfig.fields) {
        test(`Tab: ${param.tab}; Column: "${fieldConfig.columnName}"`, {
          tag: ['@1092', '@1093', '@1095', '@1096', '@1854']
        }, async ({ homePage }) => {
          await homePage.tileClientList.prepareTileOnTab(param, 'selectAll')
          await homePage.tileClientList.pagination.switchRowsPerPage(15)
          const pagesCount = await homePage.tileClientList.pagination.lastPageNumber()

          for (const sortingOrder of Object.values(SortingOrder)) {
            await homePage.tileClientList.pagination.firstPage()

            await homePage.tileClientList.table.sorting.sortBy({
              columnName: fieldConfig.columnName,
              sortingOrder: sortingOrder
            })
            
            const tableRowArray: TableRow[] = await homePage.tileClientList.table.data()
            for (let i = 1; i < pagesCount; i++) {
              await homePage.tileClientList.pagination.nextPage()
              tableRowArray.push(...await homePage.tileClientList.table.data())
            }

            await homePage.tileClientList.table.sorting.assertSorting(
              param.tableConfig,
              tableRowArray,
              {
                columnName: fieldConfig.columnName,
                sortingOrder: sortingOrder
              },
            )
          }
        })
      }
    }
  })

  test.describe('Sorting nested table', () => {
    for (const param of ClientsConfig.sortingTestParamsArray) {
      if (!param.tableConfig.fields) {
        console.error('Cant perform tests: Sorting nested table - nestedTableDataConfig is not defined')
        return
      }
      if (param.tableConfig.nestedTableDataConfig == null) { continue }
      for (const field of param.tableConfig.nestedTableDataConfig.fields.filter(x => x.platforms?.includes(process.env.PLATFORM!))) {
        if (!field.enable_sorting) { continue }

        test(`Tab: ${param.tab}; Nested Column: "${field.columnName}`, {
          tag: ['@5088']
        }, async ({ homePage }) => {
          await homePage.tileClientList.customizeColumns.selectAllColumns()
          await homePage.tileClientList.table.expandNestedTable()
          for (const sortingOrder of Object.values(SortingOrder)) {
            await homePage.tileClientList.table.sorting.sortAllNestedTeblesOnCurrentPageBy({
              columnName: field.columnName,
              sortingOrder: sortingOrder
            })
            const tableRowArray: TableRow[] = await homePage.tileClientList.table.data()

            await homePage.tileClientList.table.sorting.assertNestedSorting(
              param.tableConfig.nestedTableDataConfig!,
              tableRowArray,
              {
                columnName: field.columnName,
                sortingOrder: sortingOrder
              },
            )
          }
        })
      }
    }
  })

  test.describe('Customize columns form', () => {
    for (const param of ClientsConfig.customizeColumnsParamsArray) {
      test(`Default. Tab: ${param.tab}`, {
        tag: ['@953', '@2836']
      }, async ({ homePage }) => {
        await homePage.tileClientList.prepareTileOnTab(param)
        const tableData = await homePage.tileClientList.table.data()

        await homePage.tileClientList.customizeColumns.compareCustomizeColumnsAndTable({tableRowArray: tableData})
        await homePage.tileClientList.table.assertMainTableDefaultState(param.tableConfig, tableData)
        if (param.tableConfig.nestedTableDataConfig) {          
          const nestedTableData = tableData.find(row => row.nestedTableRow != undefined)?.nestedTableRow
          await homePage.tileClientList.table.assertNestedTableDefaultState(param.tableConfig.nestedTableDataConfig, nestedTableData)
        }
      })

      test(`All selected. Tab: ${param.tab}`, async ({ homePage }) => {
        await homePage.tileClientList.prepareTileOnTab(param, 'selectAll')
        await homePage.tileClientList.customizeColumns.compareCustomizeColumnsAndTable()
      })

      test(`All deselected. Tab: ${param.tab}`, async ({ homePage }) => {
        await homePage.tileClientList.prepareTileOnTab(param, 'deselectAll')
        await homePage.tileClientList.customizeColumns.compareCustomizeColumnsAndTable()
      })

      test(`Selecting/deselecting some of options. Tab: ${param.tab}`, async ({ homePage }) => {
        await homePage.tileClientList.prepareTileOnTab(param, 'selectAll')
        const customizeColumnOptions = await homePage.tileClientList.customizeColumns.data()
        await homePage.tileClientList.customizeColumns.compareCustomizeColumnsAndTable()
        await homePage.tileClientList.customizeColumns.deselectItemsByName([
          customizeColumnOptions[1].itemText,
        ])
        await homePage.tileClientList.customizeColumns.compareCustomizeColumnsAndTable()
      })

      for (const field of param.tableConfig.fields.filter(x => x.platforms?.includes(process.env.PLATFORM!))) {
        test(`Selecting/deselecting each toggle separately. Tab: ${param.tab}; Nested Column: "${field.columnName}`, {
          tag: ['@5089']
        }, async ({ apiHelpers, homePage }) => {
          if (param.tab === ClientsConfig.tabs.following) await apiHelpers.flagSomeClientsItemIfEmpty(3)
          await homePage.tileClientList.prepareTileOnTab(param, 'deselectAll')
          await homePage.tileClientList.customizeColumns.selectItemsByName(field.columnName)
          await homePage.tileClientList.customizeColumns.compareCustomizeColumnsAndTable()
          await homePage.tileClientList.customizeColumns.deselectItemsByName(field.columnName)
          await homePage.tileClientList.customizeColumns.compareCustomizeColumnsAndTable()
        })
      }

      test(`Reordering columns by dragging Up changes the order in Form and Table for tab: ${param.tab}`, {
        tag: ['@5090']
      }, async ({ apiHelpers, homePage }) => {
        const toolbarDataBefore: CustomizeMenuItem[] = []
        const toolbarDataAfter: CustomizeMenuItem[] = []
        if (param.tab === ClientsConfig.tabs.following) await apiHelpers.flagSomeClientsItemIfEmpty(3)

        toolbarDataBefore.push(...await homePage.tileClientList.customizeColumns.data())
        await homePage.tileClientList.customizeColumns.openMenu()
        await homePage.tileClientList.customizeColumns.dragAndDropMenuItemsByName(toolbarDataBefore[toolbarDataBefore.length-1].itemText, toolbarDataBefore[0].itemText)
        toolbarDataAfter.push(... await homePage.tileClientList.customizeColumns.data())
        // Change the initial state according to the performed changes: move the latest element to the very beginning
        if (toolbarDataBefore.length >= 2) {
          const lastElement = toolbarDataBefore.pop()
          toolbarDataBefore.unshift(lastElement!)
        }
        // Check if Initial state with applied changes match Final state
        expect.soft(toolbarDataAfter,`Assert columns order changed after dragging in Customize Columns form`).toEqual(toolbarDataBefore)
        await homePage.tileClientList.customizeColumns.compareCustomizeColumnsAndTable()
      })

      test(`Reordering columns by dragging Down changes the order in Form and Table for tab: ${param.tab}`, {
        tag: ['@5090']
      }, async ({ apiHelpers, homePage }) => {
        const toolbarDataBefore: CustomizeMenuItem[] = []
        const toolbarDataAfter: CustomizeMenuItem[] = []
        if (param.tab === ClientsConfig.tabs.following) await apiHelpers.flagSomeClientsItemIfEmpty(3)

        toolbarDataBefore.push(...await homePage.tileClientList.customizeColumns.data())
        await homePage.tileClientList.customizeColumns.openMenu()
        await homePage.tileClientList.customizeColumns.dragAndDropMenuItemsByName(toolbarDataBefore[0].itemText, toolbarDataBefore[toolbarDataBefore.length-1].itemText)
        toolbarDataAfter.push(... await homePage.tileClientList.customizeColumns.data())
        if (toolbarDataBefore.length >= 2) {
          const firstElement = toolbarDataBefore.shift()
          toolbarDataBefore.push(firstElement!)
        }
        expect.soft(toolbarDataAfter,`Assert columns order changed after dragging in Customize Columns form`).toEqual(toolbarDataBefore)
        await homePage.tileClientList.customizeColumns.compareCustomizeColumnsAndTable()
      })

      test(`Blue line indicator is displayed while dragging Up for tab: ${param.tab}`, async ({ homePage }) => {
        const toolbarData = await homePage.tileClientList.customizeColumns.data()
        await homePage.tileClientList.customizeColumns.openMenu()
        await homePage.tileClientList.customizeColumns.dragItemByName(toolbarData[toolbarData.length-1].itemText, toolbarData[0].itemText)
        await expect(homePage.tileClientList.customizeColumns.locators.menuDropSeparator,`Blue line indicator is displayed while dragging Up`).toBeVisible()
        await expect(homePage.tileClientList.customizeColumns.locators.menuItemAfterSeparator,`I view a blue line indicator at the bottom edge of the upper column`).toContainText(toolbarData[0].itemText)
      })
    
      test(`Blue line indicator is displayed while dragging Down for tab: ${param.tab}`, async ({ homePage }) => {
        const toolbarData = await homePage.tileClientList.customizeColumns.data()
        await homePage.tileClientList.customizeColumns.openMenu()
        await homePage.tileClientList.customizeColumns.dragItemByName(toolbarData[0].itemText, toolbarData[toolbarData.length-1].itemText)
        await expect(homePage.tileClientList.customizeColumns.locators.menuDropSeparator,`Blue line indicator is displayed while dragging Up`).toBeVisible()
        await expect(homePage.tileClientList.customizeColumns.locators.menuItemBeforeSeparator,`I view a blue line indicator at the bottom edge of the lower column`).toContainText(toolbarData[toolbarData.length-1].itemText)
      })
    }
  })

  test.describe('Tile menu options', () => {
  
    test('Close tile actions by clicking tile menu options', {
      tag: '@1013'
    }, async ({ homePage }) => {
      await test.step('And I open the tile menu options', async () => {
        await homePage.tileClientList.tileOptionsButton.click()
        await expect(homePage.tileClientList.menuOptionRemoveTile, 'Waiting for menu options to be visible').toBeVisible()
      })
      await test.step('And close the tile actions menu by clicking on the tile options menu button', async () => {
        await homePage.tileClientList.tileOptionsButton.click()
        await expect(homePage.tileClientList.menuOptionRemoveTile, 'Expecting tile menu popup to not be visible').toBeHidden()
      })
    })

    test('Close the tile actions menu by clicking outside of the menu area', {
      tag: '@1012'
    }, async ({ homePage }) => {
      await test.step('And I open the tile menu options', async () => {
        await homePage.tileClientList.tileOptionsButton.click()
        await expect(homePage.tileClientList.menuOptionRemoveTile, 'Waiting for menu options to be visible').toBeVisible()
      })
      await test.step('And close the tile actions menu by clicking outside of the menu area', async () => { 
        await homePage.welcomeMessage.click()
        await expect(homePage.tileClientList.menuOptionRemoveTile, 'Expecting tile menu popup to not be visible').toBeHidden()
      })
    })

    test('Tile action menu options should be present', {
      tag: ['@986', '@3409']
    }, async ({ homePage }) => {
      await test.step('When I click on tile options in the top right corner of the tile', async () => {
        await homePage.tileClientList.tileOptionsButton.click()
      })
      await homePage.tileClientList.validateTileMenuOptions(Object.values(ClientsConfig.tileMenuOptions))
    })

    test('Tile action menu options should be present for client list nested table', {
      tag: '@1449'
    }, async ({ homePage }) => {
      await test.step('When I click on options next to the client name', async () => {
        await homePage.tileClientList.openRowActionsMenuInPosition(3)
      })
      await homePage.tileClientList.validateTileMenuOptions(Object.values(ClientsConfig.nestedMenuOptions))
    })

    for (const trigger of Object.values(CloseModalTrigger)) {
      test(`Tile action menu "Learn about this tile" should show as expected and close it by ${trigger}`, {
        tag: ['@3601', '@3602', '@3603', '@3604', '@3605']
      }, async ({ homePage }) => {
        await test.step('When I click on "Learn about this tile"', async () => {
          await homePage.tileClientList.tileOptionsButton.click()
          await homePage.tileClientList.clickTileOptionByText(ClientsConfig.tileMenuOptions.learnAboutTile)
        })
        await test.step('Validate "Learn about this tile" modal screen', async () => {
          await homePage.modalScreen.validateActionModalContent(ClientsConfig.learnAboutThisTileProperties)
          await homePage.modalScreen.closeModal(trigger)
        })
      })
    }
    
  })
})

syncedTest.describe('Resizable tile test case', {
  tag: ['@assetmark', '@cheetah', '@2692']
}, () => {
  const widgetName = DashboardConfig.tiles.clients.name
  for (const param of DashboardConfig.resizableTestParam) {
    syncedTest(`Tile "${widgetName}" should be displayed in a ${param.size} size`, async ({ removeAllWidgets, page, apiHelpers }) => {
      await syncedTest.step(`Add widget "${widgetName}" with height ${param.height} and width ${param.width}`, async () => {
        const widget = apiHelpers.widgets.getWidgets().client_list
        await apiHelpers.addWidgetOnDashboard(widget, {height: param.height, width: param.width})
      })
      await syncedTest.step(`Validates widget "${widgetName}" size (needs page refresh)`, async () => {
        const homePage = new HomePage(page)
        await homePage.goto()
        await homePage.waitPageIsReady()
        await homePage.tileClientList.validateTileSize(param.size)
      })
    })
  }
})

import { test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { distinctDashboardTest, expect } from '../../../../ewm3/fixtures/distinct-dashboard-ui-fixture'
import { EWM3Config, Platforms } from '../../../../ewm3/service-data/config'
import { DashboardConfig } from '../../../../ewm3/service-data/tile-config/dashboard.config'
const envTiles = Object.values(DashboardConfig.tiles).filter(x => x.platforms.includes(EWM3Config.PLATFORM))
const tileNames = envTiles.map(x => x.name)

distinctDashboardTest.describe('Manage tiles tests', {
  tag: ['@assetmark', '@cheetah', '@stable']
}, () => {
  distinctDashboardTest.use({ storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT) })

  distinctDashboardTest.describe('Close manage tiles menu tests', {
    tag: '@250'
  }, () => {
    distinctDashboardTest.beforeEach(async ({ homePage }) => {
      await homePage.openTileManager()
      await expect(homePage.tileManager.manageTilesTitle, 'Validates CMS text received matches expectation').toHaveText('Select tiles to add or remove')
    })

    // distinctDashboardTest is used to run tests in paralel without breaking for using the same dashboard and same user
    distinctDashboardTest('Manage Tiles. Clicking the "Close" button closes the tile menu', {
      tag: ['@246', '@2705']
    }, async ({ homePage }) => {
      await expect(homePage.tileManager.openedManageTilesMenu).toHaveText('Manage Tiles')
      await homePage.tileManager.closeManageTilesMenuButton.click()
      await expect(homePage.tileManager.manageTilesWholeModule, 'Expecting for side tile menu to not be visible').not.toBeVisible()
    })
    
    distinctDashboardTest('Manage Tiles. Click outside the tile menu has no effect and closes tile menu', {
      tag: ['@2705', '@2708', '@1012']
    }, async ({ homePage }) => {
      // Even if most items will not respond to a click with the tile menu open, items on the header still will respond
      await homePage.welcomeMessage.click({force: true})
      await expect(homePage.dashboard.dashboardListDropdownTrigger, 'Expecting that the click had no effect').toBeVisible()
      await expect(homePage.tileManager.manageTilesWholeModule, 'Expecting for side tile menu to not be visible').not.toBeVisible()
    })
        
    distinctDashboardTest('Manage Tiles. Pressing escape key closes tile menu', {
      tag: '@2705'
    }, async ({ homePage }) => {
      await homePage.pressKey('Escape')
      await expect(homePage.tileManager.manageTilesWholeModule, 'Expecting for side tile menu to not be visible').not.toBeVisible()
    })

    distinctDashboardTest('Manage Tiles. Click header profile menu still opens menu options with tile manager opened', {
      tag: '@959'
    }, async ({ homePage }) => {
      // Even if most items will not respond to a click with the tile menu open, items on the header still will respond
      await homePage.header.openProfileMenu()
      await homePage.header.validateDropdownItems(Object.values(DashboardConfig.userMenuDropdownItems))
      await expect(homePage.tileManager.manageTilesWholeModule, 'Expecting for side tile menu to not be visible').not.toBeVisible()
    })

  })

  distinctDashboardTest.describe('Select tiles from tile menu', {
    tag: '@560'
  }, () => {
    distinctDashboardTest.beforeEach(async ({ homePage }) => {
      await expect(homePage.manageTilesMenuButton, 'Validating manage tiles button tooltip').toHaveAttribute('aria-label', 'Open Tile Manager', {ignoreCase: true})
      await homePage.openTileManager()
    })

    distinctDashboardTest('Manage Tiles. Clicking areas that are not tiles inside tile menu keeps it open', {
      tag: '@2709'
    }, async ({ removeAllWidgets, homePage }) => {
      await homePage.tileManager.useSampleDashboard.click()
      await homePage.tileManager.manageTilesTitle.click()
      await expect(homePage.tileManager.openedManageTilesMenu, 'Expecting for side tile menu to not be visible after selecting use sample dashboard').toBeVisible()
    })

    distinctDashboardTest('Manage Tiles. Toggle all with select all toggle will show all tiles on dashboard page', async ({ removeAllWidgets, homePage }) => {
      await homePage.tileManager.toggleSelectAll.check()
      await expect(homePage.tileManager.toggleSelectAll, 'Expecting for select all toggle to be checked').toBeChecked()
      await homePage.validateTileVisibleOnDashboard(true, tileNames)
    })

    distinctDashboardTest('Manage Tiles. Toggle all one by one (enabling)', async ({ removeAllWidgets, homePage }) => {
      await homePage.tileManager.toggleAllTilesOneByOne()
      await expect(homePage.tileManager.toggleSelectAll, 'Expecting for select all toggle to be checked').toBeChecked()
      await homePage.validateTileVisibleOnDashboard(true, tileNames)
    })

    distinctDashboardTest('Manage Tiles. Toggle all one by one (disabling)', {
      tag: '@694'
    }, async ({ removeAllWidgets, homePage }) => {
      await homePage.tileManager.toggleSelectAll.check()
      await homePage.tileManager.toggleAllTilesOneByOne()
      await expect(homePage.tileManager.toggleSelectAll, 'Expecting for select all toggle to be not checked').not.toBeChecked()
      await homePage.validateTileVisibleOnDashboard(false, tileNames)
      await homePage.dashboard.validateDashboardIsEmpty()
    })

    for (const tile of envTiles) {
      distinctDashboardTest(`Manage Tiles. ${tile.name} shows on dashboard when toggled, disappears when untoggled`, async ({ removeAllWidgets, homePage }) => {
        await homePage.tileManager.toggleTile(tile.name)
        await homePage.validateTileVisibleOnDashboard(true, tile.name)
        await homePage.tileManager.untoggleTile(tile.name)
        await homePage.validateTileVisibleOnDashboard(false, tile.name)
      })
    }
  })

  distinctDashboardTest.describe('Delete tiles from dashboard', {
    tag: ['@1756', '@987', '@1952']
  }, () => {
    distinctDashboardTest('Manage Tiles. Should be able to delete any tile from dashboard', async ({ addAllWidgets, homePage }) => {
      await distinctDashboardTest.step('Remove all tiles through tile action menu', async () => {
        await homePage.tileAssetsOnPlatform.removeTile()
        await homePage.tileClientList.removeTile()
        await homePage.tileInvestments.removeTile()
        await homePage.tileNetFlows.removeTile()
        await homePage.tileStatusAndTracking.removeTile()
        if (process.env.PLATFORM === Platforms.ASSETMARK) {
          await homePage.tileAdvisorBenefits.removeTile()
          await homePage.tileFees.removeTile()
        }
      })
      await homePage.dashboard.validateDashboardIsEmpty()
    })
  })

})

test.describe('Manage tiles tests', {
  tag: ['@stable']
}, () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

  test.describe('Tile preview feature', {
    tag: ['@assetmark', '@cheetah', '@248']
  }, () => {
    for (const tile of envTiles) {
      const tileName = tile.name
      test(`Manage tiles. Toggle for tile "${tileName}" should have tile preview`, async ({ homePage }) => {
        await homePage.openTileManager()
        await test.step(`Hover over "${tileName}" trigger inside tile manager`, async () => {
          await (await homePage.tileManager.getToggleByName(tileName)).hover()
        })
        await homePage.tileManager.validateTilePreviewForTile(tileName)
      })
    }
  })

  test('Manage tiles. Validate tile list on tile manager', {
    tag: ['@assetmark', '@cheetah', '@1122']
  }, async ({ homePage }) => {
    await homePage.openTileManager()
    for (let i = 0; i < tileNames.length; i++) {
      if (i === 0) await expect(homePage.tileManager.sidebarTileList.nth(0)).toHaveText('Select All')
      await test.step(`Toggle in position "${i}" should be "${tileNames[i]}" inside tile manager`, async () => {
        await expect(homePage.tileManager.sidebarTileList.nth(i+1)).toContainText(tileNames[i])
      })
    }
  })

  test.describe('Cheetah only tests', {
    tag: '@cheetah'
  }, () => {

    test('Tiles that are assetmark only should not be present for cheetah', {
      tag: ['@5121', '@5125']
    }, async ({ homePage }) => {
      const assetmarkOnlyTiles = Object.values(DashboardConfig.tiles).filter(x => x.platforms.toLocaleString() === Platforms.ASSETMARK)
      await homePage.openTileManager()
      for (const tile of assetmarkOnlyTiles) {
        const tileName = tile.name
        await test.step(`Tile "${tileName}" should not be present at cheetah tenant`, async () => {
          await expect(await homePage.tileManager.getToggleByName(tileName)).toHaveCount(0)
        })
      }
    })

  })

})

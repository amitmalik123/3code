import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { EWM3Config } from '../../../../ewm3/service-data/config'
import { HomePage } from '../../../../ewm3/ui/pages/home-page'
import { NetflowsConfig } from '../../../../ewm3/service-data/tile-config/netflows.config'
import { CloseModalTrigger } from '../../../../ewm3/ui/elements/modal-screen.feature'

test.describe('Net Flows tests', {
  tag: ['@assetmark', '@cheetah', '@stable']
}, () => {
  test.use({ storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT) })

  test('Tile action menu options should be present', {
    tag: '@986'
  }, async ({ homePage }) => {
    await test.step('When I click on tile options in the top right corner of the tile', async () => {
      await homePage.tileNetFlows.tileOptionsButton.click()
    })
    await expect(homePage.tileNetFlows.menuOptionRemoveTile, 'The tile menu options should be displayed').toBeVisible()
    await homePage.tileNetFlows.validateTileMenuOptions(Object.values(NetflowsConfig.tileMenuOptions))
  })

  for (const param of NetflowsConfig.timePeriodsParams) {
    test(`Select period: ${param.timePeriod}`, {
      tag: ['@1489', '@1490', '@1493']
    }, async ({ page }) => {
      const responsePromise = page.waitForResponse(response =>
        response.url().includes(`/advisormetrics/api/v2/metrics/netflow/${param.apiPathParam}`) && response.status() === 200,
      {timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM}
      )
      const homePage = new HomePage(page)
      await homePage.goto()
      await homePage.waitPageIsReady()
      await test.step(`When user select "${param.timePeriod}" time period selector`, async () => {
        await homePage.tileNetFlows.selectTimePeriodSelector(param.timePeriod)

      })
      const responseBody = await (await responsePromise).json()
      const expectedCurrentDateLabel = param.labelDateFormat(new Date(responseBody.startDate))
      await test.step(`Then time selector will display the current time period: "${param.timePeriod}"`, async () => {
        await homePage.tileNetFlows.verifyTagForTimePeriod(expectedCurrentDateLabel)
      })

    })
  }

  for (const trigger of Object.values(CloseModalTrigger)) {
    test(`Tile action menu "${NetflowsConfig.tileMenuOptions.learnAboutTile}" should show as expected and close it by ${trigger}`, {
      tag: ['@3942', '@3943', '@3944', '@3945', '@3946']
    }, async ({ homePage }) => {
      await test.step('When I click on "Learn about this tile"', async () => {
        await homePage.tileNetFlows.tileOptionsButton.click()
        await homePage.tileNetFlows.clickTileOptionByText(NetflowsConfig.tileMenuOptions.learnAboutTile)
      })
      await test.step('Validate "Learn about this tile" modal screen', async () => {
        await homePage.modalScreen.validateActionModalContent(NetflowsConfig.learnAboutThisTileProperties)
        await homePage.modalScreen.closeModal(trigger)
      })
    })
  }

  for (const period of NetflowsConfig.timePeriodsParams) {
    test(`Tool tip on the graphics displays ${NetflowsConfig.toolTipItems} values for period: ${period.timePeriod}`, {
      tag: ['@401', '@403', '@405']
    }, async ({ homePage }) => {
      await homePage.tileNetFlows.selectTimePeriodSelector(period.timePeriod)
      await test.step('Hover over a grouped bar in my stacked bar chart', async () => {
        await homePage.tileNetFlows.barChart.hover()
      })
      await test.step(`Hover tool tip should displays ${NetflowsConfig.toolTipItems} for period ${period.timePeriod}`, async () => {
        await homePage.tileNetFlows.validateToolTipLabels(NetflowsConfig.toolTipItems)
        await homePage.tileNetFlows.validateToolTipItemsCurrencyFormat(NetflowsConfig.toolTipItems)
      })
    })
  }
  
  test('Metric should be in correct format for Net flows widget', {
    tag: '@941'
  }, async ({ homePage }) => {
    const font = NetflowsConfig.font
    const testParams = [
      {
        font: font.timePeriod, elementLocator: homePage.tileNetFlows.timePeriodSelected
      }, 
      {
        font: font.metricValue, elementLocator: homePage.tileNetFlows.metricValue
      },
      {
        font: font.changesIndicator, elementLocator: homePage.tileNetFlows.changesIndicator
      }
    ]
    await test.step('Then user verify that the widget should display the metric in correct format', async () => {
      await homePage.validateFontFormats(testParams)
    })
  }) 

})

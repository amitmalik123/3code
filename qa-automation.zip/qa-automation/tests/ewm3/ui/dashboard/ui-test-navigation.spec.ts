import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { EWM3Config, Platforms } from '../../../../ewm3/service-data/config'
import { DashboardConfig } from '../../../../ewm3/service-data/tile-config/dashboard.config'
import { CookiesConfig } from '../../../../ewm3/service-data/tile-config/privacy-popup.config'
import { ClientSectionHouseholdPage } from '../../../../ewm3/ui/pages/client-section-household-page'
import { HomePage } from '../../../../ewm3/ui/pages/home-page'
const envLinks = Object.values(DashboardConfig.headerLinks).filter(x => x.platforms.includes(EWM3Config.PLATFORM))
const advisorLinks = Object.values(DashboardConfig.advisorWorkstationDropdownItems).filter(x => x.platforms.includes(EWM3Config.PLATFORM))

test.describe('Isolated tests group', {
  tag: ['@stable']
}, () => {
  test.use({ storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT) })
  
  test('Profile menu list have all expected options', {
    tag: ['@assetmark', '@cheetah', '@3522', '@3435']
  }, async ({ homePage }) => {
    await test.step('Profile dropdown options should show as expected', async () => {
      await homePage.header.openProfileMenu()
      await homePage.header.validateDropdownItems(Object.values(DashboardConfig.userMenuDropdownItems))
    })
  })

  test('Hovering over the home button should show expected options', {
    tag: ['@assetmark', '@574', '@575', '@576', '@577']
  }, async ({ homePage }) => {
    await test.step('Validate home button hover dropdown options', async () => {
      await homePage.header.homeButton.hover()
      await expect(homePage.header.homeButtonDropDown, 'Waiting for hover dropdown to appear').toBeVisible()
      await homePage.validateHomeButtonHoverOptions()
    })
  })

  test('Header links should include all expected items', {
    tag: ['@cheetah', '@assetmark', '@5126', '@5128']
  }, async ({ homePage }) => {
    const links = envLinks.map(x => x.name)
    await homePage.header.validateHeaderLinksPresent(links)
  })

  test('Advisor workstation links should show up according to platform', {
    tag: ['@cheetah', '@assetmark', '@5073']
  }, async ({ homePage }) => {
    const links = advisorLinks.map(x => x.name)
    await homePage.header.advisorWorkstation.click()
    await homePage.header.validateDropdownItems(links)
  })

  test.describe('Cookies modal tests', () => {

    test('Cookie options should show as expected', {
      tag: ['@assetmark', '@cheetah', '@3436', '@5784']
    }, async ({ homePage }) => {
      await homePage.header.clickProfileMenuOption(DashboardConfig.userMenuDropdownItems.cookieSettings)
      await homePage.privacyPopup.validateCookieOptions()
    })

    test('Should be able to change cookie settings', {
      tag: ['@assetmark', '@cheetah', '@3439']
    }, async ({ homePage }) => {
      await homePage.header.clickProfileMenuOption(DashboardConfig.userMenuDropdownItems.cookieSettings)
      for (const preference of Object.values(CookiesConfig.preferences)) {
        if (preference.toggle) {
          await test.step(`Toggle cookie preference "${preference.name}" and reopen cookie modal to verify changes were saved`, async () => {
            await homePage.privacyPopup.toggleCookieOptions(preference.name)
            // Open modal again after closing
            await homePage.header.clickProfileMenuOption(DashboardConfig.userMenuDropdownItems.cookieSettings)
            await homePage.privacyPopup.validateToggleIsChecked(preference.name, true)
          })
        }
      }
    })

  })

  test.describe('Cheetah only tests', {
    tag: '@cheetah'
  }, () => {

    test('Hovering over the home button should not shown dropdown', {
      tag: ['@5070']
    }, async ({ homePage }) => {
      await test.step('Validate home button hover has no dropdown options', async () => {
        await homePage.header.homeButton.hover()
        await expect(homePage.header.homeButtonDropDown, 'Waiting for hover dropdown not to appear').not.toBeVisible({timeout: 1000})
      })
    })

    test('Header for cheetah should not include links that are only for assetmark', {
      tag: ['@5126', '@5128']
    }, async ({ homePage }) => {
      const assetmarkOnlyLinks = Object.values(DashboardConfig.headerLinks).filter(x => x.platforms.toLocaleString() === Platforms.ASSETMARK)
      const links = assetmarkOnlyLinks.map(x => x.name)
      await homePage.header.validateHeaderLinksNotPresent(links)
    })

    test(`Header Home button redirects to Dashboard home page`, {
      tag: ['@cheetah', '@5113']
    }, async ({ page }) => {
      const baseURL = EWM3Config.BASE_URL
      const homePage = new HomePage(page)

      await page.goto('/nonexistingpage')
      await expect(homePage.header.homeButton).toBeAttached()
      await homePage.privacyPopup.checkPopupAndClose()

      await homePage.header.homeButton.click()
      await expect(homePage.manageTilesMenuButton).toBeVisible()
      await expect(page).toHaveURL(baseURL + `/dashboard`)
    })
    
  })

  test.describe('Header items CMS API -> UI', () => {
    test(`Home button click redirects to cms url`, {
      tag: ['@cheetah', '@5071']
    }, async ({ page }) => {
      const url = 'https://www.google.com/'
      await page.route('**/monitoring/api/v1/cms/ewm-metadata/menu_items/main', async route => {
        const response = await route.fetch()
        const json = await response.json()
        const data = JSON.parse(json.data)

        data.forEach(x => {
          if (x['title'] == 'Home') {
            x['uri'] = url }
        })

        json.data = JSON.stringify(data)

        await route.fulfill({ response, json })
      })

      const homePage = new HomePage(page)
      await homePage.goto()
      await homePage.waitPageIsReady()
      await homePage.header.homeButton.click()

      await expect(page).toHaveURL(url)
    })
  })

})

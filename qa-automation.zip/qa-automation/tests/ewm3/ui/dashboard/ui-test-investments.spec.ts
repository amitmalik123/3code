import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { EWM3Config } from '../../../../ewm3/service-data/config'
import { InvestmentsConfig } from '../../../../ewm3/service-data/tile-config/investments.config'
import { PageSwitchTrigger } from '../../../../ewm3/ui/features/pagination.feature'
import { TableRow } from '../../../../ewm3/ui/features/table.feature'
import { HomePage } from '../../../../ewm3/ui/pages/home-page'
import { SortingOrder } from '../../../../ewm3/ui/features/sorting.feature'
import { CloseModalTrigger } from '../../../../ewm3/ui/elements/modal-screen.feature'

test.describe('Investments Tile tests', {
  tag: ['@assetmark', '@cheetah', '@stable']
}, () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

  test('Tile action menu options should be present', {
    tag: ['@986', '@3409']
  }, async ({ homePage }) => {
    await test.step('When I click on tile options in the top right corner of the tile', async () => {
      await homePage.tileInvestments.tileOptionsButton.click()
    })
    await homePage.tileInvestments.validateTileMenuOptions(Object.values(InvestmentsConfig.tileMenuOptions))
  })

  for (const tab of [InvestmentsConfig.tabs.strategies, InvestmentsConfig.tabs.investment_approach]) {
    test(`Compare chart legend and table data. Tab: ${tab}`, {
      tag: ['@1538', '@1539', '@3433']
    }, async ({ homePage }) => {
      await homePage.tileInvestments.openTab(tab)
      await homePage.tileInvestments.customizeColumns.selectAllColumns()
      await expect(homePage.tileInvestments.table.locators.table).toBeVisible()
      await homePage.tileInvestments.table.sorting.sortBy({
        columnName: InvestmentsConfig.columnNamesStrategies.total_assets,
        sortingOrder: SortingOrder.DESCENDING
      })
      await homePage.tileInvestments.compareParseChartLegendAndTable()
    })
  }

  for (const trigger of Object.values(CloseModalTrigger)) {
    test(`Tile action menu "Learn about this tile" should show as expected and close it by ${trigger}`, {
      tag: ['@3954', '@3955', '@3956', '@3957', '@3958']
    }, async ({ homePage }) => {
      await test.step('When I click on "Learn about this tile"', async () => {
        await homePage.tileInvestments.tileOptionsButton.click()
        await homePage.tileInvestments.clickTileOptionByText(InvestmentsConfig.tileMenuOptions.learnAboutTile)
      })
      await test.step('Validate "Learn about this tile" modal screen', async () => {
        await homePage.modalScreen.validateActionModalContent(InvestmentsConfig.learnAboutThisTileProperties)
        await homePage.modalScreen.closeModal(trigger)
      })
    })
  }

  test.describe('Search', () => {
    for (const param of InvestmentsConfig.searchTestParamsArray) {
      test(`Tab ${param.tab} searching ${param.fieldForSearchQuery} using ${param.searchTrigger}`, {
        tag: ['@1456', '@1458', '@1464', '@1466']
      }, async ({ homePage }) => {
        await homePage.tileInvestments.openTab(param.tab)
        await homePage.tileInvestments.customizeColumns.selectAllColumns()
        await expect(homePage.tileInvestments.table.locators.table).toBeVisible()
        await homePage.tileInvestments.table.expandNestedTable()
        const tableData = await homePage.tileInvestments.table.data()

        const searchQuery = homePage.tileInvestments.table.getRandomValueByColumnName(
          tableData, param.fieldForSearchQuery
        )
        if (searchQuery) {
          await homePage.tileInvestments.search.makeSearch(searchQuery, param.searchTrigger)
          await homePage.tileInvestments.search.verifySearchResult(searchQuery, param.searchableFieldArray)
        } else throw new Error(`Could not generate search query for field ${searchQuery}`)

      })
    }
  })

  test.describe('Pagination', () => {
    for (const trigger of Object.values(PageSwitchTrigger)) {
      test(`Switching to the last/first pages using ${trigger}`, async ({ homePage }) => {
        await homePage.tileInvestments.openStrategiesTab()
        await homePage.tileInvestments.pagination.switchRowsPerPage(5)
        await expect(homePage.tileInvestments.table.locators.table).toBeVisible()
        await homePage.tileInvestments.pagination.lastPage(trigger, true)
        await homePage.tileInvestments.pagination.firstPage(trigger, true)
      })

      test(`Switching to the next/previous pages using ${trigger}`, async ({ homePage }) => {
        await homePage.tileInvestments.openStrategiesTab()
        await homePage.tileInvestments.pagination.switchRowsPerPage(5)
        await expect(homePage.tileInvestments.table.locators.table).toBeVisible()
        await homePage.tileInvestments.pagination.nextPage(trigger, true)
        await homePage.tileInvestments.pagination.prevPage(trigger, true)
      })
    }

    for (const rowsPerPage of [5,10,15]) {
      test(`I assert rows per page. Set ${rowsPerPage} rows per page`, async ({ homePage }) => {
        await homePage.tileInvestments.openStrategiesTab()
        await expect(homePage.tileInvestments.table.locators.table).toBeVisible()
        await homePage.tileInvestments.pagination.switchRowsPerPage(rowsPerPage, true)
      })
    }

  })

  test.describe('Data Mapping API->UI', () => {
    for (const param of InvestmentsConfig.mappingParamsArray) {
      test(`Data Mapping ${param.endpoint}`, {
        tag: '@1354'
      }, async ({ page }) => {
        const responsePromise = page.waitForResponse(response =>
          response.url().includes(param.endpoint) && response.status() === 200,
        { timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM }
        )
        const homePage = new HomePage(page)
        await homePage.goto()
        await homePage.waitPageIsReady()
        await homePage.tileInvestments.openTab(param.tab)
        await homePage.tileInvestments.customizeColumns.selectAllColumns()
        const responseBody = await (await responsePromise).json()
        await expect(homePage.tileInvestments.table.locators.table).toBeVisible()
        await homePage.tileInvestments.table.expandNestedTable()
        const tableData = await homePage.tileInvestments.table.data()
        await homePage.tileInvestments.table.assertDataMapping(
          responseBody,
          tableData,
          param.mappingConfig
        )
      })
    }
  })

  test.describe('Sorting', () => {
    for (const param of InvestmentsConfig.sortingTestParamsArray) {
      for (const fieldConfig of param.tableConfig.fields) {
        for (const sortingOrder of Object.values(SortingOrder)) {
          test(`Tab: ${param.tab} ; Column: "${fieldConfig.columnName}"; ${sortingOrder}`, {
            tag: ['@1264', '@1265', '@1267', '@1268', '@1748', '@1959']
          }, async ({ homePage }) => {
            await homePage.tileInvestments.openTab(param.tab)
            await homePage.tileInvestments.table.locators.table.waitFor({state: 'visible'})
            await homePage.tileInvestments.customizeColumns.selectAllColumns()
            await homePage.tileInvestments.pagination.switchRowsPerPage(15)

            await homePage.tileInvestments.table.sorting.sortBy({
              columnName: fieldConfig.columnName,
              sortingOrder: sortingOrder
            })

            const pagesCount = await homePage.tileInvestments.pagination.lastPageNumber()
            const tableRowArray: TableRow[] = await homePage.tileInvestments.table.data()
            for (let i = 1; i < pagesCount; i++) {
              await homePage.tileInvestments.pagination.nextPage()
              tableRowArray.push(...await homePage.tileInvestments.table.data())
            }
            await homePage.tileInvestments.table.sorting.assertSorting(
              param.tableConfig,
              tableRowArray,
              {
                columnName: fieldConfig.columnName,
                sortingOrder: sortingOrder
              },
            )
          })
        }
      }
    }
  })

  test.describe('Customize columns form', () => {
    for (const param of InvestmentsConfig.customizeColumnsParamsArray) {
      test(`Default. Tab: ${param.tab}`, {
        tag: '@1285'
      }, async ({ homePage }) => {
        await homePage.tileInvestments.openTab(param.tab)
        await homePage.tileInvestments.table.locators.table.waitFor({state: 'visible'})
        await homePage.tileInvestments.customizeColumns.resetToDefault()

        await homePage.tileInvestments.table.expandNestedTable(1)
        const tableData = await homePage.tileInvestments.table.data()
        const nestedTableData = tableData.find(row => row.nestedTableRow != undefined)?.nestedTableRow

        await homePage.tileInvestments.customizeColumns.compareCustomizeColumnsAndTable({tableRowArray: tableData})
        await homePage.tileInvestments.table.assertMainTableDefaultState(param.tableConfig, tableData)
        await homePage.tileInvestments.table.assertNestedTableDefaultState(param.tableConfig.nestedTableDataConfig, nestedTableData)
      })

      test(`All selected. Tab: ${param.tab}`, async ({ homePage }) => {
        await homePage.tileInvestments.openTab(param.tab)
        await homePage.tileInvestments.table.locators.table.waitFor({state: 'visible'})
        await homePage.tileInvestments.customizeColumns.selectAllColumns()
        await homePage.tileInvestments.customizeColumns.compareCustomizeColumnsAndTable()
      })

      test(`All deselected. Tab: ${param.tab}`, async ({ homePage }) => {
        await homePage.tileInvestments.openTab(param.tab)
        await homePage.tileInvestments.table.locators.table.waitFor({state: 'visible'})
        await homePage.tileInvestments.customizeColumns.deselectAllColumns()
        await homePage.tileInvestments.customizeColumns.compareCustomizeColumnsAndTable()
      })

      test(`Selecting/deselecting some of options. Tab: ${param.tab}`, {
        tag: '@1283'
      }, async ({ homePage }) => {
        await homePage.tileInvestments.openTab(param.tab)
        await homePage.tileInvestments.table.locators.table.waitFor({state: 'visible'})
        const customizeColumnOptions = await homePage.tileInvestments.customizeColumns.data()
        await homePage.tileInvestments.customizeColumns.selectAllColumns()
        await homePage.tileInvestments.customizeColumns.compareCustomizeColumnsAndTable()
        await homePage.tileInvestments.customizeColumns.deselectItemsByName([
          customizeColumnOptions[1].itemText,
        ])
        await homePage.tileInvestments.customizeColumns.compareCustomizeColumnsAndTable()
      })
    }
  })
})

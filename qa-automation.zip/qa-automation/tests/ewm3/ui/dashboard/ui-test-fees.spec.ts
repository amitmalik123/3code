import { test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { EWM3Config } from '../../../../ewm3/service-data/config'
import { HomePage } from '../../../../ewm3/ui/pages/home-page'
import { AdvisorMetricsV2 } from '../../../../ewm3/api/advisormetrics/v2/endpoints'
import { FeeResponse } from '../../../../ewm3/api/advisormetrics/v2/types'
import { GeneralUtils } from '../../../../utils/generalUtils'
import { expect } from '@playwright/test'
import { FeesConfig } from '../../../../ewm3/service-data/tile-config/fees.config'
import { DashboardConfig } from '../../../../ewm3/service-data/tile-config/dashboard.config'
import { syncedTest } from '../../../../ewm3/fixtures/synced-ui-fixtures'
import { CloseModalTrigger } from '../../../../ewm3/ui/elements/modal-screen.feature'

test.describe('Fees tests', {
  tag: ['@assetmark', '@stable']
}, () => {
  test.use({ storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT) })

  test('Tile action menu options should be present', {
    tag: '@986'
  }, async ({ homePage }) => {
    await test.step('When I click on tile options in the top right corner of the tile', async () => {
      await homePage.tileFees.tileOptionsButton.click()
    })
    await homePage.tileFees.validateTileMenuOptions(Object.values(FeesConfig.tileMenuOptions))
  })

  test('Validate Fees amounts format', {
    tag: ['@960', '@1414']
  }, async ({ homePage }) => {
    const font = FeesConfig.font
    const testParams = [
      {
        font: font.totalValue, elementLocator: homePage.tileFees.totalFeesValue
      }, 
      {
        font: font.timePeriod, elementLocator: homePage.tileFees.timePeriodSelected
      },
      {
        font: font.changesIndicator, elementLocator: homePage.tileFees.changesIndicator
      }
    ]
    await homePage.validateFontFormats(testParams)
    await test.step('Validate tooltip shows when hovering barchart', async () => {
      await homePage.tileFees.barChart.hover()
      await expect(homePage.tileFees.toolTip).toBeVisible()
    })
    await test.step('Fee amount will be displayed in currency with two decimal places', async () => {
      await homePage.tileFees.validateAmountFormat(homePage.tileFees.toolTipFeesList)
    })
  })

  for (const trigger of Object.values(CloseModalTrigger)) {
    test(`Tile action menu "Learn about this tile" should show as expected and close it by ${trigger}`, {
      tag: ['@3948', '@3949', '@3950', '@3951', '@3952']
    }, async ({ homePage }) => {
      await test.step('When I click on "Learn about this tile"', async () => {
        await homePage.tileFees.tileOptionsButton.click()
        await homePage.tileFees.clickTileOptionByText(FeesConfig.tileMenuOptions.learnAboutTile)
      })
      await test.step('Validate "Learn about this tile" modal screen', async () => {
        await homePage.modalScreen.validateActionModalContent(FeesConfig.learnAboutThisTileProperties)
        await homePage.modalScreen.closeModal(trigger)
      })
    })
  }

})

test.describe('Not isolated tests group', {
  tag: ['@assetmark', '@singleThreadOnly', '@169', '@179', '@944', '@958','@961', '@963', '@1986']
}, () => {
  test.use({ storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT) })
  
  test('Assert drop down list for time period', async ({ page, apiHelpers }) => {
    const endpoint = new AdvisorMetricsV2().metrics.fees
    const responsePromise = page.waitForResponse(response =>
      response.url().includes(endpoint.route) && response.status() === 200,
    {timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM}
    )

    const homePage = new HomePage(page)
    const widget = apiHelpers.widgets.getWidgets().revenue
    await apiHelpers.addWidgetOnDashboard(widget, {height:4, width:3})
    await homePage.goto()
    await homePage.waitPageIsReady()

    const responseBody: FeeResponse = await (await responsePromise).json()
    const expectedCurrentDateLabel = GeneralUtils.getCurrentQuarter(new Date(responseBody.trendValue.startOfPeriod))
    await homePage.tileFees.verifyCurrentTimePeriod(expectedCurrentDateLabel)

    await homePage.tileFees.timePeriodSelector.click()

    await test.step('Then I should be able to verify the drop down list of the past 12 available quarters', async () => {
      await expect(homePage.tileFees.timePeriodSelectorDropDownList).toBeVisible()
    })

    await test.step('Then I make sure if API response has data in recent quarter or not', async () => {
      if (!responseBody.history[responseBody.history.length - 1].data) {
        await expect(homePage.tileFees.tableNoContentStub,
          'There is no content for the last quarter in API response. I expect to see no content stub in a table').toBeVisible()
        await test.step('Then I switch quarter to prior', async () => {
          await homePage.tileFees.timePeriodDropdownOptions.nth(1).click()
        })
      }
    })

    await test.step('Then I verify that format of displayed sums currency with two decimal places should be displayed.', async () => {
      await homePage.tileFees.validateAmountFormat(homePage.tileFees.revenueValues)
      await homePage.tileFees.validateAmountFormat(homePage.tileFees.averageRevenuePerClientValues)
    })

    await test.step('Then I should be able to verify that default data in the table display will show the most recent closed quarter', async () => {
      await homePage.tileFees.validateDefaultQuarter()
    })

    await test.step('Then I should be able to verify that most recent quarter are at the top from the dropdown list', async () => {
      await homePage.tileFees.timePeriodSelector.click()
      await homePage.tileFees.verifyRecentQuarterAtTheTop(responseBody.history[responseBody.history.length - 1].startDate)
    })

    await test.step('Given user verify the table headers for fees widget on large size', async () => {
      const tableHeaders = FeesConfig.tableHeaders
      await homePage.tileFees.verifyTableHeadersForfeesWidget(tableHeaders)
    })
  })
})

syncedTest.describe('Resizable tile test case', {
  tag: ['@assetmark', '@2692']
}, () => {
  const widgetName = DashboardConfig.tiles.fees.name
  for (const param of DashboardConfig.resizableTestParam) {
    syncedTest(`Tile "${widgetName}" should be displayed in a ${param.size} size`, async ({ removeAllWidgets, page, apiHelpers }) => {
      await syncedTest.step(`Add widget "${widgetName}" with height ${param.height} and width ${param.width}`, async () => {
        const widget = apiHelpers.widgets.getWidgets().revenue
        await apiHelpers.addWidgetOnDashboard(widget, {height: param.height, width: param.width})
      })
      await syncedTest.step(`Validates widget "${widgetName}" size (needs page refresh)`, async () => {
        const homePage = new HomePage(page)
        await homePage.goto()
        await homePage.waitPageIsReady()
        await homePage.tileFees.validateTileSize(param.size)
      })
    })
  }
})

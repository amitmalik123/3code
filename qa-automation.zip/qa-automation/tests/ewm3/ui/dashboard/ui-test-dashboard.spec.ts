import { expect, syncedTest } from '../../../../ewm3/fixtures/synced-ui-fixtures'
import { EWM3Config } from '../../../../ewm3/service-data/config'
import { test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { Random } from '../../../../utils/random'
import { GeneralUtils } from '../../../../utils/generalUtils'
import { DashboardConfig } from '../../../../ewm3/service-data/tile-config/dashboard.config'
import { HomePage } from '../../../../ewm3/ui/pages/home-page'
import { SampleDashboardMock } from '../../../../ewm3/ui/mocks/sample-dashboard-mock'
const envTiles = Object.values(DashboardConfig.tiles).filter(x => x.platforms.includes(EWM3Config.PLATFORM))

syncedTest.describe('Dashboard general tests', {
  tag: ['@assetmark', '@cheetah', '@stable']
}, () => {
  syncedTest.describe('Add and remove dashboards tests', () => {

    syncedTest('Should be able to add a new dashboard when there are less than five', {
      tag: ['@67', '@612']
    }, async ({ initDashboardData, homePage }) => {
      await homePage.dashboard.dashboardListDropdownTrigger.click()
      await expect(homePage.dashboard.dashboardListAddNewDashboard, 'Expecting the button to add new dashboard to be enabled').toBeEnabled()
      await syncedTest.step('New dashboards created should start empty', async () => {
        const newDashboard = await homePage.dashboard.createNewDashboard()
        await homePage.dashboard.switchToDashboardByName(newDashboard)
        await homePage.dashboard.validateDashboardIsEmpty()
      })
    })

    syncedTest('Should be able to delete dashboards when there is more than one', {
      tag: ['@71', '@72', '@91', '@605', '@613', '@615', '@617', '@639', '@640']
    }, async ({ createMaxDashboards, homePage }) => {
      await homePage.dashboard.dashboardListDropdownTrigger.click()
      await syncedTest.step('Validates user can NOT add more dashboards after max limit', async () => {
        await expect(homePage.dashboard.dashboardListAddNewDashboard, 'Expecting the button to add new dashboard to be disabled with max dashboard count').not.toBeEnabled()
      })
      await syncedTest.step('Validates user can delete a dashboard successfully', async () => {
        await homePage.dashboard.deleteDashboardInPosition(1)
      })
    })

    syncedTest('Should be able to go back and cancel dashboard deletion after selecting delete option', {
      tag: '@616'
    },  async ({ createMaxDashboards, homePage }) => {
      await homePage.dashboard.dashboardListDropdownTrigger.click()
      await syncedTest.step('Validates user can cancel the action of deleting a dashboard', async () => {
        await homePage.dashboard.dashboardListDeleteDashboard.first().click()
        await homePage.dashboard.modalCancelOption.click()
        // Give less timeout here to make sure message is not shown, and not that it will disappear
        await expect(homePage.dashboard.dashboardActionSuccessMessage).not.toBeVisible({timeout: 1000})
      })
    })

    syncedTest('Should NOT be able to delete dashboard if there is only one default dashboard', {
      tag: ['@93', '@254']
    }, async ({ initDashboardData, homePage }) => {
      await homePage.dashboard.dashboardListDropdownTrigger.click()
      await syncedTest.step('Validates user can not delete the default dashboard', async () => {
        await expect(homePage.dashboard.dashboardListAddNewDashboard, 'Expecting the button to add new dashboard to be enabled').toBeEnabled()
        await expect(homePage.dashboard.dashboardListDeleteDashboard, 'Expecting the button to delete default dashboard to be disabled').toBeDisabled()
      })
    })

    syncedTest('Should create sample dashboard if user has no dashboards', {
      tag: ['@5067']
    }, async ({ initEmptyDashboard, page }) => {
      const homePage = new HomePage(page)
      await homePage.goto()
      await homePage.waitPageIsReady()
      await homePage.openTileManager()
      await homePage.validateDefaultDashboard(envTiles)
    })
  })

  syncedTest.describe('Copy dashboards', () => {
    syncedTest('Cannot copy dashboards when dashboard number has reached limit', {
      tag: ['@606', '@614']
    }, async ({ createMaxDashboards, homePage }) => {
      await syncedTest.step('Validate copy dashboard is disabled', async () => {
        await homePage.dashboard.dashboardListDropdownTrigger.click()
        await homePage.dashboard.validateCannotCopyDashboards()
      })
    })

    syncedTest('Copy dashboard from previously created dashboard', {
      tag: ['@608', '@609']
    }, async ({ initDashboardData, homePage }) => {
      await syncedTest.step('Copy default dashboard', async () => {
        await homePage.dashboard.dashboardListDropdownTrigger.click()
        // Copies the default dashboard. To use different positions, ensure there are dashboards created for those positions
        await homePage.dashboard.copyDashboardInPosition(0)
      })
    })
  })

  syncedTest.describe('Verify dashboards', () => {
    syncedTest('List of Dashboards should be alphabetically sorted', {
      tag: ['@85', '@604']
    }, async ({ createMaxDashboards, homePage }) => {
      await homePage.dashboard.dashboardListDropdownTrigger.click()
      await homePage.dashboard.validateDashboardListSortedAlphabetically()
    })

    syncedTest('Switch from one dashboard to another', {
      tag: ['@77', '@610']
    }, async ({ createMaxDashboards, homePage }) => {
      await syncedTest.step('Select a different dashboard', async () => {
        await homePage.dashboard.switchToDashboardInPosition(2)
      })
    })
  })

  syncedTest.describe('Rename dashboards', {
    tag: ['@84', '@86', '@87', '@1742', '@1743', '@1744', '@2133']
  }, () => {
    for (const count of [1, 50, 51]) {
      syncedTest(`Rename dashboard to a name with length of "${count}" characters`, async ({ createMaxDashboards, homePage }) => {
        const dashboardName = Random.getString(count)
        await syncedTest.step('Switches to a different dashboard and renames it', async () => {
          // Max random is 4 because max number of dashboards should be 5. Index starts at 0
          await homePage.dashboard.switchToDashboardInPosition(GeneralUtils.getRandomNumber(4))
          await homePage.dashboard.dashboardSelected.fill(dashboardName)
          // Closes dashboard list (needs the refreshing to show new name)
          await homePage.dashboard.dashboardListDropdownTrigger.click()
        })
        await syncedTest.step('Validates dashboard selected was renamed', async () => {
          // Opens dashboard list again (needs the refreshing to show new name)
          await homePage.dashboard.dashboardListDropdownTrigger.click()
          // Needs to verify the whole list because of alphabetical sorting, might not be in the same position
          await homePage.dashboard.validateDashboardIsPresentInDashboardList(dashboardName)
          await homePage.dashboard.validateSelectedDashboardName(dashboardName)
        })
      })
    }
  })

})

test.describe('Isolated dashboards tests (no need for separate user)', {
  tag: ['@assetmark', '@cheetah', '@stable']
}, () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

  test('Items from user dropdown menu should be visible with the Tile Manager opened', {
    tag: ['@3522']
  }, async ({ homePage }) => {
    await test.step('When I open the user dropdown menu with the Tile Manager opened', async () => {
      await homePage.openTileManager()
      await homePage.header.profile.click()
    })
    await test.step('Then the items from the user dropdown menu should be visible', async () => {
      await homePage.header.validateDropdownItems(Object.values(DashboardConfig.userMenuDropdownItems))
    })
  })

  test('Sample Dashboard should have the default options toggled', {
    tag: ['@1739', '@5099', '@5100']
  }, async ({ homePage }) => {
    await homePage.openTileManager()
    await homePage.tileManager.useSampleDashboard.click()
    await homePage.validateDefaultDashboard(envTiles)
  })

  test.describe('Sample dashboard CMS API -> UI', () => {
    test(`Sample dashboard follows cms api response pattern`, {
      tag: ['@5068']
    }, async ({ homePage }) => {
      const widgetsOnMock: string[] = []
      const widgetsNames: string[] = []
      const widgetsNotEnabledNames: string[] = []
      const mockWidgets = SampleDashboardMock.modifiedSampleDashboard.data.map(item => item.widget_setting.map(x => x.cmsId))
      const widgetCmsIds = Object.values(DashboardConfig.tiles).map(x => x.cmsId)
      
      await homePage.replaceSampleDashboard()
      await homePage.goto()
      await homePage.waitPageIsReady()

      await homePage.openTileManager()
      await homePage.tileManager.useSampleDashboard.click()

      for (const widget of widgetCmsIds) {
        if (mockWidgets[0].includes(widget)) {
          widgetsOnMock.push(widget)
        }
      }

      for (const widget of widgetsOnMock) {
        const element = envTiles.filter(item => item.cmsId === widget).map(x => x.name)
        widgetsNames.push(element[0])
      }

      for (const widget of envTiles) {
        if (!widgetsOnMock.includes(widget.cmsId)) {
          widgetsNotEnabledNames.push(widget.name)
        }
      }

      await homePage.tileManager.validateToggleChecked(true, widgetsNames)
      await homePage.tileManager.validateToggleChecked(false, widgetsNotEnabledNames)
    })
  })

})

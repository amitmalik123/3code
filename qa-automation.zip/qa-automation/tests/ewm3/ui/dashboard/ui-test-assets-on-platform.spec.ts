import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { EWM3Config } from '../../../../ewm3/service-data/config'
import { AssetsOnPlatformConfig } from '../../../../ewm3/service-data/tile-config/assets-on-platform.config'
import { CloseModalTrigger } from '../../../../ewm3/ui/elements/modal-screen.feature'
import { HomePage } from '../../../../ewm3/ui/pages/home-page'

test.describe('Assets On Platform tests', {
  tag: ['@assetmark', '@cheetah', '@stable']
}, () => {
  test.use({ storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT) })

  test('Tile action menu options should be present', {
    tag: ['@986']
  }, async ({ homePage }) => {
    await test.step('When I click on tile options in the top right corner of the tile', async () => {
      await homePage.tileAssetsOnPlatform.tileOptionsButton.click()
    })
    await homePage.tileAssetsOnPlatform.validateTileMenuOptions(Object.values(AssetsOnPlatformConfig.tileMenuOptions))
  })

  test('Monthly, Quarterly and Yearly time periods should be available for Assets On Platform chart', {
    tag: '@976'
  }, async ({ homePage }) => {
    const font = AssetsOnPlatformConfig.font
    const testParams = [
      {
        font: font.timePeriod, elementLocator: homePage.tileAssetsOnPlatform.timePeriodSelected
      }, 
      {
        font: font.metricValue, elementLocator: homePage.tileAssetsOnPlatform.metricValue
      },
      {
        font: font.changesIndicator, elementLocator: homePage.tileAssetsOnPlatform.changesIndicator
      }
    ]
    await test.step('Then I verify that line chart in AUM for selected time period should be display ', async () => {
      await homePage.tileAssetsOnPlatform.validateTimePeriodsAreVisible(Object.values(AssetsOnPlatformConfig.timePeriods))
    })
    await test.step('Verify that the widget should display the metric in correct format', async () => {
      await homePage.validateFontFormats(testParams)
    })
    await test.step('Monthly time period should be the default selection', async () => {
      await homePage.tileAssetsOnPlatform.validateTimePeriodSelected(AssetsOnPlatformConfig.timePeriods.monthly)
    })
  })

  for (const trigger of Object.values(CloseModalTrigger)) {
    test(`Tile action menu "Learn about this tile" should show as expected and close it by ${trigger}`, {
      tag: ['@3936', '@3937', '@3938', '@3939', '@3940']
    }, async ({ homePage }) => {
      await test.step('When I click on "Learn about this tile"', async () => {
        await homePage.tileAssetsOnPlatform.tileOptionsButton.click()
        await homePage.tileAssetsOnPlatform.clickTileOptionByText(AssetsOnPlatformConfig.tileMenuOptions.learnAboutTile)
      })
      await test.step('Validate "Learn about this tile" modal screen', async () => {
        await homePage.modalScreen.validateActionModalContent(AssetsOnPlatformConfig.learnAboutThisTileProperties)
        await homePage.modalScreen.closeModal(trigger)
      })
    })
  }
  
})

test.describe('Isolated tests group', {
  tag: ['@assetmark', '@cheetah', '@singleThreadOnly']
}, () => {
  test.use({ storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT) })

  for (const param of AssetsOnPlatformConfig.timePeriodsParams) {
    test(`Time period ${param.timePeriod} persist from session to session test`, {
      tag: '@1560'
    }, async ({ homePage, page }) => {
      await test.step(`And I select the ${param.timePeriod} time period `, async () => {
        await homePage.tileAssetsOnPlatform.selectTimePeriod(param.timePeriod)
        await homePage.tileAssetsOnPlatform.validateTimePeriodSelected(param.timePeriod)
        await page.reload()
        await homePage.tileAssetsOnPlatform.validateTimePeriodTag(param.label)
      })
    })
  }
    
  for (const param of AssetsOnPlatformConfig.sizesParams) {
    test(`Size: "${param.size}" tile layout test`, {
      tag: ['@947', '@1558', '@2692']
    }, async ({ page, apiHelpers }) => {
      const homePage = new HomePage(page)
      const widget = apiHelpers.widgets.getWidgets().aum
      await apiHelpers.addWidgetOnDashboard(widget, {height: param.widgetHeight, width: param.widgetWidth})
      await homePage.goto()
      await homePage.waitPageIsReady()
      if (param.isTimePeriodVisible) {
        await homePage.tileAssetsOnPlatform.validateTimePeriodsAreVisible(Object.values(AssetsOnPlatformConfig.timePeriods))
      } else {
        await expect(homePage.tileAssetsOnPlatform.timePeriodsButtons.first()).not.toBeVisible()
      }
    })
  }

})

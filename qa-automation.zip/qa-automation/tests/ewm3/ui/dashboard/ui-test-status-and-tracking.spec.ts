import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { EWM3Config } from '../../../../ewm3/service-data/config'
import { GeneralUtils } from '../../../../utils/generalUtils'
import { StatusAndTrackingConfig } from '../../../../ewm3/service-data/tile-config/status-and-tracking.config'
import { HomePage } from '../../../../ewm3/ui/pages/home-page'
import { SearchTrigger } from '../../../../ewm3/ui/features/search.feature'
import { PageSwitchTrigger } from '../../../../ewm3/ui/features/pagination.feature'
import { SortingOrder } from '../../../../ewm3/ui/features/sorting.feature'
import { TableRow } from '../../../../ewm3/ui/features/table.feature'
import { CloseModalTrigger } from '../../../../ewm3/ui/elements/modal-screen.feature'

test.describe('Status & Tracking Tile tests', {
  tag: ['@assetmark', '@cheetah', '@stable']
}, () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

  test('Tile action menu options should be present', {
    tag: ['@986', '@1299']
  }, async ({ homePage }) => {
    // Todo: add link validations
    await test.step('When I click on tile options in the top right corner of the tile', async () => {
      await homePage.tileStatusAndTracking.tileOptionsButton.click()
    })
    await homePage.tileStatusAndTracking.validateTileMenuOptions(Object.values(StatusAndTrackingConfig.tileMenuOptions))
  })

  for (const trigger of Object.values(CloseModalTrigger)) {
    test(`Tile action menu "Learn about this tile" should show as expected and close it by ${trigger}`, {
      tag: ['@3960', '@3961', '@3962', '@3963', '@3964']
    }, async ({ homePage }) => {
      await test.step('When I click on "Learn about this tile"', async () => {
        await homePage.tileStatusAndTracking.tileOptionsButton.click()
        await homePage.tileStatusAndTracking.clickTileOptionByText(StatusAndTrackingConfig.tileMenuOptions.learnAboutTile)
      })
      await test.step('Validate "Learn about this tile" modal screen', async () => {
        await homePage.modalScreen.validateActionModalContent(StatusAndTrackingConfig.learnAboutThisTileProperties)
        await homePage.modalScreen.closeModal(trigger)
      })
    })
  }

  test(`Needs attention badge test`, {
    tag: '@1181'
  }, async ({ page }) => {
    const responsePromise = page.waitForResponse(response =>
      response.url().includes(StatusAndTrackingConfig.endpoints.needs_attention) && response.status() === 200,
    { timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM }
    )
    const homePage = new HomePage(page)
    await homePage.goto()
    await homePage.waitPageIsReady()
    await homePage.tileStatusAndTracking.openNeedAttentionTab()
    const apiTotalItems = (await (await responsePromise).json()).data.length
    const badgeTotalItems = +(await homePage.tileStatusAndTracking.needAttentionCountBadge.innerText())
    const tableInfoTotalItems = GeneralUtils.extractDigitsFromStringToArray(
      (await homePage.tileStatusAndTracking.pagination.locators.amount.innerText())
    )[2]
    expect(apiTotalItems === badgeTotalItems && badgeTotalItems === tableInfoTotalItems,
      'Expect that badge total count corresponds total need attention items count'
    ).toBeTruthy()
  })

  test.describe('Search', () => {
    for (const dataFromField of StatusAndTrackingConfig.searchableFields) {
      for (const trigger of Object.values(SearchTrigger)) {
        test(`Searching ${dataFromField} using ${trigger}`, async ({ homePage }) => {
          await homePage.tileStatusAndTracking.openNeedAttentionTab()
          await homePage.tileStatusAndTracking.customizeColumns.selectAllColumns()
          await expect(homePage.tileStatusAndTracking.table.locators.table).toBeVisible()
          const tableData = await homePage.tileStatusAndTracking.table.data()
          const searchQuery = homePage.tileStatusAndTracking.table.getRandomValueByColumnName(
            tableData, dataFromField
          )
          if (searchQuery) {
            await homePage.tileStatusAndTracking.search.makeSearch(searchQuery, trigger)
            await homePage.tileStatusAndTracking.search.verifySearchResult(searchQuery, StatusAndTrackingConfig.searchableFields)
          } else throw new Error(`Could not generate search query for field ${dataFromField}`)
        })
      }
    }
  })

  test.describe('Pagination', () => {
    for (const trigger of Object.values(PageSwitchTrigger)) {
      test(`Switching to the last/first pages using ${trigger}`, {
        tag: '@1178'
      }, async ({ homePage }) => {
        await homePage.tileStatusAndTracking.openNeedAttentionTab()
        await expect(homePage.tileStatusAndTracking.table.locators.table).toBeVisible()
        await homePage.tileStatusAndTracking.pagination.lastPage(trigger, true)
        await homePage.tileStatusAndTracking.pagination.firstPage(trigger, true)
      })

      test(`Switching to the next/previous pages using ${trigger}`, {
        tag: '@1178'
      }, async ({ homePage }) => {
        await homePage.tileStatusAndTracking.openNeedAttentionTab()
        await expect(homePage.tileStatusAndTracking.table.locators.table).toBeVisible()
        await homePage.tileStatusAndTracking.pagination.nextPage(trigger, true)
        await homePage.tileStatusAndTracking.pagination.prevPage(trigger, true)
      })
    }

    for (const rowsPerPage of [5,10,15]) {
      test(`I assert rows per page. Set ${rowsPerPage} rows per page`, {
        tag: ['@1175', '@1179']
      }, async ({ homePage }) => {
        await homePage.tileStatusAndTracking.openNeedAttentionTab()
        await expect(homePage.tileStatusAndTracking.table.locators.table).toBeVisible()
        await homePage.tileStatusAndTracking.pagination.switchRowsPerPage(rowsPerPage, true)
      })
    }

  })

  test.describe('Data Mapping API->UI', () => {
    for (const param of StatusAndTrackingConfig.mappingParamsArray) {
      test(`Data Mapping ${param.endpoint}`, {
        tag: '@1180'
      }, async ({apiHelpers, page}) => {
        if (param.tab === StatusAndTrackingConfig.tabs.following.name) {
          const getFollowing = await apiHelpers.endpoints.getStatusAndTrackingFollowing()
          if (getFollowing.status() === 204) {
            await test.step(`Then: add work some items to following`, async () => {
              const response = await apiHelpers.endpoints.getStatusAndTracking('needattention')
              await apiHelpers.responseIs200(response)
              let responseBody = await response.json()

              responseBody = responseBody.data[GeneralUtils.getRandomNumber(responseBody.data.length)]
              await apiHelpers.endpoints.postWorkItemFlags(responseBody.id)
            })
          }
        }

        const responsePromise = page.waitForResponse(response =>
          response.url().includes(param.endpoint) && response.status() === 200,
        { timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM }
        )
        const homePage = new HomePage(page)
        await homePage.goto()
        await homePage.waitPageIsReady()
        await homePage.tileStatusAndTracking.openTab(param.tab)
        await homePage.tileStatusAndTracking.customizeColumns.selectAllColumns()
        const responseBody = await (await responsePromise).json()
        await expect(homePage.tileStatusAndTracking.table.locators.table).toBeVisible()
        const tableData = await homePage.tileStatusAndTracking.table.data()
        await homePage.tileStatusAndTracking.table.assertDataMapping(
          responseBody,
          tableData,
          StatusAndTrackingConfig.tableDataConfig
        )
      })
    }
  })

  test.describe('Sorting', {
    tag: '@1195'
  }, () => {
    for (const tab of Object.values(StatusAndTrackingConfig.tabs)) {
      for (const fieldConfig of StatusAndTrackingConfig.tableDataConfig.fields) {
        for (const sortingOrder of Object.values(SortingOrder)) {
          test(`Tab: ${tab.name} ; Column: "${fieldConfig.columnName}"; ${sortingOrder}`, async ({ homePage }) => {
            await homePage.tileStatusAndTracking.openTab(tab.name)
            await homePage.tileStatusAndTracking.table.locators.table.waitFor({state: 'visible'})
            await homePage.tileStatusAndTracking.customizeColumns.selectAllColumns()
            await homePage.tileStatusAndTracking.customizeColumns.closeMenu()
            await homePage.tileStatusAndTracking.pagination.switchRowsPerPage(15)

            await homePage.tileStatusAndTracking.table.sorting.sortBy({
              columnName: fieldConfig.columnName,
              sortingOrder: sortingOrder
            })

            const pagesCount = await homePage.tileStatusAndTracking.pagination.lastPageNumber()
            const tableRowArray: TableRow[] = await homePage.tileStatusAndTracking.table.data()
            for (let i = 1; i < pagesCount; i++) {
              await homePage.tileStatusAndTracking.pagination.nextPage()
              tableRowArray.push(...await homePage.tileStatusAndTracking.table.data())
            }
            await homePage.tileStatusAndTracking.table.sorting.assertSorting(
              StatusAndTrackingConfig.tableDataConfig,
              tableRowArray,
              {
                columnName: fieldConfig.columnName,
                sortingOrder: sortingOrder
              },
            )
          })
        }
      }
    }
  })

  test.describe('Customize columns form', () => {
    for (const tab of Object.values(StatusAndTrackingConfig.tabs)) {
      let filters = Object.values(tab.filters)

      test(`Default. Tab: ${tab.name}`, {
        tag: ['@1176', '@1189', '@1193']
      }, async ({ homePage }) => {
        await homePage.tileStatusAndTracking.openTab(tab.name)
        await homePage.tileStatusAndTracking.table.locators.table.waitFor({state: 'visible'})
        await homePage.tileStatusAndTracking.customizeColumns.resetToDefault()
        const tableData = await homePage.tileStatusAndTracking.table.data()
        await homePage.tileStatusAndTracking.customizeColumns.compareCustomizeColumnsAndTable({tableRowArray: tableData})
        await homePage.tileStatusAndTracking.table.assertMainTableDefaultState(StatusAndTrackingConfig.tableDataConfig, tableData)
      })

      test(`All selected. Tab: ${tab.name}`, async ({ homePage }) => {
        await homePage.tileStatusAndTracking.openTab(tab.name)
        await homePage.tileStatusAndTracking.table.locators.table.waitFor({state: 'visible'})
        await homePage.tileStatusAndTracking.customizeColumns.selectAllColumns()
        await homePage.tileStatusAndTracking.customizeColumns.compareCustomizeColumnsAndTable()
      })

      test(`All deselected. Tab: ${tab.name}`, {
        tag: '@1191'
      }, async ({ homePage }) => {
        await homePage.tileStatusAndTracking.openTab(tab.name)
        await homePage.tileStatusAndTracking.table.locators.table.waitFor({state: 'visible'})
        await homePage.tileStatusAndTracking.customizeColumns.deselectAllColumns()
        await homePage.tileStatusAndTracking.customizeColumns.compareCustomizeColumnsAndTable()
      })

      test(`Selecting/deselecting some of the options. Tab: ${tab.name}`, async ({ homePage }) => {
        await homePage.tileStatusAndTracking.openTab(tab.name)
        await homePage.tileStatusAndTracking.table.locators.table.waitFor({state: 'visible'})
        const customizeColumnOptions = await homePage.tileStatusAndTracking.customizeColumns.data()
        await homePage.tileStatusAndTracking.customizeColumns.selectAllColumns()
        await homePage.tileStatusAndTracking.customizeColumns.compareCustomizeColumnsAndTable()
        await homePage.tileStatusAndTracking.customizeColumns.deselectItemsByName([
          customizeColumnOptions[1].itemText,
        ])
        await homePage.tileStatusAndTracking.customizeColumns.compareCustomizeColumnsAndTable()
      })

      test(`Verify filter options. Tab: ${tab.name}`, {
        tag: ['@5978', '@5979', '@5980', '@5981', '@6001', '@6002', '@6003', '@6004', '@6005', '@6006']
      }, async ({ homePage }) => {
        await homePage.tileStatusAndTracking.openTab(tab.name)
        await homePage.tileStatusAndTracking.table.locators.table.waitFor({state: 'visible'})
        await homePage.tileStatusAndTracking.customizeColumns.selectAllColumns()
        await homePage.tileStatusAndTracking.customizeColumns.closeMenu()
        // Removes completion date from filters for tabs that don't have them
        if (tab.name !== StatusAndTrackingConfig.tabs.completed.name && tab.name !== StatusAndTrackingConfig.tabs.following.name) { 
          filters = Object.values(tab.filters).filter(x => x.presentAtAllTabs === true)
        }
        let index = 0
        for (const filter of filters) {
          await test.step(`Validate ${filter.name} shows as expected`, async () => {
            await homePage.tileStatusAndTracking.customizeColumns.locators.openMenuButton.click()
            if (filter.isMoveable) {
              // Validates filter is draggable // Note that this does NOT drag the filter item
              await expect(homePage.tileStatusAndTracking.customizeColumns.locators.dragButtonByName(filter.name)).toBeVisible()
            }
            // Validates filter position index
            await homePage.tileStatusAndTracking.customizeColumns.validateItemIndex(filter.name, index)
            await homePage.tileStatusAndTracking.customizeColumns.closeMenu()
            if (filter.isSorteable) {
              await homePage.tileStatusAndTracking.table.sorting.validateHeaderItemIsSortable(filter.name)
            } else { await homePage.tileStatusAndTracking.table.sorting.validateHeaderItemIsNotSortable(filter.name) }        
          })
          index ++
        }
      })
    } 
  })

})

test.describe('Flag/Unflag items as following', {
  tag: ['@assetmark', '@cheetah', '@singleThreadOnly']
}, () => {
  test.use({storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT)})

  for (const tab of Object.values(StatusAndTrackingConfig.tabs)) {
    if (tab.name !== StatusAndTrackingConfig.tabs.following.name) {
      test(`Flag/Unflag items. Tab: ${tab.name}`, {
        tag: ['@1616', '@1617', '@1618', '@1619', '@1620']
      }, async ({ unflagAllItemsWorkItem, homePage }) => {
        await homePage.tileStatusAndTracking.openTab(tab.name)
        await homePage.tileStatusAndTracking.table.locators.table.waitFor({state: 'visible'})
        const tableData = await homePage.tileStatusAndTracking.table.data()
        const randomIndex = GeneralUtils.getRandomNumber(tableData.length)
        const itemNumber: string = tableData[randomIndex].cell.filter(a => a.columnName === 'Item Number')[0].value
        await test.step(`Flags random item "${itemNumber}"`, async () => {
          await homePage.tileStatusAndTracking.flagItem(itemNumber)
          await homePage.tileStatusAndTracking.verifyItemIsFlagged(true, itemNumber)
        })
        await test.step(`Verifies item with item number "${itemNumber}" was flagged and added to following tab`, async () => {
          await homePage.tileStatusAndTracking.openTab(StatusAndTrackingConfig.tabs.following.name)
          await homePage.tileStatusAndTracking.table.locators.table.waitFor({state: 'visible'})
          await homePage.tileStatusAndTracking.validateItemIsInTable(true, itemNumber)
          // Validates all items in following tab are flagged
          await homePage.tileStatusAndTracking.validateFollowingItems()
        })
        await test.step(`Remove item with item number "${itemNumber}" from following list`, async () => {
          await homePage.tileStatusAndTracking.flagItem(itemNumber)
          await homePage.tileStatusAndTracking.validateItemIsInTable(false, itemNumber)
        })
        await test.step(`Item with item number "${itemNumber}" should still be present at tab ${tab.name}`, async () => {
          await homePage.tileStatusAndTracking.openTab(tab.name)
          await homePage.tileStatusAndTracking.table.locators.table.waitFor({state: 'visible'})
          await homePage.tileStatusAndTracking.validateItemIsInTable(true, itemNumber)
        })
      })
    }
  }

})


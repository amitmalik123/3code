import { expect, test } from '../../../../ewm3/fixtures/base-ui-fixture'
import { syncedTest } from '../../../../ewm3/fixtures/synced-ui-fixtures'
import { EWM3Config } from '../../../../ewm3/service-data/config'
import { DashboardConfig } from '../../../../ewm3/service-data/tile-config/dashboard.config'
import { AdvisorBenefitsConfig } from '../../../../ewm3/service-data/tile-config/advisor-benefits.config'
import { HomePage } from '../../../../ewm3/ui/pages/home-page'
import { AdvisorMetricsV2 } from '../../../../ewm3/api/advisormetrics/v2/endpoints'
import { CloseModalTrigger } from '../../../../ewm3/ui/elements/modal-screen.feature'

test.describe('Advisor benefits tests', {
  tag: ['@assetmark', '@stable']
}, () => {
  test.use({ storageState: EWM3Config.browserStorageState(EWM3Config.USERNAME_DEFAULT) })

  test('Tile action menu options should be present', {
    tag: '@986'
  }, async ({ homePage }) => {
    await test.step('When I click on tile options in the top right corner of the tile', async () => {
      await homePage.tileAdvisorBenefits.tileOptionsButton.click()
    })
    await homePage.tileAdvisorBenefits.validateTileMenuOptions(Object.values(AdvisorBenefitsConfig.tileMenuOptions))
  })

  test('Advisor Benefits disclaimer message should be shown', {
    tag: '@1608'
  }, async ({ homePage }) => {
    const disclaimerMessage = AdvisorBenefitsConfig.disclaimer
    await test.step('Validate assets on platform tooltip disclaimer message', async () => {
      await homePage.tileAdvisorBenefits.tileFooter.hover()
      await expect(homePage.tileAdvisorBenefits.tooltipDisclaimer, 'Expecting cms message to be shown in full on the tooltip')
        .toHaveText(disclaimerMessage, {ignoreCase: true})
    })
  })

  for (const trigger of Object.values(CloseModalTrigger)) {
    test(`Tile action menu "Learn about this tile" should show as expected and close it by ${trigger}`, {
      tag: ['@3928', '@3929', '@3930', '@3931', '@3932']
    }, async ({ homePage }) => {
      await test.step('When I click on "Learn about this tile"', async () => {
        await homePage.tileAdvisorBenefits.tileOptionsButton.click()
        await homePage.tileAdvisorBenefits.clickTileOptionByText(AdvisorBenefitsConfig.tileMenuOptions.learnAboutTile)
      })
      await test.step('Validate "Learn about this tile" modal screen', async () => {
        await homePage.modalScreen.validateActionModalContent(AdvisorBenefitsConfig.learnAboutThisTileProperties)
        await homePage.modalScreen.closeModal(trigger)
      })
    })
  }

  test('Advisor Benefits program level should be categorized correctly', {
    tag: '@1609'
  }, async ({ homePage }) => {
    await test.step('Validate assets on platform value categorizes the user into the correct advisor benefits program level', async () => {
      await homePage.tileAdvisorBenefits.validateProgramLevel()
    })
  })

  for (const level of AdvisorBenefitsConfig.programLevels) {
    test.describe('Advisor Benefits program levels (with mocked data)', {
      tag: ['@1609', '@1610']
    }, () => {
      test.beforeEach(async ({ page }) => {
        await test.step(`Sends mock to set ${level.name} status`, async () => {
          await page.route(new AdvisorMetricsV2().metrics.advisorBenefits.route, async route => {
            await route.fulfill({ json: level.mockData })
          })
        })
      })

      test(`Advisor Benefits program level should be categorized as ${level.name}`, async ({ homePage }) => {
        await homePage.tileAdvisorBenefits.validateProgramLevel()
      })
   
    })
  }
})

syncedTest.describe('Resizable tile test case', {
  tag: ['@assetmark', '@stable', '@2692']
}, () => {
  const widgetName = DashboardConfig.tiles.advisor_benefits.name
  for (const param of DashboardConfig.resizableTestParam) {
    syncedTest(`Tile "${widgetName}" should be displayed in a ${param.size} size`, async ({ removeAllWidgets, page, apiHelpers }) => {
      await syncedTest.step(`Add widget "${widgetName}" with height ${param.height} and width ${param.width}`, async () => {
        const widget = apiHelpers.widgets.getWidgets().advisor_benefits
        await apiHelpers.addWidgetOnDashboard(widget, {height: param.height, width: param.width})
      })
      await syncedTest.step(`Validates widget "${widgetName}" size (needs page refresh)`, async () => {
        const homePage = new HomePage(page)
        await homePage.goto()
        await homePage.waitPageIsReady()
        await homePage.tileAdvisorBenefits.validateTileSize(param.size)
      })
    })
  }
})

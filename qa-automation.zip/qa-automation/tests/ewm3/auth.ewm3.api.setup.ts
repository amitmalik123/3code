import { test as setup } from '@playwright/test'
import {EWM3Endpoints} from '../../ewm3/api/endpoints'
import {EWM3Config} from '../../ewm3/service-data/config'

setup('authenticate', async ({ request }) => {
  // Perform authentication steps.
  const endpoints = new EWM3Endpoints(request)
  const response = await endpoints.postMakeLogin(
    EWM3Config.USERNAME_DEFAULT,
    EWM3Config.PASSWORD
  )

  // End of authentication steps.

  const data = await response.text()
  //process.env.API_TOKEN = `Bearer ${data.access_token}`;
  const fs = require('fs')
  const dir = EWM3Config.AUTH_FILES_PATH

  if (!fs.existsSync(dir)){
    fs.mkdirSync(dir)
  }
  fs.writeFile(EWM3Config.AUTH_API_PATH, data, function(err) {
    if (err) {
      console.log(err)
    }
  })
})
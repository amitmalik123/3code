import { EWM3Config, Platforms } from '../../ewm3/service-data/config'
import { LoginPage } from '../../ewm3/ui/pages/login-page'
import { HomePage } from '../../ewm3/ui/pages/home-page'
import { test as setup } from '../../ewm3/fixtures/base-ui-fixture'

const assetMarkUsers = [
  EWM3Config.USERNAME_DEFAULT,
  EWM3Config.USERNAME_ACTION_LINKS,
  //Config.userNameWithData,
  //Config.userNameWithNoData
]

const cheetahUsers = [
  EWM3Config.USERNAME_DEFAULT,
]

let userSet: Set<string>
if (process.env.PLATFORM === Platforms.CHEETAH) {
  userSet = new Set(cheetahUsers)
} else { userSet = new Set(assetMarkUsers) }

const usersArray = Array.from(userSet)

for (const user of usersArray) {
  setup(`authenticate: ${user}`, async ({page}) => {
    // Perform authentication steps.
    const loginPage = new LoginPage(page)
    await loginPage.makeLogin(
      user,
      EWM3Config.PASSWORD
    )
    const homePage = new HomePage(page)
    await homePage.waitPageIsReady()

    // End of authentication steps.
    await homePage.page.context().storageState({path: EWM3Config.browserStorageState(user)})
  })

  setup.afterEach(async ({ apiHelpers }) => {
    await apiHelpers.deleteAllDashboards()
    await apiHelpers.setDefaultDashboard()
    await apiHelpers.addAllWidgetsOnDashboard()
  })
}

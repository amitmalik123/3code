import { test as setup } from '@playwright/test'
import {BaseApiHelpers} from '../../base/base-api-helpers'
import {IngestionV1} from '../../ingestion/api/ingestion/v1/endpoints/endpoints'
import {IngestionConfig} from '../../ingestion/service-data/config'

setup('authenticate', async ({ request }) => {
  // Perform authentication steps.
  const api = new BaseApiHelpers(request)
  const response = await api.makeRequest(new IngestionV1().auth.makeLogin)

  // End of authentication steps.

  const data = await response.text()
  //process.env.API_TOKEN = `Bearer ${data.access_token}`;
  const fs = require('fs')
  const dir = IngestionConfig.AUTH_FILES_PATH

  if (!fs.existsSync(dir)){
    fs.mkdirSync(dir)
  }
  fs.writeFile(IngestionConfig.AUTH_API_PATH, data, function(err) {
    if (err) {
      console.log(err)
    }
  })
})
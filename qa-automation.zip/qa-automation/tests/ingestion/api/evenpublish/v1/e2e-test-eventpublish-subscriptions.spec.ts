import { mergeTests } from '@playwright/test'
import {test as ingestionTest} from '../../../../../ingestion/fixtures/ingestion-api-fixture'
import {test as eventPublishTest} from '../../../../../ingestion/fixtures/eventpublish-api-fixture'
import {test as webhookTest} from '../../../../../webhook/fixtures/webhook-api-fixture'
import {EventPublishV1} from '../../../../../ingestion/api/eventpublish/v1/endpoints'
import {
  Subscriber,
  SubscriptionMessageType,
  SubscriptionNotificationType,
  SubscriptionStatus,
  SubscriptionType
} from '../../../../../ingestion/api/eventpublish/v1/types'
import {WEBHOOK_SERVER_URL} from '../../../../../webhook/server.config'
import {IngestionV1} from '../../../../../ingestion/api/ingestion/v1/endpoints/endpoints'
import {BaseMessage} from '../../../../../ingestion/api/ingestion/v1/endpoints/produce/base-message'
import {v4 as uuid} from 'uuid'
import {HttpMethod} from '../../../../../base/base-endpoint'
import {Webhook} from '../../../../../webhook/api/endpoints'
import {CreatedWebhookResponse} from '../../../../../webhook/api/types'
import { IngestionConfig } from '../../../../../ingestion/service-data/config'
import { Random } from '../../../../../utils/random'
import { faker } from '@faker-js/faker'
import { WebhookServerConstants } from '../../../../../webhook/constants'
import { WebhookApiHelpers, WebhookTestCase } from '../../../../../webhook/api/api-helpers'
import { EventPublisherApiHelpers } from '../../../../../ingestion/api/eventpublish/api-helpers'
import { IngestionApiHelpers } from '../../../../../ingestion/api/api-helpers'

// Playrwight function to merge fixtures objects
export const test = mergeTests(ingestionTest, eventPublishTest, webhookTest)

test.describe('Event publisher API V1 subscriptions', {
  tag: ['@e2e', '@eventpublish'],
}, () => {
  let api: EventPublisherApiHelpers
  let ingestionApi: IngestionApiHelpers
  let webhookApi: WebhookApiHelpers
  test.beforeEach(`Preconditions: Create api helpers with valid request context`, async ({ingestionRequestContext, eventPublishRequestContext, webhookRequestContext}) => {
    api = new EventPublisherApiHelpers(eventPublishRequestContext)
    ingestionApi = new IngestionApiHelpers(ingestionRequestContext)
    webhookApi = new WebhookApiHelpers(webhookRequestContext)
  })

  /**
 * Produces an ingestion API event.
 * 
 * @param message - Ingestion api message object.
 * @returns The enriched ingestion endpoint data.
 * 
 * @remarks
 * This function processes an event by retrieving the ingestion endpoint from the message,
 * making an API request to the endpoint, ensuring the response is 200 OK, and then enriching
 * the endpoint data to match the event publisher output.
 * 
 * @example
 * ```typescript
 * const ingestion = new IngestionV1()
 * const result = await produceEvent(ingestion.produce.benefitLevel);
 * console.log(result); // Logs the enriched ingestion endpoint data
 * ```
 */
  async function produceEvent(message: BaseMessage){
    const ingestionEndpoint = message.getEndpoint({floatReturnType: 'number', intReturnType: 'number'})
    return await test.step(`Produce ingestion API event`, async () => {
      const response = await ingestionApi.makeRequest(ingestionEndpoint)
      await api.responseIs200(response)
      // Enriching endpoint body to make it equal to eventpublisher output (Add SourceIDs or etc.)
      await api.enrichEndpointData(ingestionEndpoint)
      return ingestionEndpoint
    })
  }
  
  test.describe('200/201 Ok/Created', {
    tag: ['@status_code_201', '@status_code_200', '@positive'],
  }, () => {
    const eventPublish = new EventPublishV1()
    const ingestion = new IngestionV1()
    const webhook = new Webhook()
    let webhookId: string
    let createdSubscriberId: string
    let createdSubscriber: Subscriber
    const waitBeforeActionInSeconds = faker.number.int({min: 1, max: 5})

    const eventsArray: {type: SubscriptionMessageType, message: BaseMessage}[] = [
      {
        type: SubscriptionMessageType.BenefitLevel,
        message: ingestion.produce.benefitLevel
      },
      {
        type: SubscriptionMessageType.UpsertGoal,
        message: ingestion.produce.goal
      },
      {
        type: SubscriptionMessageType.Flows,
        message: ingestion.produce.flows
      },
      {
        type: SubscriptionMessageType.MarketValue,
        message: ingestion.produce.marketValue
      },
      {
        type: SubscriptionMessageType.UpsertContact,
        message: ingestion.produce.contact
      },
      {
        type: SubscriptionMessageType.UpsertHoldings,
        message: ingestion.produce.holdings
      },
      {
        type: SubscriptionMessageType.UpsertInvestmentManager,
        message: ingestion.produce.investmentManager
      },
      // todo: clarify the requirements for UpsertNonFinancialData. As of now it returns 500 status code
      // {
      //   type: SubscriptionMessageType.UpsertNonFinancialData,
      //   message: ingestion.produce.nonFinancialData
      // },
      {
        type: SubscriptionMessageType.UpsertOrganization,
        message: ingestion.produce.organization
      },
      {
        type: SubscriptionMessageType.UpsertPerformance,
        message: ingestion.produce.performance
      },
      {
        type: SubscriptionMessageType.UpsertProductFamily,
        message: ingestion.produce.productFamily
      },
      {
        type: SubscriptionMessageType.UpsertSourceAccount,
        message: ingestion.produce.sourceAccount
      },
      {
        type: SubscriptionMessageType.UpsertSummaryPerformance,
        message: ingestion.produce.summaryPerformance
      },
      {
        type: SubscriptionMessageType.UpsertVirtualAccount,
        message: ingestion.produce.virtualAccount
      },
      {
        type: SubscriptionMessageType.Fee,
        message: ingestion.produce.fee
      }, 
      {
        type: SubscriptionMessageType.UpsertWorkItem,
        message: ingestion.produce.workItem
      },
      {
        type: SubscriptionMessageType.UpsertGroup,
        message: ingestion.produce.userGroup
      },
      {
        type: SubscriptionMessageType.UpsertProposal,
        message: ingestion.produce.proposal
      },
      {
        type: SubscriptionMessageType.User,
        message: ingestion.produce.user
      },
      
    ]

    test.afterEach(`Clean up. Delete created subscriber by id if it is defined`, async () => {
      if (createdSubscriberId) await api.makeRequest(eventPublish.subscriptions.deleteSubscriber(createdSubscriberId))
    })

    for (const event of eventsArray) {
      
      test.describe(`${event.type}`, () => {

        test.beforeEach(`Preconditions: Create new subscriber and webhook`, async () => {
          const createWebhookResponse = await webhookApi.makeRequest(webhook.postNewWebhook())
          const createWebhookResponseBody: CreatedWebhookResponse = await createWebhookResponse.json()
          webhookId = createWebhookResponseBody.id
          const subscriberBody: Subscriber = {
            name: `${event.type} ${IngestionConfig.E2E_TEST_ITEM_TAG} subscriber ${uuid()}`,
            baseUrl: WEBHOOK_SERVER_URL,
            authenticationScheme: 'None',
            authenticationType: 'None',
            authenticationAttributes: {},
            customHeaders: {},
            subscriptions: [
              {
                name: `${event.type} ${IngestionConfig.E2E_TEST_ITEM_TAG} subscription ${uuid()}`,
                parameters: {
                  status: SubscriptionStatus.Active,
                  subscriptionType: SubscriptionType.WebHook,
                  messageTypes: [event.type],
                  actionVerb: HttpMethod.POST,
                  waitBeforeActionInSeconds,
                  url: `${WEBHOOK_SERVER_URL}/webhook/${webhookId}`,
                  batchSize: 500,
                  notification: {
                    address: IngestionConfig.TEST_MAIL,
                    notificationType: SubscriptionNotificationType.Email
                  }
                }
              }
            ]
          }
          createdSubscriber = await api.createSubscriber({subscriberBody})
          createdSubscriberId = createdSubscriber.id ?? ''
        })
  
        test(`Produce an event and receive a webhook message`, async () => {
          const ingestionEndpoint = await produceEvent(event.message)
          await webhookApi.assertWebhook(
            createdSubscriber, 
            [
              {
                testCase: WebhookTestCase.WEBHOOK_RECEIVED_MESSAGE,
                type: event.type,
                webhookId,
                ingestionEndpoint
              }
            ]
          )
        })

        test.describe(`Update subscriber tests`, () => {

          test.beforeEach(`Preconditions: Ensure that the webhook receives the message.`, async () => {
            const ingestionEndpoint = await produceEvent(event.message)
            await webhookApi.assertWebhook(
              createdSubscriber, 
              [
                {
                  testCase: WebhookTestCase.WEBHOOK_RECEIVED_MESSAGE,
                  type: event.type,
                  webhookId,
                  ingestionEndpoint
                }
              ]
            )
          })

          test(`Change subscription webhook url`, async () => {
            let newWebhookId = ''
            await test.step(`Create new webhook`, async () => {
              const createWebhookResponse = await webhookApi.makeRequest(webhook.postNewWebhook())
              const createWebhookResponseBody: CreatedWebhookResponse = await createWebhookResponse.json()
              newWebhookId = createWebhookResponseBody.id
            })
            
            await test.step(`Update subscription. Set new webhook url`, async () => {
              createdSubscriber.subscriptions[0].parameters.url = `${WEBHOOK_SERVER_URL}/webhook/${newWebhookId}`
              const updateSubscriber = await api.makeRequest(eventPublish.subscriptions.putSubscriber(createdSubscriberId, createdSubscriber))
              await api.responseIs200(updateSubscriber)
            })
  
            const ingestionEndpoint = await produceEvent(event.message)
  
            await test.step(`Assert that the old webhook does not receive the data, whereas the new webhook does`, async () => {
              await webhookApi.assertWebhook(
                createdSubscriber, 
                [
                  {
                    testCase: WebhookTestCase.WEBHOOK_NOT_RECEIVED_MESSAGE,
                    type: event.type,
                    webhookId, //old webhook
                    ingestionEndpoint
                  },
                  {
                    testCase: WebhookTestCase.WEBHOOK_RECEIVED_MESSAGE,
                    type: event.type,
                    webhookId: newWebhookId, //new webhook
                    ingestionEndpoint
                  }
                ]
              )
            })
            
          })
  
          test(`Delete subscriber. Webhook does not get new messages`, async () => {
            
            await test.step(`Delete subscriber`, async () => {
              const deleteSubscriber = await api.makeRequest( eventPublish.subscriptions.deleteSubscriber(createdSubscriberId))
              await api.responseIs204(deleteSubscriber)
              createdSubscriberId = ''
            })
  
            const ingestionEndpoint = await produceEvent(event.message)
  
            await webhookApi.assertWebhook(
              createdSubscriber, 
              [
                {
                  testCase: WebhookTestCase.WEBHOOK_NOT_RECEIVED_MESSAGE,
                  type: event.type,
                  webhookId, 
                  ingestionEndpoint
                }
              ]
            )
          })

          test(`Delete all subscriber's subscriptions. Webhook does not get new messages`, async () => {
            
            await test.step(`Update subscriber. Delete all subscriber's subscriptions`, async () => {
              createdSubscriber.subscriptions = []
              const updateSubscriber = await api.makeRequest(eventPublish.subscriptions.putSubscriber(createdSubscriberId, createdSubscriber))
              await api.responseIs200(updateSubscriber)
            })
  
            const ingestionEndpoint = await produceEvent(event.message)
  
            await webhookApi.assertWebhook(
              createdSubscriber, 
              [
                {
                  testCase: WebhookTestCase.WEBHOOK_NOT_RECEIVED_MESSAGE,
                  type: event.type,
                  webhookId, 
                  ingestionEndpoint
                }
              ]
            )
          })

        })

      })

      test.describe(`${event.type}`, () => {

        test.beforeEach(`Preconditions: Create new subscriber and webhook`, async () => {
          const createWebhookResponse = await webhookApi.makeRequest(webhook.postNewWebhook())
          const createWebhookResponseBody: CreatedWebhookResponse = await createWebhookResponse.json()
          webhookId = createWebhookResponseBody.id
          const subscriberBody: Subscriber = {
            name: `${event.type} ${IngestionConfig.E2E_TEST_ITEM_TAG} subscriber ${uuid()}`,
            baseUrl: WEBHOOK_SERVER_URL,
            authenticationScheme: 'None',
            authenticationType: 'OAuth20',
            authenticationAttributes: {
              AuthURL: `${WEBHOOK_SERVER_URL}/oauth/token`,
              ClientId: WebhookServerConstants.CLIENT_ID,
              ClientSecret: WebhookServerConstants.CLIENT_SECRET
            },
            customHeaders: Random.generateRandomKeyValuePairs(),
            subscriptions: [
              {
                name: `${event.type} ${IngestionConfig.E2E_TEST_ITEM_TAG} subscription ${uuid()}`,
                parameters: {
                  status: SubscriptionStatus.Active,
                  subscriptionType: SubscriptionType.WebHook,
                  messageTypes: [event.type],
                  actionVerb: HttpMethod.POST,
                  waitBeforeActionInSeconds,
                  url: `${WEBHOOK_SERVER_URL}/webhook/${webhookId}`,
                  batchSize: 500,
                  notification: {
                    address: IngestionConfig.TEST_MAIL,
                    notificationType: SubscriptionNotificationType.Email
                  }
                }
              }
            ]
          }
          createdSubscriber = await api.createSubscriber({subscriberBody})
          createdSubscriberId = createdSubscriber.id ?? ''
        })
  
        test(`Auth and custom headers test`, async () => {
          const ingestionEndpoint = await produceEvent(event.message)
          
          await webhookApi.assertWebhook(
            createdSubscriber, 
            [
              {
                testCase: WebhookTestCase.WEBHOOK_RECEIVED_MESSAGE,
                type: event.type,
                webhookId,
                ingestionEndpoint
              }
            ]
          )
        })
      })

    }
  })

})
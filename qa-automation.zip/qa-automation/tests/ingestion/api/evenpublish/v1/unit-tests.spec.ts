import { expect, test } from '../../../../../webhook/fixtures/webhook-api-fixture'
import {Webhook, WebhookAuth} from '../../../../../webhook/api/endpoints'
import { WebhookApiHelpers } from '../../../../../webhook/api/api-helpers'
import {CreatedWebhookResponse, WebhookAuthAttemptsResponseBody, WebhookAuthResponseBody, WebhookObject, isWebhookAuthResponseBody} from '../../../../../webhook/api/types'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../utils/random'
import {sleep} from '../../../../../utils/generalUtils'
import { WebhookServerConstants } from '../../../../../webhook/constants'
test.describe('Unit test for event publisher testing features', () => {
  const webhook = new Webhook()
  const auth = new WebhookAuth()
  let api: WebhookApiHelpers

  test.beforeEach(`Preconditions. Create api helpers with valid request context`, async ({webhookRequestContext}) => {
    api = new WebhookApiHelpers(webhookRequestContext)
  })

  test(`Webhook default test`, async () => {
    const createWebhookResponse = await api.makeRequest(webhook.postNewWebhook())
    const createWebhookResponseBody: CreatedWebhookResponse = await createWebhookResponse.json()
    const id = createWebhookResponseBody.id

    const webhookListResponse = await api.makeRequest(webhook.getWebhookArray())
    const webhookListResponseBody: WebhookObject[] = await webhookListResponse.json()
    expect(webhookListResponseBody.find(w => w.id === id),
      `Expect that created webhook exists in webhooks array response`
    ).toEqual({id, messages: []})

    for (let i = 0; i < 3; i++) {
      await test.step(`Sending webhook message and assert that webhook was received`, async () => {
        const randomBody = faker.datatype.boolean() ? Random.generateRandomKeyValuePairs() : [Random.generateRandomKeyValuePairs()]
        const timestamp = new Date()
        const response = await api.makeRequest(webhook.postWebhookMessage(id, randomBody))
        await api.responseIs200(response)
        const webhookByIdResponse = await api.makeRequest(webhook.getWebhookDataById(id))
        const webhookByIdResponseBody: WebhookObject = await webhookByIdResponse.json()

        expect(webhookByIdResponseBody.messages.length,
          `Expect that length of response body webhook messages array is equal to count of sent webhook messages: ${i+1}`
        ).toEqual(i+1)

        expect(webhookByIdResponseBody.messages[i].body,
          `Expect webhook message with index: ${i} and sent webhook message to be equal`
        ).toEqual(randomBody)

        const actualTimestamp = new Date(webhookByIdResponseBody.messages[i].timestamp)
        expect(Math.abs(actualTimestamp.getTime() - timestamp.getTime()),
          `Expect the actual webhook timestamp  ${actualTimestamp.toISOString()} 
        to be close to time when message was sent ${timestamp.toISOString()}`
        ).toBeLessThan(300)

        await sleep(1000)
      })
    }

  })

  test(`Webhook different status codes test`, async () => {
    const createWebhookResponse = await api.makeRequest(webhook.postNewWebhook())
    const createWebhookResponseBody: CreatedWebhookResponse = await createWebhookResponse.json()

    const id = createWebhookResponseBody.id
    const randomBody = faker.datatype.boolean() ? Random.generateRandomKeyValuePairs() : [Random.generateRandomKeyValuePairs()]

    const response204 = await api.makeRequest(webhook.postWebhookMessage(id, randomBody, {status: 204}))
    await api.responseIs204(response204)
    const response400 = await api.makeRequest(webhook.postWebhookMessage(id, randomBody, {status: 400}))
    await api.responseIs400(response400)

  })

  test(`Webhook return headers test`, async () => {
    const createWebhookResponse = await api.makeRequest(webhook.postNewWebhook())
    const createWebhookResponseBody: CreatedWebhookResponse = await createWebhookResponse.json()

    const id = createWebhookResponseBody.id
    const randomBody = faker.datatype.boolean() ? Random.generateRandomKeyValuePairs() : [Random.generateRandomKeyValuePairs()]

    const postMessage = webhook.postWebhookMessage(id, randomBody)
    postMessage.extraHeaders = Random.generateRandomKeyValuePairs()
    await api.makeRequest(postMessage)

    const webhookByIdResponse = await api.makeRequest(webhook.getWebhookDataById(id))
    const webhookByIdResponseBody: WebhookObject = await webhookByIdResponse.json()
    await api.jsonContainsData(webhookByIdResponseBody.messages[0].headers, postMessage.extraHeaders)

  })

  test.describe('Auth tests', () => {
    const validEndpointsParams =[
      {
        title: 'Creds passed via body',
        endpoint: () => {
          return auth.getToken(
            {
              grant_type: WebhookServerConstants.GRANT_TYPE,
              client_id: WebhookServerConstants.CLIENT_ID,
              client_secret: WebhookServerConstants.CLIENT_SECRET
            }
          )}
      },
      {
        title: 'Creds passed via headers(Basic auth)',
        endpoint: () => {
          const endpoint = auth.getToken(
            {
              grant_type: WebhookServerConstants.GRANT_TYPE
            }
          )
          // Concatenate username and password with a colon
          const credentials = `${WebhookServerConstants.CLIENT_ID}:${WebhookServerConstants.CLIENT_SECRET}`
    
          // Encode the credentials in Base64
          const encodedCredentials = Buffer.from(credentials).toString('base64')
    
          endpoint.extraHeaders = {
            ...endpoint.extraHeaders,
            // Prefix with 'Basic ' and return the token
            authorization: `Basic ${encodedCredentials}`
          }
          return endpoint
        }
      }
    ]
    test.describe('Successfull auth', () => {
      for(const param of validEndpointsParams){
        test(param.title, async () => {
          const response = await api.makeRequest(param.endpoint())
          await api.responseIs200(response)
          const responseBody: WebhookAuthResponseBody = await response.json()
          await test.step(`Assert response body`, async () => {
            expect(responseBody.access_token, 
              `Expect access_token to match regex: ${WebhookServerConstants.ACCESS_TOKEN_REGEX}`
            ).toMatch(WebhookServerConstants.ACCESS_TOKEN_REGEX)
            expect(responseBody.refresh_token, 
              `Expect refresh_token to match regex: ${WebhookServerConstants.REFRESH_TOKEN_REGEX}`
            ).toMatch(WebhookServerConstants.REFRESH_TOKEN_REGEX)
            expect(responseBody.expires_in, 
              `Expect expires_in to be: ${WebhookServerConstants.TOKEN_EXPIRES_IN}`
            ).toEqual(WebhookServerConstants.TOKEN_EXPIRES_IN)
            expect(responseBody.token_type, 
              `Expect token_type to be: ${WebhookServerConstants.TOKEN_TYPE}`
            ).toEqual(WebhookServerConstants.TOKEN_TYPE)
          })
        })

        test(`${param.title}. Auth attempts list test`, async () => {
          const response = await api.makeRequest(param.endpoint())
          await api.responseIs200(response)
          const responseBody: WebhookAuthResponseBody = await response.json()
          await test.step(`Assert that auth attempt is presented in the list`, async () => {
            const endpoint = auth.getAuthAttempts()
            const authAttemptsResponse = await api.makeRequest(endpoint)
            await api.responseIs200(response)
            const authAttemptsResponseBody: WebhookAuthAttemptsResponseBody = await authAttemptsResponse.json()
            const attempt = authAttemptsResponseBody.find(item => {
              if(isWebhookAuthResponseBody(item.responseBody)){
                return item.responseBody.access_token === responseBody.access_token
              } return false
            }
            )
            expect(attempt, 
              `Expect that attempt was found in the list`
            ).toBeDefined()
            await api.jsonContainsData(attempt?.headers, param.endpoint().extraHeaders)
            expect(attempt?.body,
              `Expect that attempt has the same body as actual request body`
            ).toEqual(param.endpoint().formData)
            expect(attempt?.responseStatusCode, 
              `Expect that attempt status code is 200`
            ).toEqual(200)
            expect(attempt?.responseBody, 
              `Expect that attempt response body is the same as actual response body`
            ).toEqual(responseBody)
          })
        })
      }
    })

    test.describe('Failed auth', () => {

      const badRequestBodies = [
        {
          title: 'Invalid grant type',
          requestBody: {
            grant_type: 'invalid_grant_type',
            client_id: WebhookServerConstants.CLIENT_ID,
            client_secret: WebhookServerConstants.CLIENT_SECRET
          }
        },
        {
          title: 'Missing client id',
          requestBody: {
            grant_type: WebhookServerConstants.GRANT_TYPE,
            client_secret: WebhookServerConstants.CLIENT_SECRET
          }
        },
        {
          title: 'Missing client secret',
          requestBody: {
            grant_type: WebhookServerConstants.GRANT_TYPE,
            client_id: WebhookServerConstants.CLIENT_ID
          }
        },
        {
          title: 'Missing client id and secret',
          requestBody: {
            grant_type: WebhookServerConstants.GRANT_TYPE,
          }
        },
        {
          title: 'Missing grant type client id and secret',
          requestBody: {}
        }
      ]
    
      for(const param of badRequestBodies){
        test(`${param.title}`, async () => {
          const endpoint = auth.getToken(
            param.requestBody
          )
          const response = await api.makeRequest(endpoint)
          await api.responseIs400(response)
        })
      }

      const unauthorizedRequestBodies = [
        {
          title: 'Invalid client id',
          requestBody: {
            grant_type: WebhookServerConstants.GRANT_TYPE,
            client_id: 'invalid_client_id',
            client_secret: WebhookServerConstants.CLIENT_SECRET
          }
        },
        {
          title: 'Invalid client secret',
          requestBody: {
            grant_type: WebhookServerConstants.GRANT_TYPE,
            client_id: WebhookServerConstants.CLIENT_ID,
            client_secret: 'invalid_client_secret'
          }
        },
        {
          title: 'Invalid client id and secret',
          requestBody: {
            grant_type: WebhookServerConstants.GRANT_TYPE,
            client_id: 'invalid_client_id',
            client_secret: 'invalid_client_secret'
          }
        }
      ]
      for(const param of unauthorizedRequestBodies){
        test(`${param.title}`, async () => {
          const endpoint = auth.getToken(
            param.requestBody
          )
          const response = await api.makeRequest(endpoint)
          await api.responseIs401(response)
        })
      }

    })
  })

})

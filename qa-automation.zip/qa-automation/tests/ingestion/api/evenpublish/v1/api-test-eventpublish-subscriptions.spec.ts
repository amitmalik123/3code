import { expect, test } from '../../../../../ingestion/fixtures/eventpublish-api-fixture'
import {BaseApiEndpoint, HttpMethod} from '../../../../../base/base-endpoint'
import {EventPublishV1} from '../../../../../ingestion/api/eventpublish/v1/endpoints'
import {v4 as uuid} from 'uuid'
import {Random} from '../../../../../utils/random'
import {Subscriber, Subscription} from '../../../../../ingestion/api/eventpublish/v1/types'
import {generateEventPublishSubscription} from '../../../../../ingestion/api/eventpublish/v1/payloads/subscription'
import {generateEventPublishSubscriber} from '../../../../../ingestion/api/eventpublish/v1/payloads/subscriber'
import {faker} from '@faker-js/faker'
import { EventPublisherApiHelpers } from '../../../../../ingestion/api/eventpublish/api-helpers'

test.describe('Event publisher API V1 subscriptions', {
  tag: ['@api', '@eventpublish'],
}, () => {

  const eventPublish = new EventPublishV1()
  let createdSubscriberId: string
  let createdSubscriber: Subscriber
  let api: EventPublisherApiHelpers

  const endpoints: BaseApiEndpoint[] = [
    eventPublish.subscriptions.getSubscribers(),
    eventPublish.subscriptions.postSubscribers(),
    eventPublish.subscriptions.getSubscriberById(),
    eventPublish.subscriptions.putSubscriber(),
    eventPublish.subscriptions.deleteSubscriber(),
    eventPublish.subscriptions.getSubscriptionsArrayBySubscriberId(),
    eventPublish.subscriptions.getSubscriptionBySubscriberId(),
    eventPublish.subscriptions.postSubscriptionsBySubscriberId()
  ]

  test.beforeEach(`Preconditions. Create api helpers with valid request context`, async ({eventPublishRequestContext}) => {
    api = new EventPublisherApiHelpers(eventPublishRequestContext)
  })

  test.describe(`200/201 Ok/Created`, {
    tag: ['@status_code_201', '@status_code_200', '@positive'],
  }, () => {

    test.afterEach(`Clean up. Delete created subscriber by id if it is defined`, async () => {
      if (createdSubscriberId) await api.makeRequest(eventPublish.subscriptions.deleteSubscriber(createdSubscriberId))
    })

    test(`Create new subscriber with empty subscriptions array`, async () => {
      const endpoint = eventPublish.subscriptions.postSubscribers()
      endpoint.body.subscriptions = []

      createdSubscriber = await api.createSubscriber({subscriberBody: endpoint.body})
      createdSubscriberId = createdSubscriber.id ?? ''

      // Get subscriber by ID
      const response = await api.makeRequest(eventPublish.subscriptions.getSubscriberById(createdSubscriberId))
      await api.responseIs200(response)
      const responseBody: Subscriber = await response.json()

      expect(responseBody,
        'Assert that the subscriber that was retrieved by id is equal to the created subscriber object'
      ).toEqual(createdSubscriber)
    })

    for (const generateSubscriptionsId of [true, false]) {
      test.describe(`Generate subscription ID by client: ${generateSubscriptionsId}`, {
        tag: ['@status_code_201', '@status_code_200', '@positive'],
      }, () => {
  
        test.beforeEach(`Preconditions. Create new subscriber`, async () => {
          createdSubscriber = await api.createSubscriber({generateSubscriptionsId})
          createdSubscriberId = createdSubscriber.id ?? ''
        })
  
        test(`Validate json schema. ${eventPublish.subscriptions.getSubscribers().title}`, async () => {
          const endpoint = eventPublish.subscriptions.getSubscribers()
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          api.validateJsonSchema(endpoint, await response.json())
        })
  
        test(`Validate json schema. ${eventPublish.subscriptions.getSubscriberById().title}`, async () => {
          const endpoint = eventPublish.subscriptions.getSubscriberById(createdSubscriberId)
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          api.validateJsonSchema(endpoint, await response.json())
        })
  
        test(`Validate json schema. ${eventPublish.subscriptions.getSubscriptionsArrayBySubscriberId().title}`, async () => {
          const endpoint = eventPublish.subscriptions.getSubscriptionsArrayBySubscriberId(createdSubscriberId)
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          api.validateJsonSchema(endpoint, await response.json())
        })
  
        test(`Validate json schema. ${eventPublish.subscriptions.getSubscriptionBySubscriberId().title}`, async () => {
          const randomSubscriptionIndex = Random.getNumber(createdSubscriber.subscriptions.length)
          const subscriptionId = createdSubscriber.subscriptions[randomSubscriptionIndex].id
          const endpoint = eventPublish.subscriptions.getSubscriptionBySubscriberId(createdSubscriberId, subscriptionId)
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          api.validateJsonSchema(endpoint, await response.json())
        })
  
        test(`Created subscriber exists in subscribers' array`, async () => {
          const endpoint = eventPublish.subscriptions.getSubscribers()
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          const responseBody: Subscriber[] = await response.json()
          const subscriber = responseBody.find(subscriber => subscriber.id === createdSubscriberId)
          if (subscriber) {
            subscriber.subscriptions = api.sortSubscriptions(subscriber.subscriptions)
            expect(subscriber,
              'Assert that the subscriber from the array is equal to the created subscriber object'
            ).toEqual(createdSubscriber)
          } else throw new Error('Subscriber was not found in subscribers\' array')
        })
  
        test(`Create new subscriber. Use existing subscriber's subscription name`, async () => {
          let newCreatedSubscriber: Subscriber
          await test.step(`Get existing subscriber's subscription name and use it as a name for new subscriber's subscription`, async () => {
            const subscriberBody = generateEventPublishSubscriber({generateSubscriptionsId})
            subscriberBody.subscriptions[0].name = createdSubscriber.subscriptions[0].name
            newCreatedSubscriber = await api.createSubscriber({generateSubscriptionsId, subscriberBody})
          })
          await test.step(`Assert that the new subscriber is presented in the subscribers' array`, async () => {
            const endpoint = eventPublish.subscriptions.getSubscribers()
            const response = await api.makeRequest(endpoint)
            await api.responseIs200(response)
            const responseBody: Subscriber[] = await response.json()
            const subscriber = responseBody.find(subscriber => subscriber.id === newCreatedSubscriber.id)
            if (subscriber) {
              subscriber.subscriptions = api.sortSubscriptions(subscriber.subscriptions)
              expect(subscriber,
                'Assert that the subscriber from the array is equal to the created subscriber object'
              ).toEqual(newCreatedSubscriber)
            } else throw new Error('Subscriber was not found in subscribers\' array')
          })
          await test.step(`Clean up. Delete new subscriber`, async () => {
            await api.makeRequest(eventPublish.subscriptions.deleteSubscriber(newCreatedSubscriber.id))
          })
  
        })
  
        test(`Created subscriber can be retrieved by subscriber's id`, async () => {
          const endpoint = eventPublish.subscriptions.getSubscriberById(createdSubscriberId)
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          const responseBody: Subscriber = await response.json()
  
          responseBody.subscriptions = api.sortSubscriptions(responseBody.subscriptions)
          expect(responseBody,
            'Assert that the subscriber that was retrieved by id is equal to the created subscriber object'
          ).toEqual(createdSubscriber)
        })
  
        test(`Created subscriber's subscriptions can be retrieved by subscriber's id`, async () => {
          const endpoint = eventPublish.subscriptions.getSubscriptionsArrayBySubscriberId(createdSubscriberId)
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          let responseBody: Subscription[] = await response.json()
  
          responseBody = api.sortSubscriptions(responseBody)
          expect(responseBody,
            `Assert that the subscriber's subscriptions array is equal to the created subscriber's subscriptions array`
          ).toEqual(createdSubscriber.subscriptions)
        })
  
        test(`Created subscriber has specific subscription`, async () => {
          const randomSubscriptionIndex = Random.getNumber(createdSubscriber.subscriptions.length)
          const subscriptionId = createdSubscriber.subscriptions[randomSubscriptionIndex].id
          const endpoint = eventPublish.subscriptions.getSubscriptionBySubscriberId(createdSubscriberId, subscriptionId)
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          const responseBody: Subscription = await response.json()
  
          expect(responseBody,
            `Assert that the subscriber's specific subscription that was retrieved by id is equal to the created subscriber's subscription object`
          ).toEqual(createdSubscriber.subscriptions[randomSubscriptionIndex])
        })
  
        test(`Created subscriber can be updated (authenticationAttributes and customHeaders are empty). Compare with get subscriber by id`, async () => {
          const updatedSubscriber = generateEventPublishSubscriber(
            {
              subscriberId: createdSubscriberId,
              generateSubscriptionsId
            }
          )
          updatedSubscriber.authenticationAttributes = {}
          updatedSubscriber.customHeaders = {}
          const endpoint = eventPublish.subscriptions.putSubscriber(createdSubscriberId, updatedSubscriber)
  
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
          // Prepare updatedSubscriber to assert. Add IDs and sort subscriptions
          if (!generateSubscriptionsId) await api.addSubscriptionsIdToSubscriber(updatedSubscriber)
          updatedSubscriber.subscriptions = api.sortSubscriptions(updatedSubscriber.subscriptions)
  
          const getSubscriberResponse = await api.makeRequest(eventPublish.subscriptions.getSubscriberById(createdSubscriberId))
          await api.responseIs200(getSubscriberResponse)
          const getSubscriberResponseBody: Subscriber = await getSubscriberResponse.json()
          getSubscriberResponseBody.subscriptions = api.sortSubscriptions(getSubscriberResponseBody.subscriptions)
  
          expect(getSubscriberResponseBody,
            'Assert that the updatedSubscriber that was retrieved by id is equal to the updated updatedSubscriber object'
          ).toEqual(updatedSubscriber)
        })
  
        test(`Created subscriber can be updated. Compare with get subscribers list`, async () => {
          // Generating new subscriber object
          const updatedSubscriber = generateEventPublishSubscriber(
            {
              subscriberId: createdSubscriberId,
              generateSubscriptionsId
            }
          )
          // Setting values for authenticationAttributes and customHeaders (by default they can be random OR empty)
          updatedSubscriber.authenticationAttributes = Random.generateRandomKeyValuePairs()
          updatedSubscriber.customHeaders = Random.generateRandomKeyValuePairs()
          const response = await api.makeRequest(eventPublish.subscriptions.putSubscriber(createdSubscriberId, updatedSubscriber))
          await api.responseIs200(response)
          // Prepare updatedSubscriber to assert. Add IDs and sort subscriptions
          if (!generateSubscriptionsId) await api.addSubscriptionsIdToSubscriber(updatedSubscriber)
          updatedSubscriber.subscriptions = api.sortSubscriptions(updatedSubscriber.subscriptions)
  
          const getSubscribersListResponse = await api.makeRequest(eventPublish.subscriptions.getSubscribers())
          await api.responseIs200(getSubscribersListResponse)
          const getSubscribersListResponseBody: Subscriber[] = await getSubscribersListResponse.json()
          const subscriber = getSubscribersListResponseBody.find(subscriber => subscriber.id === createdSubscriberId)
  
          if (subscriber) {
            subscriber.subscriptions = api.sortSubscriptions(subscriber.subscriptions)
            expect(subscriber,
              'Assert that the subscriber array contains subscriber that is equal to the updated subscriber object'
            ).toEqual(updatedSubscriber)
          } else throw new Error('Subscriber was not found in subscribers\' array')
        })
  
        test(`Created subscriber can be updated. Subscriptions array is empty`, async () => {
          const endpoint = eventPublish.subscriptions.putSubscriber(createdSubscriberId)
          endpoint.body.subscriptions = []
          const response = await api.makeRequest(endpoint)
          await api.responseIs200(response)
    
          const getSubscriberResponse = await api.makeRequest(eventPublish.subscriptions.getSubscriberById(createdSubscriberId))
          await api.responseIs200(getSubscriberResponse)
          const getSubscriberResponseBody: Subscriber = await getSubscriberResponse.json()
    
          expect(getSubscriberResponseBody,
            'Assert that the updatedSubscriber that was retrieved by id is equal to the updated updatedSubscriber object'
          ).toEqual(endpoint.body)
        })
  
        test(`Add new subscription to created subscriber`, async () => {
          // Generate an array of subscriptions
          const subscriptions = Array.from({length: faker.number.int({min: 1, max: 10})},
            () => generateEventPublishSubscription({ subscriberId: createdSubscriberId, generateSubscriptionsId }))
          // Make post request to add new subscriptions to subscriber
          const endpoint = eventPublish.subscriptions.postSubscriptionsBySubscriberId(createdSubscriberId, subscriptions)
          const response = await api.makeRequest(endpoint)
          await api.responseIs201(response)
  
          createdSubscriber.subscriptions.push(...endpoint.body)
          createdSubscriber.subscriptions = api.sortSubscriptions(createdSubscriber.subscriptions)
          // If subscription ID was not generated by client we need to get ID from event publisher
          if (!generateSubscriptionsId) await api.addSubscriptionsIdToSubscriber(createdSubscriber)
  
          const getSubscriberResponse = await api.makeRequest(eventPublish.subscriptions.getSubscriberById(createdSubscriberId))
          await api.responseIs200(getSubscriberResponse)
          const getSubscriberResponseBody: Subscriber = await getSubscriberResponse.json()
          getSubscriberResponseBody.subscriptions = api.sortSubscriptions(getSubscriberResponseBody.subscriptions)
  
          expect(getSubscriberResponseBody).toEqual(createdSubscriber)
        })
  
        test.describe('Delete subscriber tests', {
          tag: ['@status_code_204'],
        }, () => {
          let deleteEndpoint: BaseApiEndpoint
          test.beforeEach(`Preconditions. Delete subscriber by id`, async () => {
            deleteEndpoint = eventPublish.subscriptions.deleteSubscriber(createdSubscriberId)
            const response = await api.makeRequest(deleteEndpoint)
            await api.responseIs204(response)
            await api.responseBodyIsEmpty(response)
          })
          test.afterEach(`Clean up. Set subscriberId=null`, async () => {
            createdSubscriberId = ''
          })
  
          test(`Delete already deleted return 404`, {
            tag: ['@status_code_404', '@negative'],
          }, async () => {
            const response = await api.makeRequest(deleteEndpoint)
            await api.responseIs404(response)
            await api.validateErrorResponse(response)
          })
  
          test(`Deleted subscription is not presented in subscribers list`, async () => {
            const endpoint = eventPublish.subscriptions.getSubscribers()
            const response = await api.makeRequest(endpoint)
            await api.responseIs200(response)
            const responseBody: Subscriber[] = await response.json()
            const subscriber = responseBody.find(subscriber => subscriber.id === createdSubscriberId)
  
            expect(subscriber, 'Assert that the subscriber is not presented in the subscribers array').not.toBeDefined()
          })
  
          test(`Deleted subscription can't be retrieved by subscriber's id`, async () => {
            const endpoint = eventPublish.subscriptions.getSubscriberById(createdSubscriberId)
            const response = await api.makeRequest(endpoint)
            await api.responseIs404(response)
            await api.validateErrorResponse(response)
          })
  
        })
  
      })
    }

  })

  test.describe('400 Bad request', {
    tag: ['@status_code_400', '@negative'],
  }, () => {

    const eventPublish = new EventPublishV1()
    const endpoints: BaseApiEndpoint[] = [
      eventPublish.subscriptions.postSubscribers(),
      eventPublish.subscriptions.putSubscriber(uuid()),
      eventPublish.subscriptions.postSubscriptionsBySubscriberId(uuid())
    ]
    for (const endpoint of endpoints) {
      test(`Random body. ${endpoint.title}`, async () => {
        endpoint.body = Random.generateRandomKeyValuePairs()

        const response = await api.makeRequest(endpoint)
        await api.responseIs400(response)
        await api.validateMultipleErrorsResponse(response)
      })
    }

  })

  test.describe('401 Unauthorized. No token passed', {
    tag: ['@status_code_401', '@negative'],
  }, () => {

    for (const endpoint of endpoints) {
      test(`${endpoint.title}`, async ({eventPublishUnauthorizedContext}) => {
        const api = new EventPublisherApiHelpers(eventPublishUnauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

  test.describe('401 Unauthorized. Token is expired', {
    tag: ['@status_code_401', '@negative'],
  }, () => {

    for (const endpoint of endpoints) {
      test(`${endpoint.title}`, async ({eventPublishExpiredTokenContext}) => {
        const api = new EventPublisherApiHelpers(eventPublishExpiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

  test.describe('404 Not found', {
    tag: ['@status_code_404', '@negative'],
  }, () => {
    const endpoints: BaseApiEndpoint[] = [
      eventPublish.subscriptions.getSubscriberById(uuid()),
      eventPublish.subscriptions.putSubscriber(uuid()),
      eventPublish.subscriptions.deleteSubscriber(uuid()),
      eventPublish.subscriptions.getSubscriptionsArrayBySubscriberId(uuid()),
      eventPublish.subscriptions.getSubscriptionBySubscriberId(uuid(), uuid()),
      eventPublish.subscriptions.postSubscriptionsBySubscriberId(uuid())
    ]
    for (const endpoint of endpoints) {
      test(`${endpoint.title}`, async () => {
        const response = await api.makeRequest(endpoint)
        await api.responseIs404(response)
        await api.validateErrorResponse(response)
      })
    }

  })

  test.describe('405 Method is not allowed', {
    tag: ['@status_code_405', '@negative'],
  }, () => {
    const eventPublish = new EventPublishV1()
    const methods = Object.values(HttpMethod)
    type InvalidMethodTestParams = {
      endpoint: BaseApiEndpoint,
      invalidMethods: HttpMethod[]
    }
    const params: InvalidMethodTestParams[] = [
      {
        endpoint: eventPublish.subscriptions.getSubscribers(),
        invalidMethods: methods.filter(item => item !== HttpMethod.GET && item !== HttpMethod.POST)
      },
      {
        endpoint: eventPublish.subscriptions.postSubscribers(),
        invalidMethods: methods.filter(item => item !== HttpMethod.GET && item !== HttpMethod.POST && item !== HttpMethod.HEAD)
      },
      {
        endpoint: eventPublish.subscriptions.getSubscriberById(uuid()),
        invalidMethods: methods.filter(item => item !== HttpMethod.GET && item !== HttpMethod.PUT && item !== HttpMethod.DELETE)
      },
      {
        endpoint: eventPublish.subscriptions.putSubscriber(uuid()),
        invalidMethods: methods.filter(item => item !== HttpMethod.GET && item !== HttpMethod.PUT && item !== HttpMethod.DELETE && item !== HttpMethod.HEAD)
      },
      {
        endpoint: eventPublish.subscriptions.getSubscriptionsArrayBySubscriberId(uuid()),
        invalidMethods: methods.filter(item => item !== HttpMethod.GET && item !== HttpMethod.POST)
      },
      {
        endpoint: eventPublish.subscriptions.getSubscriptionBySubscriberId(uuid(), uuid()),
        invalidMethods: methods.filter(item => item !== HttpMethod.GET)
      },
      {
        endpoint: eventPublish.subscriptions.postSubscriptionsBySubscriberId(uuid()),
        invalidMethods: methods.filter(item => item !== HttpMethod.GET && item !== HttpMethod.POST && item !== HttpMethod.HEAD)
      }
    ]
    for (const param of params) {
      const endpoint = param.endpoint
      for (const invalidMethod of param.invalidMethods) {
        test(`${endpoint.title}. Using method: "${invalidMethod}" instead of: "${endpoint.method}"`, async () => {
          endpoint.method = invalidMethod
          const response = await api.makeRequest(endpoint)
          await api.responseIs405(response)
          await api.responseBodyIsEmpty(response)
        })
      }
    }
  })

  test.describe('500 Internal Server Error', {
    tag: ['@status_code_500', '@negative'],
  }, () => {
    //TODO: Add response body validation after EWMPM-6456 is resolved

    const eventPublish = new EventPublishV1()

    test(`Use the same subscription name within the same subscriber`, async () => {
      const endpoint = eventPublish.subscriptions.postSubscribers()
      await test.step(`Add 2 subscriptions with the same name and try to create new subscriber`, async () => {
        endpoint.body.subscriptions = Array.from({length: 2}, generateEventPublishSubscription)
        endpoint.body.subscriptions[1].name = endpoint.body.subscriptions[0].name
        const response = await api.makeRequest(endpoint)
        await api.responseIs500(response)
      })
      await api.assertSubscriberIsNotPresented(endpoint.body.name)
    })

    test(`Use the same subscription ID within the same subscriber`, async () => {
      const endpoint = eventPublish.subscriptions.postSubscribers()
      await test.step(`Add 2 subscriptions with the same ID and try to create new subscriber`, async () => {
        endpoint.body.subscriptions = Array.from({length: 2}, () => generateEventPublishSubscription({generateSubscriptionsId: true}))
        endpoint.body.subscriptions[1].id = endpoint.body.subscriptions[0].id
        const response = await api.makeRequest(endpoint)
        await api.responseIs500(response)
      })
      await api.assertSubscriberIsNotPresented(endpoint.body.name)
    })

    test.describe('New subscriber is created', () => {

      test.beforeEach(`Preconditions. Create new subscriber`, async () => {
        createdSubscriber = await api.createSubscriber()
        createdSubscriberId = createdSubscriber.id ?? ''
      })

      test.afterEach(`Clean up. Delete created subscriber by id if it is defined`, async () => {
        if (createdSubscriberId) await api.makeRequest(eventPublish.subscriptions.deleteSubscriber(createdSubscriberId))
      })

      test(`Use the same subscriber name`, async () => {
        const endpoint = eventPublish.subscriptions.postSubscribers()
        await test.step(`Set the existing subscriber name and try to create new subscriber`, async () => {
          endpoint.body.name = createdSubscriber.name
          const response = await api.makeRequest(endpoint)
          await api.responseIs500(response)
        })
        await test.step(`Make sure that invalid subscriber was not created`, async () => {
          const response = await api.makeRequest(eventPublish.subscriptions.getSubscribers())
          await api.responseIs200(response)
          const responseBody: Subscriber[] = await response.json()
          const subscribers = responseBody.filter(subscriber => subscriber.name === endpoint.body.name)
          expect(subscribers.length, `Expect that there is only 1 subscriber with name ${endpoint.body.name}`).toEqual(1)
          subscribers[0].subscriptions = api.sortSubscriptions(subscribers[0].subscriptions)
          expect(subscribers[0],
            'Assert that the subscriber from the array is equal to the valid subscriber object that was created before'
          ).toEqual(createdSubscriber)

        })
      })

      test(`Use the same subscription ID`, async () => {
        const endpoint = eventPublish.subscriptions.postSubscribers()
        await test.step(`Set the existing subscription ID and try to create new subscriber`, async () => {
          endpoint.body.subscriptions[0].id = createdSubscriber.subscriptions[0].id
          const response = await api.makeRequest(endpoint)
          await api.responseIs500(response)
        })
        await api.assertSubscriberIsNotPresented(endpoint.body.name)
      })

    })

  })

})
import {HttpMethod} from '../../../../../base/base-endpoint'
import {v4 as uuid} from 'uuid'
import {Random} from '../../../../../utils/random'
import { HistorianV1 } from '../../../../../ingestion/api/historian/v1/endpoints'
import { test } from '../../../../../ingestion/fixtures/historian-api-fixture'
import { IngestionV1 } from '../../../../../ingestion/api/ingestion/v1/endpoints/endpoints'
import { BaseMessage } from '../../../../../ingestion/api/ingestion/v1/endpoints/produce/base-message'
import { IngestionApiHelpers } from '../../../../../ingestion/api/api-helpers'

test.describe('Historian API V1 replay', {
  tag: ['@api', '@historian'],
}, () => {

  const historian = new HistorianV1()
  let api: IngestionApiHelpers

  // Historian has the same path parameters as ingestion api. 
  // Using ingestion api messages as a parameter for historian api tests.
  const messagesArr: BaseMessage[] = Object.values(new IngestionV1().produce)
  const randomMessage = Random.getValueFromArray(messagesArr)
  const endpoint = historian.replay.byMessageName(randomMessage.pathParameters)

  test.beforeEach(`Preconditions. Create api helpers with valid request context`, async ({historianRequestContext}) => {
    api = new IngestionApiHelpers(historianRequestContext)
  })

  test.describe(`200 Ok`, {
    tag: ['@status_code_200', '@positive'],
  }, () => {

    test.describe(`${endpoint.title}`, () => {

      test(`All fields`, async () => {
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        // TODO: Add response body validation after fixing EWMPM-6541
      })
  
      test(`Only startDate`, async () => {
        endpoint.body.endDate = undefined
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
      })
  
      test(`Only endDate`, async () => {
        endpoint.body.startDate = undefined
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
      })
  
      test(`No dates`, async () => {
        endpoint.body.startDate = undefined
        endpoint.body.endDate = undefined
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
      })

    })

  })

  test.describe('400 Bad request', {
    tag: ['@status_code_400', '@negative'],
  }, () => {

    test.describe(`${endpoint.title}`, () => {

      test(`Random body`, async () => {
        const endpoint = historian.replay.byMessageName(randomMessage.pathParameters, Random.generateRandomKeyValuePairs())
        const response = await api.makeRequest(endpoint)
        await api.responseIs400(response)
        await api.validateMultipleErrorsResponse(response)
      })
  
      // TODO: Add invalid  after fixing EWMPM-6541

    })

  })

  test.describe('401 Unauthorized. No token passed', {
    tag: ['@status_code_401', '@negative'],
  }, () => {

    test.describe(`${endpoint.title}`, () => {

      test(`${endpoint.title}`, async ({historianUnauthorizedContext}) => {
        const api = new IngestionApiHelpers(historianUnauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })

    })

  })

  test.describe('401 Unauthorized. Token is expired', {
    tag: ['@status_code_401', '@negative'],
  }, () => {

    test.describe(`${endpoint.title}`, () => {

      test(`${endpoint.title}`, async ({historianExpiredTokenContext}) => {
        const api = new IngestionApiHelpers(historianExpiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })

    })

  })

  test.describe('404 Not found', {
    tag: ['@status_code_404', '@negative'],
  }, () => {
    
    const endpoint = historian.replay.byMessageName()

    test.describe(`${endpoint.title}`, () => {

      test(`Make request with random uuid value path parameter`, async () => {
        endpoint.pathParameters = uuid()
        const response = await api.makeRequest(endpoint)
        await api.responseIs404(response)
        await api.responseBodyIsEmpty(response)
      })
  
      test(`Make request without path parameter`, async () => {
        endpoint.pathParameters = undefined
        const response = await api.makeRequest(endpoint)
        await api.responseIs404(response)
        await api.responseBodyIsEmpty(response)
      })
  
      test(`Make request with several path parameters`, async () => {
        endpoint.pathParameters = [uuid(), uuid()]
        const response = await api.makeRequest(endpoint)
        await api.responseIs404(response)
        await api.responseBodyIsEmpty(response)
      })

    })

  })

  test.describe('405 Method is not allowed', {
    tag: ['@status_code_405', '@negative'],
  }, () => {

    test.describe(`${endpoint.title}`, () => {

      const httpMethodsArray : HttpMethod[] = [
        HttpMethod.POST,
        //HttpMethod.GET, // output is 403 status code
        HttpMethod.DELETE,
        HttpMethod.PATCH,
        HttpMethod.OPTIONS,
        //HttpMethod.HEAD // output is 403 status code
      ]

      for (const invalidMethod of httpMethodsArray) {
        test(`Using method: "${invalidMethod}" instead of: "${endpoint.method}"`, async () => {
          endpoint.method = invalidMethod
          const response = await api.makeRequest(endpoint)
          await api.responseIs405(response)
          await api.responseBodyIsEmpty(response)
        })
      }

    })

  })

  test.describe('500 Internal Server Error', {
    tag: ['@status_code_500', '@negative'],
  }, () => {

  })

})
import { faker } from '@faker-js/faker'
import {test} from '../../../../../ingestion/fixtures/ingestion-api-fixture'
import {Random} from '../../../../../utils/random'
import { expect } from '../../../../../utils/playwright-expect-extension'

test.describe('mock data tests. Demo of errors output', () => {

  test(`Success toContainArrayItems`, async () => {
    const date = new Date()
    const otherDate = faker.date.past()
    const arr = [
      {
        name: 'bob',
        age: 18,
        hobby: 'skateboard',
        obj: null,
        date: date,
        friends: ['kate', 'john'],
        relatives: [
          {type: 'mothe1r', name: 'mary', credentials: {username: 'mary1@asd.com', password: '123'}, friends: ['father', 'bob1']},
          {type: 'father', name: 'leonardo1', credentials: {username: 'leonardo1@asd.com', password: '123'}, friends: ['mother']}
        ]
      },
      {
        name: 'sean',
        age: 18,
        date: otherDate,
        //obj: undefined,
        //hobby: 'skateboard',
        friends: ['kate', 'john'],
        relatives: [
          {type: 'mother', name: 'mary', credentials: {username: 'mary11@asd.com', password: '123'}, friends: ['father', 'bob']},
          {type: 'father', name: 'leonardo', credentials: {username: 'leonardo1@asd.com', password: '123'}, friends: ['mother', 'bob']}
        ]
      }
    ]
    expect(arr).toContainArrayItems(arr, {distinctKey: 'name'})
  
  })

  test(`Success toFindItemByDistinctKey`, async () => {
    const arr = [
      {
        name: 'bob',
        age: 18,
      },
      {
        name: 'sean',
        age: 19
      }
    ]
    for (const expecteItem of arr) {
      expect.soft(arr).toFindItemByDistinctKey(expecteItem, {distinctKey: 'name'})
      expect.soft([{name: 'jack'}, {name: 'john'}]).not.toFindItemByDistinctKey(expecteItem, {distinctKey: 'name'})
    }
  
  })

  test(`Fail toFindItemByDistinctKey`, async () => {
    const expected = [
      {
        name: 'bob',
        age: 18
      },
      {
        name: 'sean',
        age: 19
      }
    ]

    const actual = [
      {
        name: 'bob',
        age: 18
      }
    ]
    for (const expecteItem of expected) {
      expect.soft(actual).toFindItemByDistinctKey(expecteItem, {distinctKey: 'name'})
    }
  
  })

  test(`Fail not toFindItemByDistinctKey`, async () => {
    const expected = [
      {
        //name: 'bob',
        age: 18
      },
      {
        name: 'sean',
        age: 19,
      }
    ]

    const actual = [
      {
        name: 'bob',
        age: 18
      },
      {
        name: 'sean',
        age: 19
      }
    ]
    for (const expecteItem of expected) {
      expect.soft(actual).not.toFindItemByDistinctKey(expecteItem, {distinctKey: 'name'})
    }
  
  })

  test(`Fail toContainArrayItems`, async () => {
    const date = new Date()
    const otherDate = faker.date.past()
    const expected = [
      {
        name: 'bob',
        age: 18,
        hobby: 'skateboard',
        obj: null,
        date: date,
        friends: ['kate', 'john'],
        relatives: [
          {type: 'mothe1r', name: 'mary', credentials: {username: 'mary1@asd.com', password: '123'}, friends: ['father', 'bob1']},
          {type: 'father', name: 'leonardo1', credentials: {username: 'leonardo1@asd.com', password: '123'}, friends: ['mother']}
        ]
      },
      {
        name: 'sean',
        age: 18,
        date: otherDate,
        //obj: undefined,
        //hobby: 'skateboard',
        friends: ['kate', 'john'],
        relatives: [
          {type: 'mother', name: 'mary', credentials: {username: 'mary11@asd.com', password: '123'}, friends: ['father', 'bob']},
          {type: 'father', name: 'leonardo', credentials: {username: 'leonardo1@asd.com', password: '123'}, friends: ['mother', 'bob']}
        ]
      },
      {
        name: 'john',
        friends: ['bob'],
        age: 20
      },
      {
        name: 'jack',
        age: 22
      },
      {
        age: 22
      },
    ]
    const actual = [
      {
        name: 'bob',
        age: 18,
        date: otherDate,
        //obj: undefined,
        //hobby: 'skateboard',
        friends: ['kate', 'john'],
        relatives: [
          {type: 'mother', name: 'mary', credentials: {username: 'mary11@asd.com', password: '123'}, friends: ['father', 'bob']},
          {type: 'father', name: 'leonardo', credentials: {username: 'leonardo1@asd.com', password: '123'}, friends: ['mother', 'bob']}
        ],
        id: ''
      },
      {
        name: 'sean',
        age: 18,
        date: otherDate,
        //obj: undefined,
        //hobby: 'skateboard',
        friends: ['kate', 'john'],
        relatives: [
          {type: 'mother', name: 'mary', credentials: {username: 'mary11@asd.com', password: '123'}, friends: ['father', 'bob']},
          {type: 'sister', name: 'ann', credentials: {username: 'ann@asd.com', password: '123'}, friends: ['mother', 'bob']},
          {type: 'father', name: 'leonardo', credentials: {username: 'leonardo1@asd.com', password: '123'}, friends: ['mother', 'bob']}
        ]
      },
      {
        name: 'john',
        friends: ['bob'],
        age: '20',
      },
      {
        name: 'kate',
        surname: 'iger'
      },
      {
        age: 22
      },
    ]
    expect(actual).toContainArrayItems(expected, {distinctKey: 'name', notNullKeys: ['id']})
  
  })

  test(`Fail toContainObject`, async () => {
    const date = new Date()
    const otherDate = faker.date.past()
    const expected = {
      name: 'bob',
      age: 18,
      hobby: 'skateboard',
      obj: null,
      date: date,
      friends: ['kate', 'john'],
      relatives: [
        {type: 'mothe1r', name: 'mary', credentials: {username: 'mary1@asd.com', password: '123'}, friends: ['father', 'bob1']},
        {type: 'father', name: 'leonardo1', credentials: {username: 'leonardo1@asd.com', password: '123'}, friends: ['mother']}
      ]
    }
    const actual = {
      name: 'bob',
      age: 18,
      date: otherDate,
      //obj: undefined,
      //hobby: 'skateboard',
      friends: ['kate', 'john'],
      relatives: [
        {type: 'mother', name: 'mary', credentials: {username: 'mary11@asd.com', password: '123'}, friends: ['father', 'bob']},
        {type: 'father', name: 'leonardo', credentials: {username: 'leonardo1@asd.com', password: '123'}, friends: ['mother', 'bob']}
      ],
      id: ''
    }
    expect(actual).toContainObject(expected)
  
  })

  test(`Success toContainObject`, async () => {
    const date = new Date()
    const obj = {
      name: 'bob',
      age: 18,
      hobby: 'skateboard',
      obj: null,
      date: date,
      friends: ['kate', 'john'],
      relatives: [
        {type: 'mothe1r', name: 'mary', credentials: {username: 'mary1@asd.com', password: '123'}, friends: ['father', 'bob1']},
        {type: 'father', name: 'leonardo1', credentials: {username: 'leonardo1@asd.com', password: '123'}, friends: ['mother']}
      ]
    }
    expect(obj).toContainObject(obj)
  
  })

  test(`Fail toHaveEqualObjectKeys`, async () => {
    const date = new Date()
    const otherDate = faker.date.past()
    const expected = {
      name: 'bob',
      age: 18,
      hobby: 'skateboard',
      obj: null,
      date: date,
      friends: ['kate', 'john'],
      relatives: [
        {type: 'mothe1r', name: 'mary', credentials: {username: 'mary1@asd.com', password: '123'}, friends: ['father', 'bob1']},
        {type: 'father', name: 'leonardo1', credentials: {username: 'leonardo1@asd.com', password: '123'}, friends: ['mother']}
      ]
    }
    const actual = {
      name: 'bob',
      age: 18,
      date: otherDate,
      //obj: undefined,
      //hobby: 'skateboard',
      friends: ['kate', 'john'],
      relatives: [
        {type: 'mother', name: 'mary', credentials: {username: 'mary11@asd.com', password: '123'}, friends: ['father', 'bob']},
        {type: 'father', name: 'leonardo', credentials: {username: 'leonardo1@asd.com', password: '123'}, friends: ['mother', 'bob']}
      ],
      id: ''
    }
    expect(actual).toHaveEqualObjectKeys(expected)
  
  })

  test(`Success toHaveEqualObjectKeys`, async () => {
    const date = new Date()
    const obj = {
      name: 'bob',
      age: 18,
      hobby: 'skateboard',
      obj: null,
      date: date,
      friends: ['kate', 'john'],
      relatives: [
        {type: 'mothe1r', name: 'mary', credentials: {username: 'mary1@asd.com', password: '123'}, friends: ['father', 'bob1']},
        {type: 'father', name: 'leonardo1', credentials: {username: 'leonardo1@asd.com', password: '123'}, friends: ['mother']}
      ]
    }
    expect(obj).toHaveEqualObjectKeys(obj)
  
  })

  test(`number generator test`, async () => {
    console.log(`Random int: ${Random.generateInt()}`)
    console.log(`Random int as string: ${Random.generateInt({returnType: 'string'})}`)
    console.log(`Random int max: ${Random.generateInt({testCase: 'max'})}`)
    console.log(`Random int min: ${Random.generateInt({testCase: 'min'})}`)
    console.log(`Random int max+1: ${Random.generateInt({testCase: 'max+1'})}`)
    console.log(`Random int min-1: ${Random.generateInt({testCase: 'min-1'})}`)
    console.log(`Random int 0-10: ${Random.generateInt({min: 0, max: 10})}`)
    console.log(`Random number 0-3: ${Random.generateTestNumber({min: 0, max: 3})}`)
    console.log(`Random int precision 15: ${Random.generateNumberByPrecision({precision: 15})}`)
    console.log(`Random int precision 20 max+1: ${Random.generateNumberByPrecision({precision: 20, testCase: 'max+1'})}`)
    console.log(`Random precision 20, scale 6: ${Random.generateNumberByPrecision({precision: 20, scale: 6})}`)
    console.log(`Random precision 16, scale 10: ${Random.generateNumberByPrecision({precision: 16, scale: 10})}`)
    console.log(`Random precision 16, scale 10 as a string: ${Random.generateNumberByPrecision({precision: 16, scale: 10, returnType: 'string'})}`)
    console.log(`Test case 0 precision 20, scale 6: ${Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: '0'})}`)
    console.log(`Test case 0 precision 16, scale 10: ${Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: '0'})}`)
    console.log(`Test case max precision 20, scale 6: ${Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: 'max'})}`)
    console.log(`Test case min precision 16, scale 10: ${Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: 'min'})}`)
    console.log(`Test case max-1 precision 20, scale 6: ${Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: 'min-1'})}`)
    console.log(`Test case max-1 precision 20, scale 6 as a string: ${Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: 'max+1', returnType: 'string'})}`)
    console.log(`Test case min+1 precision 16, scale 10: ${Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: 'max+1'})}`)
  })
})
  

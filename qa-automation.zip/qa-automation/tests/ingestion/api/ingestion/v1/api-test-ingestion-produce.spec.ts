import { test} from '../../../../../ingestion/fixtures/ingestion-api-fixture'
import {HttpMethod} from '../../../../../base/base-endpoint'
import {IngestionV1} from '../../../../../ingestion/api/ingestion/v1/endpoints/endpoints'
import {
  IngestionProduceErrors,
} from '../../../../../ingestion/api/ingestion/v1/types'
import {IngestionApiHelpers} from '../../../../../ingestion/api/api-helpers'
import {GeneralUtils, sleep} from '../../../../../utils/generalUtils'
import { IngestionApiEndpoint } from '../../../../../ingestion/api/ingestion/v1/types'
import {BaseMessage} from '../../../../../ingestion/api/ingestion/v1/endpoints/produce/base-message'
import { EmptyCase } from '../../../../../ingestion/api/ingestion/v1/types'
import {APIResponse} from '@playwright/test'
import { DateFormatters } from '../../../../../utils/date-farmatters'
import { faker } from '@faker-js/faker'

const ingestion = new IngestionV1()
let api: IngestionApiHelpers

test.beforeEach(`Preconditions. Create api helpers with valid request context`, async ({ingestionRequestContext}) => {
  api = new IngestionApiHelpers(ingestionRequestContext)
})

const produceEndpointMessages: BaseMessage[] = [
  ingestion.produce.organization,
  ingestion.produce.virtualAccount,
  ingestion.produce.sourceAccount,
  ingestion.produce.user,
  ingestion.produce.holdings,
  ingestion.produce.marketValue,
  ingestion.produce.fee,
  ingestion.produce.product,
  ingestion.produce.benefitLevel,
  ingestion.produce.flows,
  ingestion.produce.summaryPerformance,
  ingestion.produce.investmentManager,
  ingestion.produce.productFamily,
  ingestion.produce.workItem,
  ingestion.produce.userGroup,
  ingestion.produce.productPerformance,

  // Does not work. Return 500 status code. Not used in ingestion API yet:
  // ingestion.produce.realizedGainLoss,
  // ingestion.produce.transactions,
  // ingestion.produce.unrealizedGainLoss,
  // ingestion.produce.nonFinancialData,

  ingestion.produce.actionTarget,
  ingestion.produce.action,
  ingestion.produce.productChangeAction,
  ingestion.produce.riskCovarianceMatrix,
  ingestion.produce.productAvailability,
  ingestion.produce.performance,
  ingestion.produce.proposal,
  ingestion.produce.goal,
  ingestion.produce.contact
]

test.describe('Ingestion API V1 produce', {
  tag: ['@e2e', '@ingestion'],
}, () => {
  for (const message of produceEndpointMessages) {

    test.describe(`200 OK`, {
      tag: '@status_code_200',
    }, () => {

      const params = [
        {
          testTitle: 'All fields',
          endpoint: message.getEndpoint()
        },
        {
          testTitle: 'Query parameter republish=true',
          endpoint: message.getEndpoint(
            {
              queryParameters: {
                republish: true
              }
            }
          )
        }
      ]
      if(message.hasNullableFields) params.push(...[
        {
          testTitle: 'Only required fields. Not required fields are "null"',
          endpoint: message.getEndpoint({
            useAllFields: false,
            defineNullableFields: true,
            nestedItemsTestCase: {
              useAllFields: false,
              defineNullableFields: true,
            }
          })
        },
        {
          testTitle: 'Only required fields. Not required fields are "undefined"',
          endpoint: message.getEndpoint({
            useAllFields: false,
            defineNullableFields: false,
            nestedItemsTestCase: {
              useAllFields: false,
              defineNullableFields: false,
            }
          })
        }
      ])

      for (const param of params) {
        const endpoint = param.endpoint
        const dbInfo = endpoint.dbInfo
        if (dbInfo) {

          test.describe(`${endpoint.title}`, {
            tag: [`@${endpoint.title}`, ...dbInfo.map(item => '@db_' + item.dataBaseName)],
          }, () => {

            test.describe(`Insert new data in DB`, {
              tag: ['@new', '@positive'],
            }, () => {

              test(`${param.testTitle}`, async () => {
                const response = await api.makeRequest(endpoint)
                await api.responseIs200(response)
                await api.assertResponseBodySuccess(response)
                await api.enrichEndpointData(endpoint)
                await api.assertDataInDB(message, endpoint, dbInfo)
              })

            })

          })
        }
      }

    })

    const endpoint = message.getEndpoint({itemsCount: 1})
    const dbInfo = endpoint.dbInfo
    if (dbInfo) {

      test.describe(`200 OK`, {
        tag: '@status_code_200',
      }, () => {

        test.describe(`${endpoint.title}`, {
          tag: [`@${endpoint.title}`, ...dbInfo.map(item => '@db_' + item.dataBaseName)],
        }, () => {

          test.describe(`Update existing data in DB`, {
            tag: '@update',
          }, () => {

            test(`Success`, {
              tag: '@positive',
            }, async () => {
              let response: APIResponse
              await test.step(`Pass data to ingestion API`, async () => {

                response = await api.makeRequest(endpoint)
                await api.responseIs200(response)
                await api.assertResponseBodySuccess(response)
                /*
                    As of now update timestamp in DB has now mills
                    that's why if request was completed less than in a second next step is passing the "same" update timestamp.
                    To avoid false failures we have to wait 1 second to pass newer update timestamp in next step
                     */
                await sleep(1000)

              })

              await test.step(`Update payload and pass to ingestion API`, async () => {

                endpoint.body = message.updatePayloadData(endpoint)
                response = await api.makeRequest(endpoint)
                await api.responseIs200(response)
                await api.assertResponseBodySuccess(response)
                await api.enrichEndpointData(endpoint)
                await api.assertDataInDB(message, endpoint, dbInfo)
              })
            })

            test.describe(`Fail`, {
              tag: '@negative',
            }, () => {

              const params = [
                {
                  title: 'Older update timestamp',
                  updateTimestamp: DateFormatters.setMillsTo0(faker.date.past())
                },
                {
                  title: 'Same update timestamp',
                  updateTimestamp: endpoint.body[0].UpdateTimestamp
                }
              ]

              for (const param of params) {

                test(`${param.title}`, async () => {
                  let response: APIResponse

                  await test.step(`Pass data to ingestion API`, async () => {

                    response = await api.makeRequest(endpoint)
                    await api.responseIs200(response)
                    await api.assertResponseBodySuccess(response)

                  })

                  await test.step(`Update payload and pass to ingestion API`, async () => {

                    const updatedEndpoint = JSON.parse(JSON.stringify(endpoint))
                    updatedEndpoint.body = message.updatePayloadData(updatedEndpoint, param.updateTimestamp)
                    response = await api.makeRequest(updatedEndpoint)
                    await api.responseIs200(response)
                    await api.assertResponseBodySuccess(response)
                    await api.enrichEndpointData(endpoint)
                    await api.assertDataInDB(message, endpoint, dbInfo)
                  })
                })
              }
            })
          })

        })
      })

      test.describe(`207 Multi-Status`, {
        tag: ['@status_code_207', '@new', '@negative'],
      }, () => {

        test.describe(`${endpoint.title}`, {
          tag: [`@${endpoint.title}`, ...dbInfo.map(item => '@db_' + item.dataBaseName)],
        }, () => {

          //todo: when 207 status code feature will work better increase test coverage
          const invalidBodyEndpoint = message.emptyRequiredForIdGenerationFields(EmptyCase.UNDEFINED, 1)
          if (invalidBodyEndpoint){
            test(`2 items in body array: 1 valid and 1 invalid(required fields for ID generation are missing)`, async () => {
              invalidBodyEndpoint.body.push(...endpoint.body)
              const response = await api.makeRequest(invalidBodyEndpoint)
              await api.responseIs207(response)
              //todo: add 207 response body validation
              await api.enrichEndpointData(endpoint)
              await api.assertDataInDB(message, endpoint, dbInfo)
            })
          }

        })
      })
    }
  }
})

test.describe('Ingestion API V1 produce', {
  tag: ['@api', '@ingestion'],
}, () => {

  test.describe('200 OK', {
    tag: '@status_code_200',
  }, () => {
  })

  test.describe('400 Bad request', {
    tag: ['@status_code_400', '@negative'],
  }, () => {

    for (const message of produceEndpointMessages) {
      const endpoint = message.getEndpoint()
      test(`Invalid body. ${endpoint.title}`, async () => {
        const modifiedEndpoint : IngestionApiEndpoint = {...endpoint}
        modifiedEndpoint.body = `"${GeneralUtils.generateRandomAlphanumericString(15)}"`
        const response = await api.makeRequest(modifiedEndpoint)
        await api.responseIs400(response)
        await api.validateErrorResponse(response)
      })

      test(`Empty body. ${endpoint.title}`, async () => {
        const modifiedEndpoint : IngestionApiEndpoint = {...endpoint}
        modifiedEndpoint.body = ' '
        const response = await api.makeRequest(modifiedEndpoint)
        await api.responseIs400(response)
        const errors: IngestionProduceErrors = {
          $: [
            'The input does not contain any JSON tokens. Expected the input to start with a valid JSON token, when isFinalBlock is true. Path: $ | LineNumber: 0 | BytePositionInLine: 1.'
          ],
          data: [
            'The data field is required.'
          ]
        }
        await api.validateMultipleErrorsResponse(response, errors)
      })

      test(`null body. ${endpoint.title}`, async () => {
        const modifiedEndpoint : IngestionApiEndpoint = {...endpoint}
        modifiedEndpoint.body = null
        const response = await api.makeRequest(modifiedEndpoint)
        await api.responseIs400(response)
        const errors: IngestionProduceErrors = {
          '': [
            'A non-empty request body is required.'
          ],
          data: [
            'The data field is required.'
          ]
        }
        await api.validateMultipleErrorsResponse(response, errors)
      })
    }

  })

  test.describe('401 Unauthorized. No token passed', {
    tag: ['@status_code_401', '@negative'],
  }, () => {

    for (const message of produceEndpointMessages) {
      const endpoint = message.getEndpoint()
      test(`${endpoint.title}`, async ({ingestionUnauthorizedContext}) => {
        const api = new IngestionApiHelpers(ingestionUnauthorizedContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

  test.describe('401 Unauthorized. Token is expired', {
    tag: ['@status_code_401', '@negative'],
  }, () => {

    for (const message of produceEndpointMessages) {
      const endpoint = message.getEndpoint()
      test(`${endpoint.title}`, async ({ingestionExpiredTokenContext}) => {
        const api = new IngestionApiHelpers(ingestionExpiredTokenContext)
        const response = await api.makeRequest(endpoint)
        await api.responseIs401(response)
        await api.responseBodyIsEmpty(response)
      })
    }
  })

  test.describe('404 Not found', {
    tag: ['@status_code_404', '@negative'],
  }, () => {

    test(`Make request without {messagename} path param`, async () => {
      const endpoint = new IngestionV1().produce.sampleEndpoint(undefined, null)
      const response = await api.makeRequest(endpoint)
      await api.responseIs404(response)
      await api.responseBodyIsEmpty(response)
    })

    test(`Make request without several path params`, async () => {
      const endpoint = new IngestionV1().produce.sampleEndpoint(
        ['message_name', 'one_more_path_param']
        , null)
      const response = await api.makeRequest(endpoint)
      await api.responseIs404(response)
      await api.responseBodyIsEmpty(response)
    })

  })

  test.describe('405 Method is no allowed', {
    tag: ['@status_code_405', '@negative'],
  }, () => {
    const httpMethodsArray : HttpMethod[] = [
      HttpMethod.POST,
      //HttpMethod.GET, // output is 403 status code
      HttpMethod.DELETE,
      HttpMethod.PATCH,
      HttpMethod.OPTIONS,
      //HttpMethod.HEAD // output is 403 status code
    ]
    for (const httpMethod of httpMethodsArray) {
      test(`Make request using not allowed method: ${httpMethod}`, async () => {
        const endpoint = new IngestionV1().produce.sampleEndpoint('some_message', null)
        endpoint.method = httpMethod
        const response = await api.makeRequest(endpoint)
        await api.responseIs405(response)
        await api.responseBodyIsEmpty(response)
      })
    }

  })

  test.describe('500 Internal Server Error', {
    tag: ['@status_code_500', '@negative'],
  }, () => {
    for (const message of produceEndpointMessages) {

      for (const emptyCase of Object.values(EmptyCase)) {

        const endpoint = message.emptyRequiredForIdGenerationFields(emptyCase)

        if (endpoint){

          // As of now following messages are successfully passing to ingestion API(200 status code) when required fields are empty strings.
          // It causes some critical issues with Ingestion API.
          // That's why we need to ignore this test cases.
          //todo: remove after ingestion API will be ready
          const ignoreMessagesArray: BaseMessage[] = [
            ingestion.produce.userGroup,
            ingestion.produce.action,
            ingestion.produce.productChangeAction,
            ingestion.produce.riskCovarianceMatrix
          ]
          //skipping empty string tests for ignoreMessagesArray messages
          if (ignoreMessagesArray.some(item => item.pathParameters === message.pathParameters) && emptyCase===EmptyCase.EMPTY_STRING) continue
          //testing all other 500 status code tests
          test.describe(`${endpoint.title}`, () => {
            test(`Set required for ID generation fields as: "${emptyCase}"`, async () => {
              const response = await api.makeRequest(endpoint)
              await api.responseIs500(response)
              await api.validateErrorResponse(response, 'An error occurred while processing your request.')
            })
          })
        }
      }
    }
  })
})
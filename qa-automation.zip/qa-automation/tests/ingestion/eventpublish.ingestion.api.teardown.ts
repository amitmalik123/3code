
import { test as teardown } from '../../ingestion/fixtures/eventpublish-api-fixture'
import { EventPublisherApiHelpers } from '../../ingestion/api/eventpublish/api-helpers'
import {IngestionConfig} from '../../ingestion/service-data/config'
import { EventPublishV1 } from '../../ingestion/api/eventpublish/v1/endpoints'
import { Subscriber } from '../../ingestion/api/eventpublish/v1/types'

// Get specific test type env variable
const testType = process.env.TEST_TYPE
const teardownParams = [
  { 
    testType: 'api',
    subscriberName: IngestionConfig.API_TEST_ITEM_TAG,
  }, 
  {
    testType: 'e2e',
    subscriberName: IngestionConfig.E2E_TEST_ITEM_TAG,
  }
]
for (const param of teardownParams) {
  // If testType is not defined then teardown will go through all teardownParams
  // If testType is defined then teardown deletes only corresponding test data to avoid conflicts with other tests
  if (!testType || testType === param.testType) {
    teardown(`${param.subscriberName}. Delete eventpublish test subscribers`, {
      tag: ['@eventpublish', `@${param.testType}`] // BTW tags filtering is not working here. That's why we are using process.env.TEST_TYPE
    }, async ({ eventPublishRequestContext }) => {

      const eventPublish = new EventPublishV1()
      const api = new EventPublisherApiHelpers(eventPublishRequestContext)
      // Get all existing subscribers
      const response = await api.makeRequest(eventPublish.subscriptions.getSubscribers())

      if (response.status()===200){
        const responseBody: Subscriber[] = await response.json()
        // Setting up async delete task.
        const asyncTasks = responseBody.map(async subscriber => {
          // We should delete each subscriber that has param.subscriberName in the name
          if (subscriber.name.includes(param.subscriberName)){
            await api.makeRequest(eventPublish.subscriptions.deleteSubscriber(subscriber.id))
          }
        })
        // Execute tasks in async way
        await Promise.allSettled(asyncTasks)
      }
    
    })
  }
}

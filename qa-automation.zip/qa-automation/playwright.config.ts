import { defineConfig, devices } from '@playwright/test'
import { EWM3Config } from './ewm3/service-data/config'

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */

// eslint-disable-next-line @typescript-eslint/no-var-requires
require('dotenv').config({path: process.env.PLATFORM ? `.env.${process.env.PLATFORM}` : '.env.assetmark'})

/**
 * See https://playwright.dev/docs/test-configuration.
 */
export default defineConfig({
  timeout: 180000,
  expect: {
    timeout: 30000
  },
  testDir: './tests',
  /* Run tests in files in parallel */
  fullyParallel: true,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? 1 : 0,
  
  /* Opt out of parallel tests on CI. */
  workers: process.env.CI ? 4 : undefined,
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: [
    ['list',],
    [process.env.BLOB_REPORT ? 'blob':'html', { open: 'never' }],
    ['junit', {outputFile: 'test-results/e2e-junit-results.xml',}]
  ],
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    baseURL: EWM3Config.BASE_URL,
    /* Base URL to use in actions like `await page.goto('/')`. */
    // baseURL: 'http://127.0.0.1:3000',
    actionTimeout:30 * 1000,
    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    //trace: 'on-first-retry'
  },
  /* Configure projects for major browsers */
  projects: [
    { name: 'ewm3-ui-setup', testMatch: /.*\.ewm3.ui.setup\.ts/ },
    { name: 'ewm3-api-setup', testMatch: /.*\.ewm3.api.setup\.ts/ },
    { name: 'ingestion-api-setup', testMatch: /.*\.ingestion.api.setup\.ts/, teardown: 'ingestion-api-teardown' },
    { name: 'ingestion-api-teardown', testMatch: /.*\.ingestion.api.teardown\.ts/ },
    {
      name: 'ewm3-chromium',
      use: { ...devices['Desktop Chrome'],
        ignoreHTTPSErrors: true,
        // Use prepared auth state.
        //storageState: Config.authUIPath,
      },
      dependencies: ['ewm3-ui-setup'],
    },
    {
      name: 'ewm3-api',
      dependencies: ['ewm3-api-setup'],
    },
    {
      name: 'ingestion-api',
      dependencies: ['ingestion-api-setup'],
    },
    {
      name: 'ewm3-firefox',
      use: { ...devices['Desktop Firefox'],
        ignoreHTTPSErrors: true,
      },
      dependencies: ['ewm3-ui-setup'],
    },

    {
      name: 'ewm3-webkit',
      use: { ...devices['Desktop Safari'],
        ignoreHTTPSErrors: true,
      },
      dependencies: ['ewm3-ui-setup'],
    },

    /* Test against mobile viewports. */
    // {
    //   name: 'Mobile Chrome',
    //   use: { ...devices['Pixel 5'] },
    // },
    // {
    //   name: 'Mobile Safari',
    //   use: { ...devices['iPhone 12'] },
    // },

    /* Test against branded browsers. */
    // {
    //   name: 'Microsoft Edge',
    //   use: { ...devices['Desktop Edge'], channel: 'msedge' },
    // },
    // {
    //   name: 'Google Chrome',
    //   use: { ...devices['Desktop Chrome'], channel: 'chrome' },
    // },
  ],

  /* Run your local dev server before starting the tests */
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://127.0.0.1:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
})

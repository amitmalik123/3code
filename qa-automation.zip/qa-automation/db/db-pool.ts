import { Pool } from 'pg'
import { test } from '@playwright/test'
import { dbConfig } from './db-config'

export class DbPool extends Pool{

  constructor(private dbName: string = 'advisormetrics'){
    super(dbConfig(dbName))
  }

  async makeQuery(queryText: string){
    return await test.step(`I make '${this.dbName}' DB query`, async () => {
      await test.info().attach(`'${this.dbName}' DB QUERY`, {body: queryText})
      const result = await this.query(queryText)
      return await test.step(`I get '${this.dbName}' DB output`, async () => {
        await test.info().attach(`'${this.dbName}' DB OUTPUT`, {body: JSON.stringify(result.rows, null, 4)})
        return result.rows
      })
    })
  }

}


export const dbConfig = (dbName: string) => {
  return{
    user: process.env['SQLUSER'],
    password: process.env['SQLPASSWORD'],
    server: process.env[`sql${dbName}${(process.env.TARGET_ENV || 'dev').toLowerCase()}.database.windows.net`],
    port: 1433,
    database: dbName,
    connectionTimeout: 30 * 1000, //30s
    requestTimeout: 60 * 1000, //60s
    options: {
      trustServerCertificate: true,
      encrypt: true,
    }
  }
}
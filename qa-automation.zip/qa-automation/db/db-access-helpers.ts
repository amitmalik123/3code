import test from '@playwright/test'
import { DbPool } from './db-pool'

/**
 * Interface representing the information needed to access the database.
 */
export interface DbInfo {
  /**
   * The name of the database to connect to.
   */
  dataBaseName: string
  /**
   * The SQL query to execute on the database.
   * This property is optional.
   */
  query?: string
}

/**
 * Helper class for accessing and querying a database.
 */
export class DBAccessHelpers {

  /**
   * Executes a query on the specified database and returns the result.
   *
   * @param dbInfo - An object containing the database name and query.
   * @returns A promise that resolves to an array of results from the database.
   * @throws Will throw an error if the query is not provided.
   *
   * @example
   * ```typescript
   * const dbInfo: DbInfo = { dataBaseName: 'myDatabase', query: 'SELECT * FROM users' };
   * const results = await dbHelpers.getDataFromDB(dbInfo);
   * console.log(results);
   * ```
   */
  public async getDataFromDB(dbInfo: DbInfo): Promise<any[]>{
    return await test.step(`Get data from DB "${dbInfo.dataBaseName}"`, async () => {
      if(dbInfo.query){
        const db = new DbPool(dbInfo.dataBaseName)
        return await db.makeQuery(dbInfo.query)
      } else throw new Error(`Can't assert DB. Query body is not set. Please check the config of DB: "${dbInfo.dataBaseName}"; query: "${dbInfo.query}"`)
    })
  }
}
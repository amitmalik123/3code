export const dbConfig = (dbName: string) => {
  return{
    user: process.env['PGUSER'],
    host: process.env[`PGHOST_${(process.env.TARGET_ENV || 'dev').toUpperCase()}`],
    database: dbName,
    password: process.env['PGPASSWORD'],
    ssl: process.env.TARGET_ENV === 'local' ? false : {
      rejectUnauthorized: false,
    },
    port: 5432,
    query_timeout: 120 * 1000 //2 minutes
  }
}

export enum DbName  {
  accountdata = 'accountdata',
  advisormetrics = 'advisormetrics',
  advisorbenefits = 'advisorbenefits',
  auth = 'auth',
  contact = 'contact',
  feebilling = 'feebilling',
  goals = 'goals',
  historian = 'historian',
  ingestion = 'ingestion',
  investorportal = 'investorportal',
  organization = 'organization',
  product = 'product',
  proposal = 'proposal',
  worktracking = 'worktracking'

}
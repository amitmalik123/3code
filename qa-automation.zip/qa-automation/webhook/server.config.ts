// eslint-disable-next-line @typescript-eslint/no-var-requires
const os = require('os')
export function getIPv4Address(): string | null {
  const networkInterfaces = os.networkInterfaces()
  for (const interfaceName in networkInterfaces) {
    const addresses = networkInterfaces[interfaceName]
    if (addresses) {
      for (const addressInfo of addresses) {
        if (addressInfo.family === 'IPv4' && !addressInfo.internal) {
          return addressInfo.address
        }
      }
    }
  }
  return null // Return null if no IPv4 address is found
}

interface WebhookServerConfig {
  port: number;
  baseUrl: string;
}

function splitUrl(url: string): WebhookServerConfig {
  const urlPattern = /^(http:\/\/[^:]+):(\d+)$/
  const match = url.match(urlPattern)

  if (!match) {
    throw new Error('Invalid URL format')
  }

  const baseUrl = match[1]
  const port = parseInt(match[2], 10)

  return { baseUrl, port }
}

export const WEBHOOK_SERVER_URL = process.env.WEBHOOK_API_BASE_URL ?? `http://${getIPv4Address()}:3000`

export const webhookServerConfig = splitUrl(WEBHOOK_SERVER_URL)


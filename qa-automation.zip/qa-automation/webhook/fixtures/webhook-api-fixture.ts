import {type APIRequestContext, test as base, request} from '@playwright/test'
import {WEBHOOK_SERVER_URL} from '../server.config'
import { IngestionConfig } from '../../ingestion/service-data/config';

// Declare the types of your fixtures.
type MyFixtures = {
    webhookRequestContext: APIRequestContext
}

export const test = base.extend<MyFixtures>({

  webhookRequestContext: async ({ }, use) => {
    const context = await request.newContext({
      baseURL: WEBHOOK_SERVER_URL,
      timeout: IngestionConfig.API_RESPONSE_TIMEOUT,
      extraHTTPHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    })

    await use(context)
  },

})
export  *  from '@playwright/test'
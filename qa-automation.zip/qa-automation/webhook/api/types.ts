/* eslint-disable @typescript-eslint/no-explicit-any */
export type WebhookObject = { 
  id: string, 
  messages: WebhookMessage[]
}

export type WebhookMessage = {
  headers: {[key: string]: string | number | boolean }
  timestamp: string, 
  body: object | object[]
}

export type CreatedWebhookResponse = {
  message: string, 
  id: string
}

export type WebhookAuthResponseBody = {
  access_token: string,
  token_type: string,
  expires_in: number,
  refresh_token: string
}

export function isWebhookAuthResponseBody(responseBody: any): responseBody is WebhookAuthResponseBody {
  return (
    responseBody &&
    typeof responseBody === 'object' &&
    'access_token' in responseBody &&
    typeof responseBody.access_token === 'string' &&
    'token_type' in responseBody &&
    typeof responseBody.token_type === 'string' &&
    'expires_in' in responseBody &&
    typeof responseBody.expires_in === 'number' &&
    'refresh_token' in responseBody &&
    typeof responseBody.refresh_token === 'string'
  )
}

export type WebhookAuthAttempt = {
  timestamp: string,
  headers: {[key: string]: string | number | boolean }
  body: any,
  responseStatusCode: number,
  responseBody: WebhookAuthResponseBody | {error: string}
}

export type WebhookAuthAttemptsResponseBody = WebhookAuthAttempt[]
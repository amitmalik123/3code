import { BaseApiClass, BaseApiEndpoint, HttpMethod } from '../../base/base-endpoint'

export class Webhook extends BaseApiClass {
  constructor() {
    super(`/webhook`, 'webhook/api')
  }

  getWebhookArray(): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}`,
      title: `Get existing webhooks array`
    }
  }

  postNewWebhook(): BaseApiEndpoint{
    return {
      method: HttpMethod.POST,
      route: `${this.route}`,
      title: `Create new webhook`
    }
  }

  getWebhookDataById(pathParameters: string): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}`,
      pathParameters,
      title: `Get webhook data by id`
    }
  }

  postWebhookMessage(pathParameters: string, body: object | object[], queryParameters?: {status: number}): BaseApiEndpoint {
    return {
      method: HttpMethod.POST,
      route: `${this.route}`,
      pathParameters,
      queryParameters,
      body,
      title: `Post new webhook message`
    }
  }
  
}

export class WebhookAuth extends BaseApiClass {
  constructor() {
    super(`/oauth`, 'webhook/api')
  }

  getToken(formData: {grant_type?: 'client_credentials' | string, client_id?: string, client_secret?: string}): BaseApiEndpoint {
    return {
      method: HttpMethod.POST,
      route: `${this.route}/token`,
      extraHeaders: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      formData,
      title: `Get a dummy token`
    }
  }

  getAuthAttempts(){
    return {
      method: HttpMethod.GET,
      route: `${this.route}/attempts`,
      title: `Get auth attemps list`
    }
  }
  
}
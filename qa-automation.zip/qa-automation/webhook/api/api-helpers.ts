import { BaseApiHelpers } from '../../base/base-api-helpers'
import { Subscriber, SubscriptionMessageType } from '../../ingestion/api/eventpublish/v1/types'
import { IngestionApiEndpoint } from '../../ingestion/api/ingestion/v1/types'
import { IngestionConfig } from '../../ingestion/service-data/config'
import DataTransformUtils from '../../utils/data-transform'
import { executeWithRetry, sleep } from '../../utils/generalUtils'
import { expect, test } from '../../utils/playwright-expect-extension'
import { WebhookServerConstants } from '../constants'
import { Webhook } from './endpoints'
import { WebhookMessage, WebhookObject } from './types'

export enum WebhookTestCase {
  WEBHOOK_RECEIVED_MESSAGE = 'Webhook received message from event publsiher',
  WEBHOOK_NOT_RECEIVED_MESSAGE = 'Webhook did not receive message from event publsiher'
 // ...
}

export class WebhookApiHelpers extends BaseApiHelpers {

  private webhook = new Webhook()

  async assertWebhook(subcriber: Subscriber, eventsArray: {
    type: SubscriptionMessageType,
    webhookId: string,
    testCase: WebhookTestCase,
    ingestionEndpoint: IngestionApiEndpoint
  }[]){
    const asyncTasks = eventsArray.map(async event => {
      await test.step(`Assert: ${event.testCase}`, async () => {
        // Modify ingestion endpoint body to make it equal to eventpublisher output (replace or ignore some keys)
        const expectedWebhookMessageBody = await DataTransformUtils.modifyObjectArray(event.ingestionEndpoint.body, {
          keyReplacementRules: event.ingestionEndpoint.dbInfo[0].keyReplacementRules,
          removeKeys: event.ingestionEndpoint.dbInfo[0].ignoreKeys,
          removeMillsForDates: true
        })

        // Get distinct key from IngestionApiEndpoint first DBinfo object
        const distinctKey = event.ingestionEndpoint.dbInfo[0].distinctKey
        if(!distinctKey) throw new Error(`Distinct key is: "${distinctKey}". Check the ingestion message config`)
        const testParam = {
          type: event.type, 
          webhookId: event.webhookId,
          expectedWebhookMessageBody, 
          distinctKey
        }

        switch (event.testCase) {
        case WebhookTestCase.WEBHOOK_RECEIVED_MESSAGE:
          await this.assertWebhookReceivedMessage(subcriber, testParam)
          break

        case WebhookTestCase.WEBHOOK_NOT_RECEIVED_MESSAGE:
          await this.assertWebhookNotReceivedMessage(subcriber, testParam)
          break

        default:
          break
        }
      })
    })

    const results = await Promise.allSettled(asyncTasks)

    const errors = results
      .filter(result => result.status === 'rejected')
      .map(result => {
        const reason = (result as PromiseRejectedResult).reason
        return reason.message
      })

    if(errors.length > 0) throw new Error(errors.join('\n\n'))

  }

  private async validateWebhookMessageObject(subcriber: Subscriber, message: WebhookMessage){
    await test.step(`Validate webhook message object`, async () => {
  
      const defaultMessageHeaders = ['host', 'content-type', 'content-length']
      if (subcriber.authenticationType === 'OAuth20') {
        const token = message.headers.authorization.toString()
        expect.soft(token.startsWith(`${WebhookServerConstants.TOKEN_TYPE} ${WebhookServerConstants.ACCESS_TOKEN_PREFIX}`),
          `Expect that webhook received the token`
        ).toBeTruthy()
        defaultMessageHeaders.push('authorization')
        defaultMessageHeaders.push('accept')
      }
        
      const customHeadersKeysArray = Object.keys(subcriber.customHeaders)
      if(customHeadersKeysArray.length !== 0){
        expect.soft(message.headers, 
          `Expect webhook message headers to cointain all custom headers`
        ).toEqual(expect.objectContaining(subcriber.customHeaders))
        defaultMessageHeaders.push(...customHeadersKeysArray)
      }
      expect.soft(message.headers, `Assert webhook message header keys`).toHaveEqualObjectKeys(defaultMessageHeaders)
      expect(Array.isArray(message.body),
        `Expect the message body type to be an array`
      ).toBeTruthy()
    })
  }

  private async assertWebhookReceivedMessage(subcriber: Subscriber, event: { 
    type: SubscriptionMessageType,
    webhookId: string,
    expectedWebhookMessageBody: any[],
    distinctKey: string
  }){
    const subscription = subcriber.subscriptions.find(item => item.parameters.messageTypes.includes(event.type))

    if (subscription) {

      await executeWithRetry(async ()=>{
        // Delay before assert attempt
        await sleep((subscription.parameters.waitBeforeActionInSeconds * 1000) + IngestionConfig.WEBHOOK_DATA_RECEIVED_WAITING_TIME)
        // Get webhook messages
        const webhookResponse = await this.makeRequest(this.webhook.getWebhookDataById(event.webhookId))
        await this.responseIs200(webhookResponse)
        const webhookResponseBody: WebhookObject = await webhookResponse.json()
  
        expect(webhookResponseBody.messages.length,
          `Expect the messages array to not be empty`
        ).toBeGreaterThan(0)
  
        // Joining all webhook messages bodies in 1 array
        const actualJoinedAllMessagesBodies = await Promise.all(
          webhookResponseBody.messages.map(async message => {

            await this.validateWebhookMessageObject(subcriber, message)
            return message.body

          })
        ).then(results => results.flat())
  
        expect(actualJoinedAllMessagesBodies,
          `Expect that webhook has received all messages`
        ).toContainArrayItems(event.expectedWebhookMessageBody, {distinctKey: event.distinctKey})
  
      }, IngestionConfig.WEBHOOK_DATA_RECEIVED_RETRIES_COUNT)
      
    } else throw new Error(`There is no subscription connected to event: ${event.type}`)
    
  }

  private async assertWebhookNotReceivedMessage(subcriber: Subscriber, event: { 
    type: SubscriptionMessageType,
    webhookId: string,
    expectedWebhookMessageBody: any[],
    distinctKey: string
  }){
    // Delay before assert attempt
    await sleep(IngestionConfig.WEBHOOK_DATA_NOT_RECEIVED_WAITING_TIME)
    // Get webhook messages
    const webhookResponse = await this.makeRequest(this.webhook.getWebhookDataById(event.webhookId))
    await this.responseIs200(webhookResponse)
    const webhookResponseBody: WebhookObject = await webhookResponse.json()

    if(webhookResponseBody.messages.length > 0 ){
      
      // Joining all webhook messages bodies in 1 array
      const actualJoinedAllMessagesBodies = await Promise.all(
        webhookResponseBody.messages.map(async message => {
      
          await this.validateWebhookMessageObject(subcriber, message)
          return message.body
      
        })
      ).then(results => results.flat())
      await test.step(`Verify that the webhook messages array does not include any event data`, async () => {
        for (const expectedItem of event.expectedWebhookMessageBody) {
          expect.soft(actualJoinedAllMessagesBodies, 
            `Expecting not to find item by key: "${event.distinctKey}" and value: "${expectedItem[event.distinctKey]}" in webhook messages array`
          ).not.toFindItemByDistinctKey(expectedItem, {distinctKey: event.distinctKey})
        }
      })

    } else expect(webhookResponseBody.messages.length,
      `Expecting webhook messages array to be empty`
    ).toEqual(0)
    
  }
  
}
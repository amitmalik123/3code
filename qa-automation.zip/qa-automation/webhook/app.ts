/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-var-requires */
import { NextFunction, Request, Response } from 'express'
const express = require('express')
import {v4 as uuid} from 'uuid'
import { WebhookObject } from './api/types'
import { webhookServerConfig } from './server.config'
import { randomBytes } from 'crypto'
import { WebhookServerConstants } from './constants'

const app = express()
const port = webhookServerConfig.port // Choose a port for your server
    
// Middleware to parse JSON bodies
app.use(express.json())
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  if (err instanceof SyntaxError && 'body' in err) {
    return res.status(400).json({ error: 'Invalid JSON' })
  }
  next()
})

const webhookDataArray: WebhookObject[] = []

// Endpoint to create new webhook
app.post('/webhook', (req: Request, res: Response) => {
  const id = uuid()
  webhookDataArray.push({id, messages: []})
  // Respond with 201 Created and new webhook id
  res.status(201).json({message: 'Webhook is created', id}) 
})

// Endpoint to receive all webhooks and their messages
app.get('/webhook/', (req: Request, res: Response) => {
  if (webhookDataArray.length === 0){
    return res.sendStatus(204)
  }
  res.status(200).json(webhookDataArray) // Respond with 200 OK
})

// Endpoint to receive webhook by ID
app.get('/webhook/:id', (req: Request, res: Response) => {
  const { id } = req.params
  // Find the webhook by ID
  const webhook = webhookDataArray.find(w => w.id === id)

  if (!webhook) {
    return res.status(404).json({ error: 'Webhook not found' })
  }

  // Process the webhook data here as needed
  res.status(200).json(webhook)
})

// Endpoint to receive webhook messages
app.post('/webhook/:id', (req: Request, res: Response) => {
  const webhookData = req.body // Assuming webhook data is JSON
  const { id } = req.params
  const headers = JSON.parse(JSON.stringify(req.headers))
  const returnStatusCode = req.query.status? Number(req.query.status) : 200

  // Find the webhook by ID
  const webhook = webhookDataArray.find(w => w.id === id)

  if (!webhook) {
    return res.status(404).json({ error: 'Webhook not found' })
  }

  // Store the received message
  webhook.messages.push({headers, timestamp: new Date().toISOString(), body: webhookData})

  // Respond with 200 OK
  res.sendStatus(returnStatusCode) 
})

// Array of all auth attempts
const authAttempts: any[] = []

// Mock OAuth 2.0 token endpoint
app.post('/oauth/token', express.urlencoded({ extended: true }), (req: Request, res: Response) => {
  const originalReqBody = JSON.parse(JSON.stringify(req.body))
  function publishAuthAttempt(responseStatusCode: number, responseBody: any){
    authAttempts.push({
      timestamp: new Date().toISOString(), 
      headers: JSON.parse(JSON.stringify(req.headers)), 
      body: originalReqBody,
      responseStatusCode,  
      responseBody
    })
  }  

  const authHeader = req.headers.authorization

  if (authHeader && authHeader.startsWith('Basic ')) {
    const base64Credentials = authHeader.split(' ')[1]
    const credentials = Buffer.from(base64Credentials, 'base64').toString('ascii')
    const [client_id, client_secret] = credentials.split(':')

    req.body.client_id = client_id
    req.body.client_secret = client_secret
  }

  const { grant_type, client_id, client_secret } = req.body

  if (grant_type !== WebhookServerConstants.GRANT_TYPE) {
    const status = 400 
    const body = { error: 'unsupported_grant_type' }
    publishAuthAttempt(status, body)
    return res.status(status).json(body)
  }

  if (!client_id || !client_secret) {
    const status = 400 
    const body = { error: 'invalid_request' }
    publishAuthAttempt(status, body)
    return res.status(status).json(body)
  }

  // Validate client credentials
  if (client_id !== WebhookServerConstants.CLIENT_ID || client_secret !== WebhookServerConstants.CLIENT_SECRET) {
    const status = 401
    const body = { error: 'invalid_client' }
    publishAuthAttempt(status, body)
    return res.status(status).json(body)
  }

  // Generate a mock access token
  const accessToken = WebhookServerConstants.ACCESS_TOKEN_PREFIX + randomBytes(20).toString('hex')
  const refreshToken =  WebhookServerConstants.REFRESH_TOKEN_PREFIX + randomBytes(20).toString('hex')

  const body = {
    access_token: accessToken,
    token_type: WebhookServerConstants.TOKEN_TYPE,
    expires_in: WebhookServerConstants.TOKEN_EXPIRES_IN,
    refresh_token: refreshToken
  }
  publishAuthAttempt(200, body)
  // Respond with the token information
  res.json(body)
})

// Endpoint to receive all auth attempts
app.get('/oauth/attempts', (req: Request, res: Response) => {
  if (authAttempts.length === 0){
    return res.sendStatus(204)
  }
  res.status(200).json(authAttempts) // Respond with 200 OK
})

// Start the server
app.listen(port, () => {
  console.log(`Webhook server running at ${webhookServerConfig.baseUrl}:${port}`)
})
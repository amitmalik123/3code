export abstract class WebhookServerConstants{

  // Define valid client credentials
  static readonly GRANT_TYPE = 'client_credentials'
  static readonly CLIENT_ID = 'test_client_id'
  static readonly CLIENT_SECRET = 'test_client_secret'

  // Token settings
  static readonly TOKEN_TYPE = 'Bearer'
  static readonly TOKEN_EXPIRES_IN = 3600
  static readonly ACCESS_TOKEN_PREFIX = 'test_access_token_'
  static readonly REFRESH_TOKEN_PREFIX = 'test_refresh_token_'

  static readonly ACCESS_TOKEN_REGEX = /^test_access_token_[a-f0-9]{40}$/
  static readonly REFRESH_TOKEN_REGEX = /^test_refresh_token_[a-f0-9]{40}$/

}
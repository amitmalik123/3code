export default {
  testDir: 'e2e',
  reporter: [['html', { open: 'never' }]],
}
export class BicInvestmentsStrategyForBicIneligibilityMock {

  public static get data() {
    return {
      'data': [

        {
          'strategyId': '43B9BE6A-91E9-4C85-94F9-28BA3BFB456E-000D',
          'strategyAplId': 'JPMAR1',
          'items': [
            {
              'accountId': '288739DD-DEFD-4A92-8AE0-5A73E0816D8C-000D',
              'accountTitle': 'Bartt Grasso Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '4D698D076B08',
              'accountAplId': 'AN2GT1',
              'amountAllocated': 990.6985,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1KJT4',
              'parentClientAplId': 'CE97N0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': false,
          'name': 'JPMorgan Absolute Return - Profile 1',
          'totalAccounts': 1,
          'totalAssets': 990.6985,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': 'B20A3E13-7AB7-441B-B138-646336FF70D9-000D',
          'strategyAplId': 'AMFPR1',
          'items': [
            {
              'accountId': '32DCCCF6-3B99-4315-AD9A-5F3A865C98E8-000D',
              'accountTitle': 'Cartwright Siegel Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'BEE118EACF99',
              'accountAplId': 'AM3723',
              'amountAllocated': 523.4558,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1EN3M',
              'parentClientAplId': 'CE5QI6',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': false,
          'name': 'American Funds Preservation, Profile 1',
          'totalAccounts': 1,
          'totalAssets': 523.4558,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': 'E997095E-DF37-451D-96A8-147A2DB0A3D5-000D',
          'strategyAplId': 'NFETA3',
          'items': [
            {
              'accountId': '04B6C6BA-92D2-4853-BCD4-1A801F2E2E36-000D',
              'accountTitle': 'Nabil Pillsbury Trust',
              'advisorId': 'AGAOSX',
              'accountNumber': '505C59CE643A',
              'accountAplId': 'AM23E1',
              'amountAllocated': 411.7216,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W0YCT0',
              'parentClientAplId': 'CB4MO5',
              'accountType': 'MSA',
              'accountRegistrationType': 'Trust'
            }
          ],
          'isBicEligible': false,
          'name': 'New Frontier ETF, Profile 3, TS, Moderate',
          'totalAccounts': 1,
          'totalAssets': 411.7216,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': 'BE8A2A35-5FCB-4DC5-921F-1F544D295131-000D',
          'strategyAplId': 'SVSTLL',
          'items': [
            {
              'accountId': '53735268-2B60-4D62-A57F-254BB72CE07C-000D',
              'accountTitle': 'Nabil Pillsbury Roth IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'F490C302D6B6',
              'accountAplId': 'AM1VM3',
              'amountAllocated': 407.4203,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W0YCT0',
              'parentClientAplId': 'CB4MO5',
              'accountType': 'MSA',
              'accountRegistrationType': 'Roth IRA'
            }
          ],
          'isBicEligible': false,
          'name': 'Savos US Risk Controlled Strategy, Profile 6',
          'totalAccounts': 1,
          'totalAssets': 407.4203,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': 'B85067AF-FDFC-42C3-BD6D-0246190741C5-000D',
          'strategyAplId': 'NFESA2',
          'items': [
            {
              'accountId': '77222CEE-E842-440C-BC68-04A423093827-000D',
              'accountTitle': 'Magid Childs Beneficiary IRA Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': '91F1CE1B156C',
              'accountAplId': 'AL5Z83',
              'amountAllocated': 363.9643,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W0U04O',
              'parentClientAplId': 'CB2WD0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Beneficiary IRA Individual'
            }
          ],
          'isBicEligible': false,
          'name': 'New Frontier ETF, Profile 2, Moderate Conservative',
          'totalAccounts': 1,
          'totalAssets': 363.9643,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': '6B3F5263-8970-46E8-AD76-99FF88269406-000D',
          'strategyAplId': 'MKTBL2',
          'items': [
            {
              'accountId': 'A9097668-F787-44BC-8B0E-DD482340FC0E-000D',
              'accountTitle': 'Tarick McBirney Roth IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'E8CAC8F901BD',
              'accountAplId': 'AN5QT1',
              'amountAllocated': 335.3468,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1M09G',
              'parentClientAplId': 'CF0FQ0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Roth IRA'
            }
          ],
          'isBicEligible': false,
          'name': 'Global Market Blend, Profile 2, Moderate Conservative',
          'totalAccounts': 1,
          'totalAssets': 335.3468,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': 'FAE50241-A200-47A0-A5DD-C43DEA8970D6-000D',
          'strategyAplId': 'NFESA4',
          'items': [
            {
              'accountId': '346742BF-1BCE-4B7D-B83C-E3A5349C2A68-000D',
              'accountTitle': 'Keree Frierson Beneficiary IRA Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': 'CB9D562296B7',
              'accountAplId': 'AL6LQ3',
              'amountAllocated': 323.7483,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W0TLZ6',
              'parentClientAplId': 'CB2T75',
              'accountType': 'MSA',
              'accountRegistrationType': 'Beneficiary IRA Individual'
            }
          ],
          'isBicEligible': false,
          'name': 'New Frontier ETF, Profile 4, Moderate Growth',
          'totalAccounts': 1,
          'totalAssets': 323.7483,
          'currentAllocation': 0.0001
        }
      ],
      'error': {
        'message': '',
        'code': 200
      },
      'lastUpdate': {
        'value': '2024-05-24T00:00:00+00:00',
        'kind': 'CalendarDate'
      }
    }
  }
}
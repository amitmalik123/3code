export class FewAccountsMock {

  public static get data() {
    return {
      'data': {
        'data': [
          {
            'id': '69D589D2-870D-48D3-90E3-4E787F234C76-000D',
            'title': 'Brian & Naomi Wittlin, Joint Tenants with Rights of Survivorship',
            'applicationId': 'AI7W63',
            'alerts': [
              'Restricted Securities'
            ],
            'advisorIdentifier': 'AGAT58',
            'clientId': '64528C25-2C96-4155-ABCE-0CEAA300B151-000D',
            'clientName': 'Wittlin, Brian & Naomi S',
            'clientAplId': 'CA48Z7',
            'clientWebId': 'W0IT4H',
            'marketValue': 620433.2700,
            'expectedAmount': 445000.000000,
            'inceptionDate': '2017-04-27',
            'ytdPerformance': 0.0995000000,
            'oneYearPerformance': 0.1487000000,
            'threeYearPerformance': 0.0431000000,
            'fiveYearPerformance': 0.0812000000,
            'cumulativeReturn': 0.6378011097597646941154308226,
            'annualizedPerformance': 0.0705000000,
            'bankAccountNumber': '13012644',
            'status': 'Active',
            'investmentProduct': 'Clark Navigator Personalized UMA, Profile 5, Growth',
            'registrationType': 'Joint Tenant with Rights of Survivorship',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'netInvestment': 355000.000000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '191850B6-4F06-452C-9725-D010B85D1542-000D',
            'title': 'Brian & Naomi Wittlin, Joint Tenants with Rights of Survivorship',
            'applicationId': 'AI7W61',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': '64528C25-2C96-4155-ABCE-0CEAA300B151-000D',
            'clientName': 'Wittlin, Brian & Naomi S',
            'clientAplId': 'CA48Z7',
            'clientWebId': 'W0IT4H',
            'marketValue': 175539.2300,
            'expectedAmount': 255000.000000,
            'inceptionDate': '2017-04-27',
            'ytdPerformance': -0.0116000000,
            'oneYearPerformance': 0.0102000000,
            'threeYearPerformance': -0.0216000000,
            'fiveYearPerformance': -0.0020000000,
            'cumulativeReturn': 0.0510576168793789617773772785,
            'annualizedPerformance': 0.0069000000,
            'bankAccountNumber': '13012642',
            'status': 'Active',
            'investmentProduct': 'Clark Navigator Tax-Free Fixed Income',
            'registrationType': 'Joint Tenant with Rights of Survivorship',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'netInvestment': 165000.000000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': 'B53021EE-A44C-4149-A09B-0463881A0758-000D',
            'title': 'Dawn E Kleinman, Individual',
            'applicationId': 'AK4410',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': 'C37E939B-C238-40DC-9906-7A6A5EC69061-000D',
            'clientName': 'Kleinman, Dawn',
            'clientAplId': 'CD7R61',
            'clientWebId': 'W12XJO',
            'marketValue': 0.0,
            'expectedAmount': 394476.000000,
            'inceptionDate': '2020-02-26',
            'bankAccountNumber': 'BKU543117',
            'status': 'Terminated',
            'investmentProduct': 'New Frontier ETF, Profile 4, TS, Moderate Growth',
            'registrationType': 'Individual',
            'approach': '',
            'custodian': 'Pershing Advisor Solutions',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '40F4375E-F6BE-4E3B-BBFB-88ED3DC250AE-000D',
            'title': 'Dawn E Kleinman, Individual',
            'applicationId': 'AK4411',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': 'C37E939B-C238-40DC-9906-7A6A5EC69061-000D',
            'clientName': 'Kleinman, Dawn',
            'clientAplId': 'CD7R61',
            'clientWebId': 'W12XJO',
            'marketValue': 0.0,
            'expectedAmount': 386502.000000,
            'inceptionDate': '2020-02-26',
            'bankAccountNumber': 'BKU543125',
            'status': 'Terminated',
            'investmentProduct': 'SSGA, Profile 4, Tax-Sensitive, Moderate Growth',
            'registrationType': 'Individual',
            'approach': '',
            'custodian': 'Pershing Advisor Solutions',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '09EED91E-1EA9-4C66-A1FC-CC8180F7F711-000D',
            'title': 'Tracy G Lallier Successor Beneficiary, Beneficiary IRA',
            'applicationId': 'AN1825',
            'alerts': [],
            'advisorIdentifier': 'AGAT5R',
            'clientId': 'E1F7BB95-3214-4CE2-950E-E23059E444E8-000D',
            'clientName': 'Lallier, Tracy',
            'clientAplId': 'CE8RI0',
            'clientWebId': 'W1JIZP',
            'marketValue': 0.0,
            'expectedAmount': 84442.000000,
            'inceptionDate': '2023-08-04',
            'ytdPerformance': 0.0000000000,
            'oneYearPerformance': 0.0000000000,
            'threeYearPerformance': 0.0000000000,
            'fiveYearPerformance': 0.0000000000,
            'cumulativeReturn': 0.0,
            'annualizedPerformance': 0.0000000000,
            'bankAccountNumber': '40205165',
            'status': 'Terminated',
            'investmentProduct': 'Global Market Blend, Profile 3, Moderate',
            'registrationType': 'Beneficiary IRA Individual',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'netInvestment': -7341.580000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          }
        ],
        'start': 0,
        'limit': 447,
        'total': 447
      },
      'error': {
        'message': '',
        'code': 200
      },
      'lastUpdate': {
        'value': '2024-07-24T00:00:00+00:00',
        'kind': 'CalendarDate'
      }

    }
  }
}
export class AdvisorBenefitsMock {

  public static get emergingPremierStatus() {
    return {
      'data': {
        'qualifyingAssets': 3500000.0000,
        'level': 'Emerging Premier',
        'grossContributionsMTD': 58000.0000,
        'grossContributionsQTD': 128000.0000,
        'grossContributionsYTD': 1200000.0000,
        'asOfDate': '10/01/2023',
        'benefitStatusEffectiveDate': '10/01/2023',
        'benefitStatusAccommodation': 'Accommodation Granted',
        'serviceTier': 'Premier Elite Team'
      },
      'error': {
        'message': '',
        'code': 200
      }
    }
  }

  public static get premierStatus() {
    return {
      'data': {
        'qualifyingAssets': 17600000.0000,
        'level': 'Premier',
        'grossContributionsMTD': 905388.2100,
        'grossContributionsQTD': 2533526.0300,
        'grossContributionsYTD': 5284229.2500,
        'asOfDate': '10/01/2023',
        'benefitStatusEffectiveDate': '10/01/2023',
        'benefitStatusAccommodation': 'Accommodation Granted',
        'serviceTier': 'Advisor Service Team'
      },
      'error': {
        'message': '',
        'code': 200
      }
    }
  }

  public static get premierEliteStatus() {
    return {
      'data': {
        'qualifyingAssets': 25000000.0000,
        'level': 'Premier Elite',
        'grossContributionsMTD': 1252258.3300,
        'grossContributionsQTD': 3529430.4500,
        'grossContributionsYTD': 6388205.3100,
        'asOfDate': '10/01/2023',
        'benefitStatusEffectiveDate': '10/01/2023',
        'benefitStatusAccommodation': 'Accommodation Granted',
        'serviceTier': 'Gold Team'
      },
      'error': {
        'message': '',
        'code': 200
      }
    }
  }

  public static get goldStatus() {
    return {
      'data': {
        'qualifyingAssets': 48200000.0000,
        'level': 'Gold',
        'grossContributionsMTD': 3255382.8600,
        'grossContributionsQTD': 5426439.4200,
        'grossContributionsYTD': 9284523.2200,
        'asOfDate': '10/01/2023',
        'benefitStatusEffectiveDate': '10/01/2023',
        'benefitStatusAccommodation': 'Accommodation Granted',
        'serviceTier': 'Platinum Team'
      },
      'error': {
        'message': '',
        'code': 200
      }
    }
  }

  public static get platinumStatus() {
    return {
      'data': {
        'qualifyingAssets': 120200000.0000,
        'level': 'Platinum',
        'grossContributionsMTD': 3255382.8600,
        'grossContributionsQTD': 5426439.4200,
        'grossContributionsYTD': 9284523.2200,
        'asOfDate': '10/01/2023',
        'benefitStatusEffectiveDate': '10/01/2023',
        'benefitStatusAccommodation': 'Accommodation Granted',
        'serviceTier': 'Platinum Team'
      },
      'error': {
        'message': '',
        'code': 200
      }
    }

  }

  public static get platinumEliteStatus() {
    return {
      'data': {
        'qualifyingAssets': 250200000.0000,
        'level': 'Platinum Elite',
        'grossContributionsMTD': 3255382.8600,
        'grossContributionsQTD': 5426439.4200,
        'grossContributionsYTD': 9284523.2200,
        'asOfDate': '10/01/2023',
        'benefitStatusEffectiveDate': '10/01/2023',
        'benefitStatusAccommodation': 'Accommodation Granted',
        'serviceTier': 'Platinum Team'
      },
      'error': {
        'message': '',
        'code': 200
      }
    }

  }

}
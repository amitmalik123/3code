export class LongClientsMock {

  public static get data() {
    return {
      data: {
        data: [
          {
            clientName: 'Hartman, Jeff',
            advisorIdentifier: 'AGAT5R',
            numberOfAccounts: 2,
            marketValue: 333375.73,
            expectedAmount: 75000.0,
            establishedDate: '2018-06-26',
            ytdPerformance: 0.0723,
            oneYearPerformance: 0.116,
            threeYearPerformance: 0.0194,
            fiveYearPerformance: 0.0619,
            cumulativeReturn: 25.763893187326858,
            annualizedPerformance: 0.0621,
            netInvestment: 243125.01,
            assetAllocations: [
              {
                assetClass: 'Equity',
                allocationWeight: 0.2
              },
              {
                assetClass: 'FixedIncome',
                allocationWeight: 0.2
              },
              {
                assetClass: 'AlternativeInvestments',
                allocationWeight: 0.2
              },
              {
                assetClass: 'Cash',
                allocationWeight: 0.2
              },
              {
                assetClass: 'CashAlternatives',
                allocationWeight: 0.2
              }
            ],
            webAccess: false,
            id: '029FE02B-7DED-4F43-B1B0-A7E4EB9FCD44-000D',
            clientAplId: 'CB2IR3',
            clientWebId: 'W0W671',
            accounts: [
              {
                id: '0C41536E-7B2D-49A6-8746-2232AD721916-000D',
                title: 'Jeffrey K Hartman, Traditional IRA',
                applicationId: 'AJ4815',
                alerts: [],
                marketValue: 333375.73,
                expectedAmount: 75000.0,
                inceptionDate: '2018-06-26',
                ytdPerformance: 0.0723,
                oneYearPerformance: 0.116,
                threeYearPerformance: 0.02,
                fiveYearPerformance: 0.0623,
                cumulativeReturn: 0.4453077824935424,
                annualizedPerformance: 0.0625,
                bankAccountNumber: '13594548',
                status: 'Active',
                investmentProduct: 'American Funds Moderate Growth and Income, Profile 3',
                assetAllocations: [
                  {
                    assetClass: 'Equity',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'FixedIncome',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'AlternativeInvestments',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'Cash',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'CashAlternatives',
                    allocationWeight: 0.2
                  }
                ]
              },
              {
                id: 'A4626038-D491-415F-A4EC-F406AC3D4DFD-000D',
                title: 'Stefanie P Hartman, Traditional IRA',
                applicationId: 'AJ47X2',
                alerts: [],
                marketValue: 0.0,
                expectedAmount: 105000.0,
                inceptionDate: '2018-06-26',
                bankAccountNumber: '13594554',
                status: 'Terminated',
                investmentProduct: 'American Funds Moderate Growth and Income, Profile 3',
                assetAllocations: [
                  {
                    assetClass: 'Equity',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'FixedIncome',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'AlternativeInvestments',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'Cash',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'CashAlternatives',
                    allocationWeight: 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Cearley, Gregory',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 2,
            'marketValue': 0.0,
            'expectedAmount': 0.0,
            'establishedDate': '2009-07-10',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.0
              }
            ],
            'webAccess': true,
            'id': 'B2B28CC6-1F44-4979-B8DF-DEAD537F1FCB-000D',
            'clientAplId': 'C65605',
            'clientWebId': 'W08OEI',
            'accounts': [
              {
                'id': '7C396935-5FEF-40E9-93CF-BC78C647A8B0-000D',
                'title': 'Gregory Cearley, Rollover IRA',
                'applicationId': 'AB85Q5',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 50000.000000,
                'inceptionDate': '2009-07-10',
                'bankAccountNumber': '11873017',
                'status': 'Terminated',
                'investmentProduct': 'Savos Preservation Strategy',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'D1BAA4B7-DF6C-46AD-8E5F-2E8C811DB87D-000D',
                'title': 'Gregory Cearley, Rollover IRA',
                'applicationId': 'AB85Q6',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 220000.000000,
                'inceptionDate': '2009-07-10',
                'bankAccountNumber': '11873018',
                'status': 'Terminated',
                'investmentProduct': 'Global Market Blend, Profile 5, Growth',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Basra, Sarpreet',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 3,
            'marketValue': 0.0,
            'expectedAmount': 0.0,
            'establishedDate': '2018-01-29',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.0
              }
            ],
            'webAccess': false,
            'id': 'BA563AC7-3CBB-4F57-8A12-B6E0F487254F-000D',
            'clientAplId': 'CB1AQ6',
            'clientWebId': 'W0UHEU',
            'accounts': [
              {
                'id': 'F6333407-10B1-45FB-A15B-74C1A0249201-000D',
                'title': 'Sarpreet & Gurjot Basra, JT WROS',
                'applicationId': 'AJ1KW4',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 200000.000000,
                'inceptionDate': '2018-02-01',
                'bankAccountNumber': '13547842',
                'status': 'Terminated',
                'investmentProduct': 'New Frontier ETF, Profile 6, TS, Maximum Growth',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'C2BD1533-1689-4D7F-9E2E-E4236A95D701-000D',
                'title': 'Sarpreet & Gurjot Basra, JT WROS',
                'applicationId': 'AJ1KW3',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 500000.000000,
                'inceptionDate': '2018-01-29',
                'bankAccountNumber': '13547840',
                'status': 'Terminated',
                'investmentProduct': 'Clark Navigator Tax-Free Fixed Income',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'EBB531BD-E4C7-4300-94BC-B3FDE88493AC-000D',
                'title': 'Sarpreet & Gurjot Basra, JT WROS',
                'applicationId': 'AJ1KW5',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 0.000000,
                'inceptionDate': '2018-01-29',
                'bankAccountNumber': '13014730',
                'status': 'Terminated',
                'investmentProduct': 'Dollar Cost Average Cash Account',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Weir, Scott D',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 1,
            'marketValue': 0.0,
            'expectedAmount': 0.0,
            'establishedDate': '2012-07-31',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.0
              }
            ],
            'webAccess': false,
            'id': 'C1C8969E-8860-478C-AF26-1E60EB59185D-000D',
            'clientAplId': 'CA2DR0',
            'clientWebId': 'W0FS98',
            'accounts': [
              {
                'id': 'EF185ED6-CEDE-49E7-898E-4425659E62CD-000D',
                'title': 'Scott D Weir, Rollover IRA',
                'applicationId': 'AH07N8',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 187000.000000,
                'inceptionDate': '2012-07-31',
                'bankAccountNumber': '13132802',
                'status': 'Terminated',
                'investmentProduct': 'SSGA, Profile 4, Moderate Growth',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Covington, Frances',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 6,
            'marketValue': 0.0,
            'expectedAmount': 0.0,
            'establishedDate': '2003-01-31',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.0
              }
            ],
            'webAccess': false,
            'id': 'CB371670-8A2F-48A2-AB7F-A8823FB207F6-000D',
            'clientAplId': 'C02029',
            'clientWebId': 'W02M45',
            'accounts': [
              {
                'id': 'E8E6BBBF-8EFB-4BB8-AAEE-97C484D35000-000D',
                'title': 'Frances Covington, Trust',
                'applicationId': 'AJ2DG9',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 109569.000000,
                'inceptionDate': '2018-03-08',
                'bankAccountNumber': '40179891',
                'status': 'Terminated',
                'investmentProduct': 'New Frontier ETF, Profile 3, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '998C2A70-2D02-4267-922D-F16F76720296-000D',
                'title': 'Frances Covington, Trust',
                'applicationId': 'AJ2DG8',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 260516.000000,
                'inceptionDate': '2018-03-08',
                'bankAccountNumber': '40179890',
                'status': 'Terminated',
                'investmentProduct': 'American Funds Moderate Growth and Income, Profile 3',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'F8473616-6C32-4A55-9827-F0597CFF0455-000D',
                'title': 'Frances Covington  Rollover IRA',
                'applicationId': 'A36973',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 58000.000000,
                'inceptionDate': '2003-01-31',
                'bankAccountNumber': '960912665',
                'status': 'Terminated',
                'investmentProduct': 'American Funds Moderate Growth and Income, Profile 3',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'DE7DD614-862C-48CF-A519-EB507C289601-000D',
                'title': 'Frances Covington, Individual',
                'applicationId': 'AB1AJ3',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 132000.000000,
                'inceptionDate': '2008-09-18',
                'bankAccountNumber': '960039497',
                'status': 'Terminated',
                'investmentProduct': 'Litman Gregory, Profile 3, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '6906FE06-0F0C-4936-B267-FAAF1EFFE777-000D',
                'title': 'Frances Covington, Trust',
                'applicationId': 'AJ9HR4',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 75000.000000,
                'inceptionDate': '2019-05-30',
                'bankAccountNumber': '40179892',
                'status': 'Terminated',
                'investmentProduct': 'BlackRock, Risk Focused Income, Profile 1, Conservative',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '6610F731-490B-4578-87FD-42FBF1157FC7-000D',
                'title': 'Frances Covington Individual',
                'applicationId': 'AB1AJ4',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 132000.000000,
                'inceptionDate': '2008-09-18',
                'bankAccountNumber': '960039501',
                'status': 'Terminated',
                'investmentProduct': 'New Frontier ETF, Profile 3, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Mobley, Janet',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 8,
            'marketValue': 979952.1400,
            'expectedAmount': 660000.000000,
            'establishedDate': '2016-08-09',
            'ytdPerformance': 0.0590000000,
            'oneYearPerformance': 0.1135000000,
            'threeYearPerformance': 0.0175000000,
            'fiveYearPerformance': 0.0436000000,
            'cumulativeReturn': 10.451929840419189850575037053,
            'annualizedPerformance': 0.0457000000,
            'netInvestment': 697679.690000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ],
            'webAccess': true,
            'id': 'CC11B0BC-C1CC-414B-A53D-CA99A7DDC775-000D',
            'clientAplId': 'CA8575',
            'clientWebId': 'W0PM1Y',
            'accounts': [
              {
                'id': '07BCB8FD-8CC6-41F7-A833-E3EFAC08230C-000D',
                'title': 'Janet Mobley, Individual TOD',
                'applicationId': 'AL0UT2',
                'alerts': [],
                'marketValue': 63119.5700,
                'expectedAmount': 60000.000000,
                'inceptionDate': '2021-02-17',
                'ytdPerformance': 0.0293000000,
                'oneYearPerformance': 0.0443000000,
                'threeYearPerformance': -0.0122000000,
                'fiveYearPerformance': 0.0000000000,
                'cumulativeReturn': -0.0385701826912108674063095752,
                'annualizedPerformance': -0.0114000000,
                'bankAccountNumber': '13891403',
                'status': 'Active',
                'investmentProduct': 'Custodial Sweep',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'AFF1F16E-229D-4397-B24E-562ECC87F1B9-000D',
                'title': 'Janet Mobley, Traditional IRA',
                'applicationId': 'AI4D41',
                'alerts': [],
                'marketValue': 58244.7300,
                'expectedAmount': 100000.000000,
                'inceptionDate': '2016-08-09',
                'ytdPerformance': 0.0280000000,
                'oneYearPerformance': 0.0513000000,
                'threeYearPerformance': -0.0151000000,
                'fiveYearPerformance': 0.0188000000,
                'cumulativeReturn': 0.209554726518434669979191316,
                'annualizedPerformance': 0.0242000000,
                'bankAccountNumber': '13402031',
                'status': 'Active',
                'investmentProduct': 'Clark Navigator Fixed Income Total Return',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'F1D6A3D1-66CC-439A-B688-346BEDD15EB5-000D',
                'title': 'Kermit Mobley, Traditional IRA',
                'applicationId': 'AI4D38',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 285500.000000,
                'inceptionDate': '2016-08-15',
                'bankAccountNumber': '13400370',
                'status': 'Terminated',
                'investmentProduct': 'American Funds Moderate Growth and Income, Profile 3',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '866FE91E-3606-4074-88F6-F8DDDD659003-000D',
                'title': 'Janet Mobley, Traditional IRA',
                'applicationId': 'AI4D39',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 80000.000000,
                'inceptionDate': '2016-08-09',
                'bankAccountNumber': '13400371',
                'status': 'Terminated',
                'investmentProduct': 'JPMorgan, Profile 1, Conservative',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'D6DB8D71-E285-43E8-86D0-603860892B4F-000D',
                'title': 'Janet Mobley, Traditional IRA',
                'applicationId': 'AI4GD7',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 0.000000,
                'inceptionDate': '2016-08-09',
                'bankAccountNumber': '13010748',
                'status': 'Terminated',
                'investmentProduct': 'Dollar Cost Average Cash Account',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '1793F13A-F06B-4AB8-94B6-63F55B9611A8-000D',
                'title': 'Janet Mobley, Individual TOD',
                'applicationId': 'AL0UT3',
                'alerts': [],
                'marketValue': 144172.8600,
                'expectedAmount': 200000.000000,
                'inceptionDate': '2021-02-17',
                'ytdPerformance': 0.0671000000,
                'oneYearPerformance': 0.1285000000,
                'threeYearPerformance': 0.0217000000,
                'fiveYearPerformance': 0.0000000000,
                'cumulativeReturn': 0.1196797812688171252346015976,
                'annualizedPerformance': 0.0335000000,
                'bankAccountNumber': '13891404',
                'status': 'Active',
                'investmentProduct': 'US Market Blend, Profile 3, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'F9F2E10A-94D1-4E8A-B36F-689BF2E616B0-000D',
                'title': 'Janet Mobley, Traditional IRA',
                'applicationId': 'AI4D40',
                'alerts': [],
                'marketValue': 714414.9800,
                'expectedAmount': 300000.000000,
                'inceptionDate': '2016-08-15',
                'ytdPerformance': 0.0599000000,
                'oneYearPerformance': 0.1178000000,
                'threeYearPerformance': 0.0199000000,
                'fiveYearPerformance': 0.0452000000,
                'cumulativeReturn': 0.4742498858142128343637459514,
                'annualizedPerformance': 0.0501000000,
                'bankAccountNumber': '13400373',
                'status': 'Active',
                'investmentProduct': 'American Funds Moderate Growth and Income, Profile 3',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'B21600D6-64D2-4B7D-A222-19958E63F5EB-000D',
                'title': 'Kermit Mobley, Traditional IRA',
                'applicationId': 'AI4D37',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 30000.000000,
                'inceptionDate': '2016-08-18',
                'bankAccountNumber': '13400369',
                'status': 'Terminated',
                'investmentProduct': 'Clark Navigator Fixed Income Total Return',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Lallier, Tracy',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 1,
            'marketValue': 0.0,
            'expectedAmount': 0.0,
            'establishedDate': '2023-08-04',
            'ytdPerformance': 0.0000000000,
            'oneYearPerformance': 0.0000000000,
            'threeYearPerformance': 0.0000000000,
            'fiveYearPerformance': 0.0000000000,
            'cumulativeReturn': 0.0000000000000000000000000000,
            'annualizedPerformance': 0.0000000000,
            'netInvestment': -7228.810000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.0
              }
            ],
            'webAccess': false,
            'id': 'E1F7BB95-3214-4CE2-950E-E23059E444E8-000D',
            'clientAplId': 'CE8RI0',
            'clientWebId': 'W1JIZP',
            'accounts': [
              {
                'id': '09EED91E-1EA9-4C66-A1FC-CC8180F7F711-000D',
                'title': 'Tracy G Lallier Successor Beneficiary, Beneficiary IRA',
                'applicationId': 'AN1825',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 84442.000000,
                'inceptionDate': '2023-08-04',
                'ytdPerformance': 0.0000000000,
                'oneYearPerformance': 0.0000000000,
                'threeYearPerformance': 0.0000000000,
                'fiveYearPerformance': 0.0000000000,
                'cumulativeReturn': 0.0,
                'annualizedPerformance': 0.0000000000,
                'bankAccountNumber': '40205165',
                'status': 'Terminated',
                'investmentProduct': 'Global Market Blend, Profile 3, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'SREERAM PARUPUDI & SAILAJA VALLABHAJOSULA',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 2,
            'marketValue': 750071.5000,
            'expectedAmount': 400000.000000,
            'establishedDate': '2019-05-20',
            'ytdPerformance': 0.0764000000,
            'oneYearPerformance': 0.1068000000,
            'threeYearPerformance': 0.0246000000,
            'fiveYearPerformance': 0.0420000000,
            'cumulativeReturn': 9.643431892002099485573676815,
            'annualizedPerformance': 0.0443000000,
            'netInvestment': 635000.010000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ],
            'webAccess': true,
            'id': 'ED1D533D-2F55-46C2-BAF5-35BF0CEB94F1-000D',
            'clientAplId': 'CB4TC0',
            'clientWebId': 'W0ZR8C',
            'accounts': [
              {
                'id': 'CEEBED9E-39DF-4D33-BED0-10235EE99AB1-000D',
                'title': 'Sreeram Parupudi & Sailaja Vallabhajosula, JTWROS TOD',
                'applicationId': 'AJ9G87',
                'alerts': [],
                'marketValue': 268936.3200,
                'expectedAmount': 250000.000000,
                'inceptionDate': '2019-05-20',
                'ytdPerformance': -0.0076000000,
                'oneYearPerformance': 0.0116000000,
                'threeYearPerformance': -0.0203000000,
                'fiveYearPerformance': 0.0002000000,
                'cumulativeReturn': 0.0057082596835797179899073577,
                'annualizedPerformance': 0.0011000000,
                'bankAccountNumber': '13692788',
                'status': 'Active',
                'investmentProduct': 'Clark Navigator Tax-Free Fixed Income',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '100A8B81-B115-49CB-8FD3-38CAE7A245F7-000D',
                'title': 'Sreeram V. J. Parupudi & Sailaja Vallabhajosula, JTTOD',
                'applicationId': 'AK66U9',
                'alerts': [],
                'marketValue': 481135.1800,
                'expectedAmount': 150000.000000,
                'inceptionDate': '2020-06-04',
                'ytdPerformance': 0.1306000000,
                'oneYearPerformance': 0.1699000000,
                'threeYearPerformance': 0.0558000000,
                'fiveYearPerformance': 0.0000000000,
                'cumulativeReturn': 0.4935751312303748591252897676,
                'annualizedPerformance': 0.1019000000,
                'bankAccountNumber': '13811598',
                'status': 'Active',
                'investmentProduct': 'Clark Navigator Personalized UMA, Profile 6, Maximum Growth ',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Sommerfeld, William',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 1,
            'marketValue': 0.0,
            'expectedAmount': 0.0,
            'establishedDate': '2011-01-11',
            'ytdPerformance': 0.0000000000,
            'oneYearPerformance': 0.1203000000,
            'threeYearPerformance': 0.0116000000,
            'fiveYearPerformance': 0.0521000000,
            'cumulativeReturn': 0.0000000000000000000000000000,
            'annualizedPerformance': 0.0000000000,
            'netInvestment': -69191.090000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.0
              }
            ],
            'webAccess': false,
            'id': 'F0DCAB83-99B1-4FF3-B7B9-7E5DA6E7C0C8-000D',
            'clientAplId': 'CA0B36',
            'clientWebId': 'W0C1QE',
            'accounts': [
              {
                'id': '1FC76A36-1990-4C7E-82FF-B53FCD9BC006-000D',
                'title': 'William Sommerfeld, Individual',
                'applicationId': 'AC4N07',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 115000.000000,
                'inceptionDate': '2011-01-11',
                'ytdPerformance': 0.0000000000,
                'oneYearPerformance': -0.7461000000,
                'threeYearPerformance': -0.3778000000,
                'fiveYearPerformance': -0.2192000000,
                'cumulativeReturn': 0.0000000000000000000000000000,
                'annualizedPerformance': 0.0000000000,
                'bankAccountNumber': '13799121',
                'status': 'Terminated',
                'investmentProduct': 'SSGA, Profile 3, Tax-Sensitive, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Maier, Nancy M & Joseph N',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 4,
            'marketValue': 620824.2500,
            'expectedAmount': 459459.000000,
            'establishedDate': '2013-12-12',
            'ytdPerformance': 0.0622000000,
            'oneYearPerformance': 0.1121000000,
            'threeYearPerformance': 0.0165000000,
            'fiveYearPerformance': 0.0582000000,
            'cumulativeReturn': 14.566742892553706200917435685,
            'annualizedPerformance': 0.0516000000,
            'netInvestment': 343122.940000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ],
            'webAccess': true,
            'id': '87847D3E-C82C-4411-9A55-94DAB61C8009-000D',
            'clientAplId': 'CA3X07',
            'clientWebId': 'W0I94Y',
            'accounts': [
              {
                'id': 'D9C2DD6B-6A59-4804-ADB9-FA4C8C5CF4B5-000D',
                'title': 'Nancy M Maier, Traditional IRA',
                'applicationId': 'AH4FF7',
                'alerts': [],
                'marketValue': 80406.3700,
                'expectedAmount': 59459.000000,
                'inceptionDate': '2013-12-12',
                'ytdPerformance': 0.0677000000,
                'oneYearPerformance': 0.1197000000,
                'threeYearPerformance': 0.0104000000,
                'fiveYearPerformance': 0.0569000000,
                'cumulativeReturn': 0.688716073197050304964844797,
                'annualizedPerformance': 0.0506000000,
                'bankAccountNumber': '13217305',
                'status': 'Active',
                'investmentProduct': 'JPMorgan, Profile 3, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'B193EBEA-28A2-4389-996C-127298779ADC-000D',
                'title': 'Nancy M Maier and Joseph N Maier, Tenants in Common',
                'applicationId': 'AH4FF8',
                'alerts': [],
                'marketValue': 239364.0400,
                'expectedAmount': 136536.000000,
                'inceptionDate': '2014-01-16',
                'ytdPerformance': 0.0629000000,
                'oneYearPerformance': 0.1127000000,
                'threeYearPerformance': 0.0180000000,
                'fiveYearPerformance': 0.0587000000,
                'cumulativeReturn': 0.6656630116909742882422656998,
                'annualizedPerformance': 0.0497000000,
                'bankAccountNumber': '13217304',
                'status': 'Active',
                'investmentProduct': 'SSGA, Profile 3, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '7174F5C4-9A8C-403B-8503-20505A407B14-000D',
                'title': 'Nancy M Maier, Individual',
                'applicationId': 'AH4FF6',
                'alerts': [],
                'marketValue': 255009.1000,
                'expectedAmount': 213464.000000,
                'inceptionDate': '2013-12-17',
                'ytdPerformance': 0.0637000000,
                'oneYearPerformance': 0.1134000000,
                'threeYearPerformance': 0.0182000000,
                'fiveYearPerformance': 0.0588000000,
                'cumulativeReturn': 0.7029643840797301876755612369,
                'annualizedPerformance': 0.0515000000,
                'bankAccountNumber': '13217303',
                'status': 'Active',
                'investmentProduct': 'SSGA, Profile 3, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'E0D90AF7-DCAE-4156-BA5F-A321E47BD56D-000D',
                'title': 'Nancy M Maier, Individual',
                'applicationId': 'AN7D74',
                'alerts': [],
                'marketValue': 46044.7400,
                'expectedAmount': 50000.000000,
                'inceptionDate': '2024-05-09',
                'ytdPerformance': 0.0000000000,
                'oneYearPerformance': 0.0000000000,
                'threeYearPerformance': 0.0000000000,
                'fiveYearPerformance': 0.0000000000,
                'cumulativeReturn': 0.0001872074194234899828946654,
                'annualizedPerformance': 0.0009000000,
                'bankAccountNumber': '40314875',
                'status': 'Active',
                'investmentProduct': 'Custodial Sweep',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Wear, Joseph H & Kaye H',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 7,
            'marketValue': 947023.5300,
            'expectedAmount': 713975.000000,
            'establishedDate': '2012-06-22',
            'ytdPerformance': 0.0597000000,
            'oneYearPerformance': 0.1114000000,
            'threeYearPerformance': 0.0180000000,
            'fiveYearPerformance': 0.0492000000,
            'cumulativeReturn': 11.776657531866096539325364151,
            'annualizedPerformance': 0.0478000000,
            'netInvestment': 495926.380000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ],
            'webAccess': false,
            'id': '89A24F5C-5D94-4079-96BF-FAFE9335B9F3-000D',
            'clientAplId': 'CA2AE3',
            'clientWebId': 'W0EXE9',
            'accounts': [
              {
                'id': '74E2B8A8-EE45-4D71-B77F-C7A17E1D0396-000D',
                'title': 'Kaye H. Wear, Rollover IRA',
                'applicationId': 'AM35G9',
                'alerts': [],
                'marketValue': 24495.9200,
                'expectedAmount': 15340.000000,
                'inceptionDate': '2022-07-21',
                'ytdPerformance': 0.0287000000,
                'oneYearPerformance': 0.0472000000,
                'threeYearPerformance': 0.0000000000,
                'fiveYearPerformance': 0.0000000000,
                'cumulativeReturn': 0.0630665514480746352654024395,
                'annualizedPerformance': 0.0309000000,
                'bankAccountNumber': '40085818',
                'status': 'Active',
                'investmentProduct': 'Custodial Sweep',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '7EA2C700-B885-4A90-BC89-B2A451E56862-000D',
                'title': 'Kaye H. Wear, Rollover IRA',
                'applicationId': 'AC9ZL2',
                'alerts': [],
                'marketValue': 539174.2500,
                'expectedAmount': 300000.000000,
                'inceptionDate': '2012-06-22',
                'ytdPerformance': 0.0627000000,
                'oneYearPerformance': 0.1218000000,
                'threeYearPerformance': 0.0236000000,
                'fiveYearPerformance': 0.0536000000,
                'cumulativeReturn': 0.8711554046359188080006275532,
                'annualizedPerformance': 0.0532000000,
                'bankAccountNumber': '13104033',
                'status': 'Active',
                'investmentProduct': 'American Funds Moderate Growth and Income, Profile 3',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'F595BE99-23B4-46DE-914D-7AAD4778F990-000D',
                'title': 'Kaye H. Wear, Rollover IRA',
                'applicationId': 'AC9ZL3',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 130000.000000,
                'inceptionDate': '2012-06-22',
                'bankAccountNumber': '13104034',
                'status': 'Terminated',
                'investmentProduct': 'Savos Preservation Strategy',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '0F4EBDE4-B9AC-40F4-AF50-0124D820EC00-000D',
                'title': 'Kaye H. Wear, Rollover IRA',
                'applicationId': 'AL18Y1',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 32000.000000,
                'inceptionDate': '2021-02-24',
                'bankAccountNumber': '13895845',
                'status': 'Terminated',
                'investmentProduct': 'PIMCO Tactical Income Focus',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '09227935-DEB3-4CE9-A859-6CEF8E6CA894-000D',
                'title': 'Joseph H Wear, Traditional IRA',
                'applicationId': 'AH99H0',
                'alerts': [],
                'marketValue': 358033.5200,
                'expectedAmount': 380000.000000,
                'inceptionDate': '2015-08-18',
                'ytdPerformance': 0.0603000000,
                'oneYearPerformance': 0.1185000000,
                'threeYearPerformance': 0.0204000000,
                'fiveYearPerformance': 0.0503000000,
                'cumulativeReturn': 0.5293094285218641160175543296,
                'annualizedPerformance': 0.0487000000,
                'bankAccountNumber': '13335359',
                'status': 'Active',
                'investmentProduct': 'American Funds Moderate Growth and Income, Profile 3',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '54A85D7C-4766-43BC-A0E9-9DEDB9ED9EED-000D',
                'title': 'Joseph H Wear, Traditional IRA',
                'applicationId': 'AJ8577',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 30000.000000,
                'inceptionDate': '2019-03-14',
                'bankAccountNumber': '13672991',
                'status': 'Terminated',
                'investmentProduct': 'Clark Navigator Fixed Income Total Return',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '58723C47-9EDA-4FED-A1B1-5FEEE694D256-000D',
                'title': 'Joseph H Wear, Traditional IRA',
                'applicationId': 'AM35H8',
                'alerts': [],
                'marketValue': 25319.8400,
                'expectedAmount': 18635.000000,
                'inceptionDate': '2022-07-22',
                'ytdPerformance': 0.0290000000,
                'oneYearPerformance': 0.0469000000,
                'threeYearPerformance': 0.0000000000,
                'fiveYearPerformance': 0.0000000000,
                'cumulativeReturn': 0.0673280651098970280393566716,
                'annualizedPerformance': 0.0330000000,
                'bankAccountNumber': '40085826',
                'status': 'Active',
                'investmentProduct': 'Custodial Sweep',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Anglin, Richard',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 3,
            'marketValue': 169314.0100,
            'expectedAmount': 525000.000000,
            'establishedDate': '2006-05-22',
            'ytdPerformance': 0.0435000000,
            'oneYearPerformance': 0.0864000000,
            'threeYearPerformance': 0.0141000000,
            'fiveYearPerformance': 0.0525000000,
            'cumulativeReturn': 6.980049471363773653359506048,
            'annualizedPerformance': 0.0388000000,
            'netInvestment': -55312.420000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ],
            'webAccess': false,
            'id': '8F8C28F7-5B8E-4749-8523-6D5F5ED36A28-000D',
            'clientAplId': 'C36304',
            'clientWebId': 'W0547S',
            'accounts': [
              {
                'id': '5AAD905E-3F3B-429B-B987-E4333F550B12-000D',
                'title': 'Richard Anglin, Rollover IRA',
                'applicationId': 'AK5X39',
                'alerts': [],
                'marketValue': 50379.2600,
                'expectedAmount': 75000.000000,
                'inceptionDate': '2020-05-21',
                'ytdPerformance': 0.0116000000,
                'oneYearPerformance': 0.0285000000,
                'threeYearPerformance': -0.0162000000,
                'fiveYearPerformance': 0.0000000000,
                'cumulativeReturn': -0.0390715372232095937165663519,
                'annualizedPerformance': -0.0095000000,
                'bankAccountNumber': '40184502',
                'status': 'Active',
                'investmentProduct': 'American Funds Preservation, Profile 1',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '6D985F1D-CDB2-4BFE-A5C2-2BF85899CA9B-000D',
                'title': 'Richard Anglin, Rollover IRA',
                'applicationId': 'A88420',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 881000.000000,
                'inceptionDate': '2006-05-22',
                'bankAccountNumber': '960939619',
                'status': 'Terminated',
                'investmentProduct': 'No Strategist',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '35B29FE9-679A-4B1B-A86C-1CE33F07F00E-000D',
                'title': 'Richard Anglin, Rollover IRA',
                'applicationId': 'AB0NN2',
                'alerts': [],
                'marketValue': 118934.7500,
                'expectedAmount': 450000.000000,
                'inceptionDate': '2008-01-29',
                'ytdPerformance': 0.0604000000,
                'oneYearPerformance': 0.1177000000,
                'threeYearPerformance': 0.0207000000,
                'fiveYearPerformance': 0.0642000000,
                'cumulativeReturn': 1.049777244271001041304461639,
                'annualizedPerformance': 0.0445000000,
                'bankAccountNumber': '40184501',
                'status': 'Active',
                'investmentProduct': 'American Funds Moderate Growth and Income, Profile 3',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Simmons, Rachel',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 1,
            'marketValue': 168591.2800,
            'expectedAmount': 150000.000000,
            'establishedDate': '2012-07-11',
            'ytdPerformance': 0.0629000000,
            'oneYearPerformance': 0.1171000000,
            'threeYearPerformance': 0.0017000000,
            'fiveYearPerformance': 0.0381000000,
            'cumulativeReturn': 10.392329992828653521720010412,
            'annualizedPerformance': 0.0456000000,
            'netInvestment': 76620.850000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ],
            'webAccess': false,
            'id': '97885416-7529-4855-8B06-621F6E6F38BC-000D',
            'clientAplId': 'CA2BW5',
            'clientWebId': 'W0FSAW',
            'accounts': [
              {
                'id': 'B4D54640-A556-44CB-B9D7-78A377E2C067-000D',
                'title': 'Rachel Simmons, Rollover IRA',
                'applicationId': 'AH03C7',
                'alerts': [],
                'marketValue': 168591.2800,
                'expectedAmount': 150000.000000,
                'inceptionDate': '2012-07-11',
                'ytdPerformance': 0.0629000000,
                'oneYearPerformance': 0.1171000000,
                'threeYearPerformance': 0.0017000000,
                'fiveYearPerformance': 0.0381000000,
                'cumulativeReturn': 0.7103403318340017366530336427,
                'annualizedPerformance': 0.0456000000,
                'bankAccountNumber': '13133211',
                'status': 'Active',
                'investmentProduct': 'JPMorgan Global Flexible, Profile 3',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Joseph Dean',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 9,
            'marketValue': 817866.1400,
            'expectedAmount': 400110.230000,
            'establishedDate': '2008-01-22',
            'ytdPerformance': 0.0605000000,
            'oneYearPerformance': 0.1170000000,
            'threeYearPerformance': 0.0087000000,
            'fiveYearPerformance': 0.0493000000,
            'cumulativeReturn': 5.1981302058621959793242618384,
            'annualizedPerformance': 0.0340000000,
            'netInvestment': 413532.070000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ],
            'webAccess': true,
            'id': '9908FBA6-76F9-47FD-8BF1-5E644C569F69-000D',
            'clientAplId': 'C51969',
            'clientWebId': 'W06QB9',
            'accounts': [
              {
                'id': '3FEFB613-A2FA-4CC5-96C2-52DA51BDB112-000D',
                'title': 'Patricia Dean, Rollover IRA',
                'applicationId': 'AH8AS0',
                'alerts': [],
                'marketValue': 429330.8900,
                'expectedAmount': 184935.050000,
                'inceptionDate': '2015-03-27',
                'ytdPerformance': 0.0630000000,
                'oneYearPerformance': 0.1215000000,
                'threeYearPerformance': 0.0230000000,
                'fiveYearPerformance': 0.0508000000,
                'cumulativeReturn': 0.5610251212101172360108338625,
                'annualizedPerformance': 0.0489000000,
                'bankAccountNumber': '13921785',
                'status': 'Active',
                'investmentProduct': 'American Funds Moderate Growth and Income, Profile 3',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '8B27A99A-21EE-4C84-A086-742CD89092B9-000D',
                'title': 'Joseph B. Dean, Rollover IRA',
                'applicationId': 'AL23I2',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 70000.000000,
                'inceptionDate': '2021-03-31',
                'bankAccountNumber': '13921783',
                'status': 'Terminated',
                'investmentProduct': 'Savos Fixed Income Portfolio, Intermediate Duration',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '49F17AC6-99C3-464D-8B4F-392E9B16A410-000D',
                'title': 'Patricia Dean, Rollover IRA',
                'applicationId': 'AM57L5',
                'alerts': [],
                'marketValue': 41577.1000,
                'expectedAmount': 22500.000000,
                'inceptionDate': '2022-11-08',
                'ytdPerformance': 0.0282000000,
                'oneYearPerformance': 0.0489000000,
                'threeYearPerformance': 0.0000000000,
                'fiveYearPerformance': 0.0000000000,
                'cumulativeReturn': 0.0603601126038427025122997315,
                'annualizedPerformance': 0.0349000000,
                'bankAccountNumber': '40121382',
                'status': 'Active',
                'investmentProduct': 'Custodial Sweep',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '90801C0C-4EB4-48A3-B43E-CA756131CD79-000D',
                'title': 'Joseph B. Dean, Rollover IRA',
                'applicationId': 'AB0KZ6',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 225000.000000,
                'inceptionDate': '2008-01-22',
                'bankAccountNumber': '13921781',
                'status': 'Terminated',
                'investmentProduct': 'Beaumont Capital Management, Profile 3, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '6E96F132-7A97-4D22-BA2D-752850C77388-000D',
                'title': 'Patricia Dean, Rollover IRA',
                'applicationId': 'AL23J1',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 70000.000000,
                'inceptionDate': '2021-04-07',
                'bankAccountNumber': '13921786',
                'status': 'Terminated',
                'investmentProduct': 'Savos Fixed Income Portfolio, Intermediate Duration',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '5AE2F6F7-65DC-4F98-A2C1-5AA47DD3B926-000D',
                'title': 'Joseph B. Dean, Rollover IRA',
                'applicationId': 'AH8AR1',
                'alerts': [],
                'marketValue': 294336.0300,
                'expectedAmount': 120175.180000,
                'inceptionDate': '2015-04-06',
                'ytdPerformance': 0.0632000000,
                'oneYearPerformance': 0.1217000000,
                'threeYearPerformance': 0.0228000000,
                'fiveYearPerformance': 0.0507000000,
                'cumulativeReturn': 0.5548437748030468262661456698,
                'annualizedPerformance': 0.0486000000,
                'bankAccountNumber': '13921782',
                'status': 'Active',
                'investmentProduct': 'American Funds Moderate Growth and Income, Profile 3',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'D27E3AE6-6E53-4289-B751-13B4F46E5CB9-000D',
                'title': 'Joseph & Patricia Dean, Joint Tenants with Rights of Survivorship',
                'applicationId': 'AI5VT6',
                'alerts': [],
                'marketValue': 11043.1500,
                'expectedAmount': 50000.000000,
                'inceptionDate': '2016-12-08',
                'ytdPerformance': 0.0598000000,
                'oneYearPerformance': 0.1176000000,
                'threeYearPerformance': 0.0198000000,
                'fiveYearPerformance': 0.0450000000,
                'cumulativeReturn': 0.4633677590740854976262142769,
                'annualizedPerformance': 0.0512000000,
                'bankAccountNumber': '13448106',
                'status': 'Active',
                'investmentProduct': 'American Funds Moderate Growth and Income, Profile 3',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'C5FA28AE-5589-4878-BB2F-187EF5E52B8F-000D',
                'title': 'Joseph B. Dean, Rollover IRA',
                'applicationId': 'AM57D6',
                'alerts': [],
                'marketValue': 41578.9700,
                'expectedAmount': 22500.000000,
                'inceptionDate': '2022-11-08',
                'ytdPerformance': 0.0282000000,
                'oneYearPerformance': 0.0490000000,
                'threeYearPerformance': 0.0000000000,
                'fiveYearPerformance': 0.0000000000,
                'cumulativeReturn': 0.0605351682473026853357247252,
                'annualizedPerformance': 0.0350000000,
                'bankAccountNumber': '40121309',
                'status': 'Active',
                'investmentProduct': 'Custodial Sweep',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '6A1AEBAC-5F27-49F8-B43E-5D72463E49B3-000D',
                'title': 'Patricia Dean, Rollover IRA',
                'applicationId': 'AB0ZN8',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 320000.000000,
                'inceptionDate': '2008-06-11',
                'bankAccountNumber': '13921784',
                'status': 'Terminated',
                'investmentProduct': 'Beaumont Capital Management, Profile 3, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Cook, Rosemary',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 3,
            'marketValue': 609589.7900,
            'expectedAmount': 369000.000000,
            'establishedDate': '2005-12-08',
            'ytdPerformance': 0.0652000000,
            'oneYearPerformance': 0.1157000000,
            'threeYearPerformance': 0.0207000000,
            'fiveYearPerformance': 0.0559000000,
            'cumulativeReturn': 10.156960595236642418496405156,
            'annualizedPerformance': 0.0452000000,
            'netInvestment': 170535.910000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ],
            'webAccess': true,
            'id': '9E2C8BE6-2A53-4498-A4F1-02FF32368E0E-000D',
            'clientAplId': 'C31139',
            'clientWebId': 'W04RNO',
            'accounts': [
              {
                'id': '36CDB106-1342-4CB4-8B97-8585F24E4AE0-000D',
                'title': 'Rosemary Cook, Individual',
                'applicationId': 'A78927',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 100000.000000,
                'inceptionDate': '2005-12-08',
                'bankAccountNumber': '960024333',
                'status': 'Terminated',
                'investmentProduct': 'Litman Gregory, Profile 4, Moderate Growth',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '4F360B43-2C95-4337-9435-1796F0836D72-000D',
                'title': 'Rosemary  Cook, Rollover IRA',
                'applicationId': 'AI9K49',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 30000.000000,
                'inceptionDate': '2017-09-01',
                'bankAccountNumber': '960191549',
                'status': 'Terminated',
                'investmentProduct': 'BlackRock, Risk Focused Income, Profile 1, Conservative',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': 'C68413E3-0859-4934-98BE-1CC2EEDAFD72-000D',
                'title': 'Rosemary  Cook, Rollover IRA',
                'applicationId': 'A96345',
                'alerts': [],
                'marketValue': 609589.7900,
                'expectedAmount': 369000.000000,
                'inceptionDate': '2006-11-01',
                'ytdPerformance': 0.0652000000,
                'oneYearPerformance': 0.1157000000,
                'threeYearPerformance': 0.0214000000,
                'fiveYearPerformance': 0.0613000000,
                'cumulativeReturn': 1.1600960154474020982328477894,
                'annualizedPerformance': 0.0444000000,
                'bankAccountNumber': '40184669',
                'status': 'Active',
                'investmentProduct': 'SSGA, Profile 3, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            clientName: 'Clark, Jeff',
            advisorIdentifier: 'AGAT58',
            numberOfAccounts: 0,
            marketValue: 0.0,
            expectedAmount: 0.0,
            establishedDate: '1970-01-01',
            assetAllocations: [],
            webAccess: false,
            id: 'FBCBCFE8-50E1-4B9E-A3C5-1CCB73D83C83-000D',
            clientAplId: 'CD9QK9',
            clientWebId: 'W15PTM',
            accounts: []
          }
        ],
        start: 0,
        limit: 137,
        total: 137
      },
      error: {
        message: '',
        code: 200
      },
      lastUpdate: {
        value: '2024-07-23T00:00:00+00:00',
        kind: 'CalendarDate'
      }
    }
  }
}

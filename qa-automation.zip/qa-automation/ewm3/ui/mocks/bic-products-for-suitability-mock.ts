export class BicProductsForSuitabilityMock {

  public static get data() {
    return {
      'data': [
        {
          'id': '0C2C411470BB43AC838DFBDB3B6907EE',
          'groupName': 'New Frontier Global GuideMark ACE',
          'isFavourite': false,
          'products': [
            {
              'id': '0135A11B-2374-4F27-B5D8-9F19A19ED160-000D',
              'name': 'New Frontier, GuideMark ACE, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '0BA202C6-F4C2-4BE0-A4CB-C50EF6F2B87A-000D',
              'name': 'New Frontier, GuideMark ACE, Profile 1, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'C572E3AE-1E34-4F3E-86CE-E632A009E37C-000D',
              'name': 'New Frontier, GuideMark ACE, Profile 4, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'F3FEAF82-F1AA-4E50-BFEE-1E03EC7B4237-000D',
              'name': 'New Frontier, GuideMark ACE, Profile 6, Max Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'F47630AB-82C0-47B9-BCB6-0FC7B541FD52-000D',
              'name': 'New Frontier, GuideMark ACE, Profile 2, Mod Conserv',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'FA26C802-AA56-4CC0-B32E-0F468261B27E-000D',
              'name': 'New Frontier, GuideMark ACE, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'EF71EE712054A2EB35849EB4EF2B6D33',
          'groupName': 'AssetMark US Market Blend',
          'isFavourite': false,
          'products': [
            {
              'id': '04028683-E56D-4CBF-8851-ADCC4AB3F050-000D',
              'name': 'US Market Blend, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '33EB98AB-F932-470A-8FEC-14D1B9F0A3E5-000D',
              'name': 'US Market Blend, Profile 1, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '47E05220-2E13-4E09-BBF7-8EA949B82107-000D',
              'name': 'US Market Blend, Profile 2, Moderate Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '555BA758-3AC3-4D46-B175-936C06A371B5-000D',
              'name': 'US Market Blend, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '65D5EF43-8B4A-42D8-8D36-3E7EF10B9E00-000D',
              'name': 'US Market Blend, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'F846B9DC-A54F-4585-80DB-5DD7B8B41E31-000D',
              'name': 'US Market Blend, Profile 4, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'B5F58B566F4E2D59CDBCA5D2A9988CA1',
          'groupName': 'State Street Global Standard, Tax Sensitive',
          'isFavourite': false,
          'products': [
            {
              'id': '06A154C3-12B5-4F38-937D-432894D99CD1-000D',
              'name': 'SSGA, Profile 2, Tax-Sensitive, Moderate Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'A7B8E734-C7B0-46B2-A2A3-33EEBE1A4519-000D',
              'name': 'SSGA, Profile 3, Tax-Sensitive, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'B74F55C4-88FA-4171-B10F-4F38FC25E340-000D',
              'name': 'SSGA, Profile 5, Tax-Sensitive, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'C4CF0628-7ED2-4B77-A538-FF913DC54728-000D',
              'name': 'SSGA, Profile 4, Tax-Sensitive, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'D979CB69-DA35-4A63-A178-9378207E4E53-000D',
              'name': 'SSGA, Profile 1, Tax-Sensitive, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'F40089E7-CCBF-4D01-A371-EA33696FC5E6-000D',
              'name': 'SSGA, Profile 6, Tax-Sensitive, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'BBD1F2F45A2DD94D4164A16F9468DFC9',
          'groupName': 'GPS Focused Core Markets',
          'isFavourite': false,
          'products': [
            {
              'id': '06D7BD24-C2DC-49A8-A909-ABDBE1154AFA-000D',
              'name': 'GPS Focused Core Markets, P2',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '0C5D29CC-77C7-4BBC-945B-CB76AC397224-000D',
              'name': 'GPS Focused Core Markets, P1',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '3AB48F22-A998-402F-AF52-D4A4F26ED6CE-000D',
              'name': 'GPS Focused Core Markets, P4',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '5068D636-C50C-4584-8AC3-4A98F83EA0D7-000D',
              'name': 'GPS Focused Core Markets, P3',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '98D62263-E04E-4116-BB04-C59319754DEC-000D',
              'name': 'GPS Focused Core Markets, P5',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '3BF2460F23E95A034DAFA715C5AB6E0A',
          'groupName': 'First Trust Diversified Low Duration Fixed Income',
          'isFavourite': false,
          'products': [
            {
              'id': '07817981-448C-4197-8613-7CE5ACF05019-000D',
              'name': 'First Trust Diversified Low Duration Fixed Income',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'F6920ECFB9CA64E2C0C8A03E0898A697',
          'groupName': 'AssetMark MarketDimensions Portfolios - Tax Sensitive',
          'isFavourite': false,
          'products': [
            {
              'id': '079D1ECF-2F9E-4EBE-80A3-C4CF3139BB8E-000D',
              'name': 'MarketDimensions Portfolio - Tax Sensitive, Profile 2',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '2F6E4618-6A18-4365-B617-BA085C87D852-000D',
              'name': 'MarketDimensions Portfolio - Tax Sensitive, Profile 1',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '89079483-5F4B-40D8-9268-4AF03DE6A8E2-000D',
              'name': 'MarketDimensions Portfolio - Tax Sensitive, Profile 5',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'A69F34AA-AA51-4A04-A670-3EBA22B12295-000D',
              'name': 'MarketDimensions Portfolio - Tax Sensitive, Profile 4',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'BD20A7EF-7717-48FC-B88D-6B2136AE76E8-000D',
              'name': 'MarketDimensions Portfolio - Tax Sensitive, Profile 3',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'CC2E516C-72F7-4E7B-8A49-D37C0A54C014-000D',
              'name': 'MarketDimensions Portfolio - Tax Sensitive, Profile 6',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '24C32FCBA662E44FA781904A08B15D90',
          'groupName': 'AssetMark Global GuideMark Market Blend',
          'isFavourite': false,
          'products': [
            {
              'id': '08A78B11-FD5E-4E3C-AEAD-3329CAD442E6-000D',
              'name': 'Global GuideMark Market Blend, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '4D6B4801-C210-4D1C-9019-DC79D8C7DD8E-000D',
              'name': 'Global GuideMark Market Blend, Prof 2, Moderate Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '8007AC58-5172-48F2-96E9-FF930BCC12D2-000D',
              'name': 'Global GuideMark Market Blend, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '9FB70201-761D-46D6-B681-37621BF2CE3A-000D',
              'name': 'Global GuideMark Market Blend, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '8CD1F37158286631A7AE0215143FA4AD',
          'groupName': 'AssetMark US GuideMark Market Blend',
          'isFavourite': false,
          'products': [
            {
              'id': '092AD9F4-D904-4810-A439-B16670A30165-000D',
              'name': 'US GuideMark Market Blend, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '254B8B53-F7EA-4CC8-ABF6-C9A32E41C2FE-000D',
              'name': 'US GuideMark Market Blend, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '3B993D9E-B81C-40D8-9BD9-E011F8799DC2-000D',
              'name': 'US GuideMark Market Blend, Profile 2, Mod Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'FDAB5063-1ACD-4922-8711-CF498468DDEB-000D',
              'name': 'US GuideMark Market Blend, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '01F4C1C88F09ED14FFF92398C8E1DCE3',
          'groupName': 'JPMorgan Global Standard',
          'isFavourite': false,
          'products': [
            {
              'id': '0AAC96A8-9CD4-4BCB-8657-1F2300266F12-000D',
              'name': 'JPMorgan, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '1FC5D2E4-008C-4B6A-BB40-2BA44FEC5C81-000D',
              'name': 'JPMorgan, Profile 2, Moderate Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '29F983DB-19BC-4274-A24B-C943014D01DB-000D',
              'name': 'JPMorgan, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '42445358-2461-450D-BED9-B11242614D79-000D',
              'name': 'JPMorgan, Profile 1, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '8841CFFF-380A-40AC-97BB-8FD57D2CA3A0-000D',
              'name': 'JPMorgan, Profile 4, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'F1ECAE6C-8D8A-48BC-AE6D-E7C3E7BC3880-000D',
              'name': 'JPMorgan, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '3285138151DB107525ACAF9B91BE0D32',
          'groupName': 'New Frontier Multi-Asset Income',
          'isFavourite': false,
          'products': [
            {
              'id': '0BA30FA0-06FF-4FFC-B0BA-2B32C51B24E8-000D',
              'name': 'New Frontier, MAI, Profile 4, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '88095610-B15B-479B-850C-3D069842DB1F-000D',
              'name': 'New Frontier, MAI, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'C1B3B40D-E9A2-443D-A011-1C0681E335A4-000D',
              'name': 'New Frontier, MAI, Profile 2, Moderate Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '2970FE6DC713A284C8784946A619F369',
          'groupName': 'New Frontier Global Standard',
          'isFavourite': false,
          'products': [
            {
              'id': '0BDEA17B-A85A-47AD-A294-CB4592B54440-000D',
              'name': 'New Frontier ETF, Profile 1, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '1A1BBE3A-33A7-422B-88C4-31BB0267764B-000D',
              'name': 'New Frontier ETF, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '3DAE2B62-8249-4374-8F51-4195E3E038C8-000D',
              'name': 'New Frontier ETF, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '4363FC82-5907-4861-9E25-3A89BA49860F-000D',
              'name': 'New Frontier ETF, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'B85067AF-FDFC-42C3-BD6D-0246190741C5-000D',
              'name': 'New Frontier ETF, Profile 2, Moderate Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'FAE50241-A200-47A0-A5DD-C43DEA8970D6-000D',
              'name': 'New Frontier ETF, Profile 4, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '3301EF6E1D12AB639FFA01BCEBB44F71',
          'groupName': 'BlackRock Opportunistic Alternatives',
          'isFavourite': false,
          'products': [
            {
              'id': '0C012A8A-C192-47BB-A7E8-6796CC765C21-000D',
              'name': 'BlackRock Opportunistic Alternatives',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'E5AB3C45869990F35B1C28E46EE5E340',
          'groupName': 'BlackRock Equity Dividend',
          'isFavourite': false,
          'products': [
            {
              'id': '0CFA9CBB-A9B9-4DBD-BF15-FB7BEA517203-000D',
              'name': 'BlackRock Equity Dividend',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '100000.000000',
              'enforcedInvestmentMinimum': 95000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '4738A6967B0C710E43DB7CF49709922F',
          'groupName': 'GPS Focused Multi-Asset Income',
          'isFavourite': false,
          'products': [
            {
              'id': '0D9CB0A7-3A6D-4DE1-A436-4A09F49013CF-000D',
              'name': 'GPS Focused Multi-Asset Income, Profile 2, Moderate Conserv',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '20EB4C65-E443-407E-AFF2-A2370C3A1E0C-000D',
              'name': 'GPS Focused Multi-Asset Income, Profile 4, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '66D650D7-2B42-47BD-A4F1-B71B79FAC24A-000D',
              'name': 'GPS Focused Multi-Asset Income, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '4B1E67ABE65C82C8B1C06F01484BDBEF',
          'groupName': 'Aris Personal Faith',
          'isFavourite': false,
          'products': [
            {
              'id': '0FFD77C2-26B3-466A-9BCC-59B403A03067-000D',
              'name': 'Aris Personal Values - Faith, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'C10E0B5B-06C2-40E3-9E05-B79F2441A9C8-000D',
              'name': 'Aris Personal Values - Faith, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'C2361155-5D03-4487-BB50-92542A226765-000D',
              'name': 'Aris Personal Values - Faith, Profile 2, Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'CE2A636E-9F06-4A27-AC2F-0478E19E80E4-000D',
              'name': 'Aris Personal Values - Faith, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'F05D1765D659B1DFEBD6E75DF457410B',
          'groupName': 'Logan Global Growth',
          'isFavourite': false,
          'products': [
            {
              'id': '14190BD5-54E7-405B-B729-700E999BE336-000D',
              'name': 'Logan Global Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '100000.000000',
              'enforcedInvestmentMinimum': 100000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '10EC9B0B770DA027044B05AFEA9F70BB',
          'groupName': 'AssetMark MarketDimensions Portfolios',
          'isFavourite': false,
          'products': [
            {
              'id': '164A84BC-BDFE-4A39-BB3A-28EC3EA9593A-000D',
              'name': 'MarketDimensions Portfolio, Profile 6',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '3644FF90-41B6-48C1-AF6E-F96D8DEC8897-000D',
              'name': 'MarketDimensions Portfolio, Profile 1',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '81333985-9E16-4ABD-88A5-60764AEEB87B-000D',
              'name': 'MarketDimensions Portfolio, Profile 5',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '82780B1A-B144-4E3A-959C-A76FBFFED84A-000D',
              'name': 'MarketDimensions Portfolio, Profile 2',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '98CCEBBF-DA2F-4B22-A27A-CB20A2C647A8-000D',
              'name': 'MarketDimensions Portfolio, Profile 4',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'C36435AC-B4AB-41D8-B348-53FA3453167D-000D',
              'name': 'MarketDimensions Portfolio, Profile 3',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'D6FD266BDABB59CDD35E142B30CDCB84',
          'groupName': 'Savos PMP Diversified Global - Municipal',
          'isFavourite': false,
          'products': [
            {
              'id': '16852497-D65A-4E0B-802B-D8B42FC1357C-000D',
              'name': 'Savos PMP Global, Profile 4, Moderate Muni',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Municipal',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'D03280B7-F8F8-453C-80D4-C1A278BEBAE4-000D',
              'name': 'Savos PMP Global, Profile 3, Moderate Municipal',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate Municipal',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'AB84705FD8A9EC7B10F6E942A95AB77E',
          'groupName': 'AllianceBernstein Sustainable Global Thematic ADR Portfolio',
          'isFavourite': false,
          'products': [
            {
              'id': '17AC7D69-A27C-4038-8118-F723E144C56A-000D',
              'name': 'AllianceBernstein Sustainable Global Thematic ADR Portfolio',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '100000.000000',
              'enforcedInvestmentMinimum': 100000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'DF0377045606C490366AAF95F986BB27',
          'groupName': 'State Street Global Standard',
          'isFavourite': false,
          'products': [
            {
              'id': '1826FA45-4BA8-4D18-A6BF-F0D6F827A225-000D',
              'name': 'SSGA, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '5536CB3E-A5AA-4F86-BE5E-71990A9B3127-000D',
              'name': 'SSGA, Profile 2, Moderate Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '5F8D86F0-3853-4563-9BBC-C46DF8A1277F-000D',
              'name': 'SSGA, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '807F2504-9B16-42A6-B150-03FFFDFA4C47-000D',
              'name': 'SSGA, Profile 4, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '8B7BC0E4-1ABE-4DFE-89DA-BA031C87EC79-000D',
              'name': 'SSGA, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '8E754485-B64C-40C7-AD01-8F4F22352744-000D',
              'name': 'SSGA, Profile 1, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '27E542F45E83D8436BB3DCB205E1DEEB',
          'groupName': 'JPMorgan Global Flexible',
          'isFavourite': false,
          'products': [
            {
              'id': '1A815E74-5418-44D1-A541-290F29340383-000D',
              'name': 'JPMorgan Global Flexible, Profile 4',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '1FEB836E-3892-43BA-A2CD-892495ACA636-000D',
              'name': 'JPMorgan Global Flexible, Profile 3',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '4FB03180-F891-4BC6-A569-AC4D9C7F6EEB-000D',
              'name': 'JPMorgan Global Flexible, Profile 6',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '64A4CE58-1E96-4954-BA42-470E0235FC2E-000D',
              'name': 'JPMorgan Global Flexible, Profile 1',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '8775933D-E6DD-4F22-9B96-AACA565CD361-000D',
              'name': 'JPMorgan Global Flexible, Profile 2',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'EBDA35EF-2206-4455-A76B-2DD7976B6B8E-000D',
              'name': 'JPMorgan Global Flexible, Profile 5',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '3A6E18091C69544F86EEA0B96A91046E',
          'groupName': 'American Funds Model Portfolios',
          'isFavourite': false,
          'products': [
            {
              'id': '2031718C-EA0A-44D8-AD2A-2211055C3CCF-000D',
              'name': 'American Funds Moderate Growth, Profile 5',
              'riskProfile': 5.0,
              'profileName': '5 - Moderate Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '28E69358-C8B3-4AC7-BF04-1F3CB23B3DCF-000D',
              'name': 'American Funds Conservative Growth and Income, Profile 2',
              'riskProfile': 2.0,
              'profileName': '2 - Conservative Growth and Income',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '2DE1BF54-8CA4-4C98-AB2B-D195AD6CA2E4-000D',
              'name': 'American Funds Growth and Income, Profile 4',
              'riskProfile': 4.0,
              'profileName': '4 - Growth and Income',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'A7BBD8DD-89F5-419F-96A6-B8791AB8BA0A-000D',
              'name': 'American Funds Growth, Profile 6',
              'riskProfile': 6.0,
              'profileName': '6 - Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'B20A3E13-7AB7-441B-B138-646336FF70D9-000D',
              'name': 'American Funds Preservation, Profile 1',
              'riskProfile': 1.0,
              'profileName': '1 - Preservation',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '6C2D40A05205AD086168EA52D02F77D5',
          'groupName': 'Hartford Core Equity',
          'isFavourite': false,
          'products': [
            {
              'id': '24114079-EDC5-4CFA-92D3-EB293C5B27F5-000D',
              'name': 'Hartford Core Equity ',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '100000.000000',
              'enforcedInvestmentMinimum': 100000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'CDAAE6172A476FAFD4FDCC6553AFF9C4',
          'groupName': 'GPS Focused Tactical',
          'isFavourite': false,
          'products': [
            {
              'id': '24752030-B5FB-402A-A56D-E604E55602F0-000D',
              'name': 'GPS Focused Tactical, P4',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '4AFAAD57-1359-461F-9AA1-A68A94F933E1-000D',
              'name': 'GPS Focused Tactical, P3',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'B595E86D-E350-43F4-8EB3-C7BD47C3A25D-000D',
              'name': 'GPS Focused Tactical, P5',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'C0B53B69-7C42-436C-A422-FB8E2E8965A2-000D',
              'name': 'GPS Focused Tactical, P2',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'F169C2698AE2F0DD79F61BD7344DD58E',
          'groupName': 'Savos PMP Diversified Global',
          'isFavourite': false,
          'products': [
            {
              'id': '27EFC94C-080E-43B7-9170-0FF354BE8BBD-000D',
              'name': 'Savos PMP Global, Profile 4, Mod Growth Inv Grd Bnds',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth Inv Grade Bonds',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '56FB8548-4F31-44BA-95E1-686299F71A75-000D',
              'name': 'Savos PMP Global, Profile 5, Growth High Income',
              'riskProfile': 5.0,
              'profileName': '5 - Growth High Income',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '864BB3B3-BE02-4E27-827B-864430531876-000D',
              'name': 'Savos PMP Global, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'A49B049B-77A9-4A85-AE34-B146158C56C4-000D',
              'name': 'Savos PMP Global, Profile 3, Mod Inv Grade Bonds',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate Investment Grade Bonds',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'A643B7B323B0FB68EFEF000EB61E13D1',
          'groupName': 'Principal U.S. Small Cap Select Equity',
          'isFavourite': false,
          'products': [
            {
              'id': '2E21E628-F263-47B1-88AC-1E565C1336B5-000D',
              'name': 'Principal U.S. Small Cap Select Equity ',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0080000000,
              'displayInvestmentMinimum': '75000.000000',
              'enforcedInvestmentMinimum': 75000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '61EE714299780E6FA1EB272D4D6A9DB5',
          'groupName': 'First Trust Top Themes',
          'isFavourite': false,
          'products': [
            {
              'id': '309BF602-8796-47D0-9AF4-1F19BC805D71-000D',
              'name': 'First Trust Top Themes',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0065000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '8B70EA9A13C74758629AB77D2E0652CF',
          'groupName': 'GPS Fund Strategies Distribution without Alternatives',
          'isFavourite': false,
          'products': [
            {
              'id': '315A615D-A525-4399-9696-EABE1285EA06-000D',
              'name': 'GPS Distribution, Profile 4, Moderate Growth - without Alts',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '55F14623-042C-4D2F-B4D7-CA4ED5A03B56-000D',
              'name': 'GPS Distribution, Profile 3, Moderate - without Alts',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'FA5BF21C-5F49-430E-ACA8-64A2557CCE3C-000D',
              'name': 'GPS Distribution, Profile 2, Mod Conservative - without Alts',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '6BC417043D43BF7F10980AD08FCDE9ED',
          'groupName': 'Nuveen ESG Growth',
          'isFavourite': false,
          'products': [
            {
              'id': '316149DB-94C8-46AA-AFEF-094FF74D23A9-000D',
              'name': 'Nuveen ESG Growth Model Portfolio Profile 2',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '3A51A4AC-B64C-4B53-A7E5-E844E8B3F202-000D',
              'name': 'Nuveen ESG Growth Model Portfolio Profile 4',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '663A4B41-A556-46D4-87C9-117E0DCAC9B3-000D',
              'name': 'Nuveen ESG Growth Model Portfolio Profile 3',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '99D65968-AEE1-461F-A67B-E914A458DF5E-000D',
              'name': 'Nuveen ESG Growth Model Portfolio Profile 1',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '9E7E4AE9-FCD1-4E66-998B-4156D0B24830-000D',
              'name': 'Nuveen ESG Growth Model Portfolio Profile 6',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '65B0254AB715B5450ADE174AC12912D2',
          'groupName': 'American Funds Tax-Aware Model Portfolios',
          'isFavourite': false,
          'products': [
            {
              'id': '33AA40DD-876D-475B-982E-50AD66977513-000D',
              'name': 'American Funds Preservation, Tax-Exempt, Profile 1',
              'riskProfile': 1.0,
              'profileName': '1 - Preservation (Tax Exempt)',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '43822156-62FB-4D2E-95DB-3B8699A2E68F-000D',
              'name': 'American Funds Moderate Gr & Inc, Tax-Aware, Profile 3',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate Growth & Income',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'D114496F-75F2-4A64-A58D-929D65CB14B2-000D',
              'name': 'American Funds Conservative Gr & Inc, Tax-Aware, Profile 2',
              'riskProfile': 2.0,
              'profileName': '2 - Conservative Growth & Income',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'F8BCA1D8-157F-44C5-A8A0-B39BFF97C50B-000D',
              'name': 'American Funds Growth & Income, Tax-Aware, Profile 4',
              'riskProfile': 4.0,
              'profileName': '4 - Growth & Income',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '549DB335C97E62C82C9DA3E78A11F7DB',
          'groupName': 'American Funds Model Portfolios - Global',
          'isFavourite': false,
          'products': [
            {
              'id': '3636362E-EE53-477B-B0FC-FE573DA31DEA-000D',
              'name': 'American Funds Global Growth, Profile 6',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '809AFFA94ECD2C9A290A72A808032FBE',
          'groupName': 'DoubleLine Capital Low Volatility',
          'isFavourite': false,
          'products': [
            {
              'id': '367E3B77-D7CC-486E-8FF9-1A532117F67C-000D',
              'name': 'DoubleLine (R) Low Volatility, Profile 1, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'B5FDB0E04F51406F9C5CE04D64B6959E',
          'groupName': 'GPS Fund Strategies Accumulation without Alternatives',
          'isFavourite': false,
          'products': [
            {
              'id': '37ABE255-94A9-48B1-A9A0-47A546C88D75-000D',
              'name': 'GPS Accumulation, Profile 4, Moderate Growth - without Alts',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '4AF47E62-3DF9-4339-8F3F-604F7FEFE29A-000D',
              'name': 'GPS Accumulation, Profile 3, Moderate - without Alts',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '6E0F5C94-4C0A-4CFD-8C58-874E3976CFF4-000D',
              'name': 'GPS Accumulation, Profile 2, Mod Conservative - without Alts',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '8252933C-03EB-48BA-82FA-6323FA57299F-000D',
              'name': 'GPS Accumulation, Profile 1, Conservative - without Alts',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '93844EC7-82C1-4F88-B63B-55E41BFBC5B8-000D',
              'name': 'GPS Accumulation, Profile 5, Growth - without Alts',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '1DE3403CA410BEDAD6352B2902B1451E',
          'groupName': 'AssetMark Global Market Blend',
          'isFavourite': false,
          'products': [
            {
              'id': '38E424FC-578F-4D01-B1BC-43FD949B015E-000D',
              'name': 'Global Market Blend, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '6B3F5263-8970-46E8-AD76-99FF88269406-000D',
              'name': 'Global Market Blend, Profile 2, Moderate Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '6C044C05-AFA9-4F70-858A-66F5920C3571-000D',
              'name': 'Global Market Blend, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '752856BD-A697-45EB-807E-0D35205640AC-000D',
              'name': 'Global Market Blend, Profile 4, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'E6443E6B-BF62-4FD3-AEAD-93CDD6458215-000D',
              'name': 'Global Market Blend, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'FF1A8884-DC0D-4793-A9A4-4DDA7196E6C5-000D',
              'name': 'Global Market Blend, Profile 1, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'D46DCF1DC9ECB895D0BBF1CEB58C209F',
          'groupName': 'Beaumont Decathlon Aspect',
          'isFavourite': false,
          'products': [
            {
              'id': '3A0E3976-139E-4519-B8E8-74ACB8BEF082-000D',
              'name': 'Beaumont Capital Management, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0110000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '81EED585-042B-4D1D-8D6D-C3BFB7969E60-000D',
              'name': 'Beaumont Capital Management, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0110000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '91CA621C-21C6-4712-A4EB-49F5B6E7E26F-000D',
              'name': 'Beaumont Capital Management, Profile 1, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0110000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '905738F3CA790598117723C78F4F9B6E',
          'groupName': 'GPS Fund Strategies Comprehensive Distribution',
          'isFavourite': false,
          'products': [
            {
              'id': '3F17CE48-4A1C-4F5D-B4BA-A22DB96E08C2-000D',
              'name': 'GPS Distribution, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'E8B9839C-F550-4EE3-B8EC-45E1CDAB1FB6-000D',
              'name': 'GPS Distribution, Profile 2, Mod Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'FF5388B2-C2A6-4BF0-9376-1B4B0A368474-000D',
              'name': 'GPS Distribution, Profile 4, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '1A816AC15CD175E8EAE7FE383FC9795F',
          'groupName': 'First Trust Strategic Risk Core',
          'isFavourite': false,
          'products': [
            {
              'id': '3FD4285C-ABDB-4EFE-AC89-5277E4BFDD06-000D',
              'name': 'First Trust Strategic Risk Core - Conservative, P1',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '80692FF3-8816-4315-8C9E-626286CE162E-000D',
              'name': 'First Trust Strategic Risk Core - Moderate Growth, P4',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '9D192ECC-C9A9-45D3-8D52-F5A67B451577-000D',
              'name': 'First Trust Strategic Risk Core - Aggressive Growth, P5',
              'riskProfile': 5.0,
              'profileName': '5 - Aggressive Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'AEDA9DAC-D6D3-498A-9483-AB46C6172E2F-000D',
              'name': 'First Trust Strategic Risk Core - Conservative Growth, P2',
              'riskProfile': 2.0,
              'profileName': '2 - Conservative Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'EFFD2063-D7DC-4065-8C14-96E05B2F97B1-000D',
              'name': 'First Trust Strategic Risk Core - All Equity, P6',
              'riskProfile': 6.0,
              'profileName': '6 - All Equity',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'F22A7B2D-4119-4471-9316-ED88A5257B71-000D',
              'name': 'First Trust Strategic Risk Core - Balanced Growth, P3',
              'riskProfile': 3.0,
              'profileName': '3 - Balanced Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '70637E057554E6C9B84883E3F1D9C68B',
          'groupName': 'Kensington Managed Income',
          'isFavourite': false,
          'products': [
            {
              'id': '40792BD0-112E-44C5-A341-62613F7CA48F-000D',
              'name': 'Kensington Managed Income',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'C051BD9F977793EAE98033FB5E532775',
          'groupName': 'JPMorgan Absolute Return',
          'isFavourite': false,
          'products': [
            {
              'id': '43B9BE6A-91E9-4C85-94F9-28BA3BFB456E-000D',
              'name': 'JPMorgan Absolute Return - Profile 1',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'B749659BD2D626F0DA694CB817F16D94',
          'groupName': 'GPS Fund Strategies Comprehensive Accumulation',
          'isFavourite': false,
          'products': [
            {
              'id': '465CE29B-549C-4052-9EC6-A617AA55570E-000D',
              'name': 'GPS Accumulation, Profile 4, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'A309518E-8CCF-4F38-B0FD-A2CF95DD727E-000D',
              'name': 'GPS Accumulation, Profile 1, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'AD24E041-95A3-432E-8290-1CC3F8832D44-000D',
              'name': 'GPS Accumulation, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'B2590DEF-F20E-4867-BD1B-44965AC33EFA-000D',
              'name': 'GPS Accumulation, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'D5E83B84-61C9-47B8-9379-538C5C3E4E99-000D',
              'name': 'GPS Accumulation, Profile 2, Mod Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '41F2859EC56859DC4E6D6A9E88E784A0',
          'groupName': 'JPMorgan Global Flexible - Tax Sensitive',
          'isFavourite': false,
          'products': [
            {
              'id': '46CCB727-CB4F-47FD-8240-1CA6CEA810F7-000D',
              'name': 'JPMorgan Global Flexible- Tax Sensitive, Profile 4',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '51983B85-916B-4879-A109-D06993FB42DC-000D',
              'name': 'JPMorgan Global Flexible- Tax Sensitive, Profile 5',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '51EB047C-44E9-4660-B062-469343E481AC-000D',
              'name': 'JPMorgan Global Flexible- Tax Sensitive, Profile 3',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '73B45D2A-B2E5-4D7C-8B34-2EE142D217F9-000D',
              'name': 'JPMorgan Global Flexible- Tax Sensitive, Profile 1',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'ABB5D881-BE66-4DA7-941B-357E793EC256-000D',
              'name': 'JPMorgan Global Flexible- Tax Sensitive, Profile 6',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'DA3ADB6F-F32E-4598-85D8-DE9EFBB3FC60-000D',
              'name': 'JPMorgan Global Flexible- Tax Sensitive, Profile 2',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'A2F57946CA67EA550E809C8A267226B7',
          'groupName': 'Savos PMP High Dividend Global',
          'isFavourite': false,
          'products': [
            {
              'id': '47E4B1D3-4E12-4D80-8821-280BDA6CD46C-000D',
              'name': 'Savos PMP High Dividend Global, Profile 5 Growth High Income',
              'riskProfile': 5.0,
              'profileName': '5 - Growth High Income',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '4A053F8F-78C2-4464-862D-E3CF76702C27-000D',
              'name': 'Savos PMP High Dividend Glbl, Prof 4 Mod Growth Inv Grd Bnds',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth Inv Grade Bonds',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'CD8890A4-7D02-4D65-BAB4-376B3498E246-000D',
              'name': 'Savos PMP High Dividend Global, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'E501BB2D-9D6E-4408-947E-54CC4B1F29E3-000D',
              'name': 'Savos PMP High Dividend Global, Prof 3, Mod Inv Grade Bonds',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate Investment Grade Bonds',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'CB5A551E0B5FCB8CA06E9289A7B938A9',
          'groupName': 'Fiera Capital Small Mid Cap Growth Equity',
          'isFavourite': false,
          'products': [
            {
              'id': '480D3C2A-838F-45FB-B733-BBBC8D9E51CE-000D',
              'name': 'Fiera Capital Small Mid Cap Growth Equity ',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '75000.000000',
              'enforcedInvestmentMinimum': 75000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '8E61B3BFA5ED3238924862E5B86F2C98',
          'groupName': 'BlackRock TA Multi-Manager w Alts Tax Aware',
          'isFavourite': false,
          'products': [
            {
              'id': '482C7C72-BD38-4571-9E2D-6A3B10E8CEBE-000D',
              'name': 'BlackRock TA Multi-Manager w Alts Tax Aware Profile 1',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '55BD38B2-D558-4797-9B7A-76D99A68E1D3-000D',
              'name': 'BlackRock TA Multi-Manager w Alts Tax Aware Profile 3',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '5AD8F1E4-2048-412F-9870-EF2FE78921F8-000D',
              'name': 'BlackRock TA Multi-Manager w Alts Tax Aware Profile 2',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '9310DD58-D5C2-42E1-9C85-6E04C7F72AF5-000D',
              'name': 'BlackRock TA Multi-Manager w Alts Tax Aware Profile 4',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '9AB51504-A119-44BE-B068-DA586F409FB6-000D',
              'name': 'BlackRock TA Multi-Manager w Alts Tax Aware Profile 6',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '9B5BE50999A7F3911C0B3DE545D3E017',
          'groupName': 'New Frontier Global GuideMark ACE, Tax Sensitive',
          'isFavourite': false,
          'products': [
            {
              'id': '4D0F42FF-7CD4-445F-ACAD-836227A9B76B-000D',
              'name': 'New Frontier, GuideMark ACE, TS, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '75CFD238-B04B-4525-905F-762796F0DA7F-000D',
              'name': 'New Frontier, GuideMark ACE, TS, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'BA4F4161-CB6C-4564-9018-006E23604096-000D',
              'name': 'New Frontier, GuideMark ACE, TS, Prof 6, Max Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'CC28253F-ADDA-4EEA-8E61-B2F172C47728-000D',
              'name': 'New Frontier, GuideMark ACE, TS, Profile 2, Mod Conserv',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'DB19ABA3-FB59-4C89-B1C4-9AD68F34DA7D-000D',
              'name': 'New Frontier, GuideMark ACE, TS, Profile 1, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'E6E68AF0-E12E-4903-9790-EA67ADCB40D9-000D',
              'name': 'New Frontier, GuideMark ACE, TS, Profile 4, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '37339FD95149ED1A45978400E404E5D5',
          'groupName': 'Savos Fixed Income Ultra-Short Duration',
          'isFavourite': false,
          'products': [
            {
              'id': '536D75D0-7925-4146-A5DD-49F861D9A18D-000D',
              'name': 'Savos Fixed Income Portfolio, Ultra-Short Duration',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0030000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'FD6D469C2E0BD50D65550372AC201517',
          'groupName': 'Savos GMS High Dividend - Municipal',
          'isFavourite': false,
          'products': [
            {
              'id': '56452167-AF95-4548-93DB-5F59D49AFD54-000D',
              'name': 'Savos GMS High Dividend, Profile 4, Moderate Municipal',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Municipal',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '57890632-48B7-4DDB-9EFD-FD371C3D0E62-000D',
              'name': 'Savos GMS High Dividend, Profile 3, Moderate Municipal',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate Municipal',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'F9202C0681969499C0A9DD20121D7444',
          'groupName': 'JPMorgan Global Standard, Tax Sensitive',
          'isFavourite': false,
          'products': [
            {
              'id': '56E83D69-06D8-4021-B12E-B136C00879BE-000D',
              'name': 'JPMorgan, Profile 6, Tax-Sensitive, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '672211AC-A19D-4A3A-A78A-06CD4EFE3AB1-000D',
              'name': 'JPMorgan, Profile 1, Tax-Sensitive, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '8BC7A8E5-9DA0-459F-B200-C71848E3A3AD-000D',
              'name': 'JPMorgan, Profile 3, Tax-Sensitive, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'C4A88036-DD73-41E7-928F-22FE62D03EA7-000D',
              'name': 'JPMorgan, Profile 4, Tax-Sensitive, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'DE923929-E90A-446E-AEAB-534A46B43919-000D',
              'name': 'JPMorgan, Profile 5, Tax-Sensitive, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'E03341A4-7D9F-49EF-969D-1975A7B63EC0-000D',
              'name': 'JPMorgan, Profile 2, Tax-Sensitive, Moderate Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '949EA97B9828E6885C68FD856A12F4B2',
          'groupName': 'AssetMark WealthBuilder Portfolio',
          'isFavourite': false,
          'products': [
            {
              'id': '56E8B51A-52B2-462D-8FAA-9FF35786C472-000D',
              'name': 'AssetMark WealthBuilder, Profile 1',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '69D4531B-5B86-4088-BDF4-7B44E9659CD5-000D',
              'name': 'AssetMark WealthBuilder, Profile 3',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '7AAD9CCF-F6ED-4C83-B075-A39141EBADF4-000D',
              'name': 'AssetMark WealthBuilder, Profile 4',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'DA173A66-8822-4A97-B27F-9DB492E1A315-000D',
              'name': 'AssetMark WealthBuilder, Profile 6',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'EBD74B7F-F9F4-4D98-AFA3-3E957E527D6F-000D',
              'name': 'AssetMark WealthBuilder, Profile 5',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'F5C8EB86-93C7-4F2D-A253-910AF91E1E86-000D',
              'name': 'AssetMark WealthBuilder, Profile 2',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '6CDCC0DF3B3F91DF8E3C41222866CFE3',
          'groupName': 'BlackRock TA Multi-Manager w Alts',
          'isFavourite': false,
          'products': [
            {
              'id': '5AF77073-A7FF-43AC-9AA8-621E705D9D5F-000D',
              'name': 'BlackRock Target Allocation Multi-Manager w Alts Profile 2',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '7C9B4526-C243-49DB-B756-B6C0CE52AAC3-000D',
              'name': 'BlackRock Target Allocation Multi-Manager w Alts Profile 3',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '89B53D51-AEFA-4105-B6E6-E44487B773A8-000D',
              'name': 'BlackRock Target Allocation Multi-Manager w Alts Profile 1',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'A50F2C94-6737-481B-9F13-E02599CE9D9E-000D',
              'name': 'BlackRock Target Allocation Multi-Manager w Alts Profile 4',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'B8FC3C61-7FCB-4D4F-A235-CD8317E3CA7A-000D',
              'name': 'BlackRock Target Allocation Multi-Manager w Alts Profile 6',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'B7E04D7112613302CBEBFFC367D9E95B',
          'groupName': 'Savos GMS High Dividend',
          'isFavourite': false,
          'products': [
            {
              'id': '5D6831E7-924D-44A0-9A84-803047B012FC-000D',
              'name': 'Savos GMS High Dividend, Profile 5, Growth High Income',
              'riskProfile': 5.0,
              'profileName': '5 - Growth High Income',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '5D7D45CA-45BB-4416-A824-A03E800BE1B3-000D',
              'name': 'Savos GMS High Dividend, Profile 4, Mod Grth Inv Grade Bonds',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth Invesment Grade Bonds',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'A32DEF58-399C-4606-8930-E32718CF62EA-000D',
              'name': 'Savos GMS High Dividend, Profile 2',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'CA783757-7002-498A-9B79-91507C59EBB4-000D',
              'name': 'Savos GMS High Dividend, Profile 3, Moderate Inv Grade Bonds',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate Investment Grade Bonds',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'DBBFBF1D-0401-4920-A97A-19B57AEB4B57-000D',
              'name': 'Savos GMS High Dividend, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '9E87C88765EA6482C1C443987A84E0B3',
          'groupName': 'State Street Global Sector Rotation',
          'isFavourite': false,
          'products': [
            {
              'id': '5EE830F1-11FC-4404-A380-EFDC505FA682-000D',
              'name': 'SSGA, Global Sector Rotation, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '82D4DB1F-B5A2-4249-B227-5225E07A60E8-000D',
              'name': 'SSGA, Global Sector Rotation, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '8E5CCB2D-E878-4F07-A5E5-79701F3805A1-000D',
              'name': 'SSGA, Global Sector Rotation, Profile 4, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '99496FA6-C380-4618-A2EE-045BB5BDA927-000D',
              'name': 'SSGA, Global Sector Rotation, Profile 1, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'C1D402A7-A248-4AF2-A891-40CFCF15BA85-000D',
              'name': 'SSGA, Global Sector Rotation, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'E9FDCD02-7258-4E51-A15F-99716F6A5C91-000D',
              'name': 'SSGA, Global Sector Rotation, Profile 2, Moderate Conserv.',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '7A2A058C668AEF4442A7043118FFEE09',
          'groupName': 'JPMorgan U.S. Value',
          'isFavourite': false,
          'products': [
            {
              'id': '60357D79-E804-48B4-9ED7-FB81A48A19D8-000D',
              'name': 'JPMorgan U.S. Value',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '100000.000000',
              'enforcedInvestmentMinimum': 90000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '79D424EEF0345A14A38D488FC96CF7F6',
          'groupName': 'Aris Personal Social',
          'isFavourite': false,
          'products': [
            {
              'id': '60569F8E-BA84-432E-A501-00D0B0003448-000D',
              'name': 'Aris Personal Values - Social, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '77CA36E4-FA42-4089-9F03-2EA4F0FCB0C5-000D',
              'name': 'Aris Personal Values - Social, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'AE85C637-2209-48F8-9E28-F8565F646DE2-000D',
              'name': 'Aris Personal Values - Social, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'FA813592-4C64-4740-8BA0-4DFACB20BE81-000D',
              'name': 'Aris Personal Values - Social, Profile 2, Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '609BA686F52334AF59184227F9D43EE1',
          'groupName': 'JPMorgan Multi-Asset Income',
          'isFavourite': false,
          'products': [
            {
              'id': '62289531-6667-4BB3-9422-8996503DD0FB-000D',
              'name': 'JPMorgan, MAI, Profile 2, Moderate Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '63686730-C46A-49FB-8D53-C72DE78921F8-000D',
              'name': 'JPMorgan, MAI, Profile 4, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '65C33FCB-08EF-4966-922A-F67C4EA0A8CC-000D',
              'name': 'JPMorgan, MAI, Profile 3, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '7602F06EC7A4F2E0BDC7512647C5ABDD',
          'groupName': 'Savos GMS Global',
          'isFavourite': false,
          'products': [
            {
              'id': '63B4F362-3E7A-48DE-AB21-EC5F3C886BE6-000D',
              'name': 'Savos GMS Global, Profile 5, Growth High Income',
              'riskProfile': 5.0,
              'profileName': '5 - Growth High Income',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '8A0E94E6-557B-41A2-BCF3-E69385A84F93-000D',
              'name': 'Savos GMS Global, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'B0D5E393-B18E-4AB2-ABDB-F8D4209FF6C8-000D',
              'name': 'Savos GMS Global, Profile 4, Moderate Growth Inv Grade Bonds',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth Invesment Grade Bonds',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'C9DE6625-780A-4D6B-8561-74CD78D34A4D-000D',
              'name': 'Savos GMS Global, Profile 3, Moderate Investment Grade Bonds',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate Investment Grade Bonds',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '43ACD41B4F16E380AD91ECA90C011A37',
          'groupName': 'BlackRock Target Allocation ESG',
          'isFavourite': false,
          'products': [
            {
              'id': '640C1466-6540-4AAF-88D5-0AEC5DD1E34C-000D',
              'name': 'BlackRock Target Allocation ESG Models Profile 2',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'A531B24C-EFD2-44FB-AA82-4F875DDA1AFC-000D',
              'name': 'BlackRock Target Allocation ESG Models Profile 3',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'B33C7FEF-DCB6-4758-9311-1B40EBE1C01E-000D',
              'name': 'BlackRock Target Allocation ESG Models, Profile 4',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'C34A91D9-29CC-4535-89CE-F16867CC80FE-000D',
              'name': 'BlackRock Target Allocation ESG Models, Profile 6',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '903C3F99653580E51EA30EEB70097E24',
          'groupName': 'Aris Income Builder',
          'isFavourite': false,
          'products': [
            {
              'id': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'name': 'Aris Income Builder, Profile 2, Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Conservative',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': false,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'E031DAE2F71B7D92922693C4AB10BA5B',
          'groupName': 'William Blair Large Cap Growth',
          'isFavourite': false,
          'products': [
            {
              'id': '66F731BF-2988-4120-97C2-7F1A2880D254-000D',
              'name': 'William Blair Large Cap Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '100000.000000',
              'enforcedInvestmentMinimum': 100000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '7BDE240BDCFE2D9E615D33A214006F59',
          'groupName': 'Savos Fixed Income Short Duration',
          'isFavourite': false,
          'products': [
            {
              'id': '6CD1043A-F103-4E5B-89D6-AA485A609169-000D',
              'name': 'Savos Fixed Income Portfolio, Short Duration',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0030000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '556294DD8DCC6400F998C9E31B105529',
          'groupName': 'Savos PMP High Dividend Global - Municipal',
          'isFavourite': false,
          'products': [
            {
              'id': '6D846CDA-DBB1-49CF-B98A-0D134B1973BF-000D',
              'name': 'Savos PMP High Dividend Global, Prof 4, Moderate Muni',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Municipal',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '754F7982-DD09-4069-9EB0-FE8088FC1227-000D',
              'name': 'Savos PMP High Dividend Global, Profile 3, Moderate Muni',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate Municipal',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '04A491014A36AF25EC28FF7AC59135B3',
          'groupName': 'Aris Income Builder, Tax Sensitive',
          'isFavourite': false,
          'products': [
            {
              'id': '6DA9677B-8A5E-48B9-BEC3-C7A42788D371-000D',
              'name': 'Aris Income Builder, TS, Profile 2, Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Conservative',
              'fee': 0.0045000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '4D5613DC0B50B412E386AD18B0779E71',
          'groupName': 'Savos Fixed Income Long Duration',
          'isFavourite': false,
          'products': [
            {
              'id': '6DD8C9A9-0042-445C-A7C0-44D74CC73A14-000D',
              'name': 'Savos Fixed Income Portfolio, Long Duration',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0030000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '7052390349D83876E3F5F1912AFF2A58',
          'groupName': 'Capital Group Global Equity',
          'isFavourite': false,
          'products': [
            {
              'id': '6F37D4EC-B518-401B-A0F1-F08DDCD4F368-000D',
              'name': 'Capital Group Global Equity ',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '100000.000000',
              'enforcedInvestmentMinimum': 100000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'F868F2A45C60DDAAF30305ACEB9A4CC1',
          'groupName': 'New Frontier Global Standard, Tax Sensitive',
          'isFavourite': false,
          'products': [
            {
              'id': '70E5A6C6-364C-4D6B-845A-918C6C97002A-000D',
              'name': 'New Frontier ETF, Profile 6, TS, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': '85D3D13F-167B-4BD1-848A-3369EF2997A3-000D',
              'name': 'New Frontier ETF, Profile 5, TS, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'BEFE31E7-E93C-465F-861B-D5860A73EA58-000D',
              'name': 'New Frontier ETF, Profile 4, TS, Moderate Growth',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'C045CBE4-5946-4B15-B23E-6F39D45DBC2C-000D',
              'name': 'New Frontier ETF, Profile 1, TS, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'E997095E-DF37-451D-96A8-147A2DB0A3D5-000D',
              'name': 'New Frontier ETF, Profile 3, TS, Moderate',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'FC7EB76F-763F-402C-A587-7F52F918B752-000D',
              'name': 'New Frontier ETF, Profile 2, TS, Moderate Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0070000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '23F625087B687BF61AE51A875738BA20',
          'groupName': 'Federated Hermes Strategic Value Dividend',
          'isFavourite': false,
          'products': [
            {
              'id': '70EFA3FE-50C0-46C8-A20A-9DC6ACC6D234-000D',
              'name': 'Federated Hermes Strategic Value Dividend ',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '50000.000000',
              'enforcedInvestmentMinimum': 45000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '9DA3DE6148740330EDFDFAE767CE9434',
          'groupName': 'Savos Fixed Income Intermediate Duration',
          'isFavourite': false,
          'products': [
            {
              'id': '71A4BC15-5E37-426F-BA52-99C3ED9D8B01-000D',
              'name': 'Savos Fixed Income Portfolio, Intermediate Duration',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0030000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '0911B158183222EF1580E3421471F68C',
          'groupName': 'Brown Advisory Large-Cap Sustainable Growth',
          'isFavourite': false,
          'products': [
            {
              'id': '753632E3-259D-47DB-B0AF-757AF9DFC7EA-000D',
              'name': 'Brown Advisory Large-Cap Sustainable Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '100000.000000',
              'enforcedInvestmentMinimum': 100000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'AB32D2D691B921EAFA9D1CF375AE9152',
          'groupName': 'VanEck Morningstar Wide Moat',
          'isFavourite': false,
          'products': [
            {
              'id': '75ED71E0-FAE5-40F4-8192-BDE794755E7D-000D',
              'name': 'VanEck Morningstar Wide Moat',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '50000.000000',
              'enforcedInvestmentMinimum': 50000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '2DAE0797B7356C5135CD37666E21AF2A',
          'groupName': 'AlphaSimplex Risk Efficient Alternatives',
          'isFavourite': false,
          'products': [
            {
              'id': '7D7FDDC2-9FDE-42A2-B25C-9750DF95E04F-000D',
              'name': 'AlphaSimplex, Alternative Model Portfolio, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'BAD53F51B0D2A2AD56DB1424BC5C7FEF',
          'groupName': 'Savos GMS Global with Dynamic Hedging',
          'isFavourite': false,
          'products': [
            {
              'id': '824C0799-4E86-416F-A57A-1039DB001DC9-000D',
              'name': 'Savos GMS Global - Dyn Hedging, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '991A938E1CEE26E908129B2CF15F4453',
          'groupName': 'Dorsey Wright Tactical Fixed Income',
          'isFavourite': false,
          'products': [
            {
              'id': '969C3962-3AE2-4269-BE57-C8FA3BDBCD5A-000D',
              'name': 'Dorsey Wright Tactical Fixed Income',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '64F4D7717E52DC0946AB460FD58E1FC0',
          'groupName': 'Savos Preservation Strategy',
          'isFavourite': false,
          'products': [
            {
              'id': '9B4EB1D8-9DED-4CF8-AB53-20F68FD3FC81-000D',
              'name': 'Savos Preservation Strategy',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '01B94BDBCE8A50FF23B7ED27ADB15BC2',
          'groupName': 'DoubleLine Shiller Enhanced CAPE',
          'isFavourite': false,
          'products': [
            {
              'id': '9D1B89F9-8485-4750-851B-2DE194DB98A1-000D',
              'name': 'DoubleLine Shiller Enhanced CAPE - Class I',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '6BBC7263CDD317892E66E734AF006FBD',
          'groupName': 'WestEnd Global Equity',
          'isFavourite': false,
          'products': [
            {
              'id': '9EF7F250-EFA3-4102-9D18-CF4BE5F70A76-000D',
              'name': 'WestEnd Global Equity ETF, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '0ED8BCFD4B861CC9DD2519D93CA7D760',
          'groupName': 'Stone Ridge Diversified Alternatives Fund Strategy',
          'isFavourite': false,
          'products': [
            {
              'id': 'A2EBE227-E0AE-4216-80D0-0B036A72013E-000D',
              'name': 'Stone Ridge Diversified Alternatives Fund',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'DE823FE7CCE4D9E1B66A62AB99B9FA98',
          'groupName': 'GPS Focused Low Volatility',
          'isFavourite': false,
          'products': [
            {
              'id': 'A869ED69-B8F3-4F5E-BB4E-7AB63C64B682-000D',
              'name': 'GPS Focused Low Volatility, P1',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '68A9B655C171C89EE8433999793A1EB7',
          'groupName': 'Savos Fixed Income High Yield',
          'isFavourite': false,
          'products': [
            {
              'id': 'A9AF6E3B-1B39-4340-8B8B-088DEFF883AB-000D',
              'name': 'Savos Fixed Income Portfolio, High Yield',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0030000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '5A2FC3D405C2AB4D89B1DFC920BF2E3A',
          'groupName': 'Savos Fixed Income Municipal',
          'isFavourite': false,
          'products': [
            {
              'id': 'B100E6CF-FCFF-4AAA-848D-E8515E2AE272-000D',
              'name': 'Savos Municipal Portfolio, National',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0030000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '737CD02978DA850633DAA1EE8F7EE4E6',
          'groupName': 'BlackRock Multi-Asset Income',
          'isFavourite': false,
          'products': [
            {
              'id': 'B1D6821C-8AD4-4AA1-9A17-393FCF3D5694-000D',
              'name': 'BlackRock, MAI, Profile 2, Moderate Conservative',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '5E8118F3EE7B935BC3545B17B4C3C291',
          'groupName': 'Capital Group International Equity',
          'isFavourite': false,
          'products': [
            {
              'id': 'B79DFBB4-C9C2-4AED-9F50-666D80ECC9FF-000D',
              'name': 'Capital Group International Equity',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '100000.000000',
              'enforcedInvestmentMinimum': 100000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '1859ABCD4ABC98CB38B3D0F8A18DC4D7',
          'groupName': 'Principal SMA U.S. Real Estate Equity Securities',
          'isFavourite': false,
          'products': [
            {
              'id': 'B814E9A8-491F-40E3-869D-C77CACE5AFE4-000D',
              'name': 'Principal U.S. Real Estate Equity Securities',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0080000000,
              'displayInvestmentMinimum': '50000.000000',
              'enforcedInvestmentMinimum': 50000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '2E20E90FBC0A37CAEC29A63BED773EED',
          'groupName': 'AssetMark Managed Futures Strategy Fund',
          'isFavourite': false,
          'products': [
            {
              'id': 'B8C739D4-8514-4906-9704-7AFA73765BB9-000D',
              'name': 'AssetMark Managed Futures Strategy Fund',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'A10703544003F779FAB94C2AD9A1CB2C',
          'groupName': 'Capital Group Global Growth Equity',
          'isFavourite': false,
          'products': [
            {
              'id': 'B8CD7F7A-6A77-4AEF-9D5C-FD3AEC6657CA-000D',
              'name': 'Capital Group Global Growth Equity ',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '100000.000000',
              'enforcedInvestmentMinimum': 100000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '852EDAC698C54F2A9E0B2333A49EB27B',
          'groupName': 'American Funds Retirement Income',
          'isFavourite': false,
          'products': [
            {
              'id': 'BD8F0FC2-95B1-4A0F-AB45-494C4C4C6424-000D',
              'name': 'American Funds Retirement Income - Enhanced, Profile 3',
              'riskProfile': 3.0,
              'profileName': '3 - Enhanced',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'BE20418D-478C-41ED-9AC0-487DE715C048-000D',
              'name': 'American Funds Retirement Income - Conservative, Profile 1',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'E36ECA18-A22C-4266-B4CE-FBE59BB76877-000D',
              'name': 'American Funds Retirement Income - Moderate, Profile 2',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '9267E84E72EF64D89BD44D6D97ED67F9',
          'groupName': 'Savos US Risk Controlled Strategy',
          'isFavourite': false,
          'products': [
            {
              'id': 'BE8A2A35-5FCB-4DC5-921F-1F544D295131-000D',
              'name': 'Savos US Risk Controlled Strategy, Profile 6',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0090000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 20000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '452086D4C07744D0FA8B8CC09B157306',
          'groupName': 'Principal Edge Equity Income',
          'isFavourite': false,
          'products': [
            {
              'id': 'C19E0DC4-11DF-436F-8967-68337E1B95AA-000D',
              'name': 'Principal Edge Equity Income',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '50000.000000',
              'enforcedInvestmentMinimum': 50000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'A2B11EA1D1B44B651D492E03DF6DAB66',
          'groupName': 'Savos GMS Global - Municipal',
          'isFavourite': false,
          'products': [
            {
              'id': 'C2D7D6C0-7FA2-45DB-9D05-D074F6EB8140-000D',
              'name': 'Savos GMS Global, Profile 4, Moderate Municipal',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Municipal',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            },
            {
              'id': 'EA3696F8-4950-4190-9CFC-A7C5B52994A0-000D',
              'name': 'Savos GMS Global, Profile 3, Moderate Municipal',
              'riskProfile': 3.0,
              'profileName': '3 - Moderate Municipal',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '3507257FDC375DFB39C15A78F895F84E',
          'groupName': 'Julex Dynamic Sector',
          'isFavourite': false,
          'products': [
            {
              'id': 'D5D5780D-ACF5-4B09-9E83-CB372D4B3548-000D',
              'name': 'Julex, Dynamic US Sector, Profile 6, Maximum Growth',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'CF267C19AC6145D8F67616FD24BD3862',
          'groupName': 'BlackRock Risk Focused Income',
          'isFavourite': false,
          'products': [
            {
              'id': 'DEDA9439-B444-4C67-8AD5-0FB2158D2685-000D',
              'name': 'BlackRock, Risk Focused Income, Profile 1, Conservative',
              'riskProfile': 1.0,
              'profileName': '1 - Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'FB184FB9A74DA1A43C850D29549B855E',
          'groupName': 'PIMCO Tactical Income Focus',
          'isFavourite': false,
          'products': [
            {
              'id': 'E321EADC-945F-47D1-9FFF-A034F4EFA295-000D',
              'name': 'PIMCO Tactical Income Focus',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'E480C235DEAC0768EC10C6EFE46C520C',
          'groupName': 'First Trust Vest Laddered US Equity Buffer ETF Model',
          'isFavourite': false,
          'products': [
            {
              'id': 'E348FB28-6E1D-439E-99DC-744A7DC64E81-000D',
              'name': 'First Trust Vest Laddered US Equity Buffer ETF Model',
              'riskProfile': 4.0,
              'profileName': '4 - Moderate Growth',
              'fee': 0.0050000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'ACB83720F1A88187D44F5679800FFE75',
          'groupName': 'First Trust Alternatives',
          'isFavourite': false,
          'products': [
            {
              'id': 'E355ECC1-ECFC-437A-A6E9-8B74871D4C8A-000D',
              'name': 'First Trust Alternatives',
              'riskProfile': 2.0,
              'profileName': '2 - Moderate Conservative',
              'fee': 0.0060000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '10FE94B009F5F7DB4EB96C53F0BF09BA',
          'groupName': 'PIMCO TRENDS Managed Futures Fund Strategy',
          'isFavourite': false,
          'products': [
            {
              'id': 'E95E5A76-B94F-4C6C-9396-153B1A78DB09-000D',
              'name': 'PIMCO TRENDS Managed Futures Fund Strategy',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0025000000,
              'displayInvestmentMinimum': '10000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '73FDEFFD14D1397CA7E5EEDC31623708',
          'groupName': 'Neuberger Berman Disrupters Portfolio',
          'isFavourite': false,
          'products': [
            {
              'id': 'EF422D32-D2FE-4809-B0FC-40A53F35B168-000D',
              'name': 'Neuberger Berman Disrupters Portfolio',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '100000.000000',
              'enforcedInvestmentMinimum': 100000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '012AD06E05FD36346862468817C93722',
          'groupName': 'Savos GMS High Dividend with Dynamic Hedging',
          'isFavourite': false,
          'products': [
            {
              'id': 'EFC7A137-D92C-4166-AE97-914CB8F7E41F-000D',
              'name': 'Savos GMS Hi Div - Dyn Hedging, Profile 5, Growth',
              'riskProfile': 5.0,
              'profileName': '5 - Growth',
              'fee': 0.0100000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 22500.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '08FEA2969BEC9A38A911338AB041536E',
          'groupName': 'Franklin Templeton DynaTech',
          'isFavourite': false,
          'products': [
            {
              'id': 'F0009D37-7AB6-4C7A-88B5-2497CE4E696A-000D',
              'name': 'Franklin Templeton DynaTech',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0075000000,
              'displayInvestmentMinimum': '100000.000000',
              'enforcedInvestmentMinimum': 100000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': '37F76E1FE3BD0828277E3B47A59274E9',
          'groupName': 'VanEck Thematic Disruption',
          'isFavourite': false,
          'products': [
            {
              'id': 'F0E45448-A8B7-493F-8310-71A948D20C3F-000D',
              'name': 'VanEck Thematic Disruption',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0065000000,
              'displayInvestmentMinimum': '25000.000000',
              'enforcedInvestmentMinimum': 1000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        },
        {
          'id': 'C91DBB70DA7EFFE616D2C7A61F0B3677',
          'groupName': 'Acadian International ADR Non-US Equity',
          'isFavourite': false,
          'products': [
            {
              'id': 'FB19DCB2-2694-4E8C-8524-82A7E435EC7B-000D',
              'name': 'Acadian International ADR Non-U.S. Equity',
              'riskProfile': 6.0,
              'profileName': '6 - Maximum Growth',
              'fee': 0.0080000000,
              'displayInvestmentMinimum': '100000.000000',
              'enforcedInvestmentMinimum': 100000.000000,
              'currency': 'USD',
              'tmsEligibility': true,
              'bicEligibility': true
            }
          ]
        }
      ],
      'error': {
        'message': '',
        'code': 200
      }
    }
  }
}
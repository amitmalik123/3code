export class BicSelectInvestmentMock {

  public static get data() {
    return {
      'data': [
        {
          'id': 'long-list-product-group-0',
          'groupName': 'AlpSlex Risk Sient AlternaT AlpSlex Risk Sient AlternaT AlpSlex Risk Sient Alter Sient Alt',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-0-0',
              'name': 'AlpSlex Risk Sient AlternaT AlpSlex Risk Sient AlternaT AlpSlex Risk Sient Alter Sient Alt',
              'profileName': '0-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': false,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 100500
            }
          ]
        },
        {
          'id': 'long-list-product-group-1',
          'groupName': '1 AlphaSimplex Risk Sient AlternaT 1 AlphaSimplex Risk Sient AlternaT 1 AlphaSimplex Risk Sient AlternaT',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-1-0',
              'name': '1-0 AlphaSimplex Risk Sient TernaT Conservative',
              'profileName': '1-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 201000
            },
            {
              'id': 'long-list-product-1-1',
              'name': '1-1 AlphaSimplex Risk Sient AlternaT Conservative',
              'profileName': '1-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 201000
            }
          ]
        },
        {
          'id': 'long-list-product-group-2',
          'groupName': '2 AlphaSimplex Risk Sient TernaT',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-2-0',
              'name': '2-0 AlphaSimplex Risk Sient TernaT Conservative',
              'profileName': '2-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-2-1',
              'name': '2-1 AlphaSimplex Risk Sient TernaT Conservative',
              'profileName': '2-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-2-2',
              'name': '2-2 AlphaSimplex Risk Sient TernaT Conservative',
              'profileName': '2-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            }
          ]
        },
        {
          'id': 'long-list-product-group-3',
          'groupName': '3 AlphaSimplex Risk Sient TernaT',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-3-0',
              'name': '3-0 AlphaSimplex Risk Sient TernaT Conservative',
              'profileName': '3-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-3-1',
              'name': '3-1 AlphaSimplex Risk Sient TernaT Conservative',
              'profileName': '3-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-3-2',
              'name': '3-2 AlphaSimplex Risk Sient TernaT Conservative',
              'profileName': '3-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-3-3',
              'name': '3-3 AlphaSimplex Risk Sient TernaT Conservative',
              'profileName': '3-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            }
          ]
        },
        {
          'id': 'long-list-product-group-4',
          'groupName': '4 AlphaSimplex Risk Sient TernaT',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-4-0',
              'name': '4-0 AlphaSimplex Risk Sient TernaT Conservative',
              'profileName': '4-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-4-1',
              'name': '4-1 AlphaSimplex Risk Sient TernaT Conservative',
              'profileName': '4-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-4-2',
              'name': '4-2 AlphaSimplex Risk Sient Ternatives Conservative',
              'profileName': '4-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-4-3',
              'name': '4-3 AlphaSimplex Risk Sient Ternatives Conservative',
              'profileName': '4-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-4-4',
              'name': '4-4 AlphaSimplex Risk Sient Ternatives Conservative',
              'profileName': '4-4 Conservative',
              'riskProfile': 5,
              'fee': 0.016,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            }
          ]
        },
        {
          'id': 'long-list-product-group-5',
          'groupName': '5 AlphaSimplex Risk Sient TSos',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-5-0',
              'name': '5-0 AlphaSimplex Risk Sient TSos Conservative',
              'profileName': '5-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-5-1',
              'name': '5-1 AlphaSimplex Risk Sient TSos Conservative',
              'profileName': '5-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-5-2',
              'name': '5-2 AlphaSimplex Risk Sient TSos Conservative',
              'profileName': '5-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-5-3',
              'name': '5-3 AlphaSimplex Risk Sient TSos Conservative',
              'profileName': '5-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-5-4',
              'name': '5-4 AlphaSimplex Risk Sient TSos Conservative',
              'profileName': '5-4 Conservative',
              'riskProfile': 5,
              'fee': 0.016,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-5-5',
              'name': '5-5 AlphaSimplex Risk Efficient TSos Conservative',
              'profileName': '5-5 Conservative',
              'riskProfile': 6,
              'fee': 0.02,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            }
          ]
        },
        {
          'id': 'long-list-product-group-6',
          'groupName': '6 AlpSlex Risk Efficient TSos',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-6-0',
              'name': '6-0 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '6-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 100500
            }
          ]
        },
        {
          'id': 'long-list-product-group-7',
          'groupName': '7 AlpSlex Risk Efficient TSos',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-7-0',
              'name': '7-0 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '7-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 201000
            },
            {
              'id': 'long-list-product-7-1',
              'name': '7-1 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '7-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 201000
            }
          ]
        },
        {
          'id': 'long-list-product-group-8',
          'groupName': '8 AlpSlex Risk Efficient TSos',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-8-0',
              'name': '8-0 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '8-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-8-1',
              'name': '8-1 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '8-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-8-2',
              'name': '8-2 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '8-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            }
          ]
        },
        {
          'id': 'long-list-product-group-9',
          'groupName': '9 AlpSlex Risk Efficient TSos',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-9-0',
              'name': '9-0 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '9-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-9-1',
              'name': '9-1 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '9-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-9-2',
              'name': '9-2 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '9-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-9-3',
              'name': '9-3 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '9-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            }
          ]
        },
        {
          'id': 'long-list-product-group-10',
          'groupName': '10 AlpSlex Risk Efficient TSos',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-10-0',
              'name': '10-0 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '10-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-10-1',
              'name': '10-1 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '10-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-10-2',
              'name': '10-2 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '10-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-10-3',
              'name': '10-3 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '10-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-10-4',
              'name': '10-4 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '10-4 Conservative',
              'riskProfile': 6,
              'fee': 0.016,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            }
          ]
        },
        {
          'id': 'long-list-product-group-11',
          'groupName': '11 AlpSlex Risk Efficient TSos',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-11-0',
              'name': '11-0 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '11-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-11-1',
              'name': '11-1 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '11-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-11-2',
              'name': '11-2 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '11-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-11-3',
              'name': '11-3 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '11-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-11-4',
              'name': '11-4 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '11-4 Conservative',
              'riskProfile': 5,
              'fee': 0.016,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-11-5',
              'name': '11-5 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '11-5 Conservative',
              'riskProfile': 6,
              'fee': 0.02,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            }
          ]
        },
        {
          'id': 'long-list-product-group-12',
          'groupName': '12 AlpSlex Risk Efficient TerSes',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-12-0',
              'name': '12 AlpSlex Risk Efficient TerSes',
              'profileName': '12-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': false,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 100500
            }
          ]
        },
        {
          'id': 'long-list-product-group-13',
          'groupName': '13 AlpSlex Risk Efficient TerSes',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-13-0',
              'name': '13 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '13-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 201000
            },
            {
              'id': 'long-list-product-13-1',
              'name': '13-1 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '13-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 201000
            }
          ]
        },
        {
          'id': 'long-list-product-group-14',
          'groupName': '14 AlpSlex Risk Efficient TerSes',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-14-0',
              'name': '14-0 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '14-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-14-1',
              'name': '14-1 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '14-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-14-2',
              'name': '14-2 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '14-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            }
          ]
        },
        {
          'id': 'long-list-product-group-15',
          'groupName': '15 AlpSlex Risk Efficient TerSes',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-15-0',
              'name': '15-0 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '15-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-15-1',
              'name': '15-1 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '15-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-15-2',
              'name': '15-2 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '15-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-15-3',
              'name': '15-3 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '15-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            }
          ]
        },
        {
          'id': 'long-list-product-group-16',
          'groupName': '16 AlpSlex Risk Efficient TerSes',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-16-0',
              'name': '16-0 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '16-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-16-1',
              'name': '16-1 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '16-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-16-2',
              'name': '16-2 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '16-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-16-3',
              'name': '16-3 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '16-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-16-4',
              'name': '16-4 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '16-4 Conservative',
              'riskProfile': 5,
              'fee': 0.016,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            }
          ]
        },
        {
          'id': 'long-list-product-group-17',
          'groupName': '17 AlpSlex Risk Efficient TerSes',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-17-0',
              'name': '17-0 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '17-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-17-1',
              'name': '17-1 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '17-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-17-2',
              'name': '17-2 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '17-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-17-3',
              'name': '17-3 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '17-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-17-4',
              'name': '17-4 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '17-4 Conservative',
              'riskProfile': 5,
              'fee': 0.016,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-17-5',
              'name': '17-5 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '17-5 Conservative',
              'riskProfile': 6,
              'fee': 0.02,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            }
          ]
        },
        {
          'id': 'long-list-product-group-18',
          'groupName': '18 AlpSlex Risk Efficient TerSes',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-18-0',
              'name': '18-0 AlpSlex Risk Efficient TerSes Conservative',
              'profileName': '18-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 100500
            }
          ]
        },
        {
          'id': 'long-list-product-group-19',
          'groupName': '19 AlpSlex Risk Efficient TSos',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-19-0',
              'name': '19-0 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '19-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 201000
            },
            {
              'id': 'long-list-product-19-1',
              'name': '19-1 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '19-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 201000
            }
          ]
        },
        {
          'id': 'long-list-product-group-20',
          'groupName': '20 AlpSlex Risk Efficient TSos',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-20-0',
              'name': '20-0 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '20-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-20-1',
              'name': '20-1 AlpSlex Risk Efficient TSos Conservative',
              'profileName': '20-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-20-2',
              'name': '20-2 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '20-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            }
          ]
        },
        {
          'id': 'long-list-product-group-21',
          'groupName': '21 AlpSlex Risk Sient Ternatives',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-21-0',
              'name': '21-0 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '21-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-21-1',
              'name': '21-1 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '21-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-21-2',
              'name': '21-2 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '21-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-21-3',
              'name': '21-3 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '21-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            }
          ]
        },
        {
          'id': 'long-list-product-group-22',
          'groupName': '22 AlpSlex Risk Sient Ternati',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-22-0',
              'name': '22-0 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '22-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 502500
            },
            {
              'id': 'long-list-product-22-1',
              'name': '22-1 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '22-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 502500
            },
            {
              'id': 'long-list-product-22-2',
              'name': '22-2 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '22-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 502500
            },
            {
              'id': 'long-list-product-22-3',
              'name': '22-3 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '22-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 502500
            },
            {
              'id': 'long-list-product-22-4',
              'name': '22-4 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '22-4 Conservative',
              'riskProfile': 5,
              'fee': 0.016,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 502500
            }
          ]
        },
        {
          'id': 'long-list-product-group-23',
          'groupName': '23 AlpSlex Risk Sient Ternati',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-23-0',
              'name': '23-0 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '23-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 603000
            },
            {
              'id': 'long-list-product-23-1',
              'name': '23-1 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '23-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 603000
            },
            {
              'id': 'long-list-product-23-2',
              'name': '23-2 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '23-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 603000
            },
            {
              'id': 'long-list-product-23-3',
              'name': '23-3 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '23-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 603000
            },
            {
              'id': 'long-list-product-23-4',
              'name': '23-4 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '23-4 Conservative',
              'riskProfile': 5,
              'fee': 0.016,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 603000
            },
            {
              'id': 'long-list-product-23-5',
              'name': '23-5 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '23-5 Conservative',
              'riskProfile': 6,
              'fee': 0.02,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 603000
            }
          ]
        },
        {
          'id': 'long-list-product-group-24',
          'groupName': '24 AlpSlex Risk Sient Ternati',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-24-0',
              'name': '24-0 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '24-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': false,
              'bicEligibility': false,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 100500
            }
          ]
        },
        {
          'id': 'long-list-product-group-25',
          'groupName': '25 AlpSlex Risk Sient Ternati',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-25-0',
              'name': '25-0 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '25-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 201000
            },
            {
              'id': 'long-list-product-25-1',
              'name': '25-1 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '25-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 201000
            }
          ]
        },
        {
          'id': 'long-list-product-group-26',
          'groupName': '26 AlpSlex Risk Sient Ternati',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-26-0',
              'name': '26-0 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '26-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 301500
            },
            {
              'id': 'long-list-product-26-1',
              'name': '26-1 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '26-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 301500
            },
            {
              'id': 'long-list-product-26-2',
              'name': '26-2 AlpSlex Risk Sient Ternati Conservative',
              'profileName': '26-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayIntmentMinimum': '100500',
              'enforcedIntmentMinimum': 301500
            }
          ]
        },
        {
          'id': 'long-list-product-group-27',
          'groupName': '27 AlpSlex Risk Sient Ternati',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-27-0',
              'name': '27-0 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '27-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-27-1',
              'name': '27-1 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '27-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-27-2',
              'name': '27-2 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '27-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-27-3',
              'name': '27-3 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '27-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            }
          ]
        },
        {
          'id': 'long-list-product-group-31',
          'groupName': '31 AlpSlex Risk Sient Ternatives',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-31-0',
              'name': '31-0 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '31-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 201000
            },
            {
              'id': 'long-list-product-31-1',
              'name': '31-1 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '31-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 201000
            }
          ]
        },
        {
          'id': 'long-list-product-group-32',
          'groupName': '32 AlpSlex Risk Sient Ternatives',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-32-0',
              'name': '32-0 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '32-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-32-1',
              'name': '32-1 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '32-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-32-2',
              'name': '32-2 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '32-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            }
          ]
        },
        {
          'id': 'long-list-product-group-33',
          'groupName': '33 AlpSlex Risk Sient Ternatives',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-33-0',
              'name': '33-0 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '33-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-33-1',
              'name': '33-1 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '33-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-33-2',
              'name': '33-2 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '33-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-33-3',
              'name': '33-3 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '33-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            }
          ]
        },
        {
          'id': 'long-list-product-group-34',
          'groupName': '34 AlpSlex Risk Sient Ternatives',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-34-0',
              'name': '34-0 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '34-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-34-1',
              'name': '34-1 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '34-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-34-2',
              'name': '34-2 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '34-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-34-3',
              'name': '34-3 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '34-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-34-4',
              'name': '34-4 AlpSlex Risk Sient Ternatives Conservative',
              'profileName': '34-4 Conservative',
              'riskProfile': 5,
              'fee': 0.016,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            }
          ]
        },
        {
          'id': 'long-list-product-group-35',
          'groupName': '35 AlpSlex Risk Sient Ternatives',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-35-0',
              'name': '35-0 AlphaSimplex Risk Sient Ternatives Conservative',
              'profileName': '35-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-35-1',
              'name': '35-1 AlphaSimplex Risk Sient Alternatives Conservative',
              'profileName': '35-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-35-2',
              'name': '35-2 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '35-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-35-3',
              'name': '35-3 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '35-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-35-4',
              'name': '35-4 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '35-4 Conservative',
              'riskProfile': 5,
              'fee': 0.016,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-35-5',
              'name': '35-5 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '35-5 Conservative',
              'riskProfile': 6,
              'fee': 0.02,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            }
          ]
        },
        {
          'id': 'long-list-product-group-36',
          'groupName': '36 AlpSlex Risk Sient AlternaT',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-36-0',
              'name': '36 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '36-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': false,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 100500
            }
          ]
        },
        {
          'id': 'long-list-product-group-37',
          'groupName': '37 AlpSlex Risk Sient AlternaT',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-37-0',
              'name': '37 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '37-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 201000
            },
            {
              'id': 'long-list-product-37-1',
              'name': '37-1 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '37-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 201000
            }
          ]
        },
        {
          'id': 'long-list-product-group-38',
          'groupName': '38 AlpSlex Risk Sient AlternaT',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-38-0',
              'name': '38 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '38-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-38-1',
              'name': '38-1 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '38-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-38-2',
              'name': '38-2 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '38-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            }
          ]
        },
        {
          'id': 'long-list-product-group-39',
          'groupName': '39 AlpSlex Risk Sient AlternaT',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-39-0',
              'name': '39 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '39-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-39-1',
              'name': '39-1 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '39-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-39-2',
              'name': '39-2 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '39-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            },
            {
              'id': 'long-list-product-39-3',
              'name': '39-3 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '39-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': false,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 402000
            }
          ]
        },
        {
          'id': 'long-list-product-group-40',
          'groupName': '40 AlpSlex Risk Sient AlternaT',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-40-0',
              'name': '40 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '40-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-40-1',
              'name': '40-1 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '40-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-40-2',
              'name': '40-2 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '40-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-40-3',
              'name': '40-3 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '40-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            },
            {
              'id': 'long-list-product-40-4',
              'name': '40-4 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '40-4 Conservative',
              'riskProfile': 5,
              'fee': 0.016,
              'tmsEligibility': true,
              'bicEligibility': false,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 502500
            }
          ]
        },
        {
          'id': 'long-list-product-group-41',
          'groupName': '41 AlpSlex Risk Sient AlternaT',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-41-0',
              'name': '41-0 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '41-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-41-1',
              'name': '41-1 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '41-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-41-2',
              'name': '41-2 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '41-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-41-3',
              'name': '41-3 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '41-3 Conservative',
              'riskProfile': 4,
              'fee': 0.012,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-41-4',
              'name': '41-4 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '41-4 Conservative',
              'riskProfile': 5,
              'fee': 0.016,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            },
            {
              'id': 'long-list-product-41-5',
              'name': '41-5 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '41-5 Conservative',
              'riskProfile': 6,
              'fee': 0.02,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 603000
            }
          ]
        },
        {
          'id': 'long-list-product-group-98',
          'groupName': '98 AlpSlex Risk Sient AlternaT',
          'isFavourite': true,
          'products': [
            {
              'id': 'long-list-product-98-0',
              'name': '98-0 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '98-0 Conservative',
              'riskProfile': 1,
              'fee': 0,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-98-1',
              'name': '98-1 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '98-1 Conservative',
              'riskProfile': 2,
              'fee': 0.004,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            },
            {
              'id': 'long-list-product-98-2',
              'name': '98-2 AlpSlex Risk Sient AlternaT Conservative',
              'profileName': '98-2 Conservative',
              'riskProfile': 3,
              'fee': 0.008,
              'tmsEligibility': true,
              'bicEligibility': true,
              'currency': 'usd',
              'displayInvestmentMinimum': '100500',
              'enforcedInvestmentMinimum': 301500
            }
          ]
        }
      ]
    }
  }
}
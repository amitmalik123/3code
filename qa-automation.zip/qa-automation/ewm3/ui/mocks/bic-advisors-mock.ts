export class BicAdvisorsMock {

  public static get data() {
    return {
      'data': [
        {
          'sourceId': 'AGAOSX',
          'name': 'Roni Raup',
          'id': '8B8C8546-1E31-4FE4-B099-E870E80B9000-000D',
          'viewName': 'AGAOSX Roni Raup'
        }
      ],
      'error': {
        'message': '',
        'code': 200
      }
    }
  }
}
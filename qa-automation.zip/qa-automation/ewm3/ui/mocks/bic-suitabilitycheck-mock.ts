export class BicSuitabilityCheckMock {

  public static get data() {
    return {
      'data': [
        {
          'accountId': 'D50453BC-4015-4946-90DE-2F411DC0FB76-000D',
          'isSuitabilityCheckPassed': true,
          'suitabilityFailedReason': 'Suitability check passed'
        },
        {
          'accountId': 'B88EC9C8-685D-4935-B90C-78BAD621A036-000D',
          'isSuitabilityCheckPassed': false,
          'suitabilityFailedReason': "Not suitable for client's risk profile"
        },
        {
          'accountId': 'ACAF3E48-5F77-4D76-9F5A-BE26604B3A30-000D',
          'isSuitabilityCheckPassed': true,
          'suitabilityFailedReason': 'Suitability check passed'
        },
        {
          'accountId': 'B53F7447-E5CC-427C-A5F6-029C142C8268-000D',
          'isSuitabilityCheckPassed': true,
          'suitabilityFailedReason': 'Suitability check passed'
        },
        {
          'accountId': 'FA503CCE-8800-4C4C-BB15-B807148D4AE8-000D',
          'isSuitabilityCheckPassed': true,
          'suitabilityFailedReason': 'Suitability check passed'
        },
        {
          'accountId': '361B4867-72A0-4651-87D6-36BBDA8C790D-000D',
          'isSuitabilityCheckPassed': false,
          'suitabilityFailedReason': "Not suitable for client's risk profile"
        },
        {
          'accountId': '3B931CDF-190D-48B9-890E-66BDDA6EC730-000D',
          'isSuitabilityCheckPassed': true,
          'suitabilityFailedReason': 'Suitability check passed'
        },
        {
          'accountId': '46E5DFA7-6ADF-4642-AFB9-C87DC9728C5A-000D',
          'isSuitabilityCheckPassed': true,
          'suitabilityFailedReason': 'Suitability check passed'
        },
        {
          'accountId': '071A52D6-3EA2-471A-A6A7-3E959A866913-000D',
          'isSuitabilityCheckPassed': true,
          'suitabilityFailedReason': 'Suitability check passed'
        },
        {
          'accountId': '3903EDE0-410B-4885-8D89-0CED5DEB19FD-000D',
          'isSuitabilityCheckPassed': true,
          'suitabilityFailedReason': 'Suitability check passed'
        }
      ],
      'error': {
        'message': '',
        'code': 200
      }
    }
  }
}
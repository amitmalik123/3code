export class BicInvestmentChangeMock {

  public static get data() {
    return {'data':'','error':{'message':'','code':200}}
  }
}
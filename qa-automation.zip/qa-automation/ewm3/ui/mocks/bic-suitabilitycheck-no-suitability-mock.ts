export class BicSuitabilityCheckNoSuitabilityMock {

  public static get data() {
    return {
      'data': [
        {
          'accountId': '0CA8119E-E9D4-42A2-9809-199A614DFFD5-000D',
          'isSuitabilityCheckPassed': true,
          'suitabilityFailedReason': 'Suitability check passed'
        },
        {
          'accountId': '749CDD9B-77D6-495A-B823-0A051968C026-000D',
          'isSuitabilityCheckPassed': true,
          'suitabilityFailedReason': 'Suitability check passed'
        },
        {
          'accountId': 'A9EEAC53-B213-407E-A55F-A43F5FB797A2-000D',
          'isSuitabilityCheckPassed': true,
          'suitabilityFailedReason': 'Suitability check passed'
        }
      ],
      'error': {
        'message': '',
        'code': 200
      }
    }
  }
}
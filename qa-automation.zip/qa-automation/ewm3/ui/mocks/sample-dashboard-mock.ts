export class SampleDashboardMock {

  public static get modifiedSampleDashboard() {
    return {
      'data': [
        {
          'layout': 'lg',
          'widget_setting':  [
            {
              'cmsId': 'client_list',
              'coordinateX': 0,
              'coordinateY': 0,
              'height': 2,
              'width': 2
            },
            {
              'cmsId': 'net_flows',
              'coordinateX': 0,
              'coordinateY': 2,
              'height': 2,
              'width': 2
            },
            {
              'cmsId': 'status_tracking',
              'coordinateX': 0,
              'coordinateY': 4,
              'height': 4,
              'width': 2
            }
          ]
        }
      ],
    }
  }

}

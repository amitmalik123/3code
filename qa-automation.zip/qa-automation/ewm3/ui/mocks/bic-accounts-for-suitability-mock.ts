export class BicAccountsForSuitabilityMock {

  public static get data() {
    return {
      'data': [
        {
          'id': 'D50453BC-4015-4946-90DE-2F411DC0FB76-000D',
          'name': 'Hank Apollaro Traditional IRA',
          'status': 'Active',
          'registrationType': [
            'Traditional IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': true,
          'marketValue': 60299.670000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            '12F53179D35E'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': 'B88EC9C8-685D-4935-B90C-78BAD621A036-000D',
          'name': 'Hank Apollaro Joint Tenant with Rights of Survivorship',
          'status': 'Active',
          'registrationType': [
            'Joint Tenant with Rights of Survivorship'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': true,
          'marketValue': 56388.540000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            'AFD08B719E2C'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': 'B53F7447-E5CC-427C-A5F6-029C142C8268-000D',
          'name': 'Ernesto Deliramich Traditional IRA',
          'status': 'Active',
          'registrationType': [
            'Traditional IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 482302.670000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            '655C812D9449'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': 'ACAF3E48-5F77-4D76-9F5A-BE26604B3A30-000D',
          'name': 'Ernesto Deliramich Traditional IRA',
          'status': 'Active',
          'registrationType': [
            'Traditional IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 206398.860000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            'D98DE7D046AE'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '071A52D6-3EA2-471A-A6A7-3E959A866913-000D',
          'name': 'Nabil Pillsbury SEP-IRA',
          'status': 'Active',
          'registrationType': [
            'SEP-IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 44496.840000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            'F515A19EE687'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '3B931CDF-190D-48B9-890E-66BDDA6EC730-000D',
          'name': 'Nabil Pillsbury Trust',
          'status': 'Active',
          'registrationType': [
            'Trust'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 756998.670000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            '5357D3F03E0D'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': 'FA503CCE-8800-4C4C-BB15-B807148D4AE8-000D',
          'name': 'Nabil Pillsbury Traditional IRA',
          'status': 'Active',
          'registrationType': [
            'Traditional IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 85894.990000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            'A865F733DC64'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '46E5DFA7-6ADF-4642-AFB9-C87DC9728C5A-000D',
          'name': 'Nabil Pillsbury Roth IRA',
          'status': 'Active',
          'registrationType': [
            'Roth IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 40742.032000000000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 0.500000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 0.500000
            },
            {
              'sleeveProductId': '14190BD5-54E7-405B-B729-700E999BE336-000D',
              'productName': 'Logan Global Growth',
              'allocation': 0.500000
            }
          ],
          'accountNumber': [
            'F490C302D6B6'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '361B4867-72A0-4651-87D6-36BBDA8C790D-000D',
          'name': 'Nabil Pillsbury Traditional IRA',
          'status': 'Active',
          'registrationType': [
            'Traditional IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 2350818.210000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            'F51BCD3EA837'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '3903EDE0-410B-4885-8D89-0CED5DEB19FD-000D',
          'name': 'Hicham Kaneshiro Individual',
          'status': 'Active',
          'registrationType': [
            'Individual'
          ],
          'isBICIneligible': true,
          'inEligibilityReason': `Not suitable for client's risk profile`,
          'tmsEligible': false,
          'marketValue': 201497.800000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            '04A761EA2994'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': 'F7791030-1349-4E2D-9A22-CDEB39BBB44C-000D',
          'name': "Ernest O'Reilly Traditional IRA",
          'status': 'Active',
          'registrationType': [
            'Traditional IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 361215.900000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            '3853BDACB106'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': 'F644E6F7-E335-403C-BA8A-C43EF0D004BD-000D',
          'name': 'Shauna Salazar Individual',
          'status': 'Active',
          'registrationType': [
            'Individual'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 865223.953200000000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 0.380000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 0.380000
            },
            {
              'sleeveProductId': 'DEDA9439-B444-4C67-8AD5-0FB2158D2685-000D',
              'productName': 'BlackRock, Risk Focused Income, Profile 1, Conservative',
              'allocation': 0.240000
            },
            {
              'sleeveProductId': '4363FC82-5907-4861-9E25-3A89BA49860F-000D',
              'productName': 'New Frontier ETF, Profile 3, Moderate',
              'allocation': 0.380000
            }
          ],
          'accountNumber': [
            '29FFCFC929D8'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '0707300E-03BE-4F98-A8EE-3DA6D32C8B5D-000D',
          'name': 'Hinda Goldstein Traditional IRA',
          'status': 'Active',
          'registrationType': [
            'Traditional IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 145378.510000000000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 0.500000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 0.500000
            },
            {
              'sleeveProductId': '65D5EF43-8B4A-42D8-8D36-3E7EF10B9E00-000D',
              'productName': 'US Market Blend, Profile 3, Moderate',
              'allocation': 0.500000
            }
          ],
          'accountNumber': [
            '819FB3477E96'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '1C5BC100-563F-4B0E-B10D-641D632D755F-000D',
          'name': 'Hinda Goldstein Roth IRA',
          'status': 'Active',
          'registrationType': [
            'Roth IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 34737.380000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            '9F8BFA13DDE6'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': 'F375F708-A9C4-4951-BDCC-1C2AF0E8700A-000D',
          'name': 'Hinda Goldstein Traditional IRA',
          'status': 'Active',
          'registrationType': [
            'Traditional IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 69748.090000000000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 0.500000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 0.500000
            },
            {
              'sleeveProductId': '65D5EF43-8B4A-42D8-8D36-3E7EF10B9E00-000D',
              'productName': 'US Market Blend, Profile 3, Moderate',
              'allocation': 0.500000
            }
          ],
          'accountNumber': [
            '828B78250EFC'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '55F076D2-3E9C-4E16-AF23-5427A45A48C6-000D',
          'name': 'Joshua Schweihofer Joint Tenant with Rights of Survivorship',
          'status': 'Active',
          'registrationType': [
            'Joint Tenant with Rights of Survivorship'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 403850.350000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            'D88FA11ED5F0'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '56326F94-9942-446A-B4F7-1D7CE9316CEE-000D',
          'name': 'Millu Hankins Joint Tenant with Rights of Survivorship',
          'status': 'Active',
          'registrationType': [
            'Joint Tenant with Rights of Survivorship'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 67009.330000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            'CF4E8A5ABCA3'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '427155CE-C5EB-4C36-A051-6C049471ED62-000D',
          'name': 'Nyle Kojis Individual TOD',
          'status': 'Active',
          'registrationType': [
            'Individual TOD'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 84835.860000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            '950E9DD879C5'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '8F42CD8C-0754-430E-B0AA-9C627DAB1A6C-000D',
          'name': 'Nyle Kojis Traditional IRA',
          'status': 'Active',
          'registrationType': [
            'Traditional IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 83930.690000,
          'productId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': '64387EF4-8EE1-4DE9-BCB5-6FF0373DE973-000D',
              'productName': 'Aris Income Builder, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            'E86BA4C14F66'
          ],
          'requiresSuitabilityCheck': true
        }
      ],
      'error': {
        'message': '',
        'code': 200
      }
    }
  }
}
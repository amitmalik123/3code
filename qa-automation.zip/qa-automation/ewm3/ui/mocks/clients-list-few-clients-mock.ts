export class FewClientsMock {

  public static get data() {
    return {
      data: {
        data: [
          {
            clientName: 'Hartman, Jeff',
            advisorIdentifier: 'AGAT5R',
            numberOfAccounts: 2,
            marketValue: 333375.73,
            expectedAmount: 75000.0,
            establishedDate: '2018-06-26',
            ytdPerformance: 0.0723,
            oneYearPerformance: 0.116,
            threeYearPerformance: 0.0194,
            fiveYearPerformance: 0.0619,
            cumulativeReturn: 25.763893187326858,
            annualizedPerformance: 0.0621,
            netInvestment: 243125.01,
            assetAllocations: [
              {
                assetClass: 'Equity',
                allocationWeight: 0.2
              },
              {
                assetClass: 'FixedIncome',
                allocationWeight: 0.2
              },
              {
                assetClass: 'AlternativeInvestments',
                allocationWeight: 0.2
              },
              {
                assetClass: 'Cash',
                allocationWeight: 0.2
              },
              {
                assetClass: 'CashAlternatives',
                allocationWeight: 0.2
              }
            ],
            webAccess: false,
            id: '029FE02B-7DED-4F43-B1B0-A7E4EB9FCD44-000D',
            clientAplId: 'CB2IR3',
            clientWebId: 'W0W671',
            accounts: [
              {
                id: '0C41536E-7B2D-49A6-8746-2232AD721916-000D',
                title: 'Jeffrey K Hartman, Traditional IRA',
                applicationId: 'AJ4815',
                alerts: [],
                marketValue: 333375.73,
                expectedAmount: 75000.0,
                inceptionDate: '2018-06-26',
                ytdPerformance: 0.0723,
                oneYearPerformance: 0.116,
                threeYearPerformance: 0.02,
                fiveYearPerformance: 0.0623,
                cumulativeReturn: 0.4453077824935424,
                annualizedPerformance: 0.0625,
                bankAccountNumber: '13594548',
                status: 'Active',
                investmentProduct: 'American Funds Moderate Growth and Income, Profile 3',
                assetAllocations: [
                  {
                    assetClass: 'Equity',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'FixedIncome',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'AlternativeInvestments',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'Cash',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'CashAlternatives',
                    allocationWeight: 0.2
                  }
                ]
              },
              {
                id: 'A4626038-D491-415F-A4EC-F406AC3D4DFD-000D',
                title: 'Stefanie P Hartman, Traditional IRA',
                applicationId: 'AJ47X2',
                alerts: [],
                marketValue: 0.0,
                expectedAmount: 105000.0,
                inceptionDate: '2018-06-26',
                bankAccountNumber: '13594554',
                status: 'Terminated',
                investmentProduct: 'American Funds Moderate Growth and Income, Profile 3',
                assetAllocations: [
                  {
                    assetClass: 'Equity',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'FixedIncome',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'AlternativeInvestments',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'Cash',
                    allocationWeight: 0.2
                  },
                  {
                    assetClass: 'CashAlternatives',
                    allocationWeight: 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Lallier, Tracy',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 1,
            'marketValue': 0.0,
            'expectedAmount': 0.0,
            'establishedDate': '2023-08-04',
            'ytdPerformance': 0.0000000000,
            'oneYearPerformance': 0.0000000000,
            'threeYearPerformance': 0.0000000000,
            'fiveYearPerformance': 0.0000000000,
            'cumulativeReturn': 0.0000000000000000000000000000,
            'annualizedPerformance': 0.0000000000,
            'netInvestment': -7228.810000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.0
              }
            ],
            'webAccess': false,
            'id': 'E1F7BB95-3214-4CE2-950E-E23059E444E8-000D',
            'clientAplId': 'CE8RI0',
            'clientWebId': 'W1JIZP',
            'accounts': [
              {
                'id': '09EED91E-1EA9-4C66-A1FC-CC8180F7F711-000D',
                'title': 'Tracy G Lallier Successor Beneficiary, Beneficiary IRA',
                'applicationId': 'AN1825',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 84442.000000,
                'inceptionDate': '2023-08-04',
                'ytdPerformance': 0.0000000000,
                'oneYearPerformance': 0.0000000000,
                'threeYearPerformance': 0.0000000000,
                'fiveYearPerformance': 0.0000000000,
                'cumulativeReturn': 0.0,
                'annualizedPerformance': 0.0000000000,
                'bankAccountNumber': '40205165',
                'status': 'Terminated',
                'investmentProduct': 'Global Market Blend, Profile 3, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'SREERAM PARUPUDI & SAILAJA VALLABHAJOSULA',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 2,
            'marketValue': 750071.5000,
            'expectedAmount': 400000.000000,
            'establishedDate': '2019-05-20',
            'ytdPerformance': 0.0764000000,
            'oneYearPerformance': 0.1068000000,
            'threeYearPerformance': 0.0246000000,
            'fiveYearPerformance': 0.0420000000,
            'cumulativeReturn': 9.643431892002099485573676815,
            'annualizedPerformance': 0.0443000000,
            'netInvestment': 635000.010000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ],
            'webAccess': true,
            'id': 'ED1D533D-2F55-46C2-BAF5-35BF0CEB94F1-000D',
            'clientAplId': 'CB4TC0',
            'clientWebId': 'W0ZR8C',
            'accounts': [
              {
                'id': 'CEEBED9E-39DF-4D33-BED0-10235EE99AB1-000D',
                'title': 'Sreeram Parupudi & Sailaja Vallabhajosula, JTWROS TOD',
                'applicationId': 'AJ9G87',
                'alerts': [],
                'marketValue': 268936.3200,
                'expectedAmount': 250000.000000,
                'inceptionDate': '2019-05-20',
                'ytdPerformance': -0.0076000000,
                'oneYearPerformance': 0.0116000000,
                'threeYearPerformance': -0.0203000000,
                'fiveYearPerformance': 0.0002000000,
                'cumulativeReturn': 0.0057082596835797179899073577,
                'annualizedPerformance': 0.0011000000,
                'bankAccountNumber': '13692788',
                'status': 'Active',
                'investmentProduct': 'Clark Navigator Tax-Free Fixed Income',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
              {
                'id': '100A8B81-B115-49CB-8FD3-38CAE7A245F7-000D',
                'title': 'Sreeram V. J. Parupudi & Sailaja Vallabhajosula, JTTOD',
                'applicationId': 'AK66U9',
                'alerts': [],
                'marketValue': 481135.1800,
                'expectedAmount': 150000.000000,
                'inceptionDate': '2020-06-04',
                'ytdPerformance': 0.1306000000,
                'oneYearPerformance': 0.1699000000,
                'threeYearPerformance': 0.0558000000,
                'fiveYearPerformance': 0.0000000000,
                'cumulativeReturn': 0.4935751312303748591252897676,
                'annualizedPerformance': 0.1019000000,
                'bankAccountNumber': '13811598',
                'status': 'Active',
                'investmentProduct': 'Clark Navigator Personalized UMA, Profile 6, Maximum Growth ',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            'clientName': 'Sommerfeld, William',
            'advisorIdentifier': 'AGAT5R',
            'numberOfAccounts': 1,
            'marketValue': 0.0,
            'expectedAmount': 0.0,
            'establishedDate': '2011-01-11',
            'ytdPerformance': 0.0000000000,
            'oneYearPerformance': 0.1203000000,
            'threeYearPerformance': 0.0116000000,
            'fiveYearPerformance': 0.0521000000,
            'cumulativeReturn': 0.0000000000000000000000000000,
            'annualizedPerformance': 0.0000000000,
            'netInvestment': -69191.090000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.0
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.0
              }
            ],
            'webAccess': false,
            'id': 'F0DCAB83-99B1-4FF3-B7B9-7E5DA6E7C0C8-000D',
            'clientAplId': 'CA0B36',
            'clientWebId': 'W0C1QE',
            'accounts': [
              {
                'id': '1FC76A36-1990-4C7E-82FF-B53FCD9BC006-000D',
                'title': 'William Sommerfeld, Individual',
                'applicationId': 'AC4N07',
                'alerts': [],
                'marketValue': 0.0,
                'expectedAmount': 115000.000000,
                'inceptionDate': '2011-01-11',
                'ytdPerformance': 0.0000000000,
                'oneYearPerformance': -0.7461000000,
                'threeYearPerformance': -0.3778000000,
                'fiveYearPerformance': -0.2192000000,
                'cumulativeReturn': 0.0000000000000000000000000000,
                'annualizedPerformance': 0.0000000000,
                'bankAccountNumber': '13799121',
                'status': 'Terminated',
                'investmentProduct': 'SSGA, Profile 3, Tax-Sensitive, Moderate',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              }
            ]
          },
          {
            clientName: 'Clark, Jeff',
            advisorIdentifier: 'AGAT58',
            numberOfAccounts: 0,
            marketValue: 0.0,
            expectedAmount: 0.0,
            establishedDate: '1970-01-01',
            assetAllocations: [],
            webAccess: false,
            id: 'FBCBCFE8-50E1-4B9E-A3C5-1CCB73D83C83-000D',
            clientAplId: 'CD9QK9',
            clientWebId: 'W15PTM',
            accounts: []
          }
        ],
        start: 0,
        limit: 137,
        total: 137
      },
      error: {
        message: '',
        code: 200
      },
      lastUpdate: {
        value: '2024-07-23T00:00:00+00:00',
        kind: 'CalendarDate'
      }
    }
  }
}

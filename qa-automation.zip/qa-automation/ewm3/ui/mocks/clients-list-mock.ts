import { BaseClientSectionMockData } from '../pages/base-client-section-page'

export class ClientsListMock implements BaseClientSectionMockData {

  get data() {
    return {
      'data': [
        {
          'clientName': '12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890',
          'marketValue': 312462.000000,
          'netInvestments': 524837.580000,
          'ytdPerformance': 0.11500000000000000000,
          'inceptionDate': '20200120',
          'advisorIdentifier': 'AG0003',
          'id': 'C45939-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-005',
          'flagged': false,
          'clientAplId': 'C45939',
          'accounts': [
            {
              'id': 'A00044-VirtualAccount-AaBbCcDd-EeFfGg-P011-005',
              'accountRegistration': 'This Is also an Account With A Super Duper Long Name So We Can See What a Super Duper Long Account Name Looks Like In Each Of The Test Environments Just In Case it Does Not Look Good in Said Environments - Account - 044 Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234528',
              'accountStatus': 'Pending Funding',
              'marketValue': 0.0,
              'investmentStrategy': 'Sample Product - 016',
              'sourceAccounts': [
                {
                  'sourceID': 'A00044',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00044-AaBbCc-DdEdFfGg-SouceAccount-1234528'
                }
              ],
              'accountAplId': 'A00044',
              'pendingAmount': 112417.850000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00010-VirtualAccount-AaBbCcDd-EeFfGg-P011-005',
              'accountRegistration': 'Sammy Indivual',
              'alert': '',
              'alerts': [],
              'accountNumber': '9876502',
              'accountStatus': 'Active',
              'marketValue': 103934.000000,
              'investmentStrategy': 'Sample Product - 007',
              'sourceAccounts': [
                {
                  'sourceID': 'A00010',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00010-AaBbCc-DdEdFfGg-SouceAccount-9876502'
                }
              ],
              'accountAplId': 'A00010',
              'pendingAmount': 106502.530000,
              'pendingDays': 1361,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00011-VirtualAccount-AaBbCcDd-EeFfGg-P011-005',
              'accountRegistration': 'Jones Family Trust',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234502',
              'accountStatus': 'Active',
              'marketValue': 104154.000000,
              'investmentStrategy': 'Sample Product - 008',
              'sourceAccounts': [
                {
                  'sourceID': 'A00011',
                  'sourceSystem': 'PRS',
                  'sourceAccountId': 'A00011-AaBbCc-DdEdFfGg-SouceAccount-1234502'
                }
              ],
              'accountAplId': 'A00011',
              'pendingAmount': 106676.510000,
              'pendingDays': 1358,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00012-VirtualAccount-AaBbCcDd-EeFfGg-P011-005',
              'accountRegistration': 'Sashquash IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': 'N8U000003',
              'accountStatus': 'Active',
              'marketValue': 104374.000000,
              'investmentStrategy': 'Sample Product - 009',
              'sourceAccounts': [
                {
                  'sourceID': 'A00012',
                  'sourceSystem': 'TDA',
                  'sourceAccountId': 'A00012-AaBbCc-DdEdFfGg-SouceAccount-N8U000003'
                }
              ],
              'accountAplId': 'A00012',
              'pendingAmount': 106850.490000,
              'pendingDays': 1355,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Brooklyn Harvey',
          'marketValue': 49259.270000,
          'netInvestments': 1508153.060000,
          'ytdPerformance': 0.09660000000000000000,
          'inceptionDate': '20200102',
          'advisorIdentifier': 'AG0003',
          'id': 'CB0RF3-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-001',
          'flagged': false,
          'clientAplId': 'CB0RF3',
          'accounts': [
            {
              'id': 'A00001-VirtualAccount-AaBbCcDd-EeFfGg-P011-001',
              'accountRegistration': 'Brooklyn Harvey',
              'alert': '',
              'alerts': [],
              'accountNumber': '9876500',
              'accountStatus': 'Active',
              'marketValue': 49259.270000,
              'investmentStrategy': 'Sample Product - 001',
              'sourceAccounts': [
                {
                  'sourceID': 'A00001',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00001-AaBbCc-DdEdFfGg-SouceAccount-9876500'
                }
              ],
              'accountAplId': 'A00001',
              'pendingAmount': 105458.650000,
              'pendingDays': 1379,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Calum Foster',
          'marketValue': 125000.000000,
          'netInvestments': 629222.460000,
          'ytdPerformance': 0.15180000000000000000,
          'inceptionDate': '20230920',
          'advisorIdentifier': 'AG0003',
          'id': 'CB2EK3-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-013',
          'flagged': false,
          'clientAplId': 'CB2EK3',
          'accounts': [
            {
              'id': 'A00060-VirtualAccount-AaBbCcDd-EeFfGg-P011-013',
              'accountRegistration': 'Account - 060 Roth IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234544',
              'accountStatus': 'Active',
              'marketValue': 125000.000000,
              'investmentStrategy': 'Sample Product - 001',
              'sourceAccounts': [
                {
                  'sourceID': 'A00060',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00060-AaBbCc-DdEdFfGg-SouceAccount-1234544'
                }
              ],
              'accountAplId': 'A00060',
              'pendingAmount': 0.000000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Charley Lane',
          'marketValue': 551570.000000,
          'netInvestments': 590078.130000,
          'ytdPerformance': 0.13800000000000000000,
          'inceptionDate': '20230920',
          'advisorIdentifier': 'AG0003',
          'id': 'CE3Q48-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-010',
          'flagged': false,
          'clientAplId': 'CE3Q48',
          'accounts': [
            {
              'id': 'A00038-VirtualAccount-AaBbCcDd-EeFfGg-P011-010',
              'accountRegistration': 'Charley Lane Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234522',
              'accountStatus': 'Active',
              'marketValue': 109874.000000,
              'investmentStrategy': 'Sample Product - 010',
              'sourceAccounts': [
                {
                  'sourceID': 'A00038',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00038-AaBbCc-DdEdFfGg-SouceAccount-1234522'
                }
              ],
              'accountAplId': 'A00038',
              'pendingAmount': 111373.970000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00039-VirtualAccount-AaBbCcDd-EeFfGg-P011-010',
              'accountRegistration': 'Account - 039 IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234523',
              'accountStatus': 'Pending Funding',
              'marketValue': 110094.000000,
              'investmentStrategy': 'Sample Product - 011',
              'sourceAccounts': [
                {
                  'sourceID': 'A00039',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00039-AaBbCc-DdEdFfGg-SouceAccount-1234523'
                }
              ],
              'accountAplId': 'A00039',
              'pendingAmount': 111547.950000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00040-VirtualAccount-AaBbCcDd-EeFfGg-P011-010',
              'accountRegistration': 'Account - 040 Trust',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234524',
              'accountStatus': 'Pending Funding',
              'marketValue': 110314.000000,
              'investmentStrategy': 'Sample Product - 012',
              'sourceAccounts': [
                {
                  'sourceID': 'A00040',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00040-AaBbCc-DdEdFfGg-SouceAccount-1234524'
                }
              ],
              'accountAplId': 'A00040',
              'pendingAmount': 111721.930000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00041-VirtualAccount-AaBbCcDd-EeFfGg-P011-010',
              'accountRegistration': 'Account - 041 Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234525',
              'accountStatus': 'Pending Funding',
              'marketValue': 110534.000000,
              'investmentStrategy': 'Sample Product - 013',
              'sourceAccounts': [
                {
                  'sourceID': 'A00041',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00041-AaBbCc-DdEdFfGg-SouceAccount-1234525'
                }
              ],
              'accountAplId': 'A00041',
              'pendingAmount': 111895.910000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00042-VirtualAccount-AaBbCcDd-EeFfGg-P011-010',
              'accountRegistration': 'Account - 042 Trust',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234526',
              'accountStatus': 'Pending Funding',
              'marketValue': 110754.000000,
              'investmentStrategy': 'Sample Product - 014',
              'sourceAccounts': [
                {
                  'sourceID': 'A00042',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00042-AaBbCc-DdEdFfGg-SouceAccount-1234526'
                }
              ],
              'accountAplId': 'A00042',
              'pendingAmount': 112069.890000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Garfield Lopez',
          'marketValue': 866452.000000,
          'netInvestments': 511789.470000,
          'ytdPerformance': 0.11040000000000000000,
          'inceptionDate': '20200114',
          'advisorIdentifier': 'AG0003',
          'id': 'C71004-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-004',
          'flagged': false,
          'clientAplId': 'C71004',
          'accounts': [
            {
              'id': 'A00008-VirtualAccount-AaBbCcDd-EeFfGg-P011-004',
              'accountRegistration': 'Garfield Lopez IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234501',
              'accountStatus': 'Active',
              'marketValue': 103494.000000,
              'investmentStrategy': 'Sample Product - 005',
              'sourceAccounts': [
                {
                  'sourceID': 'A00008',
                  'sourceSystem': 'PRS',
                  'sourceAccountId': 'A00008-AaBbCc-DdEdFfGg-SouceAccount-1234501'
                }
              ],
              'accountAplId': 'A00008',
              'pendingAmount': 106154.570000,
              'pendingDays': 1367,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00035-VirtualAccount-AaBbCcDd-EeFfGg-P011-004',
              'accountRegistration': 'Lopez, Garfield and Sarah JROS',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234519',
              'accountStatus': 'Active',
              'marketValue': 109214.000000,
              'investmentStrategy': 'Sample Product - 007',
              'sourceAccounts': [
                {
                  'sourceID': 'A00035',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00035-AaBbCc-DdEdFfGg-SouceAccount-1234519'
                }
              ],
              'accountAplId': 'A00035',
              'pendingAmount': 110852.030000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00036-VirtualAccount-AaBbCcDd-EeFfGg-P011-004',
              'accountRegistration': 'Billy Lopez Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234520',
              'accountStatus': 'Active',
              'marketValue': 109434.000000,
              'investmentStrategy': 'Sample Product - 008',
              'sourceAccounts': [
                {
                  'sourceID': 'A00036',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00036-AaBbCc-DdEdFfGg-SouceAccount-1234520'
                }
              ],
              'accountAplId': 'A00036',
              'pendingAmount': 111026.010000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00037-VirtualAccount-AaBbCcDd-EeFfGg-P011-004',
              'accountRegistration': 'Rachel Lopez Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234521',
              'accountStatus': 'Active',
              'marketValue': 109654.000000,
              'investmentStrategy': 'Sample Product - 009',
              'sourceAccounts': [
                {
                  'sourceID': 'A00037',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00037-AaBbCc-DdEdFfGg-SouceAccount-1234521'
                }
              ],
              'accountAplId': 'A00037',
              'pendingAmount': 111199.990000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00031-VirtualAccount-AaBbCcDd-EeFfGg-P011-004',
              'accountRegistration': 'Garfield Lopez 401k',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234515',
              'accountStatus': 'Active',
              'marketValue': 108334.000000,
              'investmentStrategy': 'Sample Product - 003',
              'sourceAccounts': [
                {
                  'sourceID': 'A00031',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00031-AaBbCc-DdEdFfGg-SouceAccount-1234515'
                }
              ],
              'accountAplId': 'A00031',
              'pendingAmount': 110156.110000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00032-VirtualAccount-AaBbCcDd-EeFfGg-P011-004',
              'accountRegistration': 'Garfield Lopez 403b',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234516',
              'accountStatus': 'Active',
              'marketValue': 108554.000000,
              'investmentStrategy': 'Sample Product - 004',
              'sourceAccounts': [
                {
                  'sourceID': 'A00032',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00032-AaBbCc-DdEdFfGg-SouceAccount-1234516'
                }
              ],
              'accountAplId': 'A00032',
              'pendingAmount': 110330.090000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00033-VirtualAccount-AaBbCcDd-EeFfGg-P011-004',
              'accountRegistration': 'Garfield Lopez Roth IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234517',
              'accountStatus': 'Active',
              'marketValue': 108774.000000,
              'investmentStrategy': 'Sample Product - 005',
              'sourceAccounts': [
                {
                  'sourceID': 'A00033',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00033-AaBbCc-DdEdFfGg-SouceAccount-1234517'
                }
              ],
              'accountAplId': 'A00033',
              'pendingAmount': 110504.070000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00034-VirtualAccount-AaBbCcDd-EeFfGg-P011-004',
              'accountRegistration': 'Lopez Family Trust',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234518',
              'accountStatus': 'Active',
              'marketValue': 108994.000000,
              'investmentStrategy': 'Sample Product - 006',
              'sourceAccounts': [
                {
                  'sourceID': 'A00034',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00034-AaBbCc-DdEdFfGg-SouceAccount-1234518'
                }
              ],
              'accountAplId': 'A00034',
              'pendingAmount': 110678.050000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Georgie Meyer',
          'marketValue': 552230.000000,
          'netInvestments': 603126.240000,
          'ytdPerformance': 0.14260000000000000000,
          'inceptionDate': '20200222',
          'advisorIdentifier': 'AG0003',
          'id': 'CE3Q38-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-011',
          'flagged': false,
          'clientAplId': 'CE3Q38',
          'accounts': [
            {
              'id': 'A00043-VirtualAccount-AaBbCcDd-EeFfGg-P011-011',
              'accountRegistration': 'Account - 043 IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234527',
              'accountStatus': 'Pending Funding',
              'marketValue': 110974.000000,
              'investmentStrategy': 'Sample Product - 015',
              'sourceAccounts': [
                {
                  'sourceID': 'A00043',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00043-AaBbCc-DdEdFfGg-SouceAccount-1234527'
                }
              ],
              'accountAplId': 'A00043',
              'pendingAmount': 112243.870000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00045-VirtualAccount-AaBbCcDd-EeFfGg-P011-011',
              'accountRegistration': 'Account - 045 Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234529',
              'accountStatus': 'Pending Funding',
              'marketValue': 111414.000000,
              'investmentStrategy': 'Sample Product - 017',
              'sourceAccounts': [
                {
                  'sourceID': 'A00045',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00045-AaBbCc-DdEdFfGg-SouceAccount-1234529'
                }
              ],
              'accountAplId': 'A00045',
              'pendingAmount': 112591.830000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00046-VirtualAccount-AaBbCcDd-EeFfGg-P011-011',
              'accountRegistration': 'Account - 046 Traditional IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234530',
              'accountStatus': 'Pending Funding',
              'marketValue': 111634.000000,
              'investmentStrategy': 'Sample Product - 018',
              'sourceAccounts': [
                {
                  'sourceID': 'A00046',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00046-AaBbCc-DdEdFfGg-SouceAccount-1234530'
                }
              ],
              'accountAplId': 'A00046',
              'pendingAmount': 112765.810000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00047-VirtualAccount-AaBbCcDd-EeFfGg-P011-011',
              'accountRegistration': 'Account - 047 Tenants in Common',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234531',
              'accountStatus': 'Pending Funding',
              'marketValue': 111854.000000,
              'investmentStrategy': 'Sample Product - 019',
              'sourceAccounts': [
                {
                  'sourceID': 'A00047',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00047-AaBbCc-DdEdFfGg-SouceAccount-1234531'
                }
              ],
              'accountAplId': 'A00047',
              'pendingAmount': 112939.790000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00021-VirtualAccount-AaBbCcDd-EeFfGg-P011-011',
              'accountRegistration': 'Georgi Meyer Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': 'N8U000006',
              'accountStatus': 'Active',
              'marketValue': 106354.000000,
              'investmentStrategy': 'Sample Product - 018',
              'sourceAccounts': [
                {
                  'sourceID': 'A00021',
                  'sourceSystem': 'TDA',
                  'sourceAccountId': 'A00021-AaBbCc-DdEdFfGg-SouceAccount-N8U000006'
                }
              ],
              'accountAplId': 'A00021',
              'pendingAmount': 108416.310000,
              'pendingDays': 1328,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Hari Mays',
          'marketValue': 105914.000000,
          'netInvestments': 563981.910000,
          'ytdPerformance': 0.12880000000000000000,
          'inceptionDate': '20200216',
          'advisorIdentifier': 'AG0003',
          'id': 'C17805-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-008',
          'flagged': false,
          'clientAplId': 'C17805',
          'accounts': [
            {
              'id': 'A00019-VirtualAccount-AaBbCcDd-EeFfGg-P011-008',
              'accountRegistration': 'Pistachio Foundation',
              'alert': '',
              'alerts': [],
              'accountNumber': '9876505',
              'accountStatus': 'Active',
              'marketValue': 105914.000000,
              'investmentStrategy': 'Sample Product - 016',
              'sourceAccounts': [
                {
                  'sourceID': 'A00019',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00019-AaBbCc-DdEdFfGg-SouceAccount-9876505'
                }
              ],
              'accountAplId': 'A00019',
              'pendingAmount': 108068.350000,
              'pendingDays': 1334,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Huw Richards',
          'marketValue': 316422.000000,
          'netInvestments': 550933.800000,
          'ytdPerformance': 0.12420000000000000000,
          'inceptionDate': '20200207',
          'advisorIdentifier': 'AG0003',
          'id': 'C21551-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-007',
          'flagged': false,
          'clientAplId': 'C21551',
          'accounts': [
            {
              'id': 'A00016-VirtualAccount-AaBbCcDd-EeFfGg-P011-007',
              'accountRegistration': 'Hari Mays Tenants in Common',
              'alert': '',
              'alerts': [],
              'accountNumber': '9876504',
              'accountStatus': 'Active',
              'marketValue': 105254.000000,
              'investmentStrategy': 'Sample Product - 013',
              'sourceAccounts': [
                {
                  'sourceID': 'A00016',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00016-AaBbCc-DdEdFfGg-SouceAccount-9876504'
                }
              ],
              'accountAplId': 'A00016',
              'pendingAmount': 107546.410000,
              'pendingDays': 1343,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00017-VirtualAccount-AaBbCcDd-EeFfGg-P011-007',
              'accountRegistration': 'Hari Mays Community Property',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234504',
              'accountStatus': 'Active',
              'marketValue': 105474.000000,
              'investmentStrategy': 'Sample Product - 014',
              'sourceAccounts': [
                {
                  'sourceID': 'A00017',
                  'sourceSystem': 'PRS',
                  'sourceAccountId': 'A00017-AaBbCc-DdEdFfGg-SouceAccount-1234504'
                }
              ],
              'accountAplId': 'A00017',
              'pendingAmount': 107720.390000,
              'pendingDays': 1340,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00018-VirtualAccount-AaBbCcDd-EeFfGg-P011-007',
              'accountRegistration': 'Hari Mays Trust',
              'alert': '',
              'alerts': [],
              'accountNumber': 'N8U000005',
              'accountStatus': 'Active',
              'marketValue': 105694.000000,
              'investmentStrategy': 'Sample Product - 015',
              'sourceAccounts': [
                {
                  'sourceID': 'A00018',
                  'sourceSystem': 'TDA',
                  'sourceAccountId': 'A00018-AaBbCc-DdEdFfGg-SouceAccount-N8U000005'
                }
              ],
              'accountAplId': 'A00018',
              'pendingAmount': 107894.370000,
              'pendingDays': 1337,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Isobella Perkins',
          'marketValue': 75774.840000,
          'netInvestments': 485693.250000,
          'ytdPerformance': 0.10120000000000000000,
          'inceptionDate': '20200105',
          'advisorIdentifier': 'AG0003',
          'id': 'CB0RE8-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-002',
          'flagged': false,
          'clientAplId': 'CB0RE8',
          'accounts': [
            {
              'id': 'A00002-VirtualAccount-AaBbCcDd-EeFfGg-P011-002',
              'accountRegistration': 'Isobella Perkins Roth IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234500',
              'accountStatus': 'Active',
              'marketValue': 75774.840000,
              'investmentStrategy': 'Sample Product - 002',
              'sourceAccounts': [
                {
                  'sourceID': 'A00002',
                  'sourceSystem': 'PRS',
                  'sourceAccountId': 'A00002-AaBbCc-DdEdFfGg-SouceAccount-1234500'
                }
              ],
              'accountAplId': 'A00002',
              'pendingAmount': 105632.630000,
              'pendingDays': 1376,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00003-VirtualAccount-AaBbCcDd-EeFfGg-P011-002',
              'accountRegistration': 'Isobella Perkins Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': 'N8U000001',
              'accountStatus': 'Active',
              'marketValue': 0.0,
              'investmentStrategy': 'Sample Product - 003',
              'sourceAccounts': [
                {
                  'sourceID': 'A00003',
                  'sourceSystem': 'TDA',
                  'sourceAccountId': 'A00003-AaBbCc-DdEdFfGg-SouceAccount-N8U000001'
                }
              ],
              'accountAplId': 'A00003',
              'pendingAmount': 105806.610000,
              'pendingDays': 1373,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Kimberly Gregory',
          'marketValue': 125000.000000,
          'netInvestments': 668366.790000,
          'ytdPerformance': 0.16560000000000000000,
          'inceptionDate': '20230920',
          'advisorIdentifier': 'AG0003',
          'id': 'CB08T8-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-016',
          'flagged': false,
          'clientAplId': 'CB08T8',
          'accounts': [
            {
              'id': 'A00061-VirtualAccount-AaBbCcDd-EeFfGg-P011-016',
              'accountRegistration': 'Account - 061 Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234545',
              'accountStatus': 'Active',
              'marketValue': 125000.000000,
              'investmentStrategy': 'Sample Product - 002',
              'sourceAccounts': [
                {
                  'sourceID': 'A00061',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00061-AaBbCc-DdEdFfGg-SouceAccount-1234545'
                }
              ],
              'accountAplId': 'A00061',
              'pendingAmount': 0.000000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Laila Joseph',
          'marketValue': 314442.000000,
          'netInvestments': 537885.690000,
          'ytdPerformance': 0.11960000000000000000,
          'inceptionDate': '20200129',
          'advisorIdentifier': 'AG0003',
          'id': 'C23746-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-006',
          'flagged': false,
          'clientAplId': 'C23746',
          'accounts': [
            {
              'id': 'A00013-VirtualAccount-AaBbCcDd-EeFfGg-P011-006',
              'accountRegistration': 'Laila Joseph Individual 1',
              'alert': '',
              'alerts': [],
              'accountNumber': '9876503',
              'accountStatus': 'Active',
              'marketValue': 104594.000000,
              'investmentStrategy': 'Sample Product - 010',
              'sourceAccounts': [
                {
                  'sourceID': 'A00013',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00013-AaBbCc-DdEdFfGg-SouceAccount-9876503'
                }
              ],
              'accountAplId': 'A00013',
              'pendingAmount': 107024.470000,
              'pendingDays': 1352,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00014-VirtualAccount-AaBbCcDd-EeFfGg-P011-006',
              'accountRegistration': 'Laila Joseph Individual 2',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234503',
              'accountStatus': 'Active',
              'marketValue': 104814.000000,
              'investmentStrategy': 'Sample Product - 011',
              'sourceAccounts': [
                {
                  'sourceID': 'A00014',
                  'sourceSystem': 'PRS',
                  'sourceAccountId': 'A00014-AaBbCc-DdEdFfGg-SouceAccount-1234503'
                }
              ],
              'accountAplId': 'A00014',
              'pendingAmount': 107198.450000,
              'pendingDays': 1349,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00015-VirtualAccount-AaBbCcDd-EeFfGg-P011-006',
              'accountRegistration': 'Laila Joseph Traditional IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': 'N8U000004',
              'accountStatus': 'Active',
              'marketValue': 105034.000000,
              'investmentStrategy': 'Sample Product - 012',
              'sourceAccounts': [
                {
                  'sourceID': 'A00015',
                  'sourceSystem': 'TDA',
                  'sourceAccountId': 'A00015-AaBbCc-DdEdFfGg-SouceAccount-N8U000004'
                }
              ],
              'accountAplId': 'A00015',
              'pendingAmount': 107372.430000,
              'pendingDays': 1346,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Louis Melton',
          'marketValue': 249999.990000,
          'netInvestments': 655318.680000,
          'ytdPerformance': 0.16100000000000000000,
          'inceptionDate': '20230920',
          'advisorIdentifier': 'AG0003',
          'id': 'CB20X5-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-015',
          'flagged': false,
          'clientAplId': 'CB20X5',
          'accounts': [
            {
              'id': 'A00064-VirtualAccount-AaBbCcDd-EeFfGg-P011-015',
              'accountRegistration': 'Account - 064 IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234548',
              'accountStatus': 'Active',
              'marketValue': 249999.990000,
              'investmentStrategy': 'Sample Product - 005',
              'sourceAccounts': [
                {
                  'sourceID': 'A00064',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00064-AaBbCc-DdEdFfGg-SouceAccount-1234548'
                }
              ],
              'accountAplId': 'A00064',
              'pendingAmount': 0.000000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Malik Mcclain',
          'marketValue': 786290.380000,
          'netInvestments': 498741.360000,
          'ytdPerformance': 0.10580000000000000000,
          'inceptionDate': '20200111',
          'advisorIdentifier': 'AG0003',
          'id': 'CA40W7-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-003',
          'flagged': false,
          'clientAplId': 'CA40W7',
          'accounts': [
            {
              'id': 'A00004-VirtualAccount-AaBbCcDd-EeFfGg-P011-003',
              'accountRegistration': 'Malik Mcclain Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '9876501',
              'accountStatus': 'Active',
              'marketValue': 34112.380000,
              'investmentStrategy': 'Sample Product - 004',
              'sourceAccounts': [
                {
                  'sourceID': 'A00004',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00004-AaBbCc-DdEdFfGg-SouceAccount-9876501'
                }
              ],
              'accountAplId': 'A00004',
              'pendingAmount': 105980.590000,
              'pendingDays': 1370,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00023-VirtualAccount-AaBbCcDd-EeFfGg-P011-003',
              'accountRegistration': 'McClain 401k',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234507',
              'accountStatus': 'Active',
              'marketValue': 0.0,
              'investmentStrategy': 'Sample Product - 020',
              'sourceAccounts': [
                {
                  'sourceID': 'A00023',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00023-AaBbCc-DdEdFfGg-SouceAccount-1234507'
                }
              ],
              'accountAplId': 'A00023',
              'pendingAmount': 108764.270000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00024-VirtualAccount-AaBbCcDd-EeFfGg-P011-003',
              'accountRegistration': 'McClain 403b',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234508',
              'accountStatus': 'Active',
              'marketValue': 106794.000000,
              'investmentStrategy': 'Sample Product - 021',
              'sourceAccounts': [
                {
                  'sourceID': 'A00024',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00024-AaBbCc-DdEdFfGg-SouceAccount-1234508'
                }
              ],
              'accountAplId': 'A00024',
              'pendingAmount': 108938.250000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00025-VirtualAccount-AaBbCcDd-EeFfGg-P011-003',
              'accountRegistration': 'McClain Roth IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234509',
              'accountStatus': 'Active',
              'marketValue': 107014.000000,
              'investmentStrategy': 'Sample Product - 022',
              'sourceAccounts': [
                {
                  'sourceID': 'A00025',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00025-AaBbCc-DdEdFfGg-SouceAccount-1234509'
                }
              ],
              'accountAplId': 'A00025',
              'pendingAmount': 109112.230000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00026-VirtualAccount-AaBbCcDd-EeFfGg-P011-003',
              'accountRegistration': 'McClain Family Trust',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234510',
              'accountStatus': 'Active',
              'marketValue': 107234.000000,
              'investmentStrategy': 'Sample Product - 023',
              'sourceAccounts': [
                {
                  'sourceID': 'A00026',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00026-AaBbCc-DdEdFfGg-SouceAccount-1234510'
                }
              ],
              'accountAplId': 'A00026',
              'pendingAmount': 109286.210000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00027-VirtualAccount-AaBbCcDd-EeFfGg-P011-003',
              'accountRegistration': 'McClain JROS',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234511',
              'accountStatus': 'Active',
              'marketValue': 107454.000000,
              'investmentStrategy': 'Sample Product - 024',
              'sourceAccounts': [
                {
                  'sourceID': 'A00027',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00027-AaBbCc-DdEdFfGg-SouceAccount-1234511'
                }
              ],
              'accountAplId': 'A00027',
              'pendingAmount': 109460.190000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00028-VirtualAccount-AaBbCcDd-EeFfGg-P011-003',
              'accountRegistration': 'Johnny McClain Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234512',
              'accountStatus': 'Active',
              'marketValue': 107674.000000,
              'investmentStrategy': 'Sample Product - 025',
              'sourceAccounts': [
                {
                  'sourceID': 'A00028',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00028-AaBbCc-DdEdFfGg-SouceAccount-1234512'
                }
              ],
              'accountAplId': 'A00028',
              'pendingAmount': 109634.170000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00029-VirtualAccount-AaBbCcDd-EeFfGg-P011-003',
              'accountRegistration': 'Sally McClain Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234513',
              'accountStatus': 'Active',
              'marketValue': 107894.000000,
              'investmentStrategy': 'Sample Product - 001',
              'sourceAccounts': [
                {
                  'sourceID': 'A00029',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00029-AaBbCc-DdEdFfGg-SouceAccount-1234513'
                }
              ],
              'accountAplId': 'A00029',
              'pendingAmount': 109808.150000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00030-VirtualAccount-AaBbCcDd-EeFfGg-P011-003',
              'accountRegistration': 'Fido McClain Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234514',
              'accountStatus': 'Active',
              'marketValue': 108114.000000,
              'investmentStrategy': 'Sample Product - 002',
              'sourceAccounts': [
                {
                  'sourceID': 'A00030',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00030-AaBbCc-DdEdFfGg-SouceAccount-1234514'
                }
              ],
              'accountAplId': 'A00030',
              'pendingAmount': 109982.130000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Steppy Rivas',
          'marketValue': 103714.000000,
          'netInvestments': 694463.010000,
          'ytdPerformance': 0.17480000000000000000,
          'inceptionDate': '20200117',
          'advisorIdentifier': 'AG0003',
          'id': 'CB5YY3-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-018',
          'flagged': false,
          'clientAplId': 'CB5YY3',
          'accounts': [
            {
              'id': 'A00009-VirtualAccount-AaBbCcDd-EeFfGg-P011-018',
              'accountRegistration': 'Rivas Family Trust',
              'alert': '',
              'alerts': [],
              'accountNumber': 'N8U000002',
              'accountStatus': 'Active',
              'marketValue': 103714.000000,
              'investmentStrategy': 'Sample Product - 006',
              'sourceAccounts': [
                {
                  'sourceID': 'A00009',
                  'sourceSystem': 'TDA',
                  'sourceAccountId': 'A00009-AaBbCc-DdEdFfGg-SouceAccount-N8U000002'
                }
              ],
              'accountAplId': 'A00009',
              'pendingAmount': 106328.550000,
              'pendingDays': 1364,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Super Duper Big Long Giant Client Name For Testing Super Duper Long Client Names in the Client Tile To See What Happens When The Name Is Super Duper Long Like This One Is',
          'marketValue': 106134.000000,
          'netInvestments': 577030.020000,
          'ytdPerformance': 0.13340000000000000000,
          'inceptionDate': '20200219',
          'advisorIdentifier': 'AG0003',
          'id': 'C03197-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-009',
          'flagged': false,
          'clientAplId': 'C03197',
          'accounts': [
            {
              'id': 'A00020-VirtualAccount-AaBbCcDd-EeFfGg-P011-009',
              'accountRegistration': 'This Is an Account With A Super Duper Long Name So We Can See What a Super Duper Long Account Name Looks Like In Each Of The Test Environments Just In Case it Does Not Look Good in Said Environments',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234505',
              'accountStatus': 'Active',
              'marketValue': 106134.000000,
              'investmentStrategy': 'Sample Product - 017',
              'sourceAccounts': [
                {
                  'sourceID': 'A00020',
                  'sourceSystem': 'PRS',
                  'sourceAccountId': 'A00020-AaBbCc-DdEdFfGg-SouceAccount-1234505'
                }
              ],
              'accountAplId': 'A00020',
              'pendingAmount': 108242.330000,
              'pendingDays': 1331,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Tabitha Stevens',
          'marketValue': 250000.000000,
          'netInvestments': 681414.900000,
          'ytdPerformance': 0.17020000000000000000,
          'inceptionDate': '20230920',
          'advisorIdentifier': 'AG0003',
          'id': 'CB24C1-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-017',
          'flagged': false,
          'clientAplId': 'CB24C1',
          'accounts': [
            {
              'id': 'A00063-VirtualAccount-AaBbCcDd-EeFfGg-P011-017',
              'accountRegistration': 'Account - 063 Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234547',
              'accountStatus': 'Active',
              'marketValue': 250000.000000,
              'investmentStrategy': 'Sample Product - 004',
              'sourceAccounts': [
                {
                  'sourceID': 'A00063',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00063-AaBbCc-DdEdFfGg-SouceAccount-1234547'
                }
              ],
              'accountAplId': 'A00063',
              'pendingAmount': 0.000000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'The Jones Family',
          'marketValue': 1369914.000000,
          'netInvestments': 616174.350000,
          'ytdPerformance': 0.14720000000000000000,
          'inceptionDate': '20230506',
          'advisorIdentifier': 'AG0003',
          'id': 'CB5YY2-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-012',
          'flagged': false,
          'clientAplId': 'CB5YY2',
          'accounts': [
            {
              'id': 'A00022-VirtualAccount-AaBbCcDd-EeFfGg-P011-012',
              'accountRegistration': 'Garfield Lopez Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234506',
              'accountStatus': 'Pending Funding',
              'marketValue': 0.0,
              'investmentStrategy': 'Sample Product - 019',
              'sourceAccounts': [
                {
                  'sourceID': 'A00022',
                  'sourceSystem': 'PRS',
                  'sourceAccountId': 'A00022-AaBbCc-DdEdFfGg-SouceAccount-1234506'
                }
              ],
              'accountAplId': 'A00022',
              'pendingAmount': 108590.290000,
              'pendingDays': 159,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00048-VirtualAccount-AaBbCcDd-EeFfGg-P011-012',
              'accountRegistration': 'Account - 048 Community Property',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234532',
              'accountStatus': 'Pending Funding',
              'marketValue': 112074.000000,
              'investmentStrategy': 'Sample Product - 020',
              'sourceAccounts': [
                {
                  'sourceID': 'A00048',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00048-AaBbCc-DdEdFfGg-SouceAccount-1234532'
                }
              ],
              'accountAplId': 'A00048',
              'pendingAmount': 113113.770000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00049-VirtualAccount-AaBbCcDd-EeFfGg-P011-012',
              'accountRegistration': 'Account - 049 Trust',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234533',
              'accountStatus': 'Pending Funding',
              'marketValue': 112294.000000,
              'investmentStrategy': 'Sample Product - 021',
              'sourceAccounts': [
                {
                  'sourceID': 'A00049',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00049-AaBbCc-DdEdFfGg-SouceAccount-1234533'
                }
              ],
              'accountAplId': 'A00049',
              'pendingAmount': 113287.750000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00050-VirtualAccount-AaBbCcDd-EeFfGg-P011-012',
              'accountRegistration': 'Account - 050 IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234534',
              'accountStatus': 'Pending Funding',
              'marketValue': 112514.000000,
              'investmentStrategy': 'Sample Product - 022',
              'sourceAccounts': [
                {
                  'sourceID': 'A00050',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00050-AaBbCc-DdEdFfGg-SouceAccount-1234534'
                }
              ],
              'accountAplId': 'A00050',
              'pendingAmount': 113461.730000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00051-VirtualAccount-AaBbCcDd-EeFfGg-P011-012',
              'accountRegistration': 'Account - 051 Trust',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234535',
              'accountStatus': 'Pending Funding',
              'marketValue': 112734.000000,
              'investmentStrategy': 'Sample Product - 023',
              'sourceAccounts': [
                {
                  'sourceID': 'A00051',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00051-AaBbCc-DdEdFfGg-SouceAccount-1234535'
                }
              ],
              'accountAplId': 'A00051',
              'pendingAmount': 113635.710000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00052-VirtualAccount-AaBbCcDd-EeFfGg-P011-012',
              'accountRegistration': 'Account - 052 Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234536',
              'accountStatus': 'Pending Funding',
              'marketValue': 112954.000000,
              'investmentStrategy': 'Sample Product - 024',
              'sourceAccounts': [
                {
                  'sourceID': 'A00052',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00052-AaBbCc-DdEdFfGg-SouceAccount-1234536'
                }
              ],
              'accountAplId': 'A00052',
              'pendingAmount': 113809.690000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00053-VirtualAccount-AaBbCcDd-EeFfGg-P011-012',
              'accountRegistration': 'Account - 053 Traditional IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234537',
              'accountStatus': 'Active',
              'marketValue': 113174.000000,
              'investmentStrategy': 'Sample Product - 019',
              'sourceAccounts': [
                {
                  'sourceID': 'A00053',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00053-AaBbCc-DdEdFfGg-SouceAccount-1234537'
                }
              ],
              'accountAplId': 'A00053',
              'pendingAmount': 0.000000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00054-VirtualAccount-AaBbCcDd-EeFfGg-P011-012',
              'accountRegistration': 'Account - 054 Tenants in Common',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234538',
              'accountStatus': 'Active',
              'marketValue': 113394.000000,
              'investmentStrategy': 'Sample Product - 020',
              'sourceAccounts': [
                {
                  'sourceID': 'A00054',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00054-AaBbCc-DdEdFfGg-SouceAccount-1234538'
                }
              ],
              'accountAplId': 'A00054',
              'pendingAmount': 0.000000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00055-VirtualAccount-AaBbCcDd-EeFfGg-P011-012',
              'accountRegistration': 'Account - 055 Community Property',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234539',
              'accountStatus': 'Active',
              'marketValue': 113614.000000,
              'investmentStrategy': 'Sample Product - 021',
              'sourceAccounts': [
                {
                  'sourceID': 'A00055',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00055-AaBbCc-DdEdFfGg-SouceAccount-1234539'
                }
              ],
              'accountAplId': 'A00055',
              'pendingAmount': 0.000000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00056-VirtualAccount-AaBbCcDd-EeFfGg-P011-012',
              'accountRegistration': 'Account - 056 Trust',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234540',
              'accountStatus': 'Active',
              'marketValue': 113834.000000,
              'investmentStrategy': 'Sample Product - 022',
              'sourceAccounts': [
                {
                  'sourceID': 'A00056',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00056-AaBbCc-DdEdFfGg-SouceAccount-1234540'
                }
              ],
              'accountAplId': 'A00056',
              'pendingAmount': 0.000000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00057-VirtualAccount-AaBbCcDd-EeFfGg-P011-012',
              'accountRegistration': 'Account - 057 IRA',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234541',
              'accountStatus': 'Active',
              'marketValue': 114054.000000,
              'investmentStrategy': 'Sample Product - 023',
              'sourceAccounts': [
                {
                  'sourceID': 'A00057',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00057-AaBbCc-DdEdFfGg-SouceAccount-1234541'
                }
              ],
              'accountAplId': 'A00057',
              'pendingAmount': 0.000000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00058-VirtualAccount-AaBbCcDd-EeFfGg-P011-012',
              'accountRegistration': 'Account - 058 Trust',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234542',
              'accountStatus': 'Active',
              'marketValue': 114274.000000,
              'investmentStrategy': 'Sample Product - 024',
              'sourceAccounts': [
                {
                  'sourceID': 'A00058',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00058-AaBbCc-DdEdFfGg-SouceAccount-1234542'
                }
              ],
              'accountAplId': 'A00058',
              'pendingAmount': 0.000000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            },
            {
              'id': 'A00059-VirtualAccount-AaBbCcDd-EeFfGg-P011-012',
              'accountRegistration': 'Account - 059 Individual',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234543',
              'accountStatus': 'Active',
              'marketValue': 125000.000000,
              'investmentStrategy': 'Sample Product - 025',
              'sourceAccounts': [
                {
                  'sourceID': 'A00059',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00059-AaBbCc-DdEdFfGg-SouceAccount-1234543'
                }
              ],
              'accountAplId': 'A00059',
              'pendingAmount': 0.000000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            }
          ]
        },
        {
          'clientName': 'Valerie Lozano',
          'marketValue': 125000.000000,
          'netInvestments': 642270.570000,
          'ytdPerformance': 0.15640000000000000000,
          'inceptionDate': '20230920',
          'advisorIdentifier': 'AG0003',
          'id': 'CB24C0-CLIENTHOUSEHOLD-AABBCCDD-EEFFG-P011-014',
          'flagged': false,
          'clientAplId': 'CB24C0',
          'accounts': [
            {
              'id': 'A00062-VirtualAccount-AaBbCcDd-EeFfGg-P011-014',
              'accountRegistration': 'Account - 062 JROS',
              'alert': '',
              'alerts': [],
              'accountNumber': '1234546',
              'accountStatus': 'Active',
              'marketValue': 125000.000000,
              'investmentStrategy': 'Sample Product - 003',
              'sourceAccounts': [
                {
                  'sourceID': 'A00062',
                  'sourceSystem': 'GNW',
                  'sourceAccountId': 'A00062-AaBbCc-DdEdFfGg-SouceAccount-1234546'
                }
              ],
              'accountAplId': 'A00062',
              'pendingAmount': 0.000000,
              'pendingDays': 22,
              'advisorIdentifier': 'AG0003'
            }
          ]
        }
      ],
      'error': {
        'message': '',
        'code': 200
      }
    }
  }

  get longTitleClient() {
    return {
      'data': {
        'data': [
          {
            'clientName': 'Angelica Financial Advisors, Incorparation - Client with a very long name for test purpose',
            'advisorIdentifier': 'AGAT58',
            'numberOfAccounts': 1,
            'marketValue': 5000.00,
            'expectedAmount': 367315.000000,
            'establishedDate': '2006-05-11',
            'ytdPerformance': 0.0051000000,
            'oneYearPerformance': 0.1020000000,
            'threeYearPerformance': 0.0150000000,
            'fiveYearPerformance': 0.0527000000,
            'cumulativeReturn': 0.00828603438193948,
            'annualizedPerformance': 0.0419000000,
            'netInvestment': 1267639.790000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 5.0
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 20.0
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 35.0
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 15.0
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 25.0
              }
            ],
            'webAccess': false,
            'id': '02360E71-0E63-428F-9ACB-2A4480C83E2C-000D',
            'clientAplId': 'C36020',
            'clientWebId': 'W04TJR',
            'accounts': [
              {
                'id': 'A7B94B5A-4CC9-4789-943D-813B2C385A16-000D',
                'title': 'Angelica Fahlen Joint Tenant with Rights of Survivorship - Account with a very long name for test purpose',
                'applicationId': 'A87890',
                'alerts': [],
                'marketValue': 5000.00,
                'expectedAmount': 367315.000000,
                'inceptionDate': '2006-05-11',
                'bankAccountNumber': 'E25126C806E5',
                'status': 'Proposed',              
                'ytdPerformance': 0.0051000000,
                'oneYearPerformance': 0.1020000000,
                'threeYearPerformance': 0.0150000000,
                'fiveYearPerformance': 0.0527000000,
                'cumulativeReturn': 0.00828603438193948,
                'annualizedPerformance': 0.0419000000,
                'investmentProduct': 'Custodial Sweep',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
            ]
          },           
        ],
        'start': 0,
        'limit': 1,
        'total': 1
      },
      'error': {
        'message': '',
        'code': 200
      },
      'lastUpdate': {
        'value': '2024-04-05T00:00:00+00:00',
        'kind': 'CalendarDate'
      }
    }
  }

  get itemsForFilter() {
    return {
      'data': {
        'data': [
          {
            'clientName': 'Angelica Financial Advisors, Incorparation - Client with a very long name for test purpose',
            'advisorIdentifier': 'AGAT58',
            'numberOfAccounts': 1,
            'marketValue': 5000.00,
            'expectedAmount': 367315.000000,
            'establishedDate': '2006-05-11',
            'ytdPerformance': 0.0051000000,
            'oneYearPerformance': 0.1020000000,
            'threeYearPerformance': 0.0150000000,
            'fiveYearPerformance': 0.0527000000,
            'cumulativeReturn': 0.00828603438193948,
            'annualizedPerformance': 0.0419000000,
            'netInvestment': 1267639.790000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 5.0
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 20.0
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 35.0
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 15.0
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 25.0
              }
            ],
            'webAccess': false,
            'id': '02360E71-0E63-428F-9ACB-2A4480C83E2C-000D',
            'clientAplId': 'C36020',
            'clientWebId': 'W04TJR',
            'accounts': [
              {
                'id': 'A7B94B5A-4CC9-4789-943D-813B2C385A16-000D',
                'title': 'Angelica Fahlen Joint Tenant with Rights of Survivorship - Account with a very long name for test purpose',
                'applicationId': 'A87890',
                'alerts': [],
                'marketValue': 5000.00,
                'expectedAmount': 367315.000000,
                'inceptionDate': '2006-05-11',
                'bankAccountNumber': 'E25126C806E5',
                'status': 'Proposed',              
                'ytdPerformance': 0.0051000000,
                'oneYearPerformance': 0.1020000000,
                'threeYearPerformance': 0.0150000000,
                'fiveYearPerformance': 0.0527000000,
                'cumulativeReturn': 0.00828603438193948,
                'annualizedPerformance': 0.0419000000,
                'investmentProduct': 'Custodial Sweep',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
            ]
          },
          {
            'clientName': 'Second Client',
            'advisorIdentifier': 'AGAT59',
            'numberOfAccounts': 1,
            'marketValue': 6003.00,
            'expectedAmount': 567315.000000,
            'establishedDate': '2007-06-11',
            'ytdPerformance': 0.0081000000,
            'oneYearPerformance': 0.7020000000,
            'threeYearPerformance': 0.0350000000,
            'fiveYearPerformance': 0.0727000000,
            'cumulativeReturn': 0.00928603438193948,
            'annualizedPerformance': 0.0519000000,
            'netInvestment': 3267639.790000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.1
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.05
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.25
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.20
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.40
              }
            ],
            'webAccess': false,
            'id': '03570E71-0E63-428F-9ACB-2A4480C83E2C-000D',
            'clientAplId': 'C36030',
            'clientWebId': 'W05TJR',
            'accounts': [
              {
                'id': 'B7B35B5A-4DD9-4789-123D-823B2C385A16-000D',
                'title': 'Second Account',
                'applicationId': 'A87920',
                'alerts': [],
                'marketValue': 6000.00,
                'expectedAmount': 727315.000000,
                'inceptionDate': '2009-02-12',
                'bankAccountNumber': 'D25126C806E7',
                'status': 'Pending Funding',              
                'ytdPerformance': 0.0071000000,
                'oneYearPerformance': 0.8020000000,
                'threeYearPerformance': 0.0250000000,
                'fiveYearPerformance': 0.0687000000,
                'cumulativeReturn': 0.00948603438193948,
                'annualizedPerformance': 0.0579000000,
                'investmentProduct': 'Custodial Sweep',
                'assetAllocations': [
                  {
                    'assetClass': 'Equity',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'FixedIncome',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'AlternativeInvestments',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'Cash',
                    'allocationWeight': 0.2
                  },
                  {
                    'assetClass': 'CashAlternatives',
                    'allocationWeight': 0.2
                  }
                ]
              },
            ]
          },           
        ],
        'start': 0,
        'limit': 2,
        'total': 2
      },
      'error': {
        'message': '',
        'code': 200
      },
      'lastUpdate': {
        'value': '2024-04-22T00:00:00+00:00',
        'kind': 'CalendarDate'
      }
    }
  }

}
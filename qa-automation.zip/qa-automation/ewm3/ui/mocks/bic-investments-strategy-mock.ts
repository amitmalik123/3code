export class BicInvestmentsStrategyMock {

  public static get data() {
    return {
      'data': [
        {
          'strategyId': '196964F8-6E7F-4B44-B72A-E2ABF95E88D9-000D',
          'strategyAplId': 'SELAC3',
          'items': [
            {
              'accountId': '0DA0E063-AD36-47E9-9835-D8DF860D05C1-000D',
              'accountTitle': 'Hinda Goldstein Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '0D77B3BB0A2E',
              'accountAplId': 'AN5FG5',
              'amountAllocated': 323214.0700,
              'accountAllocation': 0.1367,
              'parentClientWebId': 'W1MEE1',
              'parentClientAplId': 'CF0BU4',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': '0EC82F16-FA31-4B9D-B208-3AD81B946114-000D',
              'accountTitle': 'Cris Muchard 401(k)',
              'advisorId': 'AGAOSX',
              'accountNumber': 'C3ED4C3EF36B',
              'accountAplId': 'AM8BH5',
              'amountAllocated': 1206785.2600,
              'accountAllocation': 0.5102,
              'parentClientWebId': 'W1IAJS',
              'parentClientAplId': 'CE7P42',
              'accountType': 'SSA',
              'accountRegistrationType': '401(k)'
            },
            {
              'accountId': '4A665322-A4BA-43E9-A05F-81BE79575314-000D',
              'accountTitle': 'Stefany Sandager Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'C0DA946FDC87',
              'accountAplId': 'AN79K6',
              'amountAllocated': 479413.7300,
              'accountAllocation': 0.2027,
              'parentClientWebId': 'W1E2VG',
              'parentClientAplId': 'CE55T4',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': 'A6064ADE-6A0A-4CC9-8DE5-8FA5B41C4D87-000D',
              'accountTitle': 'Finley Bowles Rollover IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '269A829A5443',
              'accountAplId': 'AM6MC4',
              'amountAllocated': 356160.8000,
              'accountAllocation': 0.1506,
              'parentClientWebId': 'W1FRE8',
              'parentClientAplId': 'CE71R0',
              'accountType': 'SSA',
              'accountRegistrationType': 'Rollover IRA'
            }
          ],
          'isBicEligible': false,
          'name': 'GPS Select Accumulation, Profile 3, Moderate',
          'totalAccounts': 4,
          'totalAssets': 2365573.8600,
          'currentAllocation': 0.1603
        },
        {
          'strategyId': '6429EABB-44A2-4686-B0E7-08887C722B04-000D',
          'strategyAplId': 'SELAC4',
          'items': [
            {
              'accountId': '5678B311-086A-4619-AF7C-FF3191EE82F7-000D',
              'accountTitle': 'Bartt Grasso Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '3B19F009ABB1',
              'accountAplId': 'AN2GT0',
              'amountAllocated': 1239222.8300,
              'accountAllocation': 0.5724,
              'parentClientWebId': 'W1KJT4',
              'parentClientAplId': 'CE97N0',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': 'EFE07513-A4AC-48B9-B37B-0C00A5255AE1-000D',
              'accountTitle': 'Cartwright Siegel Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '4B24F4CC4952',
              'accountAplId': 'AM3722',
              'amountAllocated': 169575.1600,
              'accountAllocation': 0.0784,
              'parentClientWebId': 'W1EN3M',
              'parentClientAplId': 'CE5QI6',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': '252C3C20-F745-408A-99A4-62C58030E955-000D',
              'accountTitle': 'Bethany Lurz Rollover IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '6CCBE0AE426E',
              'accountAplId': 'AN20X7',
              'amountAllocated': 587163.3200,
              'accountAllocation': 0.2713,
              'parentClientWebId': 'W1FRBY',
              'parentClientAplId': 'CE91V0',
              'accountType': 'SSA',
              'accountRegistrationType': 'Rollover IRA'
            },
            {
              'accountId': 'E1EEDD26-7738-44B1-8EF3-733C5C3F7E2D-000D',
              'accountTitle': 'Bartt Grasso Roth IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'CB8E71770251',
              'accountAplId': 'AN2GT2',
              'amountAllocated': 169042.9300,
              'accountAllocation': 0.0781,
              'parentClientWebId': 'W1KJT4',
              'parentClientAplId': 'CE97N0',
              'accountType': 'SSA',
              'accountRegistrationType': 'Roth IRA'
            }
          ],
          'isBicEligible': false,
          'name': 'GPS Select Accumulation, Profile 4, Moderate Growth',
          'totalAccounts': 4,
          'totalAssets': 2165004.2400,
          'currentAllocation': 0.1467
        },
        {
          'strategyId': '99208C11-8E55-4240-853F-C64F5480F022-000D',
          'strategyAplId': 'AMFBL3',
          'items': [
            {
              'accountId': '427155CE-C5EB-4C36-A051-6C049471ED62-000D',
              'accountTitle': 'Nyle Kojis Individual TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': '950E9DD879C5',
              'accountAplId': 'AK68L1',
              'amountAllocated': 84521.9200,
              'accountAllocation': 0.0444,
              'parentClientWebId': 'W14BSF',
              'parentClientAplId': 'CD8LF3',
              'accountType': 'SSA',
              'accountRegistrationType': 'Individual TOD'
            },
            {
              'accountId': '55F076D2-3E9C-4E16-AF23-5427A45A48C6-000D',
              'accountTitle': 'Joshua Schweihofer Joint Tenant with Rights of Survivorship',
              'advisorId': 'AGAOSX',
              'accountNumber': 'D88FA11ED5F0',
              'accountAplId': 'AK4MC7',
              'amountAllocated': 403850.3500,
              'accountAllocation': 0.2121,
              'parentClientWebId': 'CZ09IV',
              'parentClientAplId': 'CZ09IV',
              'accountType': 'SSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship'
            },
            {
              'accountId': '1C5BC100-563F-4B0E-B10D-641D632D755F-000D',
              'accountTitle': 'Hinda Goldstein Roth IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '9F8BFA13DDE6',
              'accountAplId': 'AN5FH3',
              'amountAllocated': 34737.3800,
              'accountAllocation': 0.0183,
              'parentClientWebId': 'W1MEE1',
              'parentClientAplId': 'CF0BU4',
              'accountType': 'SSA',
              'accountRegistrationType': 'Roth IRA'
            },
            {
              'accountId': 'ACAF3E48-5F77-4D76-9F5A-BE26604B3A30-000D',
              'accountTitle': 'Ernesto Deliramich Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'D98DE7D046AE',
              'accountAplId': 'AN7BT7',
              'amountAllocated': 205643.7300,
              'accountAllocation': 0.108,
              'parentClientWebId': 'W1NT99',
              'parentClientAplId': 'CF13A8',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': 'FE23B299-BE25-43E0-A59B-BB154E12476B-000D',
              'accountTitle': 'Nabil Pillsbury Roth IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'F490C302D6B6',
              'accountAplId': 'AM1VM3',
              'amountAllocated': 2037.1016,
              'accountAllocation': 0.0011,
              'parentClientWebId': 'W0YCT0',
              'parentClientAplId': 'CB4MO5',
              'accountType': 'MSA',
              'accountRegistrationType': 'Roth IRA'
            },
            {
              'accountId': 'F7791030-1349-4E2D-9A22-CDEB39BBB44C-000D',
              'accountTitle': "Ernest O'Reilly Traditional IRA",
              'advisorId': 'AGAOSX',
              'accountNumber': '3853BDACB106',
              'accountAplId': 'AL1FQ8',
              'amountAllocated': 359884.9000,
              'accountAllocation': 0.189,
              'parentClientWebId': 'W0UCRN',
              'parentClientAplId': 'CB17B0',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': 'C676609A-8BEB-4E18-A5F5-3222F189F7D0-000D',
              'accountTitle': 'Hinda Goldstein Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '819FB3477E96',
              'accountAplId': 'AN5FG4',
              'amountAllocated': 1453.7851,
              'accountAllocation': 0.0008,
              'parentClientWebId': 'W1MEE1',
              'parentClientAplId': 'CF0BU4',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': '8F42CD8C-0754-430E-B0AA-9C627DAB1A6C-000D',
              'accountTitle': 'Nyle Kojis Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'E86BA4C14F66',
              'accountAplId': 'AK68L5',
              'amountAllocated': 83930.6900,
              'accountAllocation': 0.0441,
              'parentClientWebId': 'W14BSF',
              'parentClientAplId': 'CD8LF3',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': '3903EDE0-410B-4885-8D89-0CED5DEB19FD-000D',
              'accountTitle': 'Hicham Kaneshiro Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': '04A761EA2994',
              'accountAplId': 'AL1U41',
              'amountAllocated': 200756.1100,
              'accountAllocation': 0.1055,
              'parentClientWebId': 'W12CYB',
              'parentClientAplId': 'CD7ME9',
              'accountType': 'SSA',
              'accountRegistrationType': 'Individual'
            },
            {
              'accountId': 'B53F7447-E5CC-427C-A5F6-029C142C8268-000D',
              'accountTitle': 'Ernesto Deliramich Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '655C812D9449',
              'accountAplId': 'AN7BT8',
              'amountAllocated': 482302.6700,
              'accountAllocation': 0.2533,
              'parentClientWebId': 'W1NT99',
              'parentClientAplId': 'CF13A8',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': '071A52D6-3EA2-471A-A6A7-3E959A866913-000D',
              'accountTitle': 'Nabil Pillsbury SEP-IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'F515A19EE687',
              'accountAplId': 'AK3FB2',
              'amountAllocated': 44496.8400,
              'accountAllocation': 0.0234,
              'parentClientWebId': 'W0YCT0',
              'parentClientAplId': 'CB4MO5',
              'accountType': 'SSA',
              'accountRegistrationType': 'SEP-IRA'
            },
            {
              'accountId': '12EE62A1-52C0-46CF-B6FA-76185B5B5B1F-000D',
              'accountTitle': 'Hinda Goldstein Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '828B78250EFC',
              'accountAplId': 'AN5FF0',
              'amountAllocated': 697.4809,
              'accountAllocation': 0.0004,
              'parentClientWebId': 'W1MEE1',
              'parentClientAplId': 'CF0BU4',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'American Funds Moderate Growth and Income, Profile 3',
          'totalAccounts': 12,
          'totalAssets': 1904312.9576,
          'currentAllocation': 0.129
        },
        {
          'strategyId': '1DAF7F30-F599-4C2E-B45B-6A5EADC3B104-000D',
          'strategyAplId': 'AACS11',
          'items': [
            {
              'accountId': 'C258C175-B125-493F-BA02-179C07326C41-000D',
              'accountTitle': 'Teena Catacchio Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': 'DC106147964D',
              'accountAplId': 'AL8654',
              'amountAllocated': 331.5300,
              'accountAllocation': 0.0002,
              'parentClientWebId': 'W1BUOA',
              'parentClientAplId': 'CE3N24',
              'accountType': 'SSA',
              'accountRegistrationType': 'Individual'
            },
            {
              'accountId': '2A691C25-9BF7-4A73-B06A-2D27F0B885F8-000D',
              'accountTitle': 'Erich Vertrees Joint Tenant with Rights of Survivorship TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': 'E1823F1E4D1A',
              'accountAplId': 'AN4I07',
              'amountAllocated': 1014377.2000,
              'accountAllocation': 0.5798,
              'parentClientWebId': 'W1M10Y',
              'parentClientAplId': 'CE9Z02',
              'accountType': 'SSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship TOD'
            },
            {
              'accountId': 'EA7ABD09-5231-460D-997C-B8EBA5EB07C3-000D',
              'accountTitle': 'Bartt Grasso Joint Tenant with Rights of Survivorship TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': '9A22A1B5A1A6',
              'accountAplId': 'AN4G45',
              'amountAllocated': 735017.0000,
              'accountAllocation': 0.4201,
              'parentClientWebId': 'W1KJT4',
              'parentClientAplId': 'CE97N0',
              'accountType': 'SSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship TOD'
            }
          ],
          'isBicEligible': false,
          'name': 'Custodial Sweep',
          'totalAccounts': 3,
          'totalAssets': 1749725.7300,
          'currentAllocation': 0.1186
        },
        {
          'strategyId': '66D1CF2F-0C72-4540-A225-D848414519B7-000D',
          'strategyAplId': 'PCEQ6U',
          'items': [
            {
              'accountId': 'A1E1E76D-152A-46FB-8B8F-502263F34BA2-000D',
              'accountTitle': 'NPC-IPG Gerrior Trust',
              'advisorId': 'AGAOSX',
              'accountNumber': '5F6492777536',
              'accountAplId': 'AM9S39',
              'amountAllocated': 1587103.5100,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1H0K1',
              'parentClientAplId': 'CE8130',
              'accountType': 'SSA',
              'accountRegistrationType': 'Trust'
            }
          ],
          'isBicEligible': false,
          'name': 'Parametric Custom, All Equity, Profile 6',
          'totalAccounts': 1,
          'totalAssets': 1587103.5100,
          'currentAllocation': 0.1075
        },
        {
          'strategyId': 'A6B5B0B3-FD56-444B-9701-D1067930DC8F-000D',
          'strategyAplId': 'SELRI3',
          'items': [
            {
              'accountId': '53195292-260A-4EBB-B750-0791A390D038-000D',
              'accountTitle': 'Grier Augspurger Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '0E4674C26739',
              'accountAplId': 'AM8WE0',
              'amountAllocated': 758705.2900,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1IISM',
              'parentClientAplId': 'CE7WH5',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': false,
          'name': 'GPS Select Distribution, Profile 3, Moderate',
          'totalAccounts': 1,
          'totalAssets': 758705.2900,
          'currentAllocation': 0.0514
        },
        {
          'strategyId': '71A4BC15-5E37-426F-BA52-99C3ED9D8B01-000D',
          'strategyAplId': 'IMA00H',
          'items': [
            {
              'accountId': '910BBEA0-CE3E-4872-9D6E-8FAE187657EF-000D',
              'accountTitle': 'Stefany Sandager Individual TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': '1EEF3C1DEAC7',
              'accountAplId': 'AN79K2',
              'amountAllocated': 627666.0800,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1E2VG',
              'parentClientAplId': 'CE55T4',
              'accountType': 'SSA',
              'accountRegistrationType': 'Individual TOD'
            }
          ],
          'isBicEligible': true,
          'name': 'Savos Fixed Income Portfolio, Intermediate Duration',
          'totalAccounts': 1,
          'totalAssets': 627666.0800,
          'currentAllocation': 0.0426
        },
        {
          'strategyId': '35B3A6A1-2354-419C-A927-3061678A797A-000D',
          'strategyAplId': 'CCTFPN',
          'items': [
            {
              'accountId': 'A6FE2B23-AD16-4B1D-BD1F-23B4FD70E722-000D',
              'accountTitle': 'NPC-IPG Gerrior Trust',
              'advisorId': 'AGAOSX',
              'accountNumber': 'CBAB630F0ACD',
              'accountAplId': 'AM9S40',
              'amountAllocated': 595050.3400,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1H0K1',
              'parentClientAplId': 'CE8130',
              'accountType': 'SSA',
              'accountRegistrationType': 'Trust'
            }
          ],
          'isBicEligible': false,
          'name': 'Clark Navigator Tax-Free Fixed Income - Pennsylvania',
          'totalAccounts': 1,
          'totalAssets': 595050.3400,
          'currentAllocation': 0.0404
        },
        {
          'strategyId': '789E4E65-E654-434D-AB9F-5E20302A409C-000D',
          'strategyAplId': 'AAGSNM',
          'items': [
            {
              'accountId': '59B93263-BA68-4AD3-99CA-5175E6F644FC-000D',
              'accountTitle': 'Darol Turchetti Joint Tenant with Rights of Survivorship',
              'advisorId': 'AGAOSX',
              'accountNumber': 'A9291D4731AD',
              'accountAplId': 'AL7ID1',
              'amountAllocated': 494426.5300,
              'accountAllocation': 0.9595,
              'parentClientWebId': 'W19UKU',
              'parentClientAplId': 'CE3DL8',
              'accountType': 'SSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship'
            },
            {
              'accountId': '6E6FD9CE-2100-4855-B906-5F08A5A3032C-000D',
              'accountTitle': 'NPC-IPG Gerrior Trust',
              'advisorId': 'AGAOSX',
              'accountNumber': 'A923CB15A44E',
              'accountAplId': 'AM9S42',
              'amountAllocated': 20880.1600,
              'accountAllocation': 0.0406,
              'parentClientWebId': 'W1H0K1',
              'parentClientAplId': 'CE8130',
              'accountType': 'SSA',
              'accountRegistrationType': 'Trust'
            }
          ],
          'isBicEligible': false,
          'name': 'General Securities - Non-Managed',
          'totalAccounts': 2,
          'totalAssets': 515306.6900,
          'currentAllocation': 0.035
        },
        {
          'strategyId': '54FAC6B4-DB11-4223-BDD1-9A2827F8D83C-000D',
          'strategyAplId': 'SELAC2',
          'items': [
            {
              'accountId': '47752B8B-F32E-46CE-B9B0-1F085B1DD750-000D',
              'accountTitle': 'Rhandy Gorrell Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'B0D476DFF21F',
              'accountAplId': 'AK3AH7',
              'amountAllocated': 283167.5800,
              'accountAllocation': 0.5937,
              'parentClientWebId': 'CZ1657',
              'parentClientAplId': 'CZ1657',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': 'E77ADCF5-E3F6-41CE-BAD6-CFA04D440432-000D',
              'accountTitle': 'Tarick McBirney Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'C50AC694E96C',
              'accountAplId': 'AN5QS5',
              'amountAllocated': 193843.9900,
              'accountAllocation': 0.4064,
              'parentClientWebId': 'W1M09G',
              'parentClientAplId': 'CF0FQ0',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': false,
          'name': 'GPS Select Accumulation, Profile 2, Moderate Conservative',
          'totalAccounts': 2,
          'totalAssets': 477011.5700,
          'currentAllocation': 0.0324
        },
        {
          'strategyId': '2DE1BF54-8CA4-4C98-AB2B-D195AD6CA2E4-000D',
          'strategyAplId': 'AMFGI4',
          'items': [
            {
              'accountId': '5C77860E-52ED-47F7-8755-648F3E12B6CF-000D',
              'accountTitle': 'Darol Turchetti Joint Tenant with Rights of Survivorship',
              'advisorId': 'AGAOSX',
              'accountNumber': '27C63EED604F',
              'accountAplId': 'AL7ID0',
              'amountAllocated': 157217.5600,
              'accountAllocation': 0.3479,
              'parentClientWebId': 'W19UKU',
              'parentClientAplId': 'CE3DL8',
              'accountType': 'SSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship'
            },
            {
              'accountId': 'A522832B-26C2-4452-A980-71E7DF29AA85-000D',
              'accountTitle': 'Magid Childs Joint Tenant with Rights of Survivorship TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': 'D33CCE54DF0A',
              'accountAplId': 'AM62M6',
              'amountAllocated': 584.6579,
              'accountAllocation': 0.0013,
              'parentClientWebId': 'W0U04O',
              'parentClientAplId': 'CB2WD0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship TOD'
            },
            {
              'accountId': 'BE277DA7-3E05-428A-B203-9E77FA624294-000D',
              'accountTitle': 'Phan Tarnovski Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'E5BC63B1F94C',
              'accountAplId': 'AL7IB9',
              'amountAllocated': 14015.0000,
              'accountAllocation': 0.0311,
              'parentClientWebId': 'W0TLYN',
              'parentClientAplId': 'CB2TK8',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': '58E7C3B7-0C7C-48B4-8782-295D61B05B90-000D',
              'accountTitle': 'Phan Tarnovski Beneficiary IRA Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': '7DA863B430DC',
              'accountAplId': 'AL7IB4',
              'amountAllocated': 75721.1200,
              'accountAllocation': 0.1676,
              'parentClientWebId': 'W0TLYN',
              'parentClientAplId': 'CB2TK8',
              'accountType': 'SSA',
              'accountRegistrationType': 'Beneficiary IRA Individual'
            },
            {
              'accountId': '38DE90FE-B026-4AC7-AD8F-7CC95F5B8758-000D',
              'accountTitle': 'Keree Frierson Beneficiary IRA Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': 'CB9D562296B7',
              'accountAplId': 'AL6LQ3',
              'amountAllocated': 323.7483,
              'accountAllocation': 0.0008,
              'parentClientWebId': 'W0TLZ6',
              'parentClientAplId': 'CB2T75',
              'accountType': 'MSA',
              'accountRegistrationType': 'Beneficiary IRA Individual'
            },
            {
              'accountId': '38F841A1-3EE2-43F6-A140-42CE0213B94B-000D',
              'accountTitle': 'Kindra Karlik Foundation (Non-Taxable)',
              'advisorId': 'AGAOSX',
              'accountNumber': '419696026AD8',
              'accountAplId': 'AL7GE8',
              'amountAllocated': 203061.8400,
              'accountAllocation': 0.4493,
              'parentClientWebId': 'CZ09Y1',
              'parentClientAplId': 'CZ09Y1',
              'accountType': 'SSA',
              'accountRegistrationType': 'Foundation (Non-Taxable)'
            },
            {
              'accountId': '4856115A-3300-455B-BC4C-897D747FDB6F-000D',
              'accountTitle': 'Cartwright Siegel Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'BEE118EACF99',
              'accountAplId': 'AM3723',
              'amountAllocated': 1062.2935,
              'accountAllocation': 0.0024,
              'parentClientWebId': 'W1EN3M',
              'parentClientAplId': 'CE5QI6',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'American Funds Growth and Income, Profile 4',
          'totalAccounts': 7,
          'totalAssets': 451986.2197,
          'currentAllocation': 0.0307
        },
        {
          'strategyId': '43822156-62FB-4D2E-95DB-3B8699A2E68F-000D',
          'strategyAplId': 'AMFTE3',
          'items': [
            {
              'accountId': 'BFF284BA-735A-434E-9A62-621A196E3AC6-000D',
              'accountTitle': 'Nabil Pillsbury Trust',
              'advisorId': 'AGAOSX',
              'accountNumber': '505C59CE643A',
              'accountAplId': 'AM23E1',
              'amountAllocated': 411.7216,
              'accountAllocation': 0.0017,
              'parentClientWebId': 'W0YCT0',
              'parentClientAplId': 'CB4MO5',
              'accountType': 'MSA',
              'accountRegistrationType': 'Trust'
            },
            {
              'accountId': '27114C88-8ACE-455B-9C53-37E2263FCC5F-000D',
              'accountTitle': 'Stefany Sandager Individual TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': 'C35FE669B948',
              'accountAplId': 'AM1UZ4',
              'amountAllocated': 1711.1063,
              'accountAllocation': 0.0068,
              'parentClientWebId': 'W1E2VG',
              'parentClientAplId': 'CE55T4',
              'accountType': 'MSA',
              'accountRegistrationType': 'Individual TOD'
            },
            {
              'accountId': '1ECD5BD7-3DFB-48F0-9D74-3445316975E2-000D',
              'accountTitle': 'Jamian Luthy Individual TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': '6DE12A77C5E1',
              'accountAplId': 'AN6NR5',
              'amountAllocated': 248143.4300,
              'accountAllocation': 0.9831,
              'parentClientWebId': 'W1NCRD',
              'parentClientAplId': 'CF0U74',
              'accountType': 'SSA',
              'accountRegistrationType': 'Individual TOD'
            },
            {
              'accountId': '4ACF2B24-E204-49A4-9C50-875EAA3AB484-000D',
              'accountTitle': 'Radu Laporta Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': '6D4BA50D6FA5',
              'accountAplId': 'AM42B8',
              'amountAllocated': 2152.4496,
              'accountAllocation': 0.0086,
              'parentClientWebId': 'CZ154F',
              'parentClientAplId': 'CZ154F',
              'accountType': 'MSA',
              'accountRegistrationType': 'Individual'
            }
          ],
          'isBicEligible': true,
          'name': 'American Funds Moderate Gr & Inc, Tax-Aware, Profile 3',
          'totalAccounts': 4,
          'totalAssets': 252418.7075,
          'currentAllocation': 0.0171
        },
        {
          'strategyId': '28E69358-C8B3-4AC7-BF04-1F3CB23B3DCF-000D',
          'strategyAplId': 'AMFIN2',
          'items': [
            {
              'accountId': 'F4B67B47-76D7-4881-922F-0ECFDBABB3DB-000D',
              'accountTitle': 'Rhandy Gorrell Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'A1CCC0777D59',
              'accountAplId': 'AK3A03',
              'amountAllocated': 128791.6100,
              'accountAllocation': 0.5121,
              'parentClientWebId': 'CZ1657',
              'parentClientAplId': 'CZ1657',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': '9A2BBD73-50A6-48B8-B2D1-3F86644719E4-000D',
              'accountTitle': 'Jomo Golombeck Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '0FE2D0C1E5FD',
              'accountAplId': 'AN4JI5',
              'amountAllocated': 122029.3900,
              'accountAllocation': 0.4852,
              'parentClientWebId': 'CZ1796',
              'parentClientAplId': 'CZ1796',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': 'BC82BF2D-3744-43D9-AA0F-71542DF00F98-000D',
              'accountTitle': 'Tarick McBirney Roth IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'E8CAC8F901BD',
              'accountAplId': 'AN5QT1',
              'amountAllocated': 335.3468,
              'accountAllocation': 0.0014,
              'parentClientWebId': 'W1M09G',
              'parentClientAplId': 'CF0FQ0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Roth IRA'
            },
            {
              'accountId': 'EFA6A698-CED9-4867-9974-8DA3BC7269F5-000D',
              'accountTitle': 'Magid Childs Beneficiary IRA Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': '91F1CE1B156C',
              'accountAplId': 'AL5Z83',
              'amountAllocated': 363.9643,
              'accountAllocation': 0.0015,
              'parentClientWebId': 'W0U04O',
              'parentClientAplId': 'CB2WD0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Beneficiary IRA Individual'
            }
          ],
          'isBicEligible': true,
          'name': 'American Funds Conservative Growth and Income, Profile 2',
          'totalAccounts': 4,
          'totalAssets': 251520.3111,
          'currentAllocation': 0.0171
        },
        {
          'strategyId': 'B2590DEF-F20E-4867-BD1B-44965AC33EFA-000D',
          'strategyAplId': 'GPANS3',
          'items': [
            {
              'accountId': '7DEB58CC-90D5-4800-A4B2-218F3EE782E7-000D',
              'accountTitle': 'Nyle Kojis Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '3500F7B3C82F',
              'accountAplId': 'AL5HN5',
              'amountAllocated': 47891.5400,
              'accountAllocation': 0.2116,
              'parentClientWebId': 'W14BSF',
              'parentClientAplId': 'CD8LF3',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': 'EBC26764-630C-4CAA-B198-467184BC18C0-000D',
              'accountTitle': 'Grier Augspurger Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'BAD9C3EC6F3C',
              'accountAplId': 'AM8WD9',
              'amountAllocated': 36485.4500,
              'accountAllocation': 0.1612,
              'parentClientWebId': 'W1IISM',
              'parentClientAplId': 'CE7WH5',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': '8649F747-EEC9-42F9-826B-27F4D0380A97-000D',
              'accountTitle': 'Brielle Ulferts Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '2060BF1508D6',
              'accountAplId': 'AM9J02',
              'amountAllocated': 127365.1200,
              'accountAllocation': 0.5626,
              'parentClientWebId': 'W1IVZO',
              'parentClientAplId': 'CE84S2',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': 'DDF9F076-F478-48BF-A800-D54A935EE05F-000D',
              'accountTitle': 'Ernesto Deliramich Roth IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'F7E18AEA2D59',
              'accountAplId': 'AN7BT6',
              'amountAllocated': 14681.0200,
              'accountAllocation': 0.0649,
              'parentClientWebId': 'W1NT99',
              'parentClientAplId': 'CF13A8',
              'accountType': 'SSA',
              'accountRegistrationType': 'Roth IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'GPS Accumulation, Profile 3, Moderate',
          'totalAccounts': 4,
          'totalAssets': 226423.1300,
          'currentAllocation': 0.0154
        },
        {
          'strategyId': 'F35CE381-2681-4577-B8BF-3EAD78FF3738-000D',
          'strategyAplId': 'SELWP1',
          'items': [
            {
              'accountId': '88F3A542-8688-46B1-AAB4-E0AB894B06FB-000D',
              'accountTitle': 'Radu Laporta Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': '3B3D8E66B6F0',
              'accountAplId': 'AM7534',
              'amountAllocated': 209572.3700,
              'accountAllocation': 1.0,
              'parentClientWebId': 'CZ154F',
              'parentClientAplId': 'CZ154F',
              'accountType': 'SSA',
              'accountRegistrationType': 'Individual'
            }
          ],
          'isBicEligible': false,
          'name': 'GPS Select Wealth Preservation, Profile 1, Conservative',
          'totalAccounts': 1,
          'totalAssets': 209572.3700,
          'currentAllocation': 0.0142
        },
        {
          'strategyId': 'D114496F-75F2-4A64-A58D-929D65CB14B2-000D',
          'strategyAplId': 'AMFTE2',
          'items': [
            {
              'accountId': 'B9E66304-B6C4-4781-9821-E37A75332542-000D',
              'accountTitle': 'Rola Cassiani Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '66D5868054AD',
              'accountAplId': 'AK94I4',
              'amountAllocated': 116260.6400,
              'accountAllocation': 0.6469,
              'parentClientWebId': 'W16369',
              'parentClientAplId': 'CD9TN9',
              'accountType': 'SSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': '184D0E3D-DB68-4775-930A-6FAA9DB674B5-000D',
              'accountTitle': 'Rola Cassiani Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': '311A162FE51C',
              'accountAplId': 'AK94I3',
              'amountAllocated': 61307.2600,
              'accountAllocation': 0.3412,
              'parentClientWebId': 'W16369',
              'parentClientAplId': 'CD9TN9',
              'accountType': 'SSA',
              'accountRegistrationType': 'Individual'
            },
            {
              'accountId': '154017C3-61DE-468D-A558-CB078C592958-000D',
              'accountTitle': 'Radu Laporta Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': '6D4BA50D6FA5',
              'accountAplId': 'AM42B8',
              'amountAllocated': 2152.4496,
              'accountAllocation': 0.012,
              'parentClientWebId': 'CZ154F',
              'parentClientAplId': 'CZ154F',
              'accountType': 'MSA',
              'accountRegistrationType': 'Individual'
            }
          ],
          'isBicEligible': true,
          'name': 'American Funds Conservative Gr & Inc, Tax-Aware, Profile 2',
          'totalAccounts': 3,
          'totalAssets': 179720.3496,
          'currentAllocation': 0.0122
        },
        {
          'strategyId': '2E9F9F04-A4C1-4F44-88F0-B5DDD7CB52DE-000D',
          'strategyAplId': 'CCFII1',
          'items': [
            {
              'accountId': '762D86D6-1DFD-492D-A493-B4F7C5B838BA-000D',
              'accountTitle': 'Teena Catacchio Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': '164AA6EAFA5D',
              'accountAplId': 'AL8T67',
              'amountAllocated': 169374.5100,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1BUOA',
              'parentClientAplId': 'CE3N24',
              'accountType': 'SSA',
              'accountRegistrationType': 'Individual'
            }
          ],
          'isBicEligible': false,
          'name': 'Clark Navigator Taxable Fixed Income',
          'totalAccounts': 1,
          'totalAssets': 169374.5100,
          'currentAllocation': 0.0115
        },
        {
          'strategyId': '04028683-E56D-4CBF-8851-ADCC4AB3F050-000D',
          'strategyAplId': 'MKTBD6',
          'items': [
            {
              'accountId': '287745E3-FE32-438E-8D70-862C69D4FA51-000D',
              'accountTitle': 'Cartwright Siegel Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': '7AD5FFD1E840',
              'accountAplId': 'AM3719',
              'amountAllocated': 64161.1800,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1EN3M',
              'parentClientAplId': 'CE5QI6',
              'accountType': 'SSA',
              'accountRegistrationType': 'Individual'
            }
          ],
          'isBicEligible': true,
          'name': 'US Market Blend, Profile 6, Maximum Growth',
          'totalAccounts': 1,
          'totalAssets': 64161.1800,
          'currentAllocation': 0.0044
        },
        {
          'strategyId': '82780B1A-B144-4E3A-959C-A76FBFFED84A-000D',
          'strategyAplId': 'AMDFA2',
          'items': [
            {
              'accountId': '003DC7CE-FAC1-4F95-8150-DA7F8A9929B0-000D',
              'accountTitle': 'Gaye Chiarenza Rollover IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'E59193EAC07B',
              'accountAplId': 'AM2263',
              'amountAllocated': 53973.1900,
              'accountAllocation': 1.0,
              'parentClientWebId': 'CZ181L',
              'parentClientAplId': 'CZ181L',
              'accountType': 'SSA',
              'accountRegistrationType': 'Rollover IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'MarketDimensions Portfolio, Profile 2',
          'totalAccounts': 1,
          'totalAssets': 53973.1900,
          'currentAllocation': 0.0037
        },
        {
          'strategyId': 'EEB24852-2BE2-4AC1-9226-D2D39B541270-000D',
          'strategyAplId': 'SELLV1',
          'items': [
            {
              'accountId': 'B6A455B8-8AAC-45AB-9385-82965BF1F1CE-000D',
              'accountTitle': 'Darol Turchetti Joint Tenant with Rights of Survivorship',
              'advisorId': 'AGAOSX',
              'accountNumber': 'FFA3C97C915E',
              'accountAplId': 'AL7IC9',
              'amountAllocated': 44606.2300,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W19UKU',
              'parentClientAplId': 'CE3DL8',
              'accountType': 'SSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship'
            }
          ],
          'isBicEligible': false,
          'name': 'GPS Select Low Volatility, Profile 1, Conservative',
          'totalAccounts': 1,
          'totalAssets': 44606.2300,
          'currentAllocation': 0.0031
        },
        {
          'strategyId': '65D5EF43-8B4A-42D8-8D36-3E7EF10B9E00-000D',
          'strategyAplId': 'MKTBD3',
          'items': [
            {
              'accountId': 'A6207C0B-910E-45A1-BE34-2CBABEB3FA54-000D',
              'accountTitle': 'Hinda Goldstein Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '819FB3477E96',
              'accountAplId': 'AN5FG4',
              'amountAllocated': 1453.7851,
              'accountAllocation': 0.0381,
              'parentClientWebId': 'W1MEE1',
              'parentClientAplId': 'CF0BU4',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': 'AD420C91-42C2-4787-9BA3-8DFB1AF1F1AB-000D',
              'accountTitle': 'Hinda Goldstein Joint Tenant with Rights of Survivorship',
              'advisorId': 'AGAOSX',
              'accountNumber': '3B72EE8DD280',
              'accountAplId': 'AN5FI9',
              'amountAllocated': 36059.5300,
              'accountAllocation': 0.9438,
              'parentClientWebId': 'W1MEE1',
              'parentClientAplId': 'CF0BU4',
              'accountType': 'SSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship'
            },
            {
              'accountId': '59F83A0E-0C93-4BD3-B5D2-2D3F5F0F0D8F-000D',
              'accountTitle': 'Hinda Goldstein Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '828B78250EFC',
              'accountAplId': 'AN5FF0',
              'amountAllocated': 697.4809,
              'accountAllocation': 0.0183,
              'parentClientWebId': 'W1MEE1',
              'parentClientAplId': 'CF0BU4',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'US Market Blend, Profile 3, Moderate',
          'totalAccounts': 3,
          'totalAssets': 38210.7960,
          'currentAllocation': 0.0026
        },
        {
          'strategyId': '3636362E-EE53-477B-B0FC-FE573DA31DEA-000D',
          'strategyAplId': 'AMFGG6',
          'items': [
            {
              'accountId': 'CD21959F-F395-4D50-A890-AF66302CEDC6-000D',
              'accountTitle': 'Teena Catacchio Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '74C74898074B',
              'accountAplId': 'AL8T64',
              'amountAllocated': 2542.1901,
              'accountAllocation': 0.0734,
              'parentClientWebId': 'W1BUOA',
              'parentClientAplId': 'CE3N24',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': '38BD4C96-F11C-4C94-9849-E3C7AEE982A0-000D',
              'accountTitle': 'Cartwright Siegel Roth IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'BC97767689CC',
              'accountAplId': 'AM3718',
              'amountAllocated': 32095.3700,
              'accountAllocation': 0.9267,
              'parentClientWebId': 'W1EN3M',
              'parentClientAplId': 'CE5QI6',
              'accountType': 'SSA',
              'accountRegistrationType': 'Roth IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'American Funds Global Growth, Profile 6',
          'totalAccounts': 2,
          'totalAssets': 34637.5601,
          'currentAllocation': 0.0024
        },
        {
          'strategyId': '2031718C-EA0A-44D8-AD2A-2211055C3CCF-000D',
          'strategyAplId': 'AMFGR5',
          'items': [
            {
              'accountId': '3D2414A5-2D09-4C5B-9012-36D4ED06AB8D-000D',
              'accountTitle': 'Neely Nichols Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'C844A854A3B2',
              'accountAplId': 'AL0BP2',
              'amountAllocated': 1191.9311,
              'accountAllocation': 0.1594,
              'parentClientWebId': 'W11DZD',
              'parentClientAplId': 'CB6563',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': 'E1E723EA-9A98-4A41-9006-E086739348A2-000D',
              'accountTitle': 'Neely Nichols Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '86B78F8AA218',
              'accountAplId': 'AL0BP0',
              'amountAllocated': 841.4537,
              'accountAllocation': 0.1125,
              'parentClientWebId': 'W11DZD',
              'parentClientAplId': 'CB6563',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': '72CDD572-B07A-4C08-97C5-96A1406C0107-000D',
              'accountTitle': 'Bartt Grasso Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '4D698D076B08',
              'accountAplId': 'AN2GT1',
              'amountAllocated': 5448.8419,
              'accountAllocation': 0.7283,
              'parentClientWebId': 'W1KJT4',
              'parentClientAplId': 'CE97N0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'American Funds Moderate Growth, Profile 5',
          'totalAccounts': 3,
          'totalAssets': 7482.2267,
          'currentAllocation': 0.0006
        },
        {
          'strategyId': '969C3962-3AE2-4269-BE57-C8FA3BDBCD5A-000D',
          'strategyAplId': 'DSWTF2',
          'items': [
            {
              'accountId': '3FA2FF10-EF38-4607-95C4-6CB55B235914-000D',
              'accountTitle': 'Magid Childs Joint Tenant with Rights of Survivorship TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': 'D33CCE54DF0A',
              'accountAplId': 'AM62M6',
              'amountAllocated': 292.3289,
              'accountAllocation': 0.1108,
              'parentClientWebId': 'W0U04O',
              'parentClientAplId': 'CB2WD0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship TOD'
            },
            {
              'accountId': '16737576-D160-4011-B2E0-CFDCAA37EEBC-000D',
              'accountTitle': 'NPC-IPG Gerrior Trust',
              'advisorId': 'AGAOSX',
              'accountNumber': 'AAAC44FA4659',
              'accountAplId': 'AM9S41',
              'amountAllocated': 851.0991,
              'accountAllocation': 0.3224,
              'parentClientWebId': 'W1H0K1',
              'parentClientAplId': 'CE8130',
              'accountType': 'MSA',
              'accountRegistrationType': 'Trust'
            },
            {
              'accountId': '4F03CF0A-743F-42BB-B07E-37EC4EC4DBB6-000D',
              'accountTitle': 'Teena Catacchio Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '74C74898074B',
              'accountAplId': 'AL8T64',
              'amountAllocated': 1089.5100,
              'accountAllocation': 0.4127,
              'parentClientWebId': 'W1BUOA',
              'parentClientAplId': 'CE3N24',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': 'FF9DD91B-EFF0-4940-B0E4-4B60A5FEC48B-000D',
              'accountTitle': 'Nabil Pillsbury Roth IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'F490C302D6B6',
              'accountAplId': 'AM1VM3',
              'amountAllocated': 407.4203,
              'accountAllocation': 0.1544,
              'parentClientWebId': 'W0YCT0',
              'parentClientAplId': 'CB4MO5',
              'accountType': 'MSA',
              'accountRegistrationType': 'Roth IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'Dorsey Wright Tactical Fixed Income',
          'totalAccounts': 4,
          'totalAssets': 2640.3583,
          'currentAllocation': 0.0002
        },
        {
          'strategyId': '81333985-9E16-4ABD-88A5-60764AEEB87B-000D',
          'strategyAplId': 'AMDFA5',
          'items': [
            {
              'accountId': '8B6C6D95-E4A9-403A-AD5F-16D130A49FD1-000D',
              'accountTitle': 'Bartt Grasso Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '4D698D076B08',
              'accountAplId': 'AN2GT1',
              'amountAllocated': 2476.7463,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1KJT4',
              'parentClientAplId': 'CE97N0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'MarketDimensions Portfolio, Profile 5',
          'totalAccounts': 1,
          'totalAssets': 2476.7463,
          'currentAllocation': 0.0002
        },
        {
          'strategyId': 'F8BCA1D8-157F-44C5-A8A0-B39BFF97C50B-000D',
          'strategyAplId': 'AMFTE4',
          'items': [
            {
              'accountId': 'E01126B4-3A2A-4B3A-913F-FA1B570BDCEA-000D',
              'accountTitle': 'Bartt Grasso Joint Tenant with Rights of Survivorship TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': '4F86188AE740',
              'accountAplId': 'AN2GT3',
              'amountAllocated': 2449.0650,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1KJT4',
              'parentClientAplId': 'CE97N0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship TOD'
            }
          ],
          'isBicEligible': true,
          'name': 'American Funds Growth & Income, Tax-Aware, Profile 4',
          'totalAccounts': 1,
          'totalAssets': 2449.0650,
          'currentAllocation': 0.0002
        },
        {
          'strategyId': 'A69F34AA-AA51-4A04-A670-3EBA22B12295-000D',
          'strategyAplId': 'ADFAT4',
          'items': [
            {
              'accountId': '8017EFBA-C3FF-43E2-A5A0-24D6218552B0-000D',
              'accountTitle': 'Bartt Grasso Joint Tenant with Rights of Survivorship TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': '4F86188AE740',
              'accountAplId': 'AN2GT3',
              'amountAllocated': 2449.0650,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1KJT4',
              'parentClientAplId': 'CE97N0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship TOD'
            }
          ],
          'isBicEligible': true,
          'name': 'MarketDimensions Portfolio - Tax Sensitive, Profile 4',
          'totalAccounts': 1,
          'totalAssets': 2449.0650,
          'currentAllocation': 0.0002
        },
        {
          'strategyId': 'B8CD7F7A-6A77-4AEF-9D5C-FD3AEC6657CA-000D',
          'strategyAplId': 'CPGGGE',
          'items': [
            {
              'accountId': 'FD921E73-B534-4606-9D36-8F26F1DC0863-000D',
              'accountTitle': 'Teena Catacchio Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': '65CEBBD68308',
              'accountAplId': 'AL8T68',
              'amountAllocated': 810.7007,
              'accountAllocation': 0.3313,
              'parentClientWebId': 'W1BUOA',
              'parentClientAplId': 'CE3N24',
              'accountType': 'MSA',
              'accountRegistrationType': 'Individual'
            },
            {
              'accountId': 'BE3FA1B8-8D51-40AB-B067-18A7BA8124AB-000D',
              'accountTitle': 'NPC-IPG Gerrior Trust',
              'advisorId': 'AGAOSX',
              'accountNumber': 'AAAC44FA4659',
              'accountAplId': 'AM9S41',
              'amountAllocated': 1636.7291,
              'accountAllocation': 0.6688,
              'parentClientWebId': 'W1H0K1',
              'parentClientAplId': 'CE8130',
              'accountType': 'MSA',
              'accountRegistrationType': 'Trust'
            }
          ],
          'isBicEligible': true,
          'name': 'Capital Group Global Growth Equity ',
          'totalAccounts': 2,
          'totalAssets': 2447.4298,
          'currentAllocation': 0.0002
        },
        {
          'strategyId': '1A1BBE3A-33A7-422B-88C4-31BB0267764B-000D',
          'strategyAplId': 'NFESA5',
          'items': [
            {
              'accountId': '4313358B-0E4B-46F8-AF5A-6614992F835B-000D',
              'accountTitle': 'Neely Nichols Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'C844A854A3B2',
              'accountAplId': 'AL0BP2',
              'amountAllocated': 1191.9311,
              'accountAllocation': 0.5862,
              'parentClientWebId': 'W11DZD',
              'parentClientAplId': 'CB6563',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            },
            {
              'accountId': 'E2AB24AB-8895-467E-AFA6-CDAE99FBE299-000D',
              'accountTitle': 'Neely Nichols Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '86B78F8AA218',
              'accountAplId': 'AL0BP0',
              'amountAllocated': 841.4537,
              'accountAllocation': 0.4139,
              'parentClientWebId': 'W11DZD',
              'parentClientAplId': 'CB6563',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'New Frontier ETF, Profile 5, Growth',
          'totalAccounts': 2,
          'totalAssets': 2033.3848,
          'currentAllocation': 0.0002
        },
        {
          'strategyId': 'FC7EB76F-763F-402C-A587-7F52F918B752-000D',
          'strategyAplId': 'NFETA2',
          'items': [
            {
              'accountId': 'D39C176E-9886-403F-A7F3-52150689FED8-000D',
              'accountTitle': 'Stefany Sandager Individual TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': 'C35FE669B948',
              'accountAplId': 'AM1UZ4',
              'amountAllocated': 1955.5500,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1E2VG',
              'parentClientAplId': 'CE55T4',
              'accountType': 'MSA',
              'accountRegistrationType': 'Individual TOD'
            }
          ],
          'isBicEligible': true,
          'name': 'New Frontier ETF, Profile 2, TS, Moderate Conservative',
          'totalAccounts': 1,
          'totalAssets': 1955.5500,
          'currentAllocation': 0.0002
        },
        {
          'strategyId': '60357D79-E804-48B4-9ED7-FB81A48A19D8-000D',
          'strategyAplId': 'JPMUV6',
          'items': [
            {
              'accountId': 'D9AF4CD5-0467-4CE6-81CA-FB83A110FD45-000D',
              'accountTitle': 'NPC-IPG Gerrior Trust',
              'advisorId': 'AGAOSX',
              'accountNumber': 'AAAC44FA4659',
              'accountAplId': 'AM9S41',
              'amountAllocated': 1833.1366,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1H0K1',
              'parentClientAplId': 'CE8130',
              'accountType': 'MSA',
              'accountRegistrationType': 'Trust'
            }
          ],
          'isBicEligible': true,
          'name': 'JPMorgan U.S. Value',
          'totalAccounts': 1,
          'totalAssets': 1833.1366,
          'currentAllocation': 0.0002
        },
        {
          'strategyId': 'E6443E6B-BF62-4FD3-AEAD-93CDD6458215-000D',
          'strategyAplId': 'MKTBL3',
          'items': [
            {
              'accountId': '1074CC57-8A8E-46F0-A448-66CC9001B15D-000D',
              'accountTitle': 'Grier Augspurger Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '25E132FA6FB4',
              'accountAplId': 'AM8WE1',
              'amountAllocated': 1827.0576,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1IISM',
              'parentClientAplId': 'CE7WH5',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'Global Market Blend, Profile 3, Moderate',
          'totalAccounts': 1,
          'totalAssets': 1827.0576,
          'currentAllocation': 0.0002
        },
        {
          'strategyId': 'C36435AC-B4AB-41D8-B348-53FA3453167D-000D',
          'strategyAplId': 'AMDFA3',
          'items': [
            {
              'accountId': 'D3825CED-9020-44EC-8C5B-6D9DA6E08E23-000D',
              'accountTitle': 'Grier Augspurger Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '25E132FA6FB4',
              'accountAplId': 'AM8WE1',
              'amountAllocated': 1827.0576,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1IISM',
              'parentClientAplId': 'CE7WH5',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'MarketDimensions Portfolio, Profile 3',
          'totalAccounts': 1,
          'totalAssets': 1827.0576,
          'currentAllocation': 0.0002
        },
        {
          'strategyId': '752856BD-A697-45EB-807E-0D35205640AC-000D',
          'strategyAplId': 'MKTBL4',
          'items': [
            {
              'accountId': 'C718410C-0434-4A3D-9DA7-DFE0CB6BF680-000D',
              'accountTitle': 'Magid Childs Joint Tenant with Rights of Survivorship TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': 'D33CCE54DF0A',
              'accountAplId': 'AM62M6',
              'amountAllocated': 584.6579,
              'accountAllocation': 0.3571,
              'parentClientWebId': 'W0U04O',
              'parentClientAplId': 'CB2WD0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship TOD'
            },
            {
              'accountId': '95E7C862-A0DB-4B62-B958-A86BB98C8B75-000D',
              'accountTitle': 'Teena Catacchio Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': '65CEBBD68308',
              'accountAplId': 'AL8T68',
              'amountAllocated': 1052.9791,
              'accountAllocation': 0.643,
              'parentClientWebId': 'W1BUOA',
              'parentClientAplId': 'CE3N24',
              'accountType': 'MSA',
              'accountRegistrationType': 'Individual'
            }
          ],
          'isBicEligible': true,
          'name': 'Global Market Blend, Profile 4, Moderate Growth',
          'totalAccounts': 2,
          'totalAssets': 1637.6370,
          'currentAllocation': 0.0002
        },
        {
          'strategyId': '9EF7F250-EFA3-4102-9D18-CF4BE5F70A76-000D',
          'strategyAplId': 'WENDG6',
          'items': [
            {
              'accountId': '57BEBC43-8DE4-4518-B7A4-495F1F98A21B-000D',
              'accountTitle': 'Bartt Grasso Joint Tenant with Rights of Survivorship TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': '4F86188AE740',
              'accountAplId': 'AN2GT3',
              'amountAllocated': 1269.8856,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1KJT4',
              'parentClientAplId': 'CE97N0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship TOD'
            }
          ],
          'isBicEligible': true,
          'name': 'WestEnd Global Equity ETF, Profile 6, Maximum Growth',
          'totalAccounts': 1,
          'totalAssets': 1269.8856,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': '14190BD5-54E7-405B-B729-700E999BE336-000D',
          'strategyAplId': 'LLCGG6',
          'items': [
            {
              'accountId': '0CD4755B-B861-43F9-980A-EE8F7653484E-000D',
              'accountTitle': 'Nabil Pillsbury Roth IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'F490C302D6B6',
              'accountAplId': 'AM1VM3',
              'amountAllocated': 1222.2610,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W0YCT0',
              'parentClientAplId': 'CB4MO5',
              'accountType': 'MSA',
              'accountRegistrationType': 'Roth IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'Logan Global Growth',
          'totalAccounts': 1,
          'totalAssets': 1222.2610,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': '0CFA9CBB-A9B9-4DBD-BF15-FB7BEA517203-000D',
          'strategyAplId': 'BLKED6',
          'items': [
            {
              'accountId': '4F549C32-8073-4185-95BD-CD1EBF577BDA-000D',
              'accountTitle': 'Stefany Sandager Individual TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': 'C35FE669B948',
              'accountAplId': 'AM1UZ4',
              'amountAllocated': 1222.2188,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1E2VG',
              'parentClientAplId': 'CE55T4',
              'accountType': 'MSA',
              'accountRegistrationType': 'Individual TOD'
            }
          ],
          'isBicEligible': true,
          'name': 'BlackRock Equity Dividend',
          'totalAccounts': 1,
          'totalAssets': 1222.2188,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': '2E21E628-F263-47B1-88AC-1E565C1336B5-000D',
          'strategyAplId': 'PSCSE6',
          'items': [
            {
              'accountId': '19C64CC1-A4F8-40B2-A689-9EBEFB5AF15E-000D',
              'accountTitle': 'NPC-IPG Gerrior Trust',
              'advisorId': 'AGAOSX',
              'accountNumber': 'AAAC44FA4659',
              'accountAplId': 'AM9S41',
              'amountAllocated': 1112.9758,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1H0K1',
              'parentClientAplId': 'CE8130',
              'accountType': 'MSA',
              'accountRegistrationType': 'Trust'
            }
          ],
          'isBicEligible': true,
          'name': 'Principal U.S. Small Cap Select Equity ',
          'totalAccounts': 1,
          'totalAssets': 1112.9758,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': 'A7BBD8DD-89F5-419F-96A6-B8791AB8BA0A-000D',
          'strategyAplId': 'AMFGR6',
          'items': [
            {
              'accountId': '47B3AC28-E2E4-4F5C-B2A3-119364FA7698-000D',
              'accountTitle': 'NPC-IPG Gerrior Trust',
              'advisorId': 'AGAOSX',
              'accountNumber': 'AAAC44FA4659',
              'accountAplId': 'AM9S41',
              'amountAllocated': 1112.9758,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1H0K1',
              'parentClientAplId': 'CE8130',
              'accountType': 'MSA',
              'accountRegistrationType': 'Trust'
            }
          ],
          'isBicEligible': true,
          'name': 'American Funds Growth, Profile 6',
          'totalAccounts': 1,
          'totalAssets': 1112.9758,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': '07817981-448C-4197-8613-7CE5ACF05019-000D',
          'strategyAplId': 'FTRLD1',
          'items': [
            {
              'accountId': '906A8169-7388-491C-993D-42DF06159BC3-000D',
              'accountTitle': 'Bartt Grasso Joint Tenant with Rights of Survivorship TOD',
              'advisorId': 'AGAOSX',
              'accountNumber': '4F86188AE740',
              'accountAplId': 'AN2GT3',
              'amountAllocated': 1088.4734,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1KJT4',
              'parentClientAplId': 'CE97N0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Joint Tenant with Rights of Survivorship TOD'
            }
          ],
          'isBicEligible': true,
          'name': 'First Trust Diversified Low Duration Fixed Income',
          'totalAccounts': 1,
          'totalAssets': 1088.4734,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': '9D1B89F9-8485-4750-851B-2DE194DB98A1-000D',
          'strategyAplId': 'DBLICS',
          'items': [
            {
              'accountId': 'A7B18928-6D95-4427-8203-4E7AD6AD177C-000D',
              'accountTitle': 'Bartt Grasso Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '4D698D076B08',
              'accountAplId': 'AN2GT1',
              'amountAllocated': 990.6985,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1KJT4',
              'parentClientAplId': 'CE97N0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'DoubleLine Shiller Enhanced CAPE - Class I',
          'totalAccounts': 1,
          'totalAssets': 990.6985,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': '43B9BE6A-91E9-4C85-94F9-28BA3BFB456E-000D',
          'strategyAplId': 'JPMAR1',
          'items': [
            {
              'accountId': '288739DD-DEFD-4A92-8AE0-5A73E0816D8C-000D',
              'accountTitle': 'Bartt Grasso Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': '4D698D076B08',
              'accountAplId': 'AN2GT1',
              'amountAllocated': 990.6985,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1KJT4',
              'parentClientAplId': 'CE97N0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'JPMorgan Absolute Return - Profile 1',
          'totalAccounts': 1,
          'totalAssets': 990.6985,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': 'B20A3E13-7AB7-441B-B138-646336FF70D9-000D',
          'strategyAplId': 'AMFPR1',
          'items': [
            {
              'accountId': '32DCCCF6-3B99-4315-AD9A-5F3A865C98E8-000D',
              'accountTitle': 'Cartwright Siegel Traditional IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'BEE118EACF99',
              'accountAplId': 'AM3723',
              'amountAllocated': 523.4558,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1EN3M',
              'parentClientAplId': 'CE5QI6',
              'accountType': 'MSA',
              'accountRegistrationType': 'Traditional IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'American Funds Preservation, Profile 1',
          'totalAccounts': 1,
          'totalAssets': 523.4558,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': 'E997095E-DF37-451D-96A8-147A2DB0A3D5-000D',
          'strategyAplId': 'NFETA3',
          'items': [
            {
              'accountId': '04B6C6BA-92D2-4853-BCD4-1A801F2E2E36-000D',
              'accountTitle': 'Nabil Pillsbury Trust',
              'advisorId': 'AGAOSX',
              'accountNumber': '505C59CE643A',
              'accountAplId': 'AM23E1',
              'amountAllocated': 411.7216,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W0YCT0',
              'parentClientAplId': 'CB4MO5',
              'accountType': 'MSA',
              'accountRegistrationType': 'Trust'
            }
          ],
          'isBicEligible': true,
          'name': 'New Frontier ETF, Profile 3, TS, Moderate',
          'totalAccounts': 1,
          'totalAssets': 411.7216,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': 'BE8A2A35-5FCB-4DC5-921F-1F544D295131-000D',
          'strategyAplId': 'SVSTLL',
          'items': [
            {
              'accountId': '53735268-2B60-4D62-A57F-254BB72CE07C-000D',
              'accountTitle': 'Nabil Pillsbury Roth IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'F490C302D6B6',
              'accountAplId': 'AM1VM3',
              'amountAllocated': 407.4203,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W0YCT0',
              'parentClientAplId': 'CB4MO5',
              'accountType': 'MSA',
              'accountRegistrationType': 'Roth IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'Savos US Risk Controlled Strategy, Profile 6',
          'totalAccounts': 1,
          'totalAssets': 407.4203,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': 'B85067AF-FDFC-42C3-BD6D-0246190741C5-000D',
          'strategyAplId': 'NFESA2',
          'items': [
            {
              'accountId': '77222CEE-E842-440C-BC68-04A423093827-000D',
              'accountTitle': 'Magid Childs Beneficiary IRA Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': '91F1CE1B156C',
              'accountAplId': 'AL5Z83',
              'amountAllocated': 363.9643,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W0U04O',
              'parentClientAplId': 'CB2WD0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Beneficiary IRA Individual'
            }
          ],
          'isBicEligible': true,
          'name': 'New Frontier ETF, Profile 2, Moderate Conservative',
          'totalAccounts': 1,
          'totalAssets': 363.9643,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': '6B3F5263-8970-46E8-AD76-99FF88269406-000D',
          'strategyAplId': 'MKTBL2',
          'items': [
            {
              'accountId': 'A9097668-F787-44BC-8B0E-DD482340FC0E-000D',
              'accountTitle': 'Tarick McBirney Roth IRA',
              'advisorId': 'AGAOSX',
              'accountNumber': 'E8CAC8F901BD',
              'accountAplId': 'AN5QT1',
              'amountAllocated': 335.3468,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W1M09G',
              'parentClientAplId': 'CF0FQ0',
              'accountType': 'MSA',
              'accountRegistrationType': 'Roth IRA'
            }
          ],
          'isBicEligible': true,
          'name': 'Global Market Blend, Profile 2, Moderate Conservative',
          'totalAccounts': 1,
          'totalAssets': 335.3468,
          'currentAllocation': 0.0001
        },
        {
          'strategyId': 'FAE50241-A200-47A0-A5DD-C43DEA8970D6-000D',
          'strategyAplId': 'NFESA4',
          'items': [
            {
              'accountId': '346742BF-1BCE-4B7D-B83C-E3A5349C2A68-000D',
              'accountTitle': 'Keree Frierson Beneficiary IRA Individual',
              'advisorId': 'AGAOSX',
              'accountNumber': 'CB9D562296B7',
              'accountAplId': 'AL6LQ3',
              'amountAllocated': 323.7483,
              'accountAllocation': 1.0,
              'parentClientWebId': 'W0TLZ6',
              'parentClientAplId': 'CB2T75',
              'accountType': 'MSA',
              'accountRegistrationType': 'Beneficiary IRA Individual'
            }
          ],
          'isBicEligible': true,
          'name': 'New Frontier ETF, Profile 4, Moderate Growth',
          'totalAccounts': 1,
          'totalAssets': 323.7483,
          'currentAllocation': 0.0001
        }
      ],
      'error': {
        'message': '',
        'code': 200
      },
      'lastUpdate': {
        'value': '2024-05-24T00:00:00+00:00',
        'kind': 'CalendarDate'
      }
    }
  }
}
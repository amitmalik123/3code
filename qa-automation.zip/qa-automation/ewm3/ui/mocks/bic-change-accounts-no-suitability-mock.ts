export class BicChangeAccountsNoSuitabilityMock {

  public static get data() {
    return {
      'data': [
        {
          'id': 'A08CB074-6A25-46FC-A8DF-F30F2A2D5067-000D',
          'name': 'Cartwright Siegel Traditional IRA',
          'status': 'Active',
          'registrationType': [
            'Traditional IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 107289.998277000000,
          'productId': '368F3A6A-0389-4DD7-874F-378898818E37-000D',
          'allocation': 0.669900,
          'sleeves': [
            {
              'sleeveProductId': '3317173C-88A1-4F50-BBA7-15155889CCDB-000D',
              'productName': 'American Funds Preservation, Profile 1',
              'allocation': 0.330100
            },
            {
              'sleeveProductId': 'F5A1FC01-2EFB-4F30-A0DD-E1294CFCB192-000D',
              'productName': 'Aris Income Builder, TS, Profile 2, Conservative',
              'allocation': 0.669900
            }
          ],
          'accountNumber': [
            'BEE118EACF99'
          ],
          'requiresSuitabilityCheck': false
        },
        {
          'id': '1EB98D7B-A17C-4D9C-A321-B6DA9C0270A5-000D',
          'name': 'Phan Tarnovski Traditional IRA',
          'status': 'Active',
          'registrationType': [
            'Traditional IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 14172.620000,
          'productId': '368F3A6A-0389-4DD7-874F-378898818E37-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': 'F5A1FC01-2EFB-4F30-A0DD-E1294CFCB192-000D',
              'productName': 'Aris Income Builder, TS, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            'E5BC63B1F94C'
          ],
          'requiresSuitabilityCheck': false
        },
        {
          'id': '1911818B-44B9-4BD1-84E3-B94C111BD1BF-000D',
          'name': 'Phan Tarnovski Beneficiary IRA Individual',
          'status': 'Active',
          'registrationType': [
            'Beneficiary IRA Individual'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 252048.480000,
          'productId': '368F3A6A-0389-4DD7-874F-378898818E37-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': 'F5A1FC01-2EFB-4F30-A0DD-E1294CFCB192-000D',
              'productName': 'Aris Income Builder, TS, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            'C4AF556F5E81'
          ],
          'requiresSuitabilityCheck': false
        },
        {
          'id': '0CA8119E-E9D4-42A2-9809-199A614DFFD5-000D',
          'name': 'Phan Tarnovski Individual',
          'status': 'Active',
          'registrationType': [
            'Individual'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 473682.920000,
          'productId': '368F3A6A-0389-4DD7-874F-378898818E37-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': 'F5A1FC01-2EFB-4F30-A0DD-E1294CFCB192-000D',
              'productName': 'Aris Income Builder, TS, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            'EC5077E13FBE'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '749CDD9B-77D6-495A-B823-0A051968C026-000D',
          'name': 'Phan Tarnovski Beneficiary IRA Individual',
          'status': 'Active',
          'registrationType': [
            'Beneficiary IRA Individual'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 76572.110000,
          'productId': '368F3A6A-0389-4DD7-874F-378898818E37-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': 'F5A1FC01-2EFB-4F30-A0DD-E1294CFCB192-000D',
              'productName': 'Aris Income Builder, TS, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            '7DA863B430DC'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': 'A9EEAC53-B213-407E-A55F-A43F5FB797A2-000D',
          'name': 'Antonio Pera Rollover IRA',
          'status': 'Active',
          'registrationType': [
            'Rollover IRA'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 49920.892000000000,
          'productId': '368F3A6A-0389-4DD7-874F-378898818E37-000D',
          'allocation': 0.350000,
          'sleeves': [
            {
              'sleeveProductId': '753DC35B-923D-4E83-B137-8F52BF1079B8-000D',
              'productName': 'Savos Fixed Income Portfolio, Intermediate Duration',
              'allocation': 0.150000
            },
            {
              'sleeveProductId': 'B1DE1958-1E94-4F35-948E-7697CD1F798E-000D',
              'productName': 'Global Market Blend, Profile 4, Moderate Growth',
              'allocation': 0.350000
            },
            {
              'sleeveProductId': '5881EEFA-F51D-4D80-844D-5E72F24BA5FD-000D',
              'productName': 'Savos US Risk Controlled Strategy, Profile 6',
              'allocation': 0.150000
            },
            {
              'sleeveProductId': 'F5A1FC01-2EFB-4F30-A0DD-E1294CFCB192-000D',
              'productName': 'Aris Income Builder, TS, Profile 2, Conservative',
              'allocation': 0.350000
            }
          ],
          'accountNumber': [
            'A307C91296FE'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '56D4426F-00FE-4E1E-83DC-2113474F92B4-000D',
          'name': 'Darol Turchetti Joint Tenant with Rights of Survivorship',
          'status': 'Active',
          'registrationType': [
            'Joint Tenant with Rights of Survivorship'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 158991.340000,
          'productId': '368F3A6A-0389-4DD7-874F-378898818E37-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': 'F5A1FC01-2EFB-4F30-A0DD-E1294CFCB192-000D',
              'productName': 'Aris Income Builder, TS, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            '27C63EED604F'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '798868D7-4131-43F6-ADCF-C8DC4371C30A-000D',
          'name': 'Magid Childs Joint Tenant with Rights of Survivorship TOD',
          'status': 'Active',
          'registrationType': [
            'Joint Tenant with Rights of Survivorship TOD'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 58988.924000000000,
          'productId': '368F3A6A-0389-4DD7-874F-378898818E37-000D',
          'allocation': 0.400000,
          'sleeves': [
            {
              'sleeveProductId': 'F5A1FC01-2EFB-4F30-A0DD-E1294CFCB192-000D',
              'productName': 'Aris Income Builder, TS, Profile 2, Conservative',
              'allocation': 0.400000
            },
            {
              'sleeveProductId': '2D1E44A2-592C-4F22-801A-37A0E2851E2E-000D',
              'productName': 'Dorsey Wright Tactical Fixed Income',
              'allocation': 0.200000
            },
            {
              'sleeveProductId': 'B1DE1958-1E94-4F35-948E-7697CD1F798E-000D',
              'productName': 'Global Market Blend, Profile 4, Moderate Growth',
              'allocation': 0.400000
            }
          ],
          'accountNumber': [
            'D33CCE54DF0A'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '8F35B088-40C2-455C-BA91-86941F62BF1D-000D',
          'name': 'Keree Frierson Beneficiary IRA Individual',
          'status': 'Active',
          'registrationType': [
            'Beneficiary IRA Individual'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 70431.985000000000,
          'productId': '368F3A6A-0389-4DD7-874F-378898818E37-000D',
          'allocation': 0.500000,
          'sleeves': [
            {
              'sleeveProductId': 'F5A1FC01-2EFB-4F30-A0DD-E1294CFCB192-000D',
              'productName': 'Aris Income Builder, TS, Profile 2, Conservative',
              'allocation': 0.500000
            },
            {
              'sleeveProductId': '8CBDD271-CDA8-47E4-B9B0-600ED9E051D2-000D',
              'productName': 'New Frontier ETF, Profile 4, Moderate Growth',
              'allocation': 0.500000
            }
          ],
          'accountNumber': [
            'D549FD84F21D'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': 'BA4064BC-3FBE-466A-8599-4E36F925455D-000D',
          'name': 'Keree Frierson Beneficiary IRA Individual',
          'status': 'Active',
          'registrationType': [
            'Beneficiary IRA Individual'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 32652.885000000000,
          'productId': '368F3A6A-0389-4DD7-874F-378898818E37-000D',
          'allocation': 0.500000,
          'sleeves': [
            {
              'sleeveProductId': 'F5A1FC01-2EFB-4F30-A0DD-E1294CFCB192-000D',
              'productName': 'Aris Income Builder, TS, Profile 2, Conservative',
              'allocation': 0.500000
            },
            {
              'sleeveProductId': '8CBDD271-CDA8-47E4-B9B0-600ED9E051D2-000D',
              'productName': 'New Frontier ETF, Profile 4, Moderate Growth',
              'allocation': 0.500000
            }
          ],
          'accountNumber': [
            'CB9D562296B7'
          ],
          'requiresSuitabilityCheck': true
        },
        {
          'id': '3DF83E35-5E97-47AE-854C-B8A06CAD23DF-000D',
          'name': 'Keree Frierson Individual',
          'status': 'Active',
          'registrationType': [
            'Individual'
          ],
          'isBICIneligible': false,
          'inEligibilityReason': '',
          'tmsEligible': false,
          'marketValue': 34218.130000,
          'productId': '368F3A6A-0389-4DD7-874F-378898818E37-000D',
          'allocation': 1.000000,
          'sleeves': [
            {
              'sleeveProductId': 'F5A1FC01-2EFB-4F30-A0DD-E1294CFCB192-000D',
              'productName': 'Aris Income Builder, TS, Profile 2, Conservative',
              'allocation': 1.000000
            }
          ],
          'accountNumber': [
            'B9880FF24584'
          ],
          'requiresSuitabilityCheck': true
        }
      ]
    }
  }
}
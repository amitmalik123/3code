export class LongAccountsMock {

  public static get data() {
    return {
      'data': {
        'data': [
          {
            'id': '69D589D2-870D-48D3-90E3-4E787F234C76-000D',
            'title': 'Brian & Naomi Wittlin, Joint Tenants with Rights of Survivorship',
            'applicationId': 'AI7W63',
            'alerts': [
              'Restricted Securities'
            ],
            'advisorIdentifier': 'AGAT58',
            'clientId': '64528C25-2C96-4155-ABCE-0CEAA300B151-000D',
            'clientName': 'Wittlin, Brian & Naomi S',
            'clientAplId': 'CA48Z7',
            'clientWebId': 'W0IT4H',
            'marketValue': 620433.2700,
            'expectedAmount': 445000.000000,
            'inceptionDate': '2017-04-27',
            'ytdPerformance': 0.0995000000,
            'oneYearPerformance': 0.1487000000,
            'threeYearPerformance': 0.0431000000,
            'fiveYearPerformance': 0.0812000000,
            'cumulativeReturn': 0.6378011097597646941154308226,
            'annualizedPerformance': 0.0705000000,
            'bankAccountNumber': '13012644',
            'status': 'Active',
            'investmentProduct': 'Clark Navigator Personalized UMA, Profile 5, Growth',
            'registrationType': 'Joint Tenant with Rights of Survivorship',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'netInvestment': 355000.000000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': 'A290B069-0835-4CDA-AD8A-C39B36CFE051-000D',
            'title': 'Francis Neelon, Rollover IRA',
            'applicationId': 'AI5RM2',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': 'C0B2E6FD-1CB0-42ED-8E9E-D060088FB393-000D',
            'clientName': 'Neelon, Francis',
            'clientAplId': 'C32651',
            'clientWebId': 'W04VDA',
            'marketValue': 140348.0600,
            'expectedAmount': 50000.000000,
            'inceptionDate': '2016-12-05',
            'ytdPerformance': 0.0252000000,
            'oneYearPerformance': 0.0461000000,
            'threeYearPerformance': -0.0261000000,
            'fiveYearPerformance': -0.0064000000,
            'cumulativeReturn': 0.0223507586721020618828586015,
            'annualizedPerformance': 0.0029000000,
            'bankAccountNumber': '13728653',
            'status': 'Active',
            'investmentProduct': 'Custodial Sweep',
            'registrationType': 'Rollover IRA',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'netInvestment': 160298.630000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '1A82C5EC-FE93-4E7E-BDEE-3B3C45BC812B-000D',
            'title': 'Janice Cawley Price Trust U/A 1/28/02',
            'applicationId': 'AL5SS1',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': '24187F99-D89E-4146-9369-81FF575531A6-000D',
            'clientName': 'Janice Cawley Price Trust U/A 1/28/02',
            'clientAplId': 'CE2DQ7',
            'clientWebId': 'W19FDS',
            'marketValue': 0.0,
            'expectedAmount': 275000.000000,
            'inceptionDate': '2021-09-07',
            'bankAccountNumber': '13029190',
            'status': 'Terminated',
            'investmentProduct': 'Clark Navigator Personalized UMA, Profile 1, Conservative',
            'registrationType': 'Trust',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': 'BFB9C797-4C85-4769-8E21-EA782E212360-000D',
            'title': 'Francis Neelon, Rollover IRA',
            'applicationId': 'A81727',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': 'C0B2E6FD-1CB0-42ED-8E9E-D060088FB393-000D',
            'clientName': 'Neelon, Francis',
            'clientAplId': 'C32651',
            'clientWebId': 'W04VDA',
            'marketValue': 0.0,
            'expectedAmount': 465981.250000,
            'inceptionDate': '2006-01-24',
            'bankAccountNumber': 'M001003976',
            'status': 'Terminated',
            'investmentProduct': 'No Strategist',
            'registrationType': 'Rollover IRA',
            'approach': '',
            'custodian': 'Fiserv ISS',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '0102AEC4-71D6-4F6B-BF1D-B5A18917BD53-000D',
            'title': 'Laura Stevens, Beneficiary IRA',
            'applicationId': 'AI4VR7',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': '3CC2A866-BF4A-4CB4-BE3A-29F90C4EDCCA-000D',
            'clientName': 'Stevens, Laura',
            'clientAplId': 'CA8CF7',
            'clientWebId': 'W0PXR2',
            'marketValue': 0.0,
            'expectedAmount': 130000.000000,
            'inceptionDate': '2016-09-14',
            'bankAccountNumber': '13429225',
            'status': 'Terminated',
            'investmentProduct': 'SSGA, Profile 3, Moderate',
            'registrationType': 'Beneficiary IRA Individual',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': 'A4E57F0A-3AE7-4F12-AC16-8D321833EAF3-000D',
            'title': 'SUZANNE ROSE, Individual',
            'applicationId': 'AK0NJ7',
            'alerts': [],
            'advisorIdentifier': 'AGAT5R',
            'clientId': '4AF96127-9460-434C-94AB-9F62494E66A4-000D',
            'clientName': 'Rose, Suzanne',
            'clientAplId': 'C01430',
            'clientWebId': 'W02ISC',
            'marketValue': 0.0,
            'expectedAmount': 0.000000,
            'inceptionDate': '2019-08-01',
            'bankAccountNumber': '13019322',
            'status': 'Terminated',
            'investmentProduct': 'Dollar Cost Average Cash Account',
            'registrationType': 'Individual',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '873FAFAF-ED6E-4D57-80CC-1A3B5F89362E-000D',
            'title': 'Dan Hanfling and Tanvi Nagpal, Joint With Rights of Survival',
            'applicationId': 'AI10P4',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': 'AC9C0ED6-393E-4504-85BC-287AC95B8591-000D',
            'clientName': 'Hanfling, Dan and Tanvi Nagpal',
            'clientAplId': 'C32315',
            'clientWebId': 'W04QLN',
            'marketValue': 0.0,
            'expectedAmount': 194130.650000,
            'inceptionDate': '2015-11-30',
            'bankAccountNumber': '960169419',
            'status': 'Terminated',
            'investmentProduct': 'SSGA, Profile 4, Moderate Growth',
            'registrationType': 'Joint Tenant with Rights of Survivorship',
            'approach': '',
            'custodian': 'Schwab',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '0C853DCD-5303-4005-9BED-ED825E1F98C6-000D',
            'title': 'Lynne P Boone, Traditional IRA',
            'applicationId': 'AI4D52',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': 'CFAA7B13-53E8-4BCC-B032-EF40BEC95B18-000D',
            'clientName': 'Boone, Lynne P',
            'clientAplId': 'CA8581',
            'clientWebId': 'W0OTXF',
            'marketValue': 0.0,
            'expectedAmount': 247761.000000,
            'inceptionDate': '2016-08-08',
            'bankAccountNumber': '960173767',
            'status': 'Terminated',
            'investmentProduct': 'SSGA, Profile 3, Moderate',
            'registrationType': 'Traditional IRA',
            'approach': '',
            'custodian': 'Schwab',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '95FDEABF-08BD-409C-9595-F19A91611F30-000D',
            'title': 'Dan Hanfling',
            'applicationId': 'AC7V55',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': 'AC9C0ED6-393E-4504-85BC-287AC95B8591-000D',
            'clientName': 'Hanfling, Dan and Tanvi Nagpal',
            'clientAplId': 'C32315',
            'clientWebId': 'W04QLN',
            'marketValue': 0.0,
            'expectedAmount': 300000.000000,
            'inceptionDate': '2011-11-01',
            'bankAccountNumber': '960971756',
            'status': 'Terminated',
            'investmentProduct': 'JPMorgan Global Flexible, Profile 3',
            'registrationType': 'Rollover IRA',
            'approach': '',
            'custodian': 'Schwab',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '69FAEBF2-1946-4FF7-A320-071164A9A9E7-000D',
            'title': 'Aimee J Sevier, SEP IRA',
            'applicationId': 'AH7MK2',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': '29F9B5FE-0494-4CA0-8415-D27197C806EE-000D',
            'clientName': 'Sevier, Vincent L & Aimee J',
            'clientAplId': 'CA1RX7',
            'clientWebId': 'W0EG5A',
            'marketValue': 0.0,
            'expectedAmount': 74000.000000,
            'inceptionDate': '2015-01-22',
            'bankAccountNumber': '13286931',
            'status': 'Terminated',
            'investmentProduct': 'SSGA, Profile 4, Moderate Growth',
            'registrationType': 'SEP-IRA',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '2440D6A4-DE2F-4161-8C3D-2D5B1DC09F09-000D',
            'title': 'VLS Innovations in Healthcare SC 401k Plan FBO Dr. Vincent Sevier AssetMark Retirement Services',
            'applicationId': 'AL23B7',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': '29F9B5FE-0494-4CA0-8415-D27197C806EE-000D',
            'clientName': 'Sevier, Vincent L & Aimee J',
            'clientAplId': 'CA1RX7',
            'clientWebId': 'W0EG5A',
            'marketValue': 465943.3300,
            'expectedAmount': 396461.000000,
            'inceptionDate': '2021-03-25',
            'ytdPerformance': 0.0786000000,
            'oneYearPerformance': 0.1352000000,
            'threeYearPerformance': 0.0303000000,
            'fiveYearPerformance': 0.0000000000,
            'cumulativeReturn': 0.1765324862618468420542515691,
            'annualizedPerformance': 0.0500000000,
            'bankAccountNumber': '13906645',
            'status': 'Active',
            'investmentProduct': 'SSGA, Profile 4, Moderate Growth',
            'registrationType': 'Individual 401(k)',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'netInvestment': 389147.000000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': 'F9EF0C58-0C6B-42AC-B35C-2BA3E0551C00-000D',
            'title': 'Vincent Sevier, Roth IRA',
            'applicationId': 'AL30W4',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': '29F9B5FE-0494-4CA0-8415-D27197C806EE-000D',
            'clientName': 'Sevier, Vincent L & Aimee J',
            'clientAplId': 'CA1RX7',
            'clientWebId': 'W0EG5A',
            'marketValue': 0.0,
            'expectedAmount': 48504.000000,
            'inceptionDate': '2021-04-30',
            'bankAccountNumber': '13919217',
            'status': 'Terminated',
            'investmentProduct': 'Custodial Sweep',
            'registrationType': 'Roth IRA',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': 'D5AD8623-645D-4907-A706-B46156CDD123-000D',
            'title': 'Betty A Lallier Trust Under Agreement',
            'applicationId': 'AH12N2',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': '48BC7471-1D60-4413-9920-1B9411AE4C06-000D',
            'clientName': 'Ragsdale Lallier, Rebecca',
            'clientAplId': 'CA1EY8',
            'clientWebId': 'W0E5C8',
            'marketValue': 0.0,
            'expectedAmount': 203000.000000,
            'inceptionDate': '2012-11-16',
            'bankAccountNumber': '13017908',
            'status': 'Terminated',
            'investmentProduct': 'SSGA, Profile 3, Moderate',
            'registrationType': 'Trust',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': 'A93D6727-B097-4587-83FF-8A309FB9F109-000D',
            'title': 'Vincent Sevier, SEP IRA',
            'applicationId': 'AC8LZ6',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': '29F9B5FE-0494-4CA0-8415-D27197C806EE-000D',
            'clientName': 'Sevier, Vincent L & Aimee J',
            'clientAplId': 'CA1RX7',
            'clientWebId': 'W0EG5A',
            'marketValue': 0.0,
            'expectedAmount': 130000.000000,
            'inceptionDate': '2012-01-26',
            'bankAccountNumber': '10187563',
            'status': 'Terminated',
            'investmentProduct': 'SSGA, Profile 4, Moderate Growth',
            'registrationType': 'SEP-IRA',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '989AD203-2B78-41D7-9228-E3E3FEA0B9F5-000D',
            'title': 'Suzanne Rose  IRA Rollover',
            'applicationId': 'A35592',
            'alerts': [],
            'advisorIdentifier': 'AGAT5R',
            'clientId': '4AF96127-9460-434C-94AB-9F62494E66A4-000D',
            'clientName': 'Rose, Suzanne',
            'clientAplId': 'C01430',
            'clientWebId': 'W02ISC',
            'marketValue': 305439.6600,
            'expectedAmount': 80000.000000,
            'inceptionDate': '2002-11-08',
            'ytdPerformance': 0.0611000000,
            'oneYearPerformance': 0.1194000000,
            'threeYearPerformance': 0.0213000000,
            'fiveYearPerformance': 0.0462000000,
            'cumulativeReturn': 2.0430963322357067520776293796,
            'annualizedPerformance': 0.0526000000,
            'bankAccountNumber': '13718643',
            'status': 'Active',
            'investmentProduct': 'American Funds Moderate Growth and Income, Profile 3',
            'registrationType': 'Rollover IRA',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'netInvestment': 116543.050000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '1884E7B3-1526-4065-A25E-40A3941734C1-000D',
            'title': 'Dan Hanfling and Tanvi Nagpal, Joint With Rights of Survival',
            'applicationId': 'A81085',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': 'AC9C0ED6-393E-4504-85BC-287AC95B8591-000D',
            'clientName': 'Hanfling, Dan and Tanvi Nagpal',
            'clientAplId': 'C32315',
            'clientWebId': 'W04QLN',
            'marketValue': 0.0,
            'expectedAmount': 267163.260000,
            'inceptionDate': '2006-01-31',
            'bankAccountNumber': '960025336',
            'status': 'Terminated',
            'investmentProduct': 'Litman Gregory, Profile 4, TS, Moderate Growth',
            'registrationType': 'Joint Tenant with Rights of Survivorship',
            'approach': '',
            'custodian': 'Schwab',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '468794E4-5F88-4C5A-964B-FB209EFFD861-000D',
            'title': 'Dan Hanfling SEP-IRA',
            'applicationId': 'A81084',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': 'AC9C0ED6-393E-4504-85BC-287AC95B8591-000D',
            'clientName': 'Hanfling, Dan and Tanvi Nagpal',
            'clientAplId': 'C32315',
            'clientWebId': 'W04QLN',
            'marketValue': 0.0,
            'expectedAmount': 91000.000000,
            'inceptionDate': '2006-01-20',
            'bankAccountNumber': '960935567',
            'status': 'Terminated',
            'investmentProduct': 'New Frontier ETF, Profile 3, Moderate',
            'registrationType': 'SEP-IRA',
            'approach': '',
            'custodian': 'Schwab',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '191850B6-4F06-452C-9725-D010B85D1542-000D',
            'title': 'Brian & Naomi Wittlin, Joint Tenants with Rights of Survivorship',
            'applicationId': 'AI7W61',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': '64528C25-2C96-4155-ABCE-0CEAA300B151-000D',
            'clientName': 'Wittlin, Brian & Naomi S',
            'clientAplId': 'CA48Z7',
            'clientWebId': 'W0IT4H',
            'marketValue': 175539.2300,
            'expectedAmount': 255000.000000,
            'inceptionDate': '2017-04-27',
            'ytdPerformance': -0.0116000000,
            'oneYearPerformance': 0.0102000000,
            'threeYearPerformance': -0.0216000000,
            'fiveYearPerformance': -0.0020000000,
            'cumulativeReturn': 0.0510576168793789617773772785,
            'annualizedPerformance': 0.0069000000,
            'bankAccountNumber': '13012642',
            'status': 'Active',
            'investmentProduct': 'Clark Navigator Tax-Free Fixed Income',
            'registrationType': 'Joint Tenant with Rights of Survivorship',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'netInvestment': 165000.000000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': 'B53021EE-A44C-4149-A09B-0463881A0758-000D',
            'title': 'Dawn E Kleinman, Individual',
            'applicationId': 'AK4410',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': 'C37E939B-C238-40DC-9906-7A6A5EC69061-000D',
            'clientName': 'Kleinman, Dawn',
            'clientAplId': 'CD7R61',
            'clientWebId': 'W12XJO',
            'marketValue': 0.0,
            'expectedAmount': 394476.000000,
            'inceptionDate': '2020-02-26',
            'bankAccountNumber': 'BKU543117',
            'status': 'Terminated',
            'investmentProduct': 'New Frontier ETF, Profile 4, TS, Moderate Growth',
            'registrationType': 'Individual',
            'approach': '',
            'custodian': 'Pershing Advisor Solutions',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '40F4375E-F6BE-4E3B-BBFB-88ED3DC250AE-000D',
            'title': 'Dawn E Kleinman, Individual',
            'applicationId': 'AK4411',
            'alerts': [],
            'advisorIdentifier': 'AGAT58',
            'clientId': 'C37E939B-C238-40DC-9906-7A6A5EC69061-000D',
            'clientName': 'Kleinman, Dawn',
            'clientAplId': 'CD7R61',
            'clientWebId': 'W12XJO',
            'marketValue': 0.0,
            'expectedAmount': 386502.000000,
            'inceptionDate': '2020-02-26',
            'bankAccountNumber': 'BKU543125',
            'status': 'Terminated',
            'investmentProduct': 'SSGA, Profile 4, Tax-Sensitive, Moderate Growth',
            'registrationType': 'Individual',
            'approach': '',
            'custodian': 'Pershing Advisor Solutions',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '09EED91E-1EA9-4C66-A1FC-CC8180F7F711-000D',
            'title': 'Tracy G Lallier Successor Beneficiary, Beneficiary IRA',
            'applicationId': 'AN1825',
            'alerts': [],
            'advisorIdentifier': 'AGAT5R',
            'clientId': 'E1F7BB95-3214-4CE2-950E-E23059E444E8-000D',
            'clientName': 'Lallier, Tracy',
            'clientAplId': 'CE8RI0',
            'clientWebId': 'W1JIZP',
            'marketValue': 0.0,
            'expectedAmount': 84442.000000,
            'inceptionDate': '2023-08-04',
            'ytdPerformance': 0.0000000000,
            'oneYearPerformance': 0.0000000000,
            'threeYearPerformance': 0.0000000000,
            'fiveYearPerformance': 0.0000000000,
            'cumulativeReturn': 0.0,
            'annualizedPerformance': 0.0000000000,
            'bankAccountNumber': '40205165',
            'status': 'Terminated',
            'investmentProduct': 'Global Market Blend, Profile 3, Moderate',
            'registrationType': 'Beneficiary IRA Individual',
            'approach': '',
            'custodian': 'AssetMark Trust',
            'netInvestment': -7341.580000,
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          }
        ],
        'start': 0,
        'limit': 447,
        'total': 447
      },
      'error': {
        'message': '',
        'code': 200
      },
      'lastUpdate': {
        'value': '2024-07-24T00:00:00+00:00',
        'kind': 'CalendarDate'
      }

    }
  }
}
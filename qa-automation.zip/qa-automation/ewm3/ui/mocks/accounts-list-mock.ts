import { BaseClientSectionMockData } from '../pages/base-client-section-page'

export class AccountsListMock implements BaseClientSectionMockData {
  get data() {
    return {
      'data': [
      ],
      'error': {
        'message': '',
        'code': 200
      }
    }
  }

  get longTitleClient() {
    return {
      'data': {
        'data': [
          {
            'id': '9E73AEE8-D129-4D6D-BA59-56D33D476D9D-000D',
            'title': 'Angelica Fahlen Joint Tenant with Rights of Survivorship - Account with Long name',
            'applicationId': '57870463282205|57870463282205',
            'alerts': [],
            'advisorIdentifier': '0036000000O8TUBAAY',
            'clientId': 'DAC27E88-0203-4A39-9B3E-B50548B9353C-000D',
            'clientName': 'Cichon Services Corp. - 403(b) Assets',
            'clientAplId': '57870463282205',
            'clientWebId': 'W0I13O',
            'marketValue': 3500.0,
            'expectedAmount': 1000.0,
            'inceptionDate': '2020-04-18',
            'ytdPerformance': 0.0281000000,
            'oneYearPerformance': 0.1720000000,
            'threeYearPerformance': 0.0358000000,
            'fiveYearPerformance': 0.0804000000,
            'cumulativeReturn': 0.943023401142895,
            'annualizedPerformance': 0.0648000000,
            'registrationType': 'Traditional IRA',               
            'custodian': 'AssetMark Trust',
            'netInvestment': 230083.130000,
            'bankAccountNumber': '31B53E258CA2',
            'status': 'Proposed',
            'investmentProduct': 'EPIC Other, Off-Platform',
            'approach': '',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
        ],
        'start': 0,
        'limit': 1,
        'total': 1
      },
      'error': {
        'message': '',
        'code': 200
      },
      'lastUpdate': {
        'value': '2024-04-05T00:00:00+00:00',
        'kind': 'CalendarDate'
      }
    }
  }

  get itemsForFilter() {
    return {
      'data': {
        'data': [
          {
            'id': '8C99AEE9-E130-4D6D-BA59-56D33D476D7C-000C',
            'title': 'Second Account',
            'applicationId': '23370463282197',
            'alerts': [],
            'advisorIdentifier': '0037000000O8TUCBAC',
            'clientId': 'DAC27E88-0203-4A39-9B3E-B50548B9353C-000D',
            'clientName': 'Cichon Services Corp. - 403(b) Assets',
            'clientAplId': '57870463282205',
            'clientWebId': 'W0I13O',
            'marketValue': 2500.0,
            'expectedAmount': 100.0,
            'inceptionDate': '2021-03-18',
            'ytdPerformance': 0.0181000000,
            'oneYearPerformance': 0.1420000000,
            'threeYearPerformance': 0.0258000000,
            'fiveYearPerformance': 0.0704000000,
            'cumulativeReturn': 0.773023401142895,
            'annualizedPerformance': 0.0548000000,
            'registrationType': 'Traditional IRA',               
            'custodian': 'AssetMark Trust',
            'netInvestment': 180083.130000,
            'bankAccountNumber': '23C53E258CC1',
            'status': 'Pending Funding',
            'investmentProduct': 'New EPIC Other',
            'approach': '',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
          {
            'id': '9E73AEE8-D129-4D6D-BA59-56D33D476D9D-000D',
            'title': 'Angelica Fahlen Joint Tenant with Rights of Survivorship - Account with Long name',
            'applicationId': '57870463282205|57870463282205',
            'alerts': [],
            'advisorIdentifier': '0036000000O8TUBAAY',
            'clientId': 'DAC27E88-0203-4A39-9B3E-B50548B9353C-000D',
            'clientName': 'Cichon Services Corp. - 403(b) Assets',
            'clientAplId': '57870463282205',
            'clientWebId': 'W0I13O',
            'marketValue': 3500.0,
            'expectedAmount': 1000.0,
            'inceptionDate': '2020-04-18',
            'ytdPerformance': 0.0281000000,
            'oneYearPerformance': 0.1720000000,
            'threeYearPerformance': 0.0358000000,
            'fiveYearPerformance': 0.0804000000,
            'cumulativeReturn': 0.943023401142895,
            'annualizedPerformance': 0.0648000000,
            'registrationType': 'Traditional IRA',               
            'custodian': 'AssetMark Trust',
            'netInvestment': 230083.130000,
            'bankAccountNumber': '31B53E258CA2',
            'status': 'Proposed',
            'investmentProduct': 'EPIC Other, Off-Platform',
            'approach': '',
            'assetAllocations': [
              {
                'assetClass': 'Equity',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'FixedIncome',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'AlternativeInvestments',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'Cash',
                'allocationWeight': 0.2
              },
              {
                'assetClass': 'CashAlternatives',
                'allocationWeight': 0.2
              }
            ]
          },
        ],
        'start': 0,
        'limit': 1,
        'total': 1
      },
      'error': {
        'message': '',
        'code': 200
      },
      'lastUpdate': {
        'value': '2024-04-05T00:00:00+00:00',
        'kind': 'CalendarDate'
      }
    }
  }
}
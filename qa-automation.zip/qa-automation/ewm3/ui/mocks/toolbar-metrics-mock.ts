export class ToolbarMetricsMock {

  get longMetricsValueHHAccounts() {
    return {
      'data': {
        'households': 188888333335,
        'accounts': 2555557777772,
        'platformAssets': 1111122222337755.48,
        'pendingFunds': 7777799999552233.98
      },
      'error': {
        'message': '',
        'code': 200
      }
    }
  }

  get longMetricsValueIndividualHH() {
    return {
      'data': {
        'id': '5EEA3FE7-140F-435F-8F20-79D7BE5A0C3A-000D',
        'name': 'Adler, Vanya',
        'applicationId': 'CA1RX7',
        'webId': 'W0EG5A',
        'accountsCount': 0,
        'portfolioValue': 1111122222337755.48,
        'clientRisk': 'Client risk placeholder - Client risk placeholder',
        'accounts': []
      },
      'error': {
        'message': '',
        'code': 200
      }
    }
  }

  get longMetricsValueIndividualAccount() {
    return {
      'data': {
        'clientRisk': 'Account risk placeholder - Account risk placeholder',
        'accountValue': 7777799999552233.98,
        'client': {
          'accounts': [
            {
              'id': '3C17B2E1-1E37-4F35-9F69-D8D977587568-000D',
              'title': 'Abbie Steer Traditional IRA',
              'applicationId': 'AEH4B4',
              'bankAccountNumber': '3D99085D26373D99085D2637'
            }
          ],
          'id': 'E5B144C6-3AC5-442C-A31E-C1C3FC16FE78-000D',
          'name': 'Steer, Abbie',
          'applicationId': 'CZ13CT',
          'webId': 'CZ13CT',
          'advisorIdentifier': 'AGAOSX'
        },
        'id': '3C17B2E1-1E37-4F35-9F69-D8D977587568-000D',
        'title': 'Abbie Steer Traditional IRA',
        'applicationId': 'AEH4B4',
        'bankAccountNumber': '3D99085D26373D99085D2637'
      },
      'error': {
        'message': '',
        'code': 200
      }
    }
  }  
}
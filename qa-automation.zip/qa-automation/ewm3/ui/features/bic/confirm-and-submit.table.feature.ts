import { AccountsToChangeTableFeature } from './change-accounts.table.feature'

export class ConfirmAndSubmitTableFeature extends AccountsToChangeTableFeature {

}
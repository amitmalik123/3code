import { expect, test } from '@playwright/test'
import { BicAccountData, TableFeature, TableRow } from '../table.feature'
import { AccountsToChangeTableLocators } from '../../elements/bic/change-accounts.table.el'
import { BicConfig } from '../../../service-data/tile-config/bic.config'
import { CsvHelpers } from '../../../../utils/csv-helpers'
import { BaseBrowserHelpers } from '../../../../base/base-browser-helpers'

export interface CsvFileData {
  'Account Title': string;
  'Status': string;
  'Reg Type': string;
  'Account #': string;
  'TMS': string;
  'Amount Allocated': string;
  'Allocated': string;
}

export class AccountsToChangeTableFeature extends TableFeature {
  readonly locators = new AccountsToChangeTableLocators(this.page, this.container)
  private readonly browserHelpers = new BaseBrowserHelpers(this.page)

  /**
 * Attempts to either select or unselect a specified number of account checkboxes based on the given action
 * It processes checkboxes only if they are enabled and only performs 'check' if they are currently unchecked,
 * or 'uncheck' if they are currently checked. This method skips accounts that cannot be processed due to being disabled
 *
 * The method will not attempt to process more accounts than are present in the table
 *
 * @param {number} count - The number of account rows to attempt to process, limited to the number of rows available
 * @param {'check' | 'uncheck'} action - The action to perform on the checkboxes, either 'check' to select, or 'uncheck' to deselect
 * @returns {Promise<number[]>} A promise that resolves to an array of indexes of the accounts that were successfully processed
 *                              This array contains the indexes of the rows where the action was successfully completed
 * 
 * @example
 * // To select the first 3 accounts that are not already selected:
 * const checkedIndexes = await accountsCheckboxes(3, 'check');
 * console.log(checkedIndexes); // Outputs indexes of newly checked accounts, e.g., [0, 2, 4]
 *
 * // To unselect the first 3 accounts that are currently selected:
 * const uncheckedIndexes = await accountsCheckboxes(3, 'uncheck');
 * console.log(uncheckedIndexes); // Outputs indexes of newly unchecked accounts, e.g., [1, 3, 5]
 */
  public async accountsCheckboxes(count: number, action: 'check' | 'uncheck'): Promise<number[]> {
    const processedIndexes: number[] = []
    const allTableRows = await this.locators.tableRows.count() // Get the total count of table rows

    await test.step(`Loop to ${action} accounts up to the specified count and assert the ${action === 'check' ? 'selection' : 'deselection'}`, async () => {
      for (let rowIndex = 0; rowIndex < Math.min(count, allTableRows); rowIndex++) {
        const checkBox = this.locators.checkbox(this.locators.tableRows.nth(rowIndex))
        const isChecked = await checkBox.isChecked()
        const isEnabled = await checkBox.isEnabled()
            
        if (isEnabled && ((action === 'check' && !isChecked) || (action === 'uncheck' && isChecked))) {
          await test.step(`${action === 'check' ? 'Checking' : 'Unchecking'} checkbox at row index: ${rowIndex}`, async () => {
            action === 'check' ? await checkBox.check() : await checkBox.uncheck()
          })
          await test.step(`Verifying checkbox at row index: ${rowIndex} is ${action === 'check' ? 'checked' : 'unchecked'}`, async () => {
            processedIndexes.push(rowIndex) // Add the index to the processedIndexes array
          })
        }
      }
      await this.assertAccountsSelection(action, processedIndexes)
    })
    return processedIndexes
  }

  /**
 * Asserts that the checkboxes in specified rows or all rows in a table are either checked or not checked,
 * based on the specified action ('check' for selected, 'uncheck' for not selected).
 * This method can operate in two modes:
 * 1. If the `rowIndex` array is provided, it asserts the state of the checkboxes only in the specified rows.
 * 2. If the `rowIndex` array is not provided, it asserts the state of the checkboxes in all rows of the table.
 *
 * @param {number[]} [rowIndex] - Optional array of row indexes. If provided, the method will only check rows at these indexes.
 *                                If omitted, the method will check all rows in the table.
 * @param {'check' | 'uncheck'} action - Specifies whether to check if the checkboxes are selected ('check') or not selected ('uncheck').
 * @returns {Promise<void>} A promise that resolves when all specified checks have been asserted without throwing an error.
 * @throws {Error} Throws an error if a checkbox in any of the specified rows does not meet the expected condition (checked or unchecked).
 */
  public async assertAccountsSelection(action: 'check' | 'uncheck', rowIndex?: number[]): Promise<void> {
    await test.step(`Asserts that the checkboxes in specified rows or all rows in a table are ${action === 'check' ? 'selected' : 'not selected'}`, async () => {
      const indexes = rowIndex || Array.from({ length: await this.locators.tableRows.count() }, (_, i) => i)
      for (const index of indexes) {
        const checkboxLocator = this.locators.checkbox(this.locators.tableRows.nth(index))
        const isEnabled = await checkboxLocator.isEnabled()
        if (isEnabled) {
          if (action === 'check') {
            await expect.soft(checkboxLocator, `Expect Account with row index: ${index} to be selected`).toBeChecked()
          } else {
            await expect.soft(checkboxLocator, `Expect Account with row index: ${index} to be not selected`).not.toBeChecked()
          }
        } else if (rowIndex) {
          expect.soft(isEnabled, `Verify that checkbox at row index ${index} is enabled and account is eligible`).toBe(true)
        }
      }
    })
  }

  /**
 * Gets the row indexes of checked and unchecked accounts
 * This method can operate in two modes:
 * 1. If the `rowIndex` array is provided, it checks the state of checkboxes only in the specified rows
 * 2. If the `rowIndex` array is not provided, it checks the state of checkboxes in all rows of the table
 *
 * @param {number[]} [rowIndex] - Optional array of row indexes. If provided, the method will only check rows at these indexes
 *                                If omitted, the method will check all rows in the table
 * @returns {Promise<[number[], number[]]>} A promise that resolves to a tuple containing two arrays:
 *                                          - The first array contains the indexes of checked accounts
 *                                          - The second array contains the indexes of unchecked accounts
 */
  public async getCheckedAndUncheckedIndexes(rowIndex?: number[]): Promise<[number[], number[]]> {
    return await test.step(`Get row indexes of checked and unchecked accounts`, async () => {
      const checkedAccountsIndexes: number[] = []
      const uncheckedAccountsIndexes: number[] = []
      const indexes = rowIndex || Array.from({ length: await this.locators.tableRows.count() }, (_, i) => i)
      
      for (const index of indexes) {
        const checkboxLocator = this.locators.checkbox(this.locators.tableRows.nth(index))
        if(await checkboxLocator.isEnabled()) { 
          if (await checkboxLocator.isChecked() ) {
            checkedAccountsIndexes.push(index)
          } 
          else {
            uncheckedAccountsIndexes.push(index)
          }
        }
      }
      return [checkedAccountsIndexes, uncheckedAccountsIndexes]
    })
  }

  /**
 * Identifies and returns the indexes of accounts that are ineligible for selection due to being disabled
 * Iterates through the first 10 accounts and checks each one to determine if it is disabled
 * 
 * @returns {Promise<number[]>} A promise that resolves to an array of indexes of the ineligible (disabled) accounts
 * 
 */
  public async ineligibleAccountsIndexes(): Promise<number[]> {
    const ineligibleAccountsIndexes: number[] = []
    const allTableRows = await this.locators.tableRows.count() // all Table Rows counter
    for (let i = 0; i < allTableRows; i++) {
      await test.step(`Checking if account at index ${i} is disabled`, async () => {
        const inputLocator = this.locators.checkboxInput(this.locators.tableRows.nth(i))
        // Check if the element is disabled
        const isDisabled = await inputLocator.isDisabled()
        if (isDisabled) {
          ineligibleAccountsIndexes.push(i)
        }
      })
    }
    return ineligibleAccountsIndexes
  }

  /**
 * Extracts values from specified rows based on the column name. If indexes are provided, it extracts
 * from those specific rows; otherwise, it extracts from all rows
 * 
 * @param tableData - Array of table rows from which data will be extracted
 * @param columnName - The name of the column from which to extract values
 * @param indexes - Optional array of indexes specifying which rows to process
 * @returns A promise that resolves to an array of string values extracted from the specified column
 * @throws Throws an error if a cell with the specified column name is not found in any targeted row
 */
  public async getFilteredTableDataViaColumnName(tableData: TableRow[], columnName: string, indexes?: number[]): Promise<string[]> {
    return await test.step(`Extracts values from specified Table rows based on the column name`, async () => {
      const rowsToProcess = indexes ? indexes.map(index => tableData[index]) : tableData
      return rowsToProcess.map(row => {
        const columnNameCell = row.cell.find(cell => cell.columnName === columnName)
        if (!columnNameCell) {
          throw new Error(`Cell with columnName '${columnName}' not found`)
        }
        return columnNameCell.value
      })
    })
  }

  /**
 * Compares data from the Investments and BIC tables using the account number as a key.
 * 
 * This method iterates over specified columns from both tables and verifies that the data matches for each account number. 
 * It performs a step-by-step comparison using a map data structure to efficiently handle the key-value pairs for account numbers and their associated values.
 *  
 * @param investmentsTableData - Array of rows representing the data from the Investments table. 
 * @param bicTableData - Array of rows representing the data from the BIC table. 
 * @returns {Promise<void>} - Returns a promise that resolves after all comparisons are completed. 
 */
  public async compareTablesData(investmentsTableData: TableRow[], bicTableData: TableRow[]) {
    const columnsArray = [BicConfig.accountsToChangeColumnNames.accountTitle, BicConfig.accountsToChangeColumnNames.amountAllocated]

    await test.step('Compare filtered BIC table data with Investments table data using account number as a key', async () => {
      for (let i = 0; i < columnsArray.length; i++) {
        
        const investmentsTableDataMap = new Map(await this.getFilteredNestedTableDataFromInvestmentTile(investmentsTableData, columnsArray[i]))
        const bicTableDataMap = new Map(await this.getFilteredTableDataWithAccountNumberViaColumnName(bicTableData, columnsArray[i]))
  
        investmentsTableDataMap.forEach((investmentsTableValue, accountNumber) => {
          const tableValue = bicTableDataMap.get(accountNumber)
          expect.soft(tableValue, `Verify table column value for account number ${accountNumber} is match in BIC and Investments table data`).toEqual(investmentsTableValue)
        })
      }
    
    })
  }

  /**
 * Extracts values from the nested table rows based on the specified column name
 * 
 * @param {TableRow[]} tableData - The array of table rows containing nested table rows
 * @param {string} columnName - The name of the column to filter and extract values from
 * @returns {Promise<[string, string][]>} - A promise that resolves to an array of arrays where the first value is the account number and the second is the value from the specified column
 * 
 * This method iterates through each row in the provided table data, then iterates through each nested row within those
 * rows. It checks each cell in the nested rows to find cells that match the specified column name and collects their
 * values into an array
 */
  private async getFilteredNestedTableDataFromInvestmentTile(tableData: TableRow[], columnName: string): Promise<[string, string][]> {
    return await test.step(`Extracts values from specified Table rows based on the column name`, async () => {
      const accountValues: [string, string][] = []

      tableData.forEach(item => {
          item.nestedTableRow!.forEach(nestedRow => {
            const accountNumberCell = nestedRow.cell.find(cell => cell.columnName === 'Account Number')
            const targetCell = nestedRow.cell.find(cell => cell.columnName === columnName)
              
            if (accountNumberCell && targetCell) {
              accountValues.push([accountNumberCell.value, targetCell.value])
            }
          })
      })

      return accountValues
    })
  }

  /**
 * Extracts values from specified rows based on the column name. If indexes are provided, it extracts
 * from those specific rows; otherwise, it extracts from all rows.
 * Returns an array of arrays where the first element is the account number and the second is the value of the specified column.
 * 
 * @param tableData - Array of table rows from which data will be extracted
 * @param columnName - The name of the column from which to extract values
 * @param indexes - Optional array of indexes specifying which rows to process
 * @returns A promise that resolves to an array of arrays, each containing the account number and the value from the specified column
 * @throws Throws an error if a cell with the specified column name is not found in any targeted row
 */
  private async getFilteredTableDataWithAccountNumberViaColumnName(tableData: TableRow[], columnName: string, indexes?: number[]): Promise<[string, string][]> {
    return await test.step(`Extract values from specified Table rows based on the column name`, async () => {
      const rowsToProcess = indexes ? indexes.map(index => tableData[index]) : tableData
      return rowsToProcess.map(row => {
        const accountNumberCell = row.cell.find(cell => cell.columnName === 'Account #')
        const columnNameCell = row.cell.find(cell => cell.columnName === columnName)
      
        if (!accountNumberCell) {
          throw new Error(`Cell with columnName 'Account #' not found`)
        }
        if (!columnNameCell) {
          throw new Error(`Cell with columnName '${columnName}' not found`)
        }
      
        return [accountNumberCell.value, columnNameCell.value]
      })
    })
  }

  /**
 * Finds the indexes of rows where the column values match any of the specified values
 * 
 * @param tableData - Array of table rows from which to find indexes
 * @param columnName - The name of the column to search for matching values
 * @param valuesToFind - Array of string values to find within the specified column
 * @returns A promise that resolves to an array of indexes where the column values match the specified values
 * @throws Throws an error if the column name is not found in any row
 */
  public async getIndexesByColumnValue(tableData: TableRow[], columnName: string, valuesToFind: string[]): Promise<number[]> {
    return await test.step(`Finding indexes for specified values in column '${columnName}'`, async () => {
      const foundIndexes: number[] = []
      tableData.forEach((row, index) => {
        const columnCell = row.cell.find(cell => cell.columnName === columnName)
        if (!columnCell) {
          throw new Error(`Column '${columnName}' not found in the table data`)
        }
        if (valuesToFind.includes(columnCell.value)) {
          foundIndexes.push(index)
        }
      })
      return foundIndexes
    })
  }

  /**
 * Toggles the "all accounts" checkbox to either check or uncheck all accounts,
 * based on the specified action. This method ensures the checkbox is enabled
 * and verifies its state after the action is performed
 *
 * @param {'check' | 'uncheck'} action - Specifies whether to check or uncheck the checkbox
 */
  public async allAccountsCheckbox(action: 'check' | 'uncheck') {
    await test.step(`Toggle checkbox to ${action} all accounts and verify the state`, async () => {
      const checkBox = this.locators.checkbox(this.locators.tableHeader)
      const isChecked = await checkBox.isChecked()
      const isEnabled = await checkBox.isEnabled()

      if (isEnabled) {
        if (action === 'check' && !isChecked) {
          await test.step('Checking the checkbox and verifying it is checked', async () => {
            await checkBox.check()
            await expect(checkBox).toBeChecked()
          })
        } else if (action === 'uncheck' && isChecked) {
          await test.step('Unchecking the checkbox and verifying it is unchecked', async () => {
            await checkBox.uncheck()
            await expect(checkBox).not.toBeChecked()
          })
        }
      }
    })
  }

  /**
 * Verifies allocation percentages and sleeve counts for accounts.
 *
 * This method:
 * 1. Iterates through table data rows.
 * 2. Finds and validates 'Account #' and 'Allocated' cells.
 * 3. Checks that allocated values are greater than 0%.
 * 4. Matches each account number to account data.
 * 5. Verifies sleeve count based on allocation:
 *    - Exactly one sleeve if allocated is 100.00%.
 *    - More than one sleeve if allocated is less than 100.00%.
 *
 * @param {TableRow[]} tableData - The table data rows.
 * @param {BicAccountData} accountData - The account data.
 * @throws {Error} If any assertion fails.
 */
  public verifyAllocationAndSleevesAvailability(tableData: TableRow[], accountData: BicAccountData) {
    const data = accountData.data 
  
    tableData.forEach(tableRow => {
      const accountNumberCell = tableRow.cell.find(cell => cell.columnName === 'Account #')
      const allocatedCell = tableRow.cell.find(cell => cell.columnName === 'Allocated')
      
      expect(accountNumberCell, 'Expect that Account # cell should be present').toBeTruthy()
      expect(allocatedCell, 'Expect that Allocated cell should be present').toBeTruthy()
  
      const accountNumber = accountNumberCell!.value
      const allocatedValue = parseFloat(allocatedCell!.value.replace('%', ''))
  
      expect(allocatedValue, `Expect that Allocated value for account ${accountNumber} should be greater than 0%`).toBeGreaterThan(0)
  
      const matchingAccount = data.find(account => account.accountNumber.includes(accountNumber))
      
      expect(matchingAccount, `Expect that matching account was found for account number ${accountNumber}`).toBeTruthy()
  
      if (allocatedValue === 100.00) {
        expect(matchingAccount!.sleeves.length, `Verify that account ${accountNumber} should have exactly one sleeve when allocated value is 100.00%`).toBe(1)
      } else if (allocatedValue < 100.00) {
        expect(matchingAccount!.sleeves.length, `Verify that account ${accountNumber} should have more than one sleeve when allocated value is less than 100.00%`).toBeGreaterThan(1)
      }
    })
  }

  /**
 * Verifies that accounts with "Amount Allocated" less than the specified investment minimum value are marked as ineligible
 * and their "Status" is set to "Below Investment Minimum".
 *
 * This method performs the following steps:
 * 1. Parses the investment minimum value from the given string format.
 * 2. Calculates the indexes of the accounts that have "Amount Allocated" less than the parsed investment minimum value.
 * 3. Asserts that the calculated ineligible account indexes match the provided ineligible accounts indexes.
 * 4. Verifies that the "Status" column in each ineligible account row has the value "Below Investment Minimum".
 *
 * @param {TableRow[]} tableData - The table data containing multiple rows.
 * @param {string} investmentMinValue - The investment minimum value in the format "$32,408.09".
 * @param {number[]} ineligibleAccountsIndexes - An array of indexes representing ineligible accounts.
 * @returns {Promise<void>} - A promise that resolves when the verification is complete.
 */
  public async verifyBelowInvestmentMinIneligibleAccounts(tableData: TableRow[], investmentMinValue: string, ineligibleAccountsIndexes: number[]) {

    await test.step('Verify ineligible accounts based on investment minimum value', async () => {
      const minValue = parseFloat(investmentMinValue.replace(/[$,]/g, ''))

      const calculatedIneligibleIndexes = tableData
        .map((row, index) => {
          const amountAllocatedCell = row.cell.find(cell => cell.columnName === BicConfig.accountsToChangeColumnNames.amountAllocated)
          const amountAllocated = amountAllocatedCell ? parseFloat(amountAllocatedCell.value.replace(/[$,]/g, '')) : 0
          return amountAllocated < minValue ? index : -1
        }).filter(index => index !== -1)

      expect(calculatedIneligibleIndexes, 'Expect that ineligible accounts indexes should match').toEqual(ineligibleAccountsIndexes)

      await this.verifyAccountsStatuses(tableData, calculatedIneligibleIndexes, 'Below Investment Minimum')
    })
  }

  /**
 * Verifies the status of accounts based on their eligibility.
 *
 * This method performs the following steps:
 * 1. Iterates through the provided indexes of ineligible accounts.
 * 2. For each ineligible account, it verifies that the "Status" column contains the specified status.
 *
 * @param {TableRow[]} tableData - The table data containing multiple rows.
 * @param {number[]} ineligibleAccountsIndexes - An array of indexes representing ineligible accounts.
 * @param {string} expectedStatus - The expected status value to verify for ineligible accounts.
 * @returns {Promise<void>} - A promise that resolves when the verification is complete.
 */
  public async verifyAccountsStatuses(tableData: TableRow[], ineligibleAccountsIndexes: number[], expectedStatus: string): Promise<void> {
    await test.step(`Verify accounts status to be ${expectedStatus}`, async () => {
      for (const index of ineligibleAccountsIndexes) {
        const statusCell = tableData[index].cell.find(cell => cell.columnName === BicConfig.accountsToChangeColumnNames.status)
        expect(statusCell, `Expect that Status cell should be present in row ${index}`).toBeTruthy()
        expect(statusCell!.value, `Expect that Status in row ${index} should be '${expectedStatus}'`).toEqual(expectedStatus)
      }
    })
  }

  /**
 * Verifies that eligible accounts have an empty status.
 *
 * This method performs the following steps:
 * 1. Filters out indexes that are eligible.
 * 2. Calls the `verifyAccountsStatuses` method to verify that the status of eligible accounts is empty.
 *
 * @param {TableRow[]} tableData - The table data containing multiple rows.
 * @param {number[]} ineligibleAccountsIndexes - An array of indexes representing ineligible accounts.
 * @returns {Promise<void>} - A promise that resolves when the verification is complete.
 */
  public async verifyEligibleAccountsStatuses(tableData: TableRow[], ineligibleAccountsIndexes: number[]): Promise<void> {
    await test.step(`Verify that eligible accounts status are empty`, async () => {
      // Filter out indexes that are eligible
      const filteredIndexes = ineligibleAccountsIndexes.map((_, index) => index)
        .filter(index => !ineligibleAccountsIndexes.includes(index))
      await this.verifyAccountsStatuses(tableData, filteredIndexes, '')
    })
  }

  /**
 * Verify that Market Value of the investment strategy selected for each account is displayed in Amount Allocated column
 *
 * @param {TableRow[]} tableData - The table data containing multiple rows.
 * @param {BicAccountData} accountData - The account data from the API.
 * @throws {Error} If any "Amount Allocated" value from the table does not match the corresponding value from the account data.
 */
  public async verifyAmountAllocatedValues(tableData: TableRow[], accountData: BicAccountData): Promise<void> {
    await test.step('Verify that Amount Allocated values from table data match those in API account data', async () => {
      const data = accountData.data

      tableData.forEach(tableRow => {
        const accountNumberCell = tableRow.cell.find(cell => cell.columnName === 'Account #')
        const amountAllocatedCell = tableRow.cell.find(cell => cell.columnName === 'Amount Allocated')

        expect(accountNumberCell, 'Expect that Account # cell should be present').toBeTruthy()
        expect(amountAllocatedCell, 'Expect that Amount Allocated cell should be present').toBeTruthy()

        const accountNumber = accountNumberCell!.value
        const tableAmountAllocated = parseFloat(amountAllocatedCell!.value.replace(/[$,]/g, '')).toFixed(2)

        const matchingAccount = data.find(account => account.accountNumber.includes(accountNumber))

        expect.soft(matchingAccount, `Verify that matching account was found for account number ${accountNumber}`).toBeTruthy()

        const apiAmountAllocated = matchingAccount!.marketValue.toFixed(2)

        expect.soft(tableAmountAllocated, `Verify that Amount Allocated value for account ${accountNumber} should match`).toEqual(apiAmountAllocated)
      })
    })
  }

  /**
 * Compares table data with CSV file data to ensure they match.
 *
 * This method iterates through each row of the provided table data and finds the corresponding row
 * in the CSV file data based on the "Account #" column. It then compares the values of the mandatory columns
 * between the table data and the CSV data to ensure they match.
 *
 * @param {TableRow[]} tableData - The table data to be compared.
 * @param {CsvFileData[]} csvFileData - The CSV file data to compare against.
 * @throws {Error} If any mandatory column is not present or if the values do not match.
 */
  private async compareTableDataWithCsvFile(tableData: TableRow[], csvFileData: CsvFileData[]) {
    await test.step('Compare table data with CSV file data', async () => {
      const configData = BicConfig.accountsToChangeColumnNames

      tableData.forEach(tableRow => {
        const accountNumberCell = tableRow.cell.find(cell => cell.columnName === 'Account #')
        expect(accountNumberCell, 'Verify that Account # cell is present').toBeTruthy()
  
        const csvRow = csvFileData.find(row => row['Account #'] === accountNumberCell!.value)
        expect(csvRow, `Verify that matching CSV row found for account number: ${accountNumberCell!.value}`).toBeTruthy()
  
        const mandatoryColumns: (keyof CsvFileData)[] = [
          configData.accountTitle as keyof CsvFileData,
          configData.status as keyof CsvFileData,
          configData.regType as keyof CsvFileData,
          configData.accountNumber as keyof CsvFileData,
          configData.tms as keyof CsvFileData,
          configData.amountAllocated as keyof CsvFileData,
          configData.allocated as keyof CsvFileData
        ]
  
        mandatoryColumns.forEach(column => {
          const tableCell = tableRow.cell.find(cell => cell.columnName === column)
          expect(tableCell, `Expect that ${column} cell is present`).toBeTruthy()
  
          const csvValue = csvRow![column]
          expect.soft(tableCell!.value, `Expect that value for column ${column} in CSV file is match to table data`).toEqual(csvValue)
        })
      })
    })
  }
  
  /**
 * Parses a CSV file and compares its data with the table data.
 * 
 * This method performs the following steps:
 * 1. Downloads the CSV file by triggering a click event on the export button.
 * 2. Parses the downloaded CSV file into an array of data objects.
 * 3. Compares the parsed CSV file data with the current table data.
 * 
 * The comparison ensures that the table data matches the data in the CSV file.
 */
  public async compareCsvFileWithTable(): Promise<void> {
    await test.step('Parsing CSV file to array and comparing Table data with CSV file data', async () => {
      const filePath = await this.browserHelpers.downloadFile(() => this.locators.exportButton.click())

      const csvFileData: CsvFileData[] = await CsvHelpers.parseCsvToArray(filePath)
      
      await this.compareTableDataWithCsvFile(await this.data(), csvFileData)
    })
  }

}
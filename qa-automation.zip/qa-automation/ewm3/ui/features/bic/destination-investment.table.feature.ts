import { expect, test } from '@playwright/test'
import { DestinationInvestmentTableLocators } from '../../elements/bic/destination-investment.table.el'
import {TableCell, TableFeature, TableRow} from '../table.feature'
import { BicConfig } from '../../../../ewm3/service-data/tile-config/bic.config'
import { UiTextStylesAssert } from '../../../../utils/UIComponentsStateAssert'
import { GeneralStyles } from '../../../service-data/generalStyles'
import { ProposalProductsDataItem, ProposalProductsResponseBody } from '../../../api/proposal/v1/types'
import { GeneralUtils } from '../../../../utils/generalUtils'
import { BicBaseTab } from '../../elements/bic/bic-base-tab.el'

export interface DestinationInvestmentsTableRow extends TableRow{
  nestedStrategyNames?: string[]
}

export class DestinationInvestmentTableFeature extends TableFeature {
  readonly locators = new DestinationInvestmentTableLocators(this.page, this.container)
  private bicBaseTab = new BicBaseTab(this.page, this.container)

  /**
 * Expands the specified number of nested tables.
 * If `expandRowsCount` is provided, it attempts to expand up to that many nested tables.
 * If there are fewer nested tables available, it expands as many as are present.
 *
 * @param {number} [expandRowsCount=1] - The number of nested tables to expand. Defaults to 1.
 */
  public async expandNestedTable(expandRowsCount: number = 1) {
  // Determine the number of rows with expandable nested tables
    const rowCount = await this.locators.expandedStrategy.count()

    // Calculate the actual number of rows to expand, considering there may be fewer than expandRowsCount
    const rowsToExpand = Math.min(expandRowsCount, rowCount)

    for (let i = 0; i < rowsToExpand; i++) {
      await this.locators.expandedStrategy.nth(i).click()
      await this.assertNestedTableOpened(i)
    }
  }

  public async collapseNestedTable(expandRowsCount: number = 1) {
    for (let i = 0; i < expandRowsCount; i++) {
      await this.locators.expandedStrategy.nth(i).click()
      await this.assertNestedTableClosed(i)
    }
  }
  
  /**
 * Asserts that the nested table at the specified row index is hidden.
 * If `rowIndex` is not provided, it checks nested tables for rows from index 0 to 9,
 * considering that there may be fewer than 10 rows or no rows at all.
 *
 * @param {number} [rowIndex] - The index of the row to check. Defaults to checking rows from 0 to 9.
 * @throws Will throw an error if there are no rows with nested tables.
 */
  public async assertNestedTableClosed(rowIndex?: number) {
  // Determine the number of rows with nested tables
    const rowCount = await this.locators.rowsWithNestedTable.count()

    // If there are no rows with nested tables, throw an error
    if (rowCount === 0) {
      throw new Error('No rows with nested tables available to check.')
    }
    // If rowIndex is not provided, create an array of indices from 0 to min(9, rowCount - 1)
    const indicesToCheck = rowIndex !== undefined ? [rowIndex] : Array.from({ length: Math.min(10, rowCount) }, (_, i) => i)

    for (const index of indicesToCheck) {
      await expect(this.locators.nestedTable(this.locators.rowsWithNestedTable.nth(index)),
        `Expect nested table with index: ${index} is collapsed and hidden`).toBeHidden()
    }
  }

  public async assertNestedTableOpened(rowIndex: number) {
    await expect(this.locators.nestedTable(this.locators.rowsWithNestedTable.nth(rowIndex)), `Expect nested table with index: ${rowIndex} is expanded and visible`).toBeVisible()
  }

  public async checkRadioButtonOnMainTable(rowIndex: number) {
    await this.locators.radioButton(this.locators.rowsWithoutNestedTable).nth(rowIndex).check()
    await expect(this.locators.radioButton(this.locators.rowsWithoutNestedTable).nth(rowIndex), `Expect that Strategy with index: ${rowIndex} is checked`).toBeChecked()
  }
  public async checkRadioButtonOnNestedTable(rowIndex: number, nestedTableItemIndex: number) {
    await this.locators.radioButton(this.locators.nestedTable(this.locators.rowsWithNestedTable.nth(rowIndex))).nth(nestedTableItemIndex).check()
    await expect(this.locators.radioButton(this.locators.nestedTable(this.locators.rowsWithNestedTable.nth(rowIndex))).nth(nestedTableItemIndex), 
      `Expect that nested Strategy with index: ${nestedTableItemIndex} of main table row with index: ${rowIndex} is checked`).toBeChecked()
  }

  /**
 * Asserts that the radio button in the main table at the specified row index is not checked.
 * If `rowIndex` is not provided, it checks radio buttons for rows from index 0 to 9,
 * considering that there may be fewer than 10 rows or no rows at all.
 *
 * @param {number} [rowIndex] - The index of the row to check. Defaults to checking rows from 0 to 9.
 * @throws Will throw an error if there are no rows in the table.
 */
  public async assertRadioButtonOnMainTableNotChecked(rowIndex?: number) {
  // Determine the number of rows in the table
    const rowCount = await this.locators.rowsWithoutNestedTable.count()

    // If there are no rows, throw an error
    if (rowCount === 0) {
      throw new Error('No main rows available in the table to check')
    }
    // If rowIndex is not provided, create an array of indices from 0 to min(9, rowCount - 1)
    const indicesToCheck = rowIndex !== undefined ? [rowIndex] : Array.from({ length: Math.min(10, rowCount) }, (_, i) => i)

    for (const index of indicesToCheck) {
      await expect(this.locators.radioButton(this.locators.rowsWithoutNestedTable.nth(index)),
        `Expect that Strategy with index: ${index} is unchecked`).not.toBeChecked()
    }
  }

  public async assertRadioButtonOnMainTableIsChecked(rowIndex: number) {
    await expect(this.locators.radioButton(this.locators.rowsWithoutNestedTable.nth(rowIndex)), `Expect that Strategy with index: ${rowIndex} is checked`).toBeChecked()
  }

  /**
 * Asserts that the radio in the nested table at the specified row index is not checked.
 * If `rowIndex` and `nestedTableItemIndex` are not provided, it checks radio buttons for rows from index 0 to 9
 * and nested table item indices from 0 to 5, considering that there may be fewer than 10 rows or no rows at all.
 *
 * @param {number} [rowIndex] - The index of the row to check. Defaults to checking rows from 0 to 9.
 * @param {number} [nestedTableItemIndex] - The index of the nested table item to check. Defaults to checking items from 0 to 5.
 * @throws Will throw an error if there are no rows with nested tables.
 */
  public async assertRadioButtonOnNestedTableNotChecked(rowIndex?: number, nestedTableItemIndex?: number) {
  // Determine the number of rows with nested tables
    const rowCount = await this.locators.rowsWithNestedTable.count()

    // If there are no rows with nested tables, throw an error
    if (rowCount === 0) {
      throw new Error('No rows with nested tables available to check.')
    }
    // If rowIndex is not provided, create an array of indices from 0 to min(9, rowCount - 1)
    const rowIndicesToCheck = rowIndex !== undefined ? [rowIndex] : Array.from({ length: Math.min(10, rowCount) }, (_, i) => i)

    for (const rowIndex of rowIndicesToCheck) {
    // Determine the number of items in the nested table for the current row
      const nestedItemCount = await this.locators.nestedTable(this.locators.rowsWithNestedTable.nth(rowIndex)).count()

      // If nestedTableItemIndex is not provided, create an array of indices from 0 to min(5, nestedItemCount - 1)
      const nestedItemIndicesToCheck = nestedTableItemIndex !== undefined ? [nestedTableItemIndex] : Array.from({ length: Math.min(6, nestedItemCount) }, (_, i) => i)

      for (const nestedItemIndex of nestedItemIndicesToCheck) {
        const radioButtonLocator = this.locators.radioButton(this.locators.nestedTable(this.container).nth(rowIndex)).nth(nestedItemIndex)
        await expect(radioButtonLocator,
          `Expect that nested Strategy with index: ${nestedItemIndex} of main table row with index: ${rowIndex} is unchecked`
        ).not.toBeChecked()
      }
    }
  }

  public async assertRadioButtonOnNestedTableIsChecked(rowIndex: number, nestedTableItemIndex: number) {
    await expect(this.locators.radioButton(this.locators.nestedTable(this.locators.rowsWithNestedTable.nth(rowIndex))).nth(nestedTableItemIndex), 
      `Expect that nested Strategy with index: ${nestedTableItemIndex} of main table row with index: ${rowIndex} is checked`).toBeChecked()
  }

  /**
 * Retrieves the strategy name from a nested table using the main table row index and the nested table item index
 * @param {number} rowIndex - The index of the row in the main table
 * @param {number} nestedTableItemIndex - The index of the item in the nested table
 * @returns {Promise<string>} A promise that resolves to the text extracted from the nested table item
 */
  public async getStrategyNameFromNestedTable(rowIndex: number, nestedTableItemIndex: number) {
  // Uses a hardcoded locator to find the text: `//input/following-sibling::label//span`
  // In this method, `nestedTable` takes a locator for the main table row that contains a nested table (`rowsWithNestedTable`), and then navigates through the indexes to find the corresponding strategy name text
    return this.locators.nestedTable(this.locators.rowsWithNestedTable.nth(rowIndex)).nth(nestedTableItemIndex).locator('//input/following-sibling::label//span').nth(nestedTableItemIndex)
  }  

  /**
 * Fetches the strategy name from the API response based on the selected nested element in the UI
 * 
 * This method navigates through the nested table structure in the UI, retrieves the selected 
 * element's text, and then matches this text with the appropriate strategy name in the API response
 * 
 * @param {ProposalProductsResponseBody} responseBody - The response body from the API containing product data
 * @param {number} rowIndex - The index of the main table row that contains the nested table
 * @param {number} nestedTableItemIndex - The index of the nested table item within the selected main table row
 * 
 * @returns {Promise<string>} - The strategy name fetched from the API response
 */
  public async getStrategyNameFromApiWhenNestedElementSelected(responseBody: ProposalProductsResponseBody, rowIndex: number, nestedTableItemIndex: number) {
    // Uses a hardcoded locator to find the text: `//input/following-sibling::label//span`
    // In this method, `nestedTable` takes a locator for the main table row that contains a nested table (`rowsWithNestedTable`), and then navigates through the indexes to find the corresponding strategy name text
    const selectedNestedElementName = await this.locators.nestedTable(this.locators.rowsWithNestedTable.nth(rowIndex)).nth(nestedTableItemIndex).locator('//input/following-sibling::label//span').nth(nestedTableItemIndex).textContent()
    const nestedStrategyName = await this.locators.rowsWithNestedTable.nth(rowIndex).locator('td').nth(0).textContent()

    const group = responseBody.data.find(group => group.groupName === nestedStrategyName)
    const strategyNameFromApi = group!.products.find(product => product.profileName === selectedNestedElementName)!.name

    return strategyNameFromApi
  }  

  /**
 * Asserts the distribution of elements in a nested table structure, goes througt all nested tables on the first page
 * This method checks if elements within a nested table are correctly
 * distributed across columns and rows, based on their bounding box data
 * It supports validating the distribution for tables with 2, 3, 4, 5, or 6 elements
 *
 * The checks include:
 * - For 2 elements: they are in the same column
 * - For 3 elements: the first two are in the same column, and the third is to the right of the first, in the same row
 * - For 4 elements: elements are organized in two columns and two rows, with specific checks for column and row alignment, and right adjacency
 * - For 5 or 6 elements:
 *    - Elements 0, 1, and 2 are in the first column, with sequential vertical alignment
 *    - Elements 3, 4 (and 5 if present) are in the second column, aligned vertically as well
 *
 * @throws {Error} Throws an error if the bounding box data for any element is not available
 */
  public async assertNestedTableElementsDistribution() {
    const numberRowsWithNestedTable = await this.locators.rowsWithNestedTable.count()
    // Expand all nested tables to ensure all elements are visible for bounding box calculations
    await this.expandNestedTable(numberRowsWithNestedTable)

    await test.step(`Assert for all nested tables in the page`, async () => {
      for (let j = 0; j < numberRowsWithNestedTable; j++) {
      // All nested table elements
        const elements = this.locators.nestedTable(this.container).nth(j).locator(this.locators.nestedTableElement)
        // Count the number of elements in the nested table
        const elementsCount = await elements.count()
        // Throw an error if there is no nested elements
        if (!elementsCount) {
          throw new Error(`Nested elements are not available`)
        }
    // Define the type for bounding box data
    type BoundingBox = { x: number; y: number; width: number; height: number; }
    // Initialize an array to store bounding box data for each element
    const boundingBoxes: BoundingBox[] = []

    await test.step(`Storing the retrieved bounding box data`, async () => {
      for (let i = 0; i < elementsCount; i++) {
        const boundingBox = await elements.nth(i).boundingBox()
        if (!boundingBox) {
          throw new Error(`Bounding box data for element at index ${i} is not available`)
        }
        boundingBoxes.push(boundingBox)
      }
    })
    // Creating 1-st and 2-nd Column arrays of nested table elemnts
    const middleIndex = Math.ceil(boundingBoxes.length / 2)
    const firstColumn = boundingBoxes.slice(0, middleIndex)
    const secondColumn = boundingBoxes.slice(middleIndex)
    // Function to determine if two elements are in the same column
    const inSameColumn = (box1: BoundingBox, box2: BoundingBox) => Math.abs(box1.x - box2.x) === 0
    // Function to determine if two elements are in the same row
    const inSameRow = (box1: BoundingBox, box2: BoundingBox) => Math.abs(box1.y - box2.y) === 0
    // Function to determine if one element is directly to the right of another
    const rightOfElement = (box1: BoundingBox, box2: BoundingBox) => box1.x + box1.width === box2.x

    await test.step(`Warning if it is only one nested element found`, async () => {
      if (elementsCount === 1) {
        console.warn(`Warning: Only one nested element found, which is insufficient for performing this assertion`)
      }
    })
    await test.step(`Assert for a nested table with more then 2 elements`, async () => {
      if (elementsCount === 2) {
        expect(inSameColumn(boundingBoxes[0], boundingBoxes[1]), 
          'Expected elements in the first column to be aligned vertically').toBeTruthy()
      } 
    })
    await test.step(`Assert for a nested table with more then 3 elements`, async () => {
      if (elementsCount >= 3) {
        for (let i = 0; i < firstColumn.length; i++) {
          if (i < firstColumn.length - 1) {
            expect(inSameColumn(firstColumn[i], firstColumn[i + 1]), 
              'Expected elements in the first column to be aligned vertically').toBeTruthy()
          }
          await test.step(`Assert for horizontal alignment and right adjacency for elements across columns`, async () => {
            if (i < secondColumn.length) {
              expect(inSameRow(firstColumn[i], secondColumn[i]), 
                'Expected elements across columns to be aligned horizontally').toBeTruthy()
              expect(rightOfElement(firstColumn[i], secondColumn[i]), 
                'Expected the element in the second column to be directly to the right of the corresponding element in the first column').toBeTruthy()
            }
          })
        }
      } 
    })
      }
    })
  }

  /**
 * Checks the 'Risk Profile' values from table data for format and range correctness
 * Throws an error if the format is incorrect or if ranges are not valid
 *
 * @param tableData - The data from the table, where each item represents a row and contains a cells array
 * @throws Throws an error if any 'Risk Profile' value has incorrect format or invalid range
 */
  public async validateRiskProfileRanges(tableData: TableRow[]) {
    // Define the regex pattern for validating the risk profile values
    const regex = /^\s*(?:[1-6]|([1-6])-([1-6]))(?:\s*,\s*(?:[1-6]|([1-6])-([1-6])))*\s*$/

    // Iterate over each row in the table data
    tableData.forEach(async row => {
      // Retrieve the risk profile value from the specified column
      const riskProfileValue = row.cell.find(item => item.columnName === BicConfig.destinationInvestmentColumnNames.riskProfile)?.value
      
      // Assert that the risk profile value is defined
      expect.soft(riskProfileValue, 'Expect that Risk Profile is presented in the table row').toBeDefined()
      
      // Validate the format of the risk profile value using the regex
      const isValidFormat = regex.test(riskProfileValue!)
      expect.soft(isValidFormat, `Validating the value "${riskProfileValue}" format of the cell text against a predefined regex`).toBeTruthy()

      // If the format is valid, further validate that the range values are logically consistent
      if (isValidFormat) {
        const segments = riskProfileValue!.split(',').map(s => s.trim())
        segments.forEach(segment => {
          if (segment.includes('-')) {
            const parts = segment.split('-').map(Number)
            const start = parts[0]
            const end = parts[1]
                    
            // Assert that the start of the range is less than or equal to the end
            expect.soft(start, 'Expect that start is less than or equal to end').toBeLessThan(end)
          }
        })
      }
    })
  }

  /**
 * Verifies that all Strategy name cells on the page have the 'ellipsis' text overflow style applied
 *
 * @throws Throws an assertion error if any of the cells do not have the 'ellipsis' style applied
 * @returns A promise that resolves if all checks pass without any assertion errors, indicating that the correct styles are applied
 */
  public async verifyStrategyNameEllipsisStyleAvailability() {
    await test.step(`Verify that all Strategy name on the page have ellipsis text style`, async () => {
      for (let i = 0; i < await this.locators.rowsAll.count(); i++) {
        const strategyNameLocator = this.locators.columns(this.locators.rowsAll.nth(i)).nth(0).locator('//*[contains(@class,"OverflowTooltip-module")]')
        await strategyNameLocator.waitFor({state:'visible'})
        expect(await strategyNameLocator.evaluate(el => getComputedStyle(el).textOverflow), `Expect that Strategy name element has ellipsis style`).toBe('ellipsis')
      }
    })
  }

  /**
 * Verifies that hovering over a long strategy name displays a tooltip with the complete name, 
 * and ensures that no tooltip is shown for short names
 * This function iterates over each row on a page, checking the width of the strategy name column and 
 * the length of the strategy name text. It performs different actions based on these measurements:
 * - If the column width is up to 524 pixels:
 *   - For names longer than 72 characters, it checks if a tooltip with the full name appears on hover
 *   - For names shorter than 68 characters, it ensures that no tooltip appears on hover
 * 
 * @throws Error if the strategy name column width exceeds 524 pixels
 */
  public async verifyHoverGivesWholeNameOfLongStrategyName() { 
    await test.step(`Verify that hover on long Strategy name gives tooltip with the whole name of Strategy and do not give on short name`, async () => {
      for (let i = 0; i < await this.locators.rowsAll.count(); i++) {
        const strategyNameColumnLocator = this.locators.columns(this.locators.rowsAll.nth(i)).nth(0)
        const strategyNameColumnTextLocator = strategyNameColumnLocator.locator('//span/parent::div')
        const strategyNameText = await strategyNameColumnLocator.textContent()
        const columnWidth = (await this.bicBaseTab.getStyleInfo(strategyNameColumnLocator)).width
        const textWidth = (await this.bicBaseTab.getStyleInfo(strategyNameColumnTextLocator)).width
        const result = textWidth/columnWidth*100
        await test.step(`Verify that tooltip appears in case if text width is up to 89.6% of column. Current % is: ${result}%`, async () => {

          if(result >= 89.6){
            await strategyNameColumnLocator.hover()
            await expect(this.locators.hoverTooltip, `Verify that tooltip is visible when hover on long Strategy name`).toBeVisible()
            expect(await this.locators.hoverTooltip.textContent(), `Verify that tooltip Strategy name is equal to name from table cell`).toEqual(strategyNameText)
            await this.locators.table.hover()
          } else {
            await strategyNameColumnLocator.hover()
            await expect(this.locators.hoverTooltip, 'Verify that tooltip is Hidden when hover on short Strategy name').toBeHidden()
          }

        })
      }
    })
  }
 
  public async tmsValuesAssert() {
    for (let i = 0; i < await this.locators.rowsAll.count(); i++) {
      const tmsColumnLocator = this.locators.columns(this.locators.rowsAll.nth(i)).nth(2).locator(this.locators.tmsTableCell)
      const tmsColumnText = await tmsColumnLocator.textContent()
      const ineligible = 'Ineligible'
      const eligible = 'Eligible'
        
      await test.step(`Verify Ineligible value font styles`, async () => {
        if (tmsColumnText === ineligible) {
          await UiTextStylesAssert.fontWeight(tmsColumnLocator.getByText(ineligible), GeneralStyles.fontLightBold) 
          await UiTextStylesAssert.fontName(tmsColumnLocator.getByText(ineligible), GeneralStyles.fontFamilyRobotoSansSerif) 
          await UiTextStylesAssert.fontSize(tmsColumnLocator.getByText(ineligible), GeneralStyles.fontSize14)
          await UiTextStylesAssert.fontColor(tmsColumnLocator.getByText(ineligible), GeneralStyles.colorBlack)
        }
      })
      await test.step(`Verify Eligible value font styles`, async () => {
        if (tmsColumnText === eligible) {
          await UiTextStylesAssert.fontWeight(tmsColumnLocator.getByText(eligible), GeneralStyles.fontLight)
          await UiTextStylesAssert.fontName(tmsColumnLocator.getByText(eligible), GeneralStyles.fontFamilyRobotoSansSerif) 
          await UiTextStylesAssert.fontSize(tmsColumnLocator.getByText(eligible), GeneralStyles.fontSize14)
          await UiTextStylesAssert.fontColor(tmsColumnLocator.getByText(eligible), GeneralStyles.colorBlack)
        }
      })
    }
  }

  /**
 * Asserts and validates the mapping of data between API responses and corresponding UI table entries
 * This method performs checks for Strategy Name, Risk Profile, TMS eligibility, and Investment Minimums,
 * and  nested table values if applicable
 *
 * @param apiResponseBody - The structured response from the API containing product data
 * @param tableRowArray - The array of table rows from the UI to be validated against the API data
 */
  public async assertDataMapping(apiResponseBody: ProposalProductsResponseBody, tableRowArray: DestinationInvestmentsTableRow[]) {
    return await test.step(`Asserts and validates the mapping of data between API responses and corresponding UI table entries`, async () => {
    // Sort the API data by group name to ensure it matches the expected UI order
      const reorderApiData = await this.reorderApiData(apiResponseBody, tableRowArray)
  
      // Extracts and prepares risk profiles from the API data
      const extractRiskProfiles = await this.extractRiskProfiles(reorderApiData)
  
      // Format risk profiles from the API data for comparison
      const formattedRiskProfiles = await this.formatRiskProfiles(extractRiskProfiles)
  
      // Iterate through each row of the table array for validation
      for (let i = 0; i < tableRowArray.length; i++) {
        const row = tableRowArray[i]
      
        // Extract values directly from the current row for comparison
        const strategyName = row.cell.find(cell => cell.columnName === 'Strategy Name')?.value
        const riskProfile = row.cell.find(cell => cell.columnName === 'Risk Profile')?.value
        const tms = row.cell.find(cell => cell.columnName === 'TMS')?.value
        const investmentMin = row.cell.find(cell => cell.columnName === 'Investment Min')?.value
  
        // Seeking max enforcedInvestmentMinimum, it will be displayed in UI formatted
        const productWithMaxInvestment = reorderApiData[i].products.reduce((max, product) => parseInt(max.displayInvestmentMinimum) > parseInt(product.displayInvestmentMinimum) ? max : product)
        const formattedMaxInvestment = GeneralUtils.normalizeCurrencyValueWithFraction(parseInt(productWithMaxInvestment.displayInvestmentMinimum), 0)
  
        // Determine the expected TMS eligibility string based on the API response. If one of tmsEligibility is true, a Strategy is Eligible
        const hasEligibleTms = reorderApiData[i].products.some(product => product.tmsEligibility)
        const expectedTmsValueInUI = hasEligibleTms ? 'Eligible' : 'Ineligible'
  
        expect.soft(strategyName, 'Verify that Strategy Name values are equal in UI table and API response').toEqual(reorderApiData[i].groupName)
        expect.soft(riskProfile, 'Verify that Risk Profile values in UI table correspond to API response').toEqual(formattedRiskProfiles[i])
        expect.soft(tms, 'Verify that TMS values in UI table correspond to API response').toEqual(expectedTmsValueInUI)
        expect.soft(investmentMin, 'Verify that Investment Min values in UI table correspond to API response').toEqual(formattedMaxInvestment)
  
        // Check and validate nested table entries if there are multiple products
        if (reorderApiData[i].products.length > 1) {
          const expectedNames = reorderApiData[i].products.sort((a, b) => a.riskProfile - b.riskProfile).map(product => product.profileName)
          const uiNames = row.nestedStrategyNames || []
  
          // Assert that the names of nested values in UI table correspond exactly to API response
          expect.soft(expectedNames, 'Verify that names of nested values in UI table match exactly with API response').toEqual(uiNames) 
        }
      }
    })
  }

  /**
 * Reorders the groups in the API response data according to the order specified in a UI table row array
 * This function matches each group name from the API response with the 'Strategy Name' column values from the UI table row array
 * It then reassembles the API response data, including only those groups found in the UI table and in the same order
 *
 * @param apiResponseBody - The original API response body 
 * @param tableRowArray - The array of UI table rows
 * @returns An object containing an array of product groups reordered as per the UI table's order
 */

  private async reorderApiData(apiResponseBody: ProposalProductsResponseBody, tableRowArray: DestinationInvestmentsTableRow[]): Promise<ProposalProductsDataItem[]> {
    return await test.step(`Filtering api response`, async () => {
      // Create a map for quick access to groups by their groupName from the API response data
      const apiGroupsMap = new Map<string,ProposalProductsDataItem>(
        apiResponseBody.data.map(group => [group.groupName, group])
      )

      // Create an array to store groups in the order they appear in the tableRowArray
      const orderedApiGroups: ProposalProductsDataItem[] = []

      // Iterate through each row in the tableRowArray
      tableRowArray.forEach(row => {
        // Extract the groupName from the 'Strategy Name' column of the current row safely
        const groupName = row.cell.find(cell => cell.columnName === 'Strategy Name')?.value
    
        // Only proceed if groupName is defined and exists in the map
        if (groupName && apiGroupsMap.has(groupName)) {
          orderedApiGroups.push(apiGroupsMap.get(groupName)!) // Non-null assertion since we checked presence
        }
      })

      return orderedApiGroups  // Returning the reordered groups
    })

  }

  /**
 * Extracts and prepares risk profiles from the API data
 * Each group's risk profiles are extracted, made unique, and sorted numerically
 * @param groups - An array of group data from the API response
 * @returns {number[][]} An array of arrays, each containing unique and sorted risk profiles for each group
 */
  private async extractRiskProfiles(groups:ProposalProductsDataItem[]) {
    return await test.step(`Extracts and prepares risk profiles from the API data`, async () => {
      return groups.map(group => {
        // Map through each product to get their risk profiles.
        const profiles = group.products.map(product => product.riskProfile)
        // Filter out duplicate profiles to ensure uniqueness.
        const uniqueProfiles = profiles.filter((value, index) => profiles.indexOf(value) === index)
        // Sort the risk profiles numerically.
        return uniqueProfiles.sort((a, b) => a - b)
      })
    })
  }

  /**
 * Formats an array of risk profiles into a string, using ranges when consecutive profiles are found
 * @param profileArrays - An array of arrays, each containing unique and sorted risk profiles
 * @returns An array of strings where each string represents the risk profiles formatted into readable ranges
 */
  public async formatRiskProfiles(profileArrays: number[][]): Promise<string[]> {
    return await test.step(`Formats an array of risk profiles into a string`, async () => {
    // Maps through each array of risk profiles to format them into string ranges
      return profileArrays.map(profiles => {
        const result: string[] = [] // Initialize an array to store the formatted result
        let start = profiles[0] // Start with the first risk profile in the array
        let end = start // Initially, end is the same as start
  
        // Iterate through the risk profiles to create ranges
        for (let i = 1; i < profiles.length; i++) {
          const current = profiles[i]
          if (current === end + 1) {
          // If the current profile is consecutive, extend the end of the range
            end = current
          } else {
          // If not consecutive, add the current range to the result and reset start and end
            if (start === end) {
              result.push(`${start}`) // Add a single value as a string
            } else {
              result.push(`${start}-${end}`) // Add a range as a string
            }
            start = current
            end = start
          }
        }
        // After finishing the loop, add the final range or single value to the result
        if (start === end) {
          result.push(`${start}`)
        } else {
          result.push(`${start}-${end}`)
        }
        return result.join(', ') // Join all ranges with a comma to form the final string for each group
      })
    })
  }

  /**
 * Retrieves data from a table and returns an array of table row objects
 * Each table row object contains cells data, which includes column names, values, 
 * and information about whether the column is fixed or sortable
 *
 * The method parses all rows of the table. For each row, it checks if the row is a regular row or a nested table row
 * - For regular rows, it gathers all cell data and constructs objects that describe each cell with properties such as:
 *   columnName, value, isFixed, and isSortable
 * - For nested table rows, it collects names from nested strategy elements and adds them to the nestedStrategyNames
 *   array of the previous row's data object
 *
 * @returns A promise that resolves with an array of table row objects
 * Each object represents a row in the table, including its cells data and any nested table information
 */

  public async data(): Promise<DestinationInvestmentsTableRow[]> {
    return await test.step(`Table data parsing`, async () => {

      const headersArray: string [] = await this.locators.tableHeaders.allInnerTexts()
      const isFixedArray: boolean[] = []
      const isSortableArray: boolean[] = []
      const headersCount = await this.locators.tableHeaders.count()

      //parse main tables sorting/dragging capabilities

      for (let i = 0; i < headersCount; i++) {
        isFixedArray.push(await (this.locators.dragButton(this.locators.tableHeaders.nth(i))).count()===0)
        isSortableArray.push(await (this.locators.sortingButton(this.locators.tableHeaders.nth(i))).count()>0)
      }
      const tableData: DestinationInvestmentsTableRow[] = []
      const rowsCount = await this.locators.rowsAll.count()
      for (let i = 0; i < rowsCount; i++) {
        const row = this.locators.rowsAll.nth(i)
        if(await row.getByTestId('nested-table-row').count()===0){
          // if row is regular (does not contain nested table), then adding data to main table
          const valuesArray: string[] = await this.locators.columns(row).allInnerTexts()
          const cellArray: TableCell[] = []
          // pushing each cell's in a row data
          for (let j = 0; j < headersArray.length; j++) {
            cellArray.push(
              {
                columnName: headersArray[j],
                value: valuesArray[j],
                isFixed: isFixedArray[j],
                isSortable: isSortableArray[j]
              }
            )
          }
          // pushing cells array and empty nested table rows array to the main TableRow array
          tableData.push(
            {
              cell: cellArray,
              nestedStrategyNames: []
            }
          )
        } else {
          // in case if row is nested table row, then adding data to nestedStrategyNames of previous row
          // Get the count of nested table elements for the current row
          const elementCount = await row.locator(this.locators.nestedTableElement).count()

          // Iterate over each nested table element
          for (let j = 0; j < elementCount; j++) {
            const text = await row.locator(this.locators.nestedTableElement).nth(j).textContent()
            // pushing nested strategy name to the previous main table row
            if (text) tableData[tableData.length-1].nestedStrategyNames?.push(text)
          }
        }

      }
      return tableData
    })
  }

  /**
 * Selects or unselects favorite strategies up to a specified count.
 * 
 * @param {number} count - The number of strategies to process.
 * @param {'select' | 'unselect'} action - The action to perform, either 'select' or 'unselect'.
 * @param {boolean} [needAssert=true] - Flag to determine if assertions should be performed after selection/unselection.
 * @returns {Promise<number[]>} - An array of processed row indexes.
 */
  public async selectingFavoriteStrategies(count: number, action: 'select' | 'unselect', needAssert: boolean = true) {
    const processedIndexes: number[] = []
    const allTableFavoriteButtons = await this.locators.favoriteStrategyButton.count() // Get the total count of table rows (favorite strategy buttons)

    await test.step(`Loop to ${action} strategies up to the specified count and assert the ${action === 'select' ? 'selection' : 'deselection'}`, async () => {
      for (let rowIndex = 0; rowIndex < Math.min(count, allTableFavoriteButtons); rowIndex++) {
        const favoriteStrategyRow = this.locators.favoriteStrategyButton.nth(rowIndex)
        const isSelected = await favoriteStrategyRow.locator(this.locators.selectedFavoriteStrategy).isVisible()
        const isUnSelected = await favoriteStrategyRow.locator(this.locators.unSelectedFavoriteStrategy).isVisible()
            
        if ( (action === 'select' && isUnSelected) || (action === 'unselect' && isSelected)) {
          await test.step(`${action === 'select' ? 'Selecting' : 'Unselecting'} strategy at row index: ${rowIndex}`, async () => {
            await this.locators.favoriteStrategyButton.nth(rowIndex).click() 
          })

          processedIndexes.push(rowIndex) // Add the index to the processedIndexes array
        }
      }
      if(needAssert) {
        await this.assertFavoriteStrategiesSelection(action, processedIndexes)
      }
    })
    return processedIndexes
  }

  /**
 * Asserts the selection state of favorite strategies for the specified rows or all rows in the table.
 * 
 * @param {'select' | 'unselect'} action - The action to assert, either 'select' or 'unselect'.
 * @param {number[]} [rowIndex] - An optional array of row indexes to assert. If not provided, all rows will be asserted.
 * @returns {Promise<void>}
 */
  public async assertFavoriteStrategiesSelection(action: 'select' | 'unselect', rowIndex?: number[]) {
    await test.step(`Asserts that the favorite strategies in specified rows or all rows in a table are ${action === 'select' ? 'selected' : 'not selected'}`, async () => {
      const indexes = rowIndex || Array.from({ length: await this.locators.favoriteStrategyButton.count() }, (_, i) => i)
      for (const index of indexes) {
        if (action === 'select') {
          await expect.soft(this.locators.favoriteStrategyButton.nth(index).locator(this.locators.selectedFavoriteStrategy), `Expect favorite strategy with row index: ${index} to be selected`).toBeVisible()
          await UiTextStylesAssert.fontColor(this.locators.favoriteStrategyButton.nth(index).locator(this.locators.selectedFavoriteStrategy), GeneralStyles.colorPrimaryMain)
        } else {
          await expect.soft(this.locators.favoriteStrategyButton.nth(index).locator(this.locators.unSelectedFavoriteStrategy), `Expect favorite strategy with row index: ${index} to be not selected`).toBeVisible()
        }
      }
    })
  }

  /**
 * Gets the indexes of favorite strategies, divided into selected and unselected.
 * 
 * @returns {Promise<[number[], number[]]>} - A promise that resolves to an array containing two arrays:
 * the first array contains the indexes of selected strategies,
 * the second array contains the indexes of unselected strategies.
 */
  public async getFavoriteStrategyIndexes(): Promise<[number[], number[]]> {
    const allTableFavoriteButtons = await this.locators.favoriteStrategyButton.count()
    const selectedIndexes: number[] = []
    const unselectedIndexes: number[] = []

    for (let rowIndex = 0; rowIndex < allTableFavoriteButtons; rowIndex++) {
      const favoriteStrategyRow = this.locators.favoriteStrategyButton.nth(rowIndex)
      const isSelected = await favoriteStrategyRow.locator(this.locators.selectedFavoriteStrategy).isVisible()
      const isUnSelected = await favoriteStrategyRow.locator(this.locators.unSelectedFavoriteStrategy).isVisible()

      if (isSelected) {
        selectedIndexes.push(rowIndex)
      } else if (isUnSelected) {
        unselectedIndexes.push(rowIndex)
      }
    }

    return [selectedIndexes, unselectedIndexes]
  }

  /**
 * Asserts that the Strategy Names are sorted in ascending order within the specified range of row indexes.
 * If rowIndexes is not provided, it checks all rows.
 * 
 * @param {TableRow[]} tableData - The table data to be checked.
 * @param {number[]} [rowIndexes] - The optional array of row indexes to check. If not provided, all rows will be checked.
 * @returns {Promise<boolean>} - Returns true if the Strategy Names are sorted, otherwise false.
 */
  public async assertStrategyNamesSorted(tableData: TableRow[], rowIndexes?: number[]): Promise<boolean> {
    const strategyNames = await test.step(`Extract the Strategy Names for the specified row indexes`, async () => {
      const indexes = rowIndexes ?? Array.from({ length: tableData.length }, (_, i) => i)
      return indexes.map(index => {
        const row = tableData[index]
        const strategyNameCell = row.cell.find(cell => cell.columnName === 'Strategy Name')
        return strategyNameCell ? strategyNameCell.value : ''
      })
    })

    const isSorted = await test.step(`Check if the Strategy Names are sorted in ascending order`, async () => {
      for (let i = 1; i < strategyNames.length; i++) {
        if (strategyNames[i - 1] > strategyNames[i]) {
          return false
        }
      }
      return true
    })

    return isSorted
  }
  
  /**
 * Extracts the Strategy Names for the specified row indexes or all rows if no indexes are provided.
 * 
 * @param {TableRow[]} tableData - The table data to be processed.
 * @param {number[]} [rowIndexes] - An optional array of row indexes to extract Strategy Names from. If not provided, all rows will be processed.
 * @returns {Promise<string[]>} - An array of Strategy Names for the specified row indexes or all rows.
 */
  public async getStrategyNames(tableData: TableRow[], rowIndexes?: number[]): Promise<string[]> {
    return await test.step(`Extract the Strategy Names for the specified row indexes or all rows`, async () => {
      const indexes = rowIndexes || Array.from({ length: tableData.length }, (_, i) => i)

      return indexes.map(index => {
        const row = tableData[index]
        const strategyNameCell = row.cell.find(cell => cell.columnName === 'Strategy Name')
        return strategyNameCell ? strategyNameCell.value : ''
      })
    })
  }

}

import { Locator, Page, expect, test } from '@playwright/test'
import { BaseCustomizeMenuLocators } from '../elements/base-customize-menu.el'

/** Interface for parsing customise menu data */
export interface CustomizeMenuItem {
    /** Checkbox condition. Is checkbox checked at the moment*/
    isChecked: boolean
    /** Checkbox condition. Is checkbox enabled at the moment (can be checked or unchecked) */
    isEnabled: boolean
    /** Customize menu item text(column heading name/title)*/
    itemText: string
}
/**
 * Generic customize menu feature class.
 * This class provides following features:
 * - to select/deselect/restore customize menu items
 * - parse customize menu data from UI table to CustomizeMenuItem array
 * */
export abstract class BaseCustomizeMenuFeature {

  protected constructor (
    protected page: Page,
    readonly locators: BaseCustomizeMenuLocators
  ) {}

  /** Selects or deselects customize menu item or items */
  protected async toggleItems(itemLocator: Locator, select: boolean) {
    await this.openMenu()
    //in case when there are multiple itemLocator then starting a loop
    const itemCount = await itemLocator.count()
    for (let i = 0; i < itemCount; i++) {
      //getting checkbox element. It is necessary to get checkbox state
      const checkbox = this.locators.checkbox(itemLocator.nth(i))
      const isChecked = await checkbox.isChecked()
      /*
            * Clicking on the option in following cases:
            * 1. Option need to be checked, but it is not checked right now
            * 2. Option do not need to be checked, but it is checked right now
            */
      if ((select && !isChecked) || (!select && isChecked)) {
        await itemLocator.nth(i).click()
      }
    }
  }

  /** Selects customize menu item or items by passed locator. Does not deselect with second usage
     * @param itemLocator - specific menu item locator that should be selected
     * */
  public async selectItemsByLocator(itemLocator: Locator) {
    await this.toggleItems(itemLocator, true)
  }

  /** Unselects customize menu item or items by passed locator.
     * @param itemLocator - specific menu item locator that should be selected
     * */
  public async unSelectItemsByLocator(itemLocator: Locator) {
    await this.toggleItems(itemLocator, false)
  }

  /** Validates index position of filter item
     * @param index - specific menu item index that should be selected
     * */
  public async validateItemIndex(itemName: string, index: number) {
    await expect(this.locators.menuItems.nth(index).locator('//span[contains (@class, "Text-module__text")]'), 
      `Expecting menu item "${itemName}" to be positioned at index "${index}"`).toHaveText(itemName)
  }

  /** Selects customize menu item or items by passed locator. Does not deselect with second usage
   * @param index - specific menu item index that should be selected
   * */
  public async selectItemsByIndex(index: number) {
    await test.step(`Selecting item by index: ${index}`, async () => {
      await this.toggleItems(this.locators.menuItems.nth(index), true)
    })
  }

  /** Deselects customize columns form option or options by passed locator. Does not select with second usage
     * @param itemLocator - specific menu item locator that should be deselected
     * */
  public async deselectItemsByLocator(itemLocator: Locator) {
    await this.toggleItems(itemLocator, false)
  }

  /** Deselects customize columns form option or options by passed locator. Does not select with second usage
   * @param index - specific menu item locator that should be deselected
   * */
  public async deselectItemsByIndex(index: number) {
    await test.step(`Deselecting item by index: ${index}`, async () => {
      await this.toggleItems(this.locators.menuItems.nth(index), false)
    })
  }

  /**
     * Selects customize columns form option or options by passed names.
     * Does not deselect with second usage
     * @param itemNames - specific column option name(text/title) or array of names that should be selected
     * */
  public async selectItemsByName(itemNames : string | string[]) {
    await test.step(`Selecting: "${itemNames}"`, async () => {
      if (typeof(itemNames) === 'string') {itemNames = [itemNames]}
      await this.selectItemsByLocator(this.locators.menuItem(new RegExp(itemNames.join('|'))))
    })
  }

  /**
     * Deselects customize menu item or items by passed names.
     * Does not select with second usage
     * @param itemNames - specific column option name(text/title) or array of names that should be deselected
     * */
  public async deselectItemsByName(itemNames : string | string[]) {
    await test.step(`Deselecting: "${itemNames}"`, async () => {
      if (typeof(itemNames) === 'string') {itemNames = [itemNames]}
      await this.deselectItemsByLocator(this.locators.menuItem(new RegExp(itemNames.join('|'))))
    })
  }

  /** Selects all items from customize menu. Does not deselect with second usage */
  public async selectAllColumns(){
    await test.step(`Selecting all items`, async () => {
      await this.selectItemsByLocator(this.locators.allItem)
    })
  }

  /** Deselects all items from customize menu. Does not select with second usage */
  public async deselectAllColumns(){
    await test.step(`Deselecting all items`, async () => {
      await this.selectItemsByLocator(this.locators.allItem)
      await this.deselectItemsByLocator(this.locators.allItem)
    })
  }

  public async click() {
    await this.locators.openMenuButton.click()
  }

  /** Asserts text on tooltip description. Keep in mind this information comes from CMS */
  public async validateCustomizeColumnsDescription(text: string) {
    await expect(this.locators.description, `Validates description text is "${text}"`).toContainText(text)
  }

  /** Asserts Title description. Keep in mind this information comes from CMS */
  public async validateCustomizeColumnsTitle(text: string) {
    await expect(this.locators.header, `Validates Title text is "${text}"`).toContainText(text)
  }

  public async openMenu() {
    if (await this.locators.menu.isHidden()){
      await this.locators.openMenuButton.click()
    }
    await expect(this.locators.menu,
      'Assert that menu is visible').toBeVisible()
  }

  public async closeMenu() {
    await this.locators.closeButton.click()
    expect(this.locators.menu,
      'Assert that menu is hidden').toBeHidden
  }

  /**
     * Parses data from customize menu
     *
     * @return Promise<CustomizeMenuItem[]> - Array of customize menu items(lines), with text and current checkboxes state
     * */
  public async data() {
    await this.openMenu()

    const customizeItemArray: CustomizeMenuItem[] = []
    const itemsCount = await this.locators.menuItems.count()
    for (let i = 0; i < itemsCount; i++) {

      const isChecked: boolean = await this.locators.checkbox(this.locators.menuItems.nth(i)).isChecked()
      const isEnabled: boolean = await this.locators.checkbox(this.locators.menuItems.nth(i)).isEnabled()
      const optionText: string = await this.locators.menuItems.nth(i).innerText()

      const customizeMenuItem: CustomizeMenuItem = {
        isChecked,
        isEnabled,
        itemText: optionText
      }
      customizeItemArray.push(customizeMenuItem)
    }
    await this.closeMenu()
    return customizeItemArray
  }

  /** Drag element with source locator and drop it by destination locator
     * @param sourceLocator - source element locator
     * @param destinationLocator - locator of destination position
     * */
  public async dragAndDropMenuItems (sourceLocator: Locator, destinationLocator: Locator) {
    await sourceLocator.hover()
    await this.page.mouse.down()
    await destinationLocator.hover()
    await destinationLocator.hover()
    await this.page.mouse.up()
  }

  /** Drag element with source name and drop it by element with destination name
     * @param sourceName - Name of the source element for dragging
     * @param destinationName -  Name of the destination element for dropping
     * */
  public async dragAndDropMenuItemsByName (sourceName: string, destinationName: string) {
    const firstMetricLocator = this.locators.dragButtonByName(sourceName)
    const lastMetricLocator = this.locators.dragButtonByName(destinationName)
    await this.dragAndDropMenuItems(firstMetricLocator, lastMetricLocator)  
  }

  /** Drag element with source name towards the element with destination name
     * @param sourceName - Name of the source element for dragging
     * @param destinationName -  Name of the destination element
     * */
  public async dragItemByName (sourceName: string, destinationName: string) {
    const sourceLocator = this.locators.dragButtonByName(sourceName)
    const destinationLocator = this.locators.dragButtonByName(destinationName)
    await sourceLocator.hover()
    await this.page.mouse.down()
    await destinationLocator.hover()
    await destinationLocator.hover()  
  }
}
import { Locator, Page, expect, test } from '@playwright/test'
import { TableCell, TableFeature } from './table.feature'
import { SearchLocators } from '../elements/search.el'
import { GeneralStyles } from '../../service-data/generalStyles'
import { UiElementsStylesAssert, UiTextStylesAssert } from '../../../utils/UIComponentsStateAssert'

/**
 * Available search triggers enum
 */
export enum SearchTrigger {
  ENTER_KEY = 'Press Enter key',
  MAGNIFYING_GLASS_BUTTON = 'Click on magnifying glass button',
  CLICK_ON_SUGGEST_OPTION = 'Click on suggest option',
  KEYBOARD_NAVIGATION_CHOOSE_SUGGEST_OPTION = 'Use arrows to navigate suggest option and press Enter key'
}

export enum CloseTrigger {
  ESC_KEY = 'Pressing Escape key',
  MOUSE_CLICK = 'Clicking somewhere in the opened window',
}

export enum SearchCancelTrigger {
  CLICK_CROSS_BUTTON = 'Clicking the cross button on search field',
  CLICK_OUTSIDE_SEARCH = 'Clicking outside the search field'
}

/**
 * SearchFeature class provides an opportunity to use search feature.
 * It is a generic class, so you will be able to reuse it with every tile that has search feature
 */
export class SearchFeature {

  readonly locators = new SearchLocators(this.page, this.container)
  constructor(protected page: Page, private container: Locator, private table:TableFeature) {
  }

  /**
     * Perform a search
     *
     * **USAGE**
     *
     * Perform a search using Default trigger (click on magnifying glass button)
     * ```js
     * const searchQuery = 'Brook'; // search query should contain at least 2 chars
     * const searchFeature = new SearchFeature(homePage.page, homePage.tileClientList, table);
     * await searchFeature.makeSearch(searchQuery);
     * ```
     *
     * Perform a search using specific trigger
     * ```js
     * const searchQuery = 'Brook'; // search query should contain at least 2 chars
     * const searchFeature = new SearchFeature(homePage.page, homePage.tileClientList, table);
     * await searchFeature.makeSearch(searchQuery, SearchTrigger.ENTER_KEY);
     * ```
     *
     * @param searchQuery - text that will be used as a search query
     * @param trigger - specific search trigger that will be used to perform a search. Optional.
     */
  public async makeSearch(searchQuery: string, trigger?: SearchTrigger) {
    await test.step(`I make search request, using trigger: "${trigger}" and search query is: "${searchQuery}"`, async () => {
      await this.locators.searchInput.fill(searchQuery)
      switch ( trigger ) {
      case SearchTrigger.ENTER_KEY:
        await this.page.keyboard.press('Enter')
        break
      default:
      case SearchTrigger.MAGNIFYING_GLASS_BUTTON:
        await this.locators.magnifyingGlassButton.click()
        break
      case SearchTrigger.CLICK_ON_SUGGEST_OPTION:
        await expect(this.locators.suggestOptions.first()).toBeVisible()
        await this.locators.suggestOptions.first().click()
        break
      case SearchTrigger.KEYBOARD_NAVIGATION_CHOOSE_SUGGEST_OPTION:
        await expect(this.locators.suggestOptions.first()).toBeVisible()
        await this.page.keyboard.press('ArrowDown')
        await this.page.keyboard.press('Enter')
        break
      }
      await expect(this.locators.suggestPopup, 'Expecting that suggest popup is not visible after completing search query').toBeHidden()
      await expect(this.locators.searchBox, 'Expecting that search box has active state').toHaveClass(/Input-module__focused/)
    })
  }

  public async fillSearchField(filledSearchQuery: string, expectedSearchQuery: string = filledSearchQuery) {
    await test.step(`I fill the search field`, async () => {
      await this.locators.searchInput.fill(filledSearchQuery)
      await expect(this.locators.searchInput, `Expecting that search field is filled by value "${filledSearchQuery}"`).toHaveValue(expectedSearchQuery)
      await expect(this.locators.searchBox, 'Expecting that search input is focused').toHaveClass(/focused/)
    })
  }

  public async cancelSearch(trigger: SearchCancelTrigger) {
    await test.step(`Cancel search with trigger: ${trigger}`, async () => {
      switch ( trigger ) {
      case SearchCancelTrigger.CLICK_CROSS_BUTTON:
        await this.locators.crossButton.click()
        break
      case SearchCancelTrigger.CLICK_OUTSIDE_SEARCH:
        await this.page.locator('//div[@id="logo"]').click()
        break
      default:
        throw new Error(`"${trigger}" is not a valid search cancel trigger.`)
      }
    })
  }

  public async assertAutoComplete(searchQuery: string) {
    await test.step(`I fill the search field with two first symbols from search query`, async () => {
      await this.locators.searchInput.pressSequentially(searchQuery.slice(0, 2))
      await expect(this.locators.searchInput, `Expecting that search field is filled by value "${searchQuery.slice(0, 2)}"`).toHaveValue(searchQuery.slice(0, 2))
      await this.verifyHighlights(searchQuery.slice(0, 2))
    })

    await test.step(`I keep typing characters one by one`, async () => {
      for(let i = 3; i <= searchQuery.length; i++) {
        await this.locators.searchInput.pressSequentially(searchQuery.slice(i - 1, i))
        await expect(this.locators.searchInput, `Expecting that search field is filled by value "${searchQuery.slice(0, i)}"`).toHaveValue(searchQuery.slice(0, i))
        await this.verifyHighlights(searchQuery.slice(0, i))
      }
    })
  }

  public async assertSearchFieldIsEmpty() {
    await expect(this.locators.searchInput, `Assert that search field is empty`).toHaveValue('')
  }

  public async assertSearchCrossButtonAbsent() {
    await expect(this.locators.crossButton, `Assert that there is no cross button when search field is empty`).toBeHidden()
  }

  public async assertSearchCrossButtonAvailable() {
    await expect(this.locators.crossButton, `Assert that the cross button is available when search field is filled`).toBeVisible()
  }

  public async assertTextStylesInSearchInputField() { 
    await UiTextStylesAssert.fontWeight(this.locators.searchInput, GeneralStyles.fontLight)
    await UiTextStylesAssert.fontName(this.locators.searchInput, GeneralStyles.fontFamilyRobotoSansSerif) 
    await UiTextStylesAssert.fontSize(this.locators.searchInput, GeneralStyles.fontSize14) 
    await UiTextStylesAssert.fontColor(this.locators.searchInput, GeneralStyles.colorBlack) 
  }

  /**
     * Verify that all suggest options highlight search query text
     *
     * **USAGE**
     *
     * ```js
     * const searchQuery = 'Brook'; // search query should contain at least 2 chars
     * const searchFeature = new SearchFeature(homePage.page, homePage.tileClientList, table);
     * await searchFeature.searchInput.fill(searchQuery); // enter search query in search input
     * await searchFeature.verifyHighlights(searchQuery); // verify suggest options highlights
     * ```
     *
     * @param searchQuery - text that was used as a search query
     */
  public async verifyHighlights(searchQuery: string) {
    await test.step(`I make sure that text in suggest is highlighted`, async () => {
      for (let i = 0; i < await this.locators.suggestOptions.count(); i++) {
        const highlightedText =  this.locators.suggestHighlightedText(this.locators.suggestOptions.nth(i))
        const countHighlightedText = await highlightedText.count()

        await test.step(`Make assert in loop if 'highlightedText' resolve a few selectors`, async () => {
          for (let j = 0; j < countHighlightedText; j++) {
            await UiTextStylesAssert.fontWeight(highlightedText.nth(j), GeneralStyles.fontLight)
            expect((await highlightedText.nth(j).innerText()).toLowerCase()).toEqual(searchQuery.toLowerCase())
          }
        })

        const allText =  this.locators.suggestText(this.locators.suggestOptions.nth(i))
        const countAllText = await allText.count()

        await test.step(`Make assert in loop if 'allText' resolve a few selectors`, async () => {
          for (let j = 0; j < countAllText; j++) {
            await UiTextStylesAssert.fontWeight(allText.nth(j), GeneralStyles.fontSemibold)
            expect((await allText.nth(j).innerText()).toLowerCase()).toContain(searchQuery.toLowerCase())
          }
        }) 
      }
    }) 
  }

  public async movingUpThroughSuggestions() {
    if (this.locators.suggestOptions.first()) {
      await test.step(`I am moving up through suggestion list`, async () => {
        for (let i = 0; i < await this.locators.suggestOptions.count(); i++) {
          const focusedSuggestion = this.locators.suggestOptions.nth(await this.locators.suggestOptions.count() - i - 1)

          await this.page.keyboard.press('ArrowUp')
          await expect(focusedSuggestion, 'Expecting that suggestion is visible').toHaveClass(/focused/)
        }
      })
    } else throw new Error(`No suggestion in current search query`)
  }

  public async movingDownThroughSuggestions() {
    if (this.locators.suggestOptions.first()) {
      await test.step(`I am moving down through suggestion list`, async () => {
        for (let i = 0; i < await this.locators.suggestOptions.count(); i++) {
          const focusedSuggestion = this.locators.suggestOptions.nth(i)

          await this.page.keyboard.press('ArrowDown')
          await expect(focusedSuggestion, 'Expecting that suggestion is focused').toHaveClass(/focused/)
        }
      })
    } else throw new Error(`No suggestion in current search query`)
  }

  public async closingSuggestion(filledSearchQuery: string, trigger?: CloseTrigger, expectedSearchQuery: string = filledSearchQuery) {
    await test.step(`I closing a list of search suggestion, using trigger: "${trigger}" and search query is: "${filledSearchQuery}"`, async () => {

      await expect(this.locators.suggestPopup, 'Expecting that suggest popup is visible after filling in input field').toBeVisible()
      await expect(this.locators.searchBox, 'Expecting that search input is focused').toHaveClass(/focused/)

      switch ( trigger ) {
      case CloseTrigger.ESC_KEY:
        await this.page.keyboard.press('Escape')
        await expect(this.locators.searchInput, `Expecting that search field is filled by value "${filledSearchQuery}"`).toHaveValue(expectedSearchQuery)
        break
      default:
      case CloseTrigger.MOUSE_CLICK:
        await this.table.locators.table.click()
        await expect(this.locators.searchInput, `Expecting that search field is empty`).toHaveValue('')
        break
      }
      await expect(this.locators.suggestPopup, 'Expecting that suggest popup is not visible').toBeHidden()
      await expect(this.locators.searchBox, 'Expecting that search input is not focused').not.toHaveClass(/focused/)
    })
  }

  public async assertNoSuggestions() { 
    await expect(this.locators.suggestPopup, 'Expecting that suggest popup is not visible').toBeHidden()
  }

  public async verifyBackgroundColorOfHoveredSuggestion() {
    await test.step(`I make sure that suggested option has specific Hovered and Selected background color`, async () => {
      const firstSuggestedOption = this.locators.suggestOptions.first()
      const secondSuggestedOption = this.locators.suggestOptions.nth(1)
      const searchBoxLocator = this.locators.searchBox
      const noBackgroundColor = GeneralStyles.noBackgroundColor
      const hoveredBackgroundColor = GeneralStyles.colorPrimary8p
      const selectedSuggestionBackgroundColor = GeneralStyles.colorPrimary20p
  
      await UiElementsStylesAssert.backgroundColor(noBackgroundColor, firstSuggestedOption)
      await firstSuggestedOption.hover()
      await UiElementsStylesAssert.backgroundColor(hoveredBackgroundColor, firstSuggestedOption)
      await firstSuggestedOption.focus()
      await searchBoxLocator.hover()
      await UiElementsStylesAssert.backgroundColor(hoveredBackgroundColor, searchBoxLocator)
      await UiElementsStylesAssert.backgroundColor(selectedSuggestionBackgroundColor, firstSuggestedOption)
  
      if (secondSuggestedOption) {
        await UiElementsStylesAssert.backgroundColor(noBackgroundColor, secondSuggestedOption)
        await secondSuggestedOption.hover()
        await UiElementsStylesAssert.backgroundColor(hoveredBackgroundColor, secondSuggestedOption)
        await UiElementsStylesAssert.backgroundColor(noBackgroundColor, firstSuggestedOption)
      }
    })
  }

  public async verifyTooltipAndBackgroundColorAppearance() {
    await test.step(`I make sure that input field has specific background color and tooltip with appropriate text appeared`, async () => {
      await UiElementsStylesAssert.backgroundColor(GeneralStyles.colorPrimary20p, this.locators.searchBox)
      await expect(this.locators.tooltip, 'Expecting that appeared tooltip has the text').toHaveText('Please, put more than 1 letter for search results')
    })
  }

  /**
 * Verifies that the search results contain information matching the search query.
 *
 * This method performs the following steps:
 * 1. Validates that the table is visible.
 * 2. Iterates through each row in the table data.
 * 3. For each row, checks each cell to see if it matches the search query based on the specified searchable fields.
 * 4. If the row contains nested rows, it iterates through each nested row and checks each cell for matches.
 * 5. Asserts that each row or its nested rows have at least one match with the search query.
 *
 * @param {string} searchQuery - The search query string to match against the table data.
 * @param {string[]} searchableFieldArray - An array of column names that are considered searchable.
 * @returns {Promise<void>} A promise that resolves when all assertions have been made.
 */
  public async verifySearchResult(searchQuery: string, searchableFieldArray: string[]): Promise<void> {
    await test.step('I make sure that search results contain information from search query', async () => {
      // The function compares the search phrase with the resulting phrase word by word
      function checkWordsInSearchMatchWordsInCell(searchQueryValue: string, cellItem: TableCell) {
        const search = searchQueryValue.toLowerCase().split(' ')
        const cellValue = cellItem.value.toLowerCase().split(' ')
        return search.every(elSearch => cellValue.some(elCellValue => elCellValue.includes(elSearch)))
      }

      await expect(this.table.locators.table, 'Verify that table is visible').toBeVisible()

      const tableData = await this.table.data()

      expect(tableData.length, 'Verify that table contains at least one row').toBeGreaterThan(0)

      // Loop, validating every table row
      for (const row of tableData) {
        let hasMatch = false

        // Function to check cells in a row
        const checkCells = async (cells: TableCell[], isNested: boolean) => {  
          for (const cell of cells) {
            if (searchableFieldArray.includes(cell.columnName)) {
              if (checkWordsInSearchMatchWordsInCell(searchQuery, cell)) {
                await test.step(
                  `${isNested ? 'Nested table ' : ''}Column name: "${cell.columnName}" - is searchable; 
                              Value: "${cell.value}" - matches with search query "${searchQuery}"`,
                  async () => {
                    hasMatch = true // In match case changing flag to 'true'
                  }
                )
              }
            }
          }
        }
        // Validate main row cells
        await checkCells(row.cell, false)

        // Validate nested rows if present
        if (row.nestedTableRow) {
          for (const nestedRow of row.nestedTableRow) {
            await checkCells(nestedRow.cell, true)
          }
        }
        expect(hasMatch, 'Expecting that current table row or its nested rows has match with search query').toBeTruthy()
      }
    })
  }

}
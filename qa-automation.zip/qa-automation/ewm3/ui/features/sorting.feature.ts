import {FieldConfig, TableDataConfig, TableRow} from './table.feature'
import {TableLocators} from '../elements/table.el'
import {Locator, Page, expect, test} from '@playwright/test'

/** Existing sorting orders*/
export enum SortingOrder {
    DESCENDING = 'Descending',
    ASCENDING = 'Ascending',
    DEFAULT = 'Default',
}

/** Custom type for handling some sorting feature functions
 * @see SortingFeature.sortBy
 * */
type SortingState = {
    columnName?: string;
    sortingOrder: SortingOrder;
};

/**
 * Generic Sorting feature class.
 * This class provides following sorting features:
 * - Sort By
 * - Assert that sorting is correct
 * */
export class SortingFeature {
  constructor(
        protected page: Page,
        container: Locator,
        readonly locators = new TableLocators(page, container)
  ) {
  }

  /**
     * Helps to normalize value for correct value compare
     * @param cellValue - value that contains in table cell that need to be normalized
     * @param fieldConfig - field config that is need for define what kind of normalization needed
     * @return any - normalized value that is ready for compare
     * @see compareValues
     * */
  private normalizeSortingValue(cellValue:string, fieldConfig:FieldConfig):any{
    const transform = fieldConfig.sortingDataTransform
    return transform ? transform(cellValue) : cellValue
  }

  /**
     * Assert that sorting is correct
     *
     * @param tableDataConfig - table data config contains rules of sorting, normalizing and etc
     * @param tableRows - parsed table data is used for getting data and comparing values from table rows
     * @param sortingState - reference sorting state, that contains column name and sorting order
     * @see SortingState
     * */
  public async assertSorting(tableDataConfig: TableDataConfig, tableRows: TableRow[], sortingState?: SortingState) {
    const currentSortingState = sortingState? sortingState : await this.getCurrentSortingState()
    await test.step(`Assert sorting feature: 
      Column "${currentSortingState.columnName || (currentSortingState.sortingOrder === SortingOrder.DEFAULT ? tableDataConfig.defaultSortingField.columnName : '')}";
      ${currentSortingState.sortingOrder}
    `, async () => {
      for (let i = 1; i < tableRows.length; i++) {
        this.assertRowSorting(
          tableDataConfig,
          tableRows[i - 1],
          tableRows[i],
          currentSortingState.sortingOrder,
          currentSortingState.sortingOrder !== SortingOrder.DEFAULT ?
            currentSortingState.columnName : undefined
        )
      }
    })
  }

  public async assertNestedSorting(nestedTableDataConfig: TableDataConfig, mainTableRows: TableRow[], sortingState?: SortingState) {
    const currentSortingState = sortingState? sortingState : await this.getCurrentSortingState()
    await test.step(`Assert sorting feature in nested tables: 
      Column "${currentSortingState.columnName || (currentSortingState.sortingOrder === SortingOrder.DEFAULT ? nestedTableDataConfig.defaultSortingField.columnName : '')}";
      ${currentSortingState.sortingOrder}
    `, async () => {
      for (let i = 0; i < mainTableRows.length; i++) {
        if(mainTableRows[i].nestedTableRow){
          const nestedTable = mainTableRows[i].nestedTableRow
          for (let j = 1; j < nestedTable.length; j++) {
            this.assertRowSorting(
              nestedTableDataConfig,
              nestedTable[j - 1],
              nestedTable[j],
              currentSortingState.sortingOrder,
              currentSortingState.sortingOrder !== SortingOrder.DEFAULT ?
                currentSortingState.columnName : undefined
            )
          }
        }
        else continue
      }
    })
  }

  /**
     * Service row assert function. You pass 2 values and function expects that sorting is correct
     * @param tableDataConfig - table data config contains rules of sorting, normalizing and etc
     * @param currentRow - previous row. Value to compare with nextRow
     * @param nextRow - current row. Value to compare with currentRow
     * @param order - Descending/Ascending/Default order
     * @param sortedColumnName - column name that which was sorted.
     * If not passed then using default sorting column name from config
     * @private
     * */
  private assertRowSorting(
    tableDataConfig: TableDataConfig,
    currentRow: TableRow,
    nextRow: TableRow,
    order: SortingOrder,
    sortedColumnName: string = tableDataConfig.defaultSortingField.columnName
  ) {
    const fieldConfig = tableDataConfig.fields.find(field => field.columnName === sortedColumnName)
    const cellIndex = nextRow.cell.findIndex(cell => cell.columnName === sortedColumnName)
    const finalSortingOrder = order === SortingOrder.DEFAULT ? tableDataConfig.defaultSortingOrder : order
    const currentValue = fieldConfig? this.normalizeSortingValue(currentRow.cell[cellIndex].value, fieldConfig): currentRow.cell[cellIndex].value
    const nextValue = fieldConfig? this.normalizeSortingValue(nextRow.cell[cellIndex].value, fieldConfig) : nextRow.cell[cellIndex].value

    expect.soft(this.compareValues(currentValue, nextValue, finalSortingOrder),
      `Comparing values current value: "${currentValue}" and next value "${nextValue}"; ${finalSortingOrder}`
    ).toBeTruthy()
  }

  /**
     * Service function for compare 2 values using specific sorting order.
     *
     * Can be used only for values of one type.
     *
     * Available types of data: string, number, Date
     *
     * @param currentValue - value for comparing with nextValue
     * @param nextValue - value for comparing with currentValue
     * @param order - sorting order. Descending/ascending
     * @private
     * @return boolean - is 2 values are sorted in a correct way
     * */
  private compareValues(currentValue:string|number|Date, nextValue:string|number|Date, order: SortingOrder){
    let comparison = 0
    
    if (currentValue === null && nextValue === null) return true
    if (currentValue === null) return order === SortingOrder.ASCENDING ? true :
      false
    if (nextValue === null) return order === SortingOrder.ASCENDING ? false :
      true

    //define current data type
    if (typeof currentValue === 'string' && typeof nextValue === 'string') {
      //perform compare
      comparison = order === SortingOrder.ASCENDING ? currentValue.localeCompare(nextValue) :
        nextValue.localeCompare(currentValue)
    } else if (typeof currentValue === 'number' && typeof nextValue === 'number') {
      if (isNaN(currentValue) && isNaN(nextValue)) return true
      if (isNaN(currentValue)) return order === SortingOrder.ASCENDING ? true :
        false
      if (isNaN(nextValue)) return order === SortingOrder.ASCENDING ? false :
        true

      comparison = order === SortingOrder.ASCENDING ? currentValue - nextValue :
        nextValue - currentValue
    } else if (currentValue instanceof Date && nextValue instanceof Date) {
      comparison = order === SortingOrder.ASCENDING ? currentValue.getTime() - nextValue.getTime() :
        nextValue.getTime() - currentValue.getTime()
    } else throw new Error(
      `Unexpected values type: 
    currentValue: ${typeof currentValue} ${currentValue} 
    nextValue: ${typeof nextValue} ${nextValue} 
    `)
    //return bool with compare result
    return comparison <= 0
  }

  /**
     * Service function for getting current sorting state
     *
     * @param tableHeadersLocator - optional. We are using main table header by default.
     * But if you want to get nested table sorting state then you need to pass nested table headers locator
     * @return Promise<SortingState> - current sorting state
     * @private
     * @see TableLocators.nestedTableHeaders
     * @see SortingState
     * */
  private async getCurrentSortingState(tableHeadersLocator: Locator = this.locators.tableHeaders): Promise<SortingState> {
    return await test.step(`Getting current sorting state`, async () => {
      const ascendingSortingColumn = tableHeadersLocator.filter({has: this.locators.ascendingSorting})
      const descendingSortingColumn = tableHeadersLocator.filter({has: this.locators.descendingSorting})
      let sortingOrder: SortingOrder
      let columnName: string = ''

      /*
            * If some column has ascending/descending sorting button then we can define current sorting state
            * if both sorting button are not presented then current sorting is default
            * */
      if (await ascendingSortingColumn.count() === 1) {
        sortingOrder = SortingOrder.ASCENDING
        columnName = await ascendingSortingColumn.innerText()
      } else if (await descendingSortingColumn.count() === 1) {
        sortingOrder = SortingOrder.DESCENDING
        columnName = await descendingSortingColumn.innerText()
      } else {
        sortingOrder = SortingOrder.DEFAULT
      }
      return await test.step(`Current sorting state is: ${columnName ? columnName + ',' : ''} ${sortingOrder}`, async () => {
        return {
          columnName: columnName,
          sortingOrder: sortingOrder,
        }
      })
    })
  }

  /**
     * Allows to sort using main or nested table
     *
     * @param sortingState - desirable sorting state
     * @param tableHeadersLocator - optional. We are using main table headers by default.
     * But if you want to use sorting in nested tables then you can pass nested table headers locator
     * @see TableLocators.nestedTableHeaders
     * @see SortingState
     * */
  public async sortBy(sortingState: SortingState, tableHeadersLocator: Locator = this.locators.tableHeaders) {
    await test.step(`Sorting by "${sortingState.columnName}" using ${sortingState.sortingOrder}`, async () => {
      const currentSortingState = await this.getCurrentSortingState(tableHeadersLocator)

      const columnHeading = tableHeadersLocator.filter({ has: this.page.locator(`text="${sortingState.columnName}"`) })
      const sortingButton = this.locators.sortingButton(columnHeading)

      let clicksCount: number = 0

      if (currentSortingState.columnName === sortingState.columnName &&
                currentSortingState.sortingOrder !== sortingState.sortingOrder) {
        // If the column is already sorted, calculate the number of clicks needed
        clicksCount = currentSortingState.sortingOrder === SortingOrder.DESCENDING
          ? sortingState.sortingOrder === SortingOrder.ASCENDING
            ? 1
            : 2
          : sortingState.sortingOrder === SortingOrder.DESCENDING
            ? 2
            : 1
      } else if (currentSortingState.columnName === sortingState.columnName &&
                currentSortingState.sortingOrder === sortingState.sortingOrder){
        clicksCount = 3
      } else {
        // Handle the case where the column is not sorted
        clicksCount = sortingState.sortingOrder === SortingOrder.DESCENDING ? 1 : 2
        if (sortingState.sortingOrder === SortingOrder.DEFAULT) {
          clicksCount = 3
        }
      }
      // Hovering column heading to trigger sorting button appearance
      await columnHeading.hover()
      // Loop for clicking sorting button until desirable sorting state will be reached
      for (let i = 0; i < clicksCount; i++) {
        await sortingButton.click()
      }
    })
  }

  public async sortAllNestedTeblesOnCurrentPageBy(sortingState: SortingState) {
    const currentNestedHeaders = this.locators.allNestedTableHeaders.nth(0).locator(this.locators.headerColumn)
    expect(await currentNestedHeaders.count()>0,
      `There is at least one Account sub table in the Households tab`
    ).toBeTruthy()

    await this.sortBy(sortingState, currentNestedHeaders)
  }

  /**
     * Validates header item has sorting button enabled
     *
     * @param headerName - header to validate sorting option is available
  * */
  public async validateHeaderItemIsSortable(headerName: string) {
    expect(await this.isHeaderSortable(headerName), 'Expects sorting button to appear on header item hover').toBeTruthy()
  }

  /**
     * Validates header item has sorting button disabled
     *
     * @param headerName - header to validate sorting option is absent
  * */
  public async validateHeaderItemIsNotSortable(headerName: string) {
    expect(await this.isHeaderSortable(headerName), 'Expects sorting button not to appear on header item hover').toBeFalsy()
  }

  private async isHeaderSortable(headerName: string): Promise<boolean> {
    return await test.step(`Get header "${headerName}" sortable state`, async () => {
      const header = this.locators.tableHeaders.filter({hasText: headerName})
      await header.hover()
      return await this.locators.sortingButton(header).isVisible()
    })
  }

}
import {Locator, Page, expect, test} from '@playwright/test'
import {CSToolbarLocators} from '../../elements/client-section/cs.toolbar.el'
import {CSToolbarMetricsMenuFeature} from './cs.toolbar-metrics-menu.feature'

export interface ToolbarMetricItem{
  name: string
  value: string
}
export interface ToolbarMetricConfig{
  uid: string,
  name: string
  apiField: string
  apiDataTransform?: (value: number) => string
}
export class CSToolbarFeature {
  readonly locators = new CSToolbarLocators(this.page, this.container)
  readonly metricsMenu = new CSToolbarMetricsMenuFeature(this.page, this.container)
  constructor(protected page: Page, protected container: Locator) {
  }

  /**
   * Get all metrics data
   * @returns Promise<ToolbarMetricItem[]> - array of metric names and values
   * */
  public async metricsData(): Promise<ToolbarMetricItem[]> {
    return await test.step(`Parse toolbar metrics data`,  async () => {
      const names = await this.locators.metricNames.allTextContents()
      const values = await this.locators.metricValues.allTextContents()

      // Check if the lengths of the arrays are equal
      if (names.length === values.length) {
        // Create an empty array to store the metrics
        const metrics: ToolbarMetricItem[] = []

        // Iterate through the arrays
        for (let i = 0; i < names.length; i++) {

          // Push the object into the metric array
          metrics.push({
            name: names[i],
            value: values[i]
          })
        }

        // Output the array of metrics
        return metrics
      } else {
        throw new Error(`Toolbar has different metric names and values count
       Toolbar metric Names count: ${names.length}
       Toolbar metric Values count: ${values.length}
       `)
      }
    })
  }

  public async ellipsisExistForMetrics(metricsNames: string[]){
    await test.step(`Check that ellipsis exist for Toolbar Metric ${metricsNames}`,  async () => {
      for (const metricName of metricsNames) {
        const currentMetric = await this.locators.metricValueByName(metricName)
        const currentNameCoordinates = await currentMetric.boundingBox()
        expect(await currentMetric.getAttribute('class'),'Assert that Metric value contains "textEllipsis" mark').toContain('textEllipsis')
        expect(currentNameCoordinates?.width === 184,'Assert that Metric value length does not exceed fixed width').toBe(true)
      }
    })
  }

  public async metricsFromTooltipMatchApi(metricsNames: string[], dataAPI, mappingConfig:ToolbarMetricConfig[]) {
    await test.step(`Get Metrics Value from Tooltip for Metric: ${metricsNames}`,  async () => {
      for (const metricName of metricsNames) {
        const currentMetricValue = await this.locators.metricValueByName(metricName)
        const currentConfigElement = mappingConfig.find(item=> item.name===metricName)
        const currentApiField= currentConfigElement?.apiField
        let apiValueRaw = 0
        if (currentApiField){
          apiValueRaw =dataAPI.data[currentApiField]
        } 
        const apiValueNormalized = currentConfigElement?.apiDataTransform?currentConfigElement.apiDataTransform(apiValueRaw):apiValueRaw
        await currentMetricValue.hover()
        const currentMetricValueTooltip = await this.locators.metricTooltipValueByName(apiValueNormalized as string)
        const tooltipAmount = await currentMetricValueTooltip.count()
        expect(tooltipAmount===1,
          `Compare metric ${metricsNames} values. Tooltip: ${currentMetricValueTooltip};  API: ${apiValueNormalized}`).toBeTruthy()
      }
    })
  }

  /**
   * Assert API->UI data mapping
   * Makes soft data assert between API and UI using the loop of every item in config
   * @param dataUI - parsed toolbar metrics
   * @param dataAPI - advisormetrics response body
   * @param mappingConfig - toolbar metrics config
   * */
  public async assertDataMapping(dataUI: ToolbarMetricItem[], dataAPI: any, mappingConfig:ToolbarMetricConfig[]){
    await test.step(`Making mapping API->UI assert`,  async () => {
      expect.soft(dataUI.length,
        `Compare number of metrics. Actual UI: ${dataUI.length};  Expected config: ${mappingConfig.length}`
      ).toEqual(mappingConfig.length)
      for (const config of mappingConfig) {
        const apiValueRaw =dataAPI.data[config.apiField]
        const apiValueNormalized = config.apiDataTransform?config.apiDataTransform(apiValueRaw):apiValueRaw
        const uiValue = dataUI.find((item) => item.name === config.name)?.value
        expect.soft(uiValue,
          `Compare ${config.name} values. UI: ${uiValue};  API raw: ${apiValueRaw}`).toEqual(apiValueNormalized)
      }
    })
  }

  public async openToolbarActionsMenu() {
    await test.step(`Open toolbar actions menu`, async () => {
      await this.locators.actionsMenuButton.click()
      await expect(this.locators.actionsMenu,
        'Assert that menu is visible').toBeVisible()

    })
  }

  public async openMetricsMenuThroughActionsMenu() {
    await test.step(`Open toolbar metrics menu using actions menu`, async () => {
      await this.openToolbarActionsMenu()
      await test.step(`Click at Toolbar Metrics item in actions menu list`, async () => {
        await this.locators.actionsMenuItems.filter({hasText: 'Toolbar Metrics'}).click()
        await expect(this.metricsMenu.locators.menu,
          'Assert that menu is visible').toBeVisible()
      })
    })
  }

  public async visibleMetricsAreCorrectAligned(lineAmount: number) {
    await test.step(`Check if visible metrics are in ${lineAmount} line(s)`, async () => {
      const metricsCount = await this.locators.metricNames.count()
      for (let i = 0; i < metricsCount; i++) {
        const currentName = await this.locators.metricNames.nth(i)
        const currentValue = await this.locators.metricValues.nth(i)
        const currentNameCoordinates = await currentName.boundingBox()
        const currentValueCoordinates = await currentValue.boundingBox()
        if (lineAmount===2){
          expect(currentNameCoordinates?.x,'Assert that Metric label and Metric value are right aligned').toEqual(currentValueCoordinates?.x)
          expect((currentNameCoordinates?.y ?? 0) + (currentNameCoordinates?.height ?? 0) <= (currentValueCoordinates?.y ?? 0),
            'Assert that Metric label y coordinate less than Metric value y coordinate').toBe(true)
        } else if (lineAmount===1) {
          expect(currentNameCoordinates?.y,'Assert that Metric label and Metric value are aligned horizontally').toEqual(currentValueCoordinates?.y)
          expect((currentNameCoordinates?.x ?? 0) + (currentNameCoordinates?.width ?? 0) <= (currentValueCoordinates?.x ?? 0),
            'Assert that Metric label х coordinate less than Metric value x coordinate').toBe(true)
        }
        else {
          throw new Error(`Unknown line amount for Toolbar metrics displaying: ${lineAmount}`)
        }
      }
    })
  }
}
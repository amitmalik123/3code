import {Locator, Page, expect, test} from '@playwright/test'
import {CSNavbarbarLocators} from '../../elements/client-section/cs.navbar.el'
import {PrivacyPopup} from  '../../elements/privacyPopup'

export class CSNavBarFeature {
  readonly locators = new CSNavbarbarLocators(this.page, this.container)
  readonly privacyPopup = new PrivacyPopup(this.page)
  constructor(protected page: Page, protected container: Locator) {
  }

  public async clickOnTabByName(tabName:string) {
    await test.step(`Open CS tab: ${tabName}`, async () => {
      await this.locators.pageMenuItemByName(tabName).click()
    })
  }

  async waitNavbarIsReady() {
    await test.step('Waiting until the page navbar is ready for use', async () => {
      await expect(this.locators.navBar).toBeVisible()
      await this.privacyPopup.checkPopupAndClose()
    })
  }
}
import {TableCell, TableFeature, TableRow} from '../table.feature'
import {Locator, Page, expect, test} from '@playwright/test'
import {ClientSectionTableLocators} from '../../elements/client-section/cs.table.el'
import {SortingFeature} from '../sorting.feature'
import {FieldConfig, TableDataConfig} from '../table.feature'
import {FilterType} from './filter/cs.base-filter.feature'
import {CSTableRangeFilterFeature} from './filter/table/cs.range-filter.feature'
import {CSTableCheckboxFilterFeature} from './filter/table/cs.checkbox-filter.feature'

export interface CSTableDataConfig extends TableDataConfig {
  /**
   * Array of distinct UI main table fields specific for the Client Section. It is made for match API and UI objects before mapping assert */

  fields: CSFieldConfig[];
  defaultSortingField: CSFieldConfig;
  nestedTableDataConfig?: CSTableDataConfig;
}

export interface CSFieldConfig extends FieldConfig {
  /** Additional CMS column capabilities specific for Client Section */
  uid: string;
  enable_filtering?: boolean;
  default_order?: number|'';
  frozen_direction?: string;
  filterType?: FilterType;
  filterDataTransform?: (value: string) => number;  
}
export interface CSTableCell extends TableCell{
  isFilterable?: boolean
}
export interface CSTableRow extends TableRow{
  cell: CSTableCell[],
  nestedTableRow?: CSTableRow[]
}
export class ClientSectionTableFeature extends TableFeature{
  constructor(page: Page, container: Locator = page.locator('//*[contains(@class, "module__contentWrapper")]')) {
    super(page, container)
  }

  readonly locators = new ClientSectionTableLocators(this.page, this.container)
  readonly sorting = new SortingFeature(this.page, this.container, this.locators)
  public filter(fieldConfig: CSFieldConfig){
    switch (fieldConfig.filterType) {
    case FilterType.RANGE:
      return new CSTableRangeFilterFeature(this.page, this.locators.tableHeaders.filter({hasText: fieldConfig.columnName}), this.container)
    case FilterType.CHECKBOX:
      return new CSTableCheckboxFilterFeature(this.page, this.locators.tableHeaders.filter({hasText: fieldConfig.columnName}), this.container)
    default:
      throw new Error('Invalid filter type')
    }
  }

  public async data(): Promise<CSTableRow[]> {
    const tableRowArray: CSTableRow[] = await super.data()
    return await test.step(`CS main table capabilities parsing (isFixed/isFilterable)`, async () => {
      const isFilterableArray: boolean[] = []
      const headersCount = await this.locators.tableHeaders.count()
      for (let i = 0; i < headersCount; i++) {
        const columnHeading = this.locators.tableHeaders.nth(i)
        isFilterableArray.push(await this.locators.filter(columnHeading).openButton.count() === 1)
      }
      for (let i = 0; i < tableRowArray.length; i++) {
        for (let j = 0; j < tableRowArray[i].cell.length; j++) {
          tableRowArray[i].cell[j].isFilterable = isFilterableArray[j]
        }
      }
      return tableRowArray
    })
  }

  /**
   * CS assertTableColumnCapabilities also checks that:
   * Should column be filterable
   */
  public async assertTableColumnCapabilities(tableDataConfig: CSTableDataConfig, table: CSTableRow | CSTableRow[], isNested: boolean = false){
    await super.assertTableColumnCapabilities(tableDataConfig, table, isNested)
  }

  protected listOfColumnCapabilitiesAsserts(cell: CSTableCell, fieldConfig: CSFieldConfig, isNested: boolean){
    super.listOfColumnCapabilitiesAsserts(cell, fieldConfig, isNested)
    //CS main tables also has filterable feature
    expect.soft(cell.isFilterable,
      `Expect ${isNested? 'nested' : 'main'} column: "${fieldConfig.columnName}" to be filterable: ${fieldConfig.enable_filtering}`
    ).toEqual(fieldConfig.enable_filtering)
  }

  protected listOfNestedColumnCapabilitiesAsserts(cell: TableCell, fieldConfig: FieldConfig, isNested: boolean){
    //CS nested table has the same capabilities list as base nested table
    super.listOfColumnCapabilitiesAsserts(cell, fieldConfig, isNested)
  }

  public async assertTableMatches(table1: CSTableRow[], table2: CSTableRow[]) {
    await test.step(`Assert tables match`, async () => {
      if(table1.length > 0) {
        expect(table1).toEqual(table2)
      } else throw new Error(`Could not assert data. Table is empty`)
    })
  }

  public async clickOnMainRowActionButton(row: Locator) {
    await test.step('I click on Main tabel row action button', async () => {
      try {
        await this.locators.mainRowActionButton(row).click()
      }
      catch {
        throw Error(`Main tabel row action button is not visible`)
      }
    })
  }

  public async clickOnNestedRowActionButton(row: Locator) {
    await test.step('I click on Nested tabel row action button', async () => {
      try {
        await this.locators.nestedRowActionButton(row).click()
      }
      catch {
        throw Error(`Nested tabel row action button is not visible`)
      }
    })
  }

  public getAllMainTableRows(): Locator {
    return this.locators.rowsMainOnly
  }

  public getAllNestedTableRows(): Locator {
    return this.locators.rowsNestedOnly
  }

  public async getNestedHeadersArray(): Promise<string[]> {
    const headersArray: string [] = await this.locators.allNestedTableHeaders.nth(0).locator(this.locators.headerColumn).allInnerTexts()
    return headersArray    
  }

  public async getMainHeadersArray(): Promise<string[]> {
    const headersArray: string [] = await this.locators.tableHeaders.allInnerTexts()
    return headersArray  
  }

  /**
     * Return the text value of specific column in specific row
     *
     * @param row - locator of the main or nested row in the table
     * @param columnName - name of the specific column
     * @param tableHeadersArray - array with the column's names for main or nested table
     * @return string - text value of the column
     * */
  public async getColumnValue(row: Locator, columnName: string, tableHeadersArray: string[]): Promise<string> {
    let columnPosition: number = 0
    let columnValue: string = ''

    for (let j = 0; j < tableHeadersArray.length; j++) {
      if (tableHeadersArray[j]==columnName) {
        columnPosition = j+1
        break
      }
    }
    if (columnPosition) {
      const columnValueLocator = this.locators.columnByPosition(row, columnPosition)
      columnValue = await columnValueLocator.textContent()??''
    }
    return columnValue
  }

  /**
     * Return locator of a clickable content for specific column in specific row
     *
     * @param row - locator of the main or nested row in the table
     * @param columnName - name of the specific column
     * @param tableHeadersArray - array with the column's names for main or nested table
     * @return Locator - content Locator of the column
     * */
  public async getContentLocatorByColumnName(row: Locator, columnName: string, tableHeadersArray: string[]): Promise<Locator|null> {
    let columnPosition: number = 0
    let columnContentLocator: Locator | null = null

    for (let j = 0; j < tableHeadersArray.length; j++) {
      if (tableHeadersArray[j]==columnName) {
        columnPosition = j+1
        break
      }
    }
    if (columnPosition) {
      const columnLocator = this.locators.columnByPosition(row, columnPosition)
      columnContentLocator = columnLocator.locator(this.locators.cellContent())
    }
    return columnContentLocator
  }
}
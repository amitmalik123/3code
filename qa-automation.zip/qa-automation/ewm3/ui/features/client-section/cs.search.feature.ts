import {SearchFeature} from '../search.feature'
import {TableFeature} from '../table.feature'
import {Locator, Page, expect, test} from '@playwright/test'
import {CSSearchLocators} from '../../elements/client-section/cs.search.el'

export interface SearchDropdownItem {
  title: string|null
  markedTitle: string|null
  accountNumber: string|null
  markedAccountNumber: string|null
}

export interface BackendAccountData {
  title: string
  accountNumber: string|null
}

export class CSSearchFeature extends SearchFeature {
  constructor (
    page: Page, container: Locator, table:TableFeature,
    readonly locators = new CSSearchLocators(page, container),
  ) {
    super(page, container, table)
  }

  public async checkSearchDropdown(searchQuery: string) {
    await test.step(`I perform search using query: "${searchQuery}" and check SearchDropdown contains searchQuery"`, async () => {
      await this.locators.searchInput.fill(searchQuery)
      await this.searchDropdownContainsResult(searchQuery)
    })
  }

  public async searchDropdownContainsResult(filledSearchQuery: string) {
    await test.step(`Assert that search Dropdown contains Search Query`, async () => {
      const searchDropdownData = await this.getSearchDropdownData()
      expect(await this.searchDropdownContainsQueryInEveryString(searchDropdownData, filledSearchQuery),
        `Expecting that search Dropdown contains Search Query: ${filledSearchQuery} in every Result string - in Title or Account number`).toBeTruthy()
    })
  }

  public async getSearchDropdownData():Promise<SearchDropdownItem[]> {
    const searchDropdownItems: SearchDropdownItem[] = []
    const itemsCount = await this.locators.suggestOptions.count()
    for (let i = 0; i < itemsCount; i++) {

      const title: string|null = await this.locators.suggestText(this.locators.suggestOptions.nth(i)).count()>0? await this.locators.suggestText(this.locators.suggestOptions.nth(i)).textContent():null
      const markedTitle: string|null = await this.getMarkedTitle(this.locators.suggestOptions.nth(i))
      const accountNumber: string|null = await this.locators.suggestAccountText(this.locators.suggestOptions.nth(i)).count()>0?await this.locators.suggestAccountText(this.locators.suggestOptions.nth(i)).textContent():null
      const markedAccountNumber: string|null = await this.locators.suggestAccountHighlightedText(this.locators.suggestOptions.nth(i)).count()>0? await this.locators.suggestAccountHighlightedText(this.locators.suggestOptions.nth(i)).textContent():null

      const searchDropdownItem: SearchDropdownItem = {
        title,
        markedTitle,
        accountNumber,
        markedAccountNumber
      }
      searchDropdownItems.push(searchDropdownItem)
    }
    return searchDropdownItems
  }

  /**
     * Service function which return part of the Title matched a Search Query.
     *
     * If there are several matched words they will be joined using ' '
     *
     * @param suggestOption - Locator of the current string in the Search Result popup
     * @return string|null - either Part of the Title that matches the Search query or null if nothing matches
     * */
  public async getMarkedTitle(suggestOption: Locator): Promise<string|null> {
    let unionMarkedTitle: string = ''
    //get the amount of words containing matched part for the Search query
    const itemsCount =await this.locators.suggestHighlightedText(suggestOption).count()
    if (itemsCount===0) return null
    for (let i = 0; i < itemsCount; i++) {
      //get the matched part of the Search query for every found word
      let markTitle = await this.locators.suggestHighlightedText(suggestOption).nth(i).textContent()
      if (markTitle) {
        //if word is not the last then separate words with the ' '
        markTitle = markTitle + ((i<itemsCount-1)?' ':'')
        unionMarkedTitle = unionMarkedTitle + markTitle
      }
    }
    return unionMarkedTitle
  }

  public async searchDropdownContainsQueryInEveryString(searchDropdownData: SearchDropdownItem[], filledSearchQuery:string): Promise<boolean> {
    for (const searchDropdownItem of searchDropdownData) {
      if(searchDropdownItem.markedTitle?.toLowerCase()!==filledSearchQuery.toLowerCase() && 
      searchDropdownItem.markedAccountNumber?.toLowerCase()!==filledSearchQuery.toLowerCase()){
        return false
      }
    }
    return true
  }

  public async checkAccountNumberInSearchResultMatchApi(backendAccountData: BackendAccountData[], searchQuery:string) {
    await test.step(`Expecting that Account title is positioned to the left, Account number to the right`, async () => {
      await this.locators.searchInput.fill(searchQuery)
      const itemsCount = await this.locators.suggestOptions.count()
      for (let i = 0; i < itemsCount; i++) {
        const currentTitleElement = await this.locators.suggestText(this.locators.suggestOptions.nth(i))
        const currentAccountNumberElement = await this.locators.suggestAccountText(this.locators.suggestOptions.nth(i))

        const title: string|null = await currentTitleElement.count()>0? await currentTitleElement.textContent():null
        let apiAccountNumbers: (string | null)[] = []

        const apiAccountNum = backendAccountData.filter(account=> account.title===title).length
        if (apiAccountNum>0) {
          apiAccountNumbers = backendAccountData.filter(account=> account.title===title).flatMap((data) => data.accountNumber ?? [])
        }
        const uiAccountNumber: string|null = await currentAccountNumberElement.count()>0?await currentAccountNumberElement.textContent():null
        if(uiAccountNumber){
          expect(apiAccountNumbers.includes(uiAccountNumber),
            'Assert that Account number in predictive search dropdown match API response').toBeTruthy()
        }
        else{
          expect(apiAccountNumbers.some((value) => value === null) || apiAccountNumbers.length===0,
            'Assert that Account number in predictive search dropdown match API response').toBeTruthy()
        }
      }
    })
  }

  public async checkAccountTitleAndNumberPosition(searchQuery:string) {
    await test.step(`Expecting that Account title is positioned to the left, Account number to the right`, async () => {
      await this.locators.searchInput.fill(searchQuery)
      const itemsCount = await this.locators.suggestOptions.count()
      for (let i = 0; i < itemsCount; i++) {
        const currentTitleElement = await this.locators.suggestText(this.locators.suggestOptions.nth(i))
        const currentAccountNumberElement = await this.locators.suggestAccountText(this.locators.suggestOptions.nth(i))
        const uiAccountNumber: string|null = await currentAccountNumberElement.count()>0?await currentAccountNumberElement.textContent():null

        if(uiAccountNumber){
          const currentTitleCoordinates = await currentTitleElement.boundingBox()
          const currentAccountNumberCoordinates = await currentAccountNumberElement.boundingBox()
          expect(currentTitleCoordinates?.y,'Assert that Title and Account Number are aligned horizontally').toEqual(currentAccountNumberCoordinates?.y)
          expect((currentTitleCoordinates?.x ?? 0) + (currentTitleCoordinates?.width ?? 0) <= (currentAccountNumberCoordinates?.x ?? 0),
            'Assert that Title х coordinate less than  Account Number x coordinate').toBe(true)
        }
      }
    })
  }

  public async ellipsisExistForSearchResult(){
    await test.step(`Check that ellipsis exist for Search Result with long Name`,  async () => {
      const itemsCount = await this.locators.suggestOptions.count()
      for (let i = 0; i < itemsCount; i++) {
        const currentTitleElement = await this.locators.suggestText(this.locators.suggestOptions.nth(i))
        const currentTitleCoordinates = await currentTitleElement.boundingBox()
        expect(await currentTitleElement.getAttribute('class'),'Assert that Title value in search result contains ellipsis mark').toContain('clamp')
        expect((currentTitleCoordinates?.width??0) <= 336,`Assert that Title value in search result does not exceed fixed width: 336. Actual width: ${currentTitleCoordinates?.width}`).toBe(true)
      }
    })
  }

  public async checkAccountNumberIsFullyVisiable(searchQuery:string){
    await test.step(`Check that Account Number is 12 characters long and fully visiable`,  async () => {
      await this.locators.searchInput.fill(searchQuery.substring(0, 2))
      const itemsCount = await this.locators.suggestOptions.count()
      for (let i = 0; i < itemsCount; i++) {
        const currentAccountNumberElement = await this.locators.suggestAccountText(this.locators.suggestOptions.nth(i))
        const uiAccountNumber: string|null = await currentAccountNumberElement.count()>0?await currentAccountNumberElement.textContent():null

        if(uiAccountNumber){
          const currentAccountNumberCoordinates = await currentAccountNumberElement.boundingBox()
          expect((currentAccountNumberCoordinates?.width??0) >= 90,`Assert that Account Number field in search result has fixed width. Current width is ${currentAccountNumberCoordinates?.width}`).toBeTruthy()
          expect(uiAccountNumber.length,'Assert that any Account Number has length 12 symbols').toBe(12)
        }
      }
    })
  }
}
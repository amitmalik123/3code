import {BaseCustomizeMenuFeature, CustomizeMenuItem} from '../base-customize-menu.feature'
import {Locator, Page, expect, test} from '@playwright/test'
import {CSToolbarLocators} from '../../elements/client-section/cs.toolbar.el'

import {CSToolbarMetricMenuLocators} from '../../elements/client-section/cs.toolbar-metrics-menu.el'
import {ToolbarMetricItem} from './cs.toolbar.feature'
export class CSToolbarMetricsMenuFeature extends BaseCustomizeMenuFeature {
  constructor (
    page: Page, container: Locator,
    readonly locators = new CSToolbarMetricMenuLocators(page, container),
    readonly toolbarLocators = new CSToolbarLocators(page, container)
  ) {
    super(page, locators)
  }

  public async compareWithToolbarItems(menuItems: CustomizeMenuItem[], toolbarItems: ToolbarMetricItem[]){
    await test.step(`Compare toolbar metrics menu and toolbar items and order`, async () => {
      const onlySelectedMenuItems = menuItems.filter((item) => item.isChecked && item.itemText!== 'All')
      for (let i = 0; i < onlySelectedMenuItems.length; i++) {
        expect.soft(toolbarItems[i].name,
          `Make sure that selected menu item: "${onlySelectedMenuItems[i].itemText}" is presented in toolbar in the same order`
        ).toEqual(onlySelectedMenuItems[i].itemText)
      }
      for (let i = 0; i < menuItems.length; i++) {
        if(!menuItems[i].isChecked){
          expect.soft(
            toolbarItems.every((toolbarItem) => toolbarItem.name !== menuItems[i].itemText),
            `Make sure that deselected menu item: "${menuItems[i].itemText}" is not presented in toolbar`
          ).toBeTruthy()
        }
      }
    })
  }

  /** Selects or deselects customize menu item or items */
  protected async toggleItems(itemLocator: Locator, select: boolean) {
    await super.toggleItems(itemLocator, select)
    await this.locators.applyButton.click()
  }

  protected async toggleItemsWithoutApplying(itemLocator: Locator, select: boolean) {
    await super.toggleItems(itemLocator, select)
  }

  public async deselectItemsByIndexWithoutApplying(index: number) {
    await test.step(`Deselecting item by index: ${index}`, async () => {
      await this.toggleItemsWithoutApplying(this.locators.menuItems.nth(index), false)
    })
  }

  public async openMenu() {
    await this.toolbarLocators.actionsMenuButton.click()
    await this.toolbarLocators.actionsMenuItems.filter({hasText: 'Toolbar Metrics'}).click()
    await expect(this.locators.menu,
      'Assert that menu is visible').toBeVisible()
  }

  public async openMenuByClickingInToolbar() {
    await this.locators.openMenuButton.click()
    await expect(this.locators.menu,
      'Assert that menu is visible').toBeVisible()
  }
}
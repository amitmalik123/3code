import {Locator, Page, expect} from '@playwright/test'
import {BaseCSFilterLocators} from '../../../elements/client-section/cs.filter.el'
import {test} from '../../../../fixtures/base-ui-fixture'
import {CSFieldConfig, CSTableCell, CSTableRow} from '../cs.table.feature'
import { ClientSectionTableLocators } from '../../../elements/client-section/cs.table.el'

export enum FilterType {
  RANGE = 'Range filter',
  CHECKBOX = 'Checkbox filter (multiple options)'
}

export interface Filter {
  name: string
  type: FilterType
  items: string[]
  rangeFrom: string | number
  rangeTo: string | number
  normalizeValue?: (value: string) => number
}

export abstract class BaseFilterFeature {
  protected constructor(protected page: Page, protected container: Locator) {
  }

  readonly locators: BaseCSFilterLocators = new BaseCSFilterLocators(this.page)
  readonly tableLocators = new ClientSectionTableLocators(this.page, this.container)

  protected async openFilterTooltip() {
    await test.step(`Open filters tooltip`, async () => {
      await this.locators.openButton.click()
      await expect(this.locators.tooltip,
        `Expect all filters tooltip to be visible`
      ).toBeVisible()
    })
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  public async apply(filter: Filter[] | Filter): Promise<void> {
  }

  public async validateFilterTooltip() {
    await test.step(`Validates filter changes`, async () => {
      await expect(this.locators.tooltip, `Expect all filters tooltip to be closed`).not.toBeVisible()
    })
  }

  public async validateEmptyState() {
    await test.step(`Validates empty filter state`, async () => {
      await expect(this.tableLocators.filterEmptystateIcon, `Check the Filter Empty state Icon`).toBeVisible()
      await expect(this.tableLocators.filterEmptystateTitle, `Check the Filter Empty state Title`).toHaveText('No items to display')
      await expect(this.tableLocators.filterEmptystateMessage, `Check the Filter Empty state Message`).toHaveText('Nothing matches your filter parameters. Try changing or removing filtering options.')
    })
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  public async reset(filter?: Filter): Promise<void> {
  }

  public async generateFilterValues(fieldConfig: CSFieldConfig, valuesList: string[],): Promise<Filter> {
    return await test.step(`Generate filter for column: "${fieldConfig.columnName}"`, async () => {
      if (fieldConfig.enable_filtering && fieldConfig.filterType) {
        const transform = fieldConfig.filterDataTransform
        const normalizedFromValue = transform ? transform (valuesList[0]) : valuesList[0]
        const normalizedToValue = transform ? transform(valuesList[1]) : valuesList[1]
        return {
          name: fieldConfig.columnName,
          type: fieldConfig.filterType,
          items: valuesList,
          rangeFrom: normalizedFromValue,
          rangeTo: normalizedToValue,
          normalizeValue: fieldConfig.sortingDataTransform
        }
      } else throw new Error(
        `Can't generate filter for column: "${fieldConfig.columnName}". Check settings
         Is column filterable: ${fieldConfig.enable_filtering}
         Filter type: ${fieldConfig.filterType}`)
    })
  }

  public async assertTableIsFiltered(filter: Filter, table: CSTableRow[]) {
    await test.step(`Assert table is filtered`, async () => {
      if(table.length > 0){
        let applicableToNestedTable = false
        const firstNestedTable = table.find(row => row.nestedTableRow !== undefined && row.nestedTableRow!.length > 0)?.nestedTableRow
        if (firstNestedTable){
          const nestedCell = firstNestedTable[0].cell.find(cell => cell.columnName === filter.name)
          if (nestedCell) applicableToNestedTable = true
        }
        for (let i = 0; i < table.length; i++) {
          if (table[i].nestedTableRow !== undefined && table[i].nestedTableRow!.length > 0 && applicableToNestedTable){
            const nestedTable = table[i].nestedTableRow
            this.assertTableIsFiltered(filter, nestedTable!)
          } else {
            const cell = table[i].cell.find(cell => cell.columnName === filter.name)
            if (cell) {
              await test.step(`Column name: "${cell.columnName}"; Value: "${cell.value}"`, async () => {
                await this.assertTableCellIsFiltered(cell, filter)
              })
            } else throw new Error(`Could not find the column: "${filter.name}" in the table`)
          }
        }
      } else throw new Error(`Could not assert data. Table is empty`)
    })
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  protected async assertTableCellIsFiltered(cell: CSTableCell, filter: Filter) {
  }

}
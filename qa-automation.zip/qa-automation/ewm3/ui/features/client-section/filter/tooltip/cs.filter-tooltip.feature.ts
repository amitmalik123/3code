import {BaseFilterFeature, Filter, FilterType} from '../cs.base-filter.feature'
import {CSFilterLocators} from '../../../../elements/client-section/cs.filter.el'
import {Locator, Page, expect} from '@playwright/test'
import {test} from '../../../../../fixtures/base-ui-fixture'
import {CSTooltipCheckboxFilterFeature} from './cs.filter-tooltip.checkbox.feature'
import {CSTooltipRangeFilterFeature} from './cs.filter-tooltip.range.feature'
import {CSTableRow} from '../../cs.table.feature'

export class CSFilterTooltipFeature extends BaseFilterFeature {
  readonly locators: CSFilterLocators = new CSFilterLocators(this.page)

  constructor(page: Page, protected container: Locator) {
    super(page, container)
  }

  protected filterFactory(type: FilterType) {
    switch (type) {
    case FilterType.RANGE:
      return new CSTooltipRangeFilterFeature(this.page, this.container)
    case FilterType.CHECKBOX:
      return new CSTooltipCheckboxFilterFeature(this.page, this.container)
    default:
      throw new Error('Invalid filter type')
    }
  }

  protected async applyAndCloseFilterTooltip() {
    await test.step(`Apply filters`, async () => {
      await this.locators.applyButton.click()
    })
    await this.validateFilterTooltip()
  }

  public async apply(filter: Filter | Filter[]) {
    await test.step(`Applying filters`, async () => {
      await this.setFilter(filter)
      await this.applyAndCloseFilterTooltip()
    })
  }

  public async setFilter(filter: Filter | Filter[]) {
    await test.step(`Setting filters`, async () => {
      await this.openFilterTooltip()
      const filters = Array.isArray(filter) ? filter : [filter]
      for (const filter of filters) {
        await test.step(`Applying filter: "${filter.name}"`, async () => {
          const openFilterItem = this.locators.openFilterItem.filter({hasText: filter.name})
          await openFilterItem.click()
          await this.filterFactory(filter.type).apply(filter)
        })
      }
    })
  }

  public async reset() {
    await test.step(`Reset filters if some filters applied`, async () => {
      if (await this.locators.filterCountBadge.count() === 1) {
        await test.step(`Some filters are applied. Reset filters`, async () => {
          await this.openFilterTooltip()
          await this.locators.deleteAllButton.click()
          await this.applyAndCloseFilterTooltip()
        })
      } else await test.step(`Filters have already been reset`, () => {
      })
    })
  }

  public async assertTableIsFiltered(filter: Filter | Filter[], table: CSTableRow[]) {
    if (Array.isArray(filter)) {
      for (const singleFilter of filter) {
        await this.filterFactory(singleFilter.type).assertTableIsFiltered(singleFilter, table)
      }
    } else {
      await this.filterFactory(filter.type).assertTableIsFiltered(filter, table)
    }
  }

  public async checkFilterAmountBadge(amount: string | number) {
    await test.step(`Verifies filter counter badge has value ${amount} after applying new filter`, async () => {
      await expect(this.locators.filterCountBadge).toHaveText(amount.toString(), {useInnerText: true})
    })
  }

}
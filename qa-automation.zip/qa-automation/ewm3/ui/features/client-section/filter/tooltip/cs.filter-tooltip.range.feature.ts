import {BaseFilterFeature, Filter} from '../cs.base-filter.feature'
import {
  CSFilterLocators,
  CSRangeFilterLocators
} from '../../../../elements/client-section/cs.filter.el'
import {Locator, Page, expect} from '@playwright/test'
import {test} from '../../../../../fixtures/base-ui-fixture'
import {CSTableCell} from '../../cs.table.feature'

export class CSTooltipRangeFilterFeature extends BaseFilterFeature {
  readonly locators: CSFilterLocators = new CSFilterLocators(this.page)

  constructor(page: Page, protected container: Locator) {
    super(page, container)
  }

  public async apply(filter: Filter) {
    const openFilterItem = this.locators.openFilterItem.filter({hasText: filter.name})
    await this.applyRangeFilter(filter, this.locators.rangeFilter(openFilterItem))
  }

  public async applyRangeFilter(filter: Filter, rangeLocators: CSRangeFilterLocators){
    function condition(value: string | number) {
      // 0 and any other number is valid number for filtering. Return true
      // null = false
      // undefined = false
      // NaN = false
      return value !== null && value !== undefined && !isNaN(+(value))
    }
    await test.step(`Applying range filter values. From: "${filter.rangeTo}"; To: "${filter.rangeTo}"`, async () => {
      if (!condition(filter.rangeFrom) && !condition(filter.rangeTo)) throw new Error(
        `Your filter: "${filter.name}" has no filtering range from and to. Please add filter range settings`)
      else {
        if (condition(filter.rangeFrom)) {
          await test.step(`Set from value: "${filter.rangeFrom}"`, async () => {
            const fromInput = rangeLocators.fromInput
            await fromInput.clear()
            await fromInput.fill(`${filter.rangeFrom}`)
          })
        }

        if (condition(filter.rangeTo)) {
          await test.step(`Set to value: "${filter.rangeTo}"`, async () => {
            const toInput = rangeLocators.toInput
            await toInput.clear()
            await toInput.fill(`${filter.rangeTo}`)
          })
        }
      }
    })
  }

  public async assertTableCellIsFiltered(cell: CSTableCell, filter: Filter) {
    const cellValue = filter.normalizeValue ? filter.normalizeValue(cell.value) : +(cell.value)
    if (filter.rangeFrom) {
      expect.soft(
        cellValue >= +(filter.rangeFrom),
        `Expect that cell value: "${cellValue}" is equal or bigger then filter "from" value: "${filter.rangeFrom}"`
      ).toBeTruthy()
    }
    if (filter.rangeTo) {
      expect.soft(
        cellValue <= +(filter.rangeTo),
        `Expect that cell value: "${cellValue}" is equal or less then filter "to" value: "${filter.rangeTo}"`
      ).toBeTruthy()
    }
  }

}
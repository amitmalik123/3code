import {BaseFilterFeature, Filter} from '../cs.base-filter.feature'
import {CSFilterLocators} from '../../../../elements/client-section/cs.filter.el'
import {Locator, Page, expect} from '@playwright/test'
import {test} from '../../../../../fixtures/base-ui-fixture'
import {CSTableCell} from '../../cs.table.feature'

export class CSTooltipCheckboxFilterFeature extends BaseFilterFeature {
  readonly locators: CSFilterLocators = new CSFilterLocators(this.page)

  constructor(page: Page, protected container: Locator) {
    super(page, container)
  }

  public async apply(filter: Filter) {
    await test.step(`Applying filter: "${filter.name}"`, async () => {
      await this.setFilter(filter)
      await this.locators.checkboxFilter.applyButton.click()
    })
  }

  public async setFilter(filter: Filter) {
    if (filter.items) {
      for (const filterItemText of filter.items) {
        await test.step(`Item: "${filterItemText}"`, async () => {
          const filterItem = this.locators.checkboxFilter.item.filter({hasText: filterItemText})
          await expect(filterItem,
            `Expect filter item: "${filterItemText}" to be presented in "${filter.name}" filter`
          ).toBeVisible()
          if (!await this.locators.checkboxFilter.itemCheckbox(filterItem).isChecked()) {
            await test.step(`Check filter item: "${filterItemText}"`, async () => {
              await filterItem.click()
            })
          } else await test.step(`Item: "${filterItemText}" has already been checked`, () => {
          })
        })
      }
    } else throw new Error(
      `Your filter: "${filter.name}" has no items. Please add items that you want to use for filtering`)
  }

  public async assertTableCellIsFiltered(cell: CSTableCell, filter: Filter) {
    expect.soft(filter.items.includes(cell.value),
      `Expect that cell value: "${cell.value}" contains in filter items array: ${filter.items}`
    ).toBeTruthy()
  }

}
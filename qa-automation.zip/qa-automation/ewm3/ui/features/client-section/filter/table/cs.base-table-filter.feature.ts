import {BaseFilterFeature, Filter} from '../cs.base-filter.feature'
import {CSTableFilterLocators} from '../../../../elements/client-section/cs.filter.el'
import {Locator, Page} from '@playwright/test'
import {test} from '../../../../../fixtures/base-ui-fixture'

export class CSBaseTableFilterFeature extends BaseFilterFeature {
  readonly locators = new CSTableFilterLocators(this.page, this.columnHeader)

  constructor(protected page: Page, protected columnHeader: Locator, protected container: Locator) {
    super(page, container)
  }

  protected async openFilterTooltip() {
    await this.locators.columnHeader.hover()
    await super.openFilterTooltip()
  }

  public async apply(filter: Filter) {
    await this.setFilter(filter)
    await test.step(`Validates filter changes`, async () => {
      await this.locators.applyButton.click()
      await this.validateFilterTooltip()
    })
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  public async setFilter(filter: Filter) {
    throw new Error('Method setFilter is not implemented')
  }

  public async reset(filter: Filter) {
    await test.step(`Reset filter: "${filter.name}"`, async () => {
      if (await this.locators.openButton.isVisible()) {
        await this.openFilterTooltip()
        await this.locators.clearButton.click()
        await this.locators.applyButton.click()
      } else await test.step(`Filter has already been reset`, () => {
      })
    })
  }

}
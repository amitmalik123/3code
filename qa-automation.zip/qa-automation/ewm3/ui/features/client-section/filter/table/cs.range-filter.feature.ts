import {Filter} from '../cs.base-filter.feature'
import {test} from '../../../../../fixtures/base-ui-fixture'
import {CSTableCell} from '../../cs.table.feature'
import {CSBaseTableFilterFeature} from './cs.base-table-filter.feature'
import {CSTooltipRangeFilterFeature} from '../tooltip/cs.filter-tooltip.range.feature'

export class CSTableRangeFilterFeature extends CSBaseTableFilterFeature {

  public async setFilter(filter: Filter) {
    await test.step(`Setting filter filter: "${filter.name}"`, async () => {
      await this.openFilterTooltip()
      await new CSTooltipRangeFilterFeature(this.page, this.container).applyRangeFilter(filter, this.locators.rangeFilter)
    })
  }

  protected async assertTableCellIsFiltered(cell: CSTableCell, filter: Filter) {
    return new CSTooltipRangeFilterFeature(this.page, this.container).assertTableCellIsFiltered(cell, filter)
  }

}
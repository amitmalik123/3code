import {Filter} from '../cs.base-filter.feature'
import {test} from '../../../../../fixtures/base-ui-fixture'
import {CSTableCell} from '../../cs.table.feature'
import {CSBaseTableFilterFeature} from './cs.base-table-filter.feature'
import {CSTooltipCheckboxFilterFeature} from '../tooltip/cs.filter-tooltip.checkbox.feature'

export class CSTableCheckboxFilterFeature extends CSBaseTableFilterFeature {

  public async setFilter(filter: Filter) {
    await test.step(`Applying filter: "${filter.name}`, async () => {
      await this.openFilterTooltip()
      await new CSTooltipCheckboxFilterFeature(this.page, this.container).setFilter(filter)
    })
  }

  protected async assertTableCellIsFiltered(cell: CSTableCell, filter: Filter) {
    return new CSTooltipCheckboxFilterFeature(this.page, this.container).assertTableCellIsFiltered(cell, filter)
  }

}
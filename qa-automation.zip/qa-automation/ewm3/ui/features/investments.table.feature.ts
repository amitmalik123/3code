import { Locator, test, } from '@playwright/test'
import { TableFeature, TableRow } from './table.feature'
import { TableLocators } from '../elements/table.el'

class InvestmentTableElement extends TableLocators {

  /**
     * @param row - row in the main table that contains expand button
     * @return Locator - expand nested table button for the specified row
     */
  public expandNestedTableButton(row: Locator): Locator {
    const expandSelector = 'div[class*="flex items-center"] svg'
    return row.locator(expandSelector)
  }
}

export class InvestmentsTableFeature extends TableFeature {

  readonly locators: InvestmentTableElement = new InvestmentTableElement(this.page, this.container)

  /**
 * Extracts and sorts the "Total Accounts" values from a given table data
 *
 * This method performs the following steps:
 * 1. Iterates over each row in the provided table data
 * 2. Finds the cell in each row where the column name is "Total Accounts"
 * 3. Converts the cell value to an integer. If the cell does not exist, it defaults to 0
 * 4. Sorts the extracted values in descending order (from largest to smallest)
 * 5. Returns an array of arrays where each sub-array contains the "Total Accounts" value and its index in the original table
 *
 * @param {TableRow[]} tableData - The table data containing multiple rows
 * @returns {Promise<[number, number][]>} A promise that resolves to an array of arrays with "Total Accounts" values and their original indexes
 */
  public async totalAccountsValues(tableData: TableRow[]): Promise<[number, number][]> {
  // Extract "Total Accounts" values with their indexes
    const totalAccountsValuesWithIndex: [number, number][] = tableData.map((row, index) => {
      const totalAccountsCell = row.cell.find(cell => cell.columnName === 'Total Accounts')
      return [totalAccountsCell ? parseInt(totalAccountsCell.value, 10) : 0, index]
    })

    // Sort the values from largest to smallest
    totalAccountsValuesWithIndex.sort((a, b) => b[0] - a[0])

    return totalAccountsValuesWithIndex
  }

} 
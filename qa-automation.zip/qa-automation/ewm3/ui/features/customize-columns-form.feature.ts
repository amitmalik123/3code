import { Locator, Page, expect, test } from '@playwright/test'
import { TableFeature, TableRow } from './table.feature'
import { CustomizeColumnsFormLocators } from '../elements/customizeColumnsForm.el'
import { BaseCustomizeMenuFeature, CustomizeMenuItem } from './base-customize-menu.feature'

/**
 * Generic table customize columns form feature class.
 * This class provides following customize columns form features:
 * - to select/deselect/restore customize columns form options
 * - parse customize columns form data from UI table to CustomizeColumnOption array
 * - validate Customize columns form->table columns appearance, names(titles/text), order
 * */
export class CustomizeColumnsFormFeature extends BaseCustomizeMenuFeature {

  constructor (
    protected page: Page, container: Locator,
    protected table:TableFeature,
    readonly locators = new CustomizeColumnsFormLocators(page, container)
  ) {
    super(page, locators)
  }

  protected async toggleItems(itemLocator: Locator, select: boolean) {
    await super.toggleItems(itemLocator, select)
    await this.locators.openMenuButton.click({force: true})
  }

  /** Selects customize columns form "All" option. Does not deselect with second usage */
  public async selectAllColumns() {
    await test.step(`Selecting "All" option`, async () => {
      await this.selectItemsByLocator(this.locators.allItem)
    })
  }

  /** Unselects customize columns form "All" option.*/
  public async unSelectAllColumns() {
    await test.step(`Unselecting "All" option`, async () => {
      await this.unSelectItemsByLocator(this.locators.allItem)
    })
  }

  /** Resets customize columns form to default state */
  public async resetToDefault() {
    await test.step(`Reset customize columns form settings to default`, async () => {
      await this.locators.openMenuButton.click()
      await expect(this.locators.restoreToDefaultButton).toBeVisible()
      await this.locators.restoreToDefaultButton.click()
    })
  }

  public async data() {
    return await test.step(`Customize columns form data parsing`, async () => {
      return super.data()
    })
  }

  /**
     * Compares data between customize columns form and table
     *
     * **USAGE**
     *
     * Manual data parsing
     * ```js
     *     // define new instance of table feature class
     *     const table = new Table(page, someTileClass)
     *     // define new instance of customize columns feature class
     *     const customizeColumnsForm = new CustomizeColumnsFormFeature(page, someTileClass, table)
     *     // parse customize columns form data
     *     const customizeColumnsFormData = await customizeColumnsForm.data()
     *     // parse table data
     *     const tableData = await table.data()
     *     // compare data
     *     customizeColumnsForm.compareCustomizeColumnsAndTable(customizeColumnsFormData, tableData)
     * ```
     *
     * Auto data parsing
     * ```js
     *     // define new instance of table feature class
     *     const table = new Table(page, someTileClass)
     *     // define new instance of customize columns feature class
     *     const customizeColumnsForm = new CustomizeColumnsFormFeature(page, someTileClass, table)
     *     // compare data
     *     customizeColumnsForm.compareCustomizeColumnsAndTable()
     * ```
     *
     * @param data - Optional. Parsed customize columns data or/and Parsed table data. In case when param is not passed
     * it will be parsed from current customize column form/table state
     * it will be parsed from current customize column form state
     * @see data
     * @see TableFeature.data
     * */

  public async compareCustomizeColumnsAndTable(data?:{customizeColumnOptions?: CustomizeMenuItem[], tableRowArray?: TableRow[]}) {
    await test.step(`Compare table and customize columns form data`, async () => {
      let formData = data?.customizeColumnOptions ? data.customizeColumnOptions : await this.data()
      const tableData = data?.tableRowArray? data.tableRowArray : await this.table.data()
      const notFixedColumns: string[] = []
      const fixedColumns: string[] = []

      for (const cell of tableData[0].cell) {
        if (!cell.isFixed) notFixedColumns.push(cell.columnName)
        else fixedColumns.push(cell.columnName)
      }

      formData = formData.filter(x => !x.itemText.toLowerCase().includes('all')) // Filter out the 'all' filter option.
      const formDataChecked = formData.filter(x => x.isChecked)
      const formDataUnchecked = formData.filter(x => !x.isChecked) 

      for (let i = 0; i < formDataChecked.length; i++) {
        expect.soft(notFixedColumns[i],
          `I expect that CHECKED customize columns form option:
                #${i} "${formDataChecked[i].itemText}" is visible in the table and has the same order`
        ).toEqual(formDataChecked[i].itemText)
      }

      for (let i = 0; i < formDataUnchecked.length; i++) {
        // Make sure that unchecked option is not visible in table
        expect.soft(notFixedColumns.includes(formDataUnchecked[i].itemText),
          `I expect that UNCHECKED customize columns form option #${i} "${formDataUnchecked[i].itemText}" is not visible in the table`
        ).toBeFalsy()
      }
      
      // Make sure that customize columns form does not contain fixed columns
      for (const fixedColumn of fixedColumns) {
        expect.soft(formData.every(o => o.itemText === fixedColumn),
          `I expect that fixed column: "${fixedColumn}" is not presented in customize columns form`
        ).toBeFalsy()

      }
    })
  }
}
import test, { Locator, Page, expect } from '@playwright/test'

export class ScrollFeature {
  constructor ( protected page: Page) {
  }

  /**
 * Scrolls the specified element in the given direction and checks if the scroll occurred based on the expectation.
 * @param elementLocator - The locator of the element to scroll.
 * @param direction - The direction to scroll ('up', 'down', 'left', 'right').
 * @param shouldScroll - Boolean indicating if the scroll should occur (default is true). 
 * When true, the method expects the scroll position to change. When false, it expects the scroll position to remain unchanged.
 * @param elementLocatorsToCheck - Optional array of locators for elements that should not scroll.
 */
  public async scrollElement(
    elementLocator: Locator, 
    direction: 'up' | 'down' | 'left' | 'right', 
    shouldScroll: boolean = true, 
    elementLocatorsToCheck?: Locator[]
  ) {
    await test.step(`Scrolling ${direction} within the specified element`, async () => {
      const scrollDistance = 1000
      const scrollOptions: Record<string, [number, number]> = {
        up: [0, -scrollDistance],
        down: [0, scrollDistance],
        left: [-scrollDistance, 0],
        right: [scrollDistance, 0]
      }

      const [scrollX, scrollY] = scrollOptions[direction]

      await test.step('Get initial scroll positions', async () => {
        const initialScrollPosition = await elementLocator.evaluate((element) => {
          return { scrollTop: element.scrollTop, scrollLeft: element.scrollLeft }
        })

        await test.step('Get initial positions of elements to check', async () => {
          const initialPositionsToCheck = elementLocatorsToCheck ? 
            await Promise.all(elementLocatorsToCheck.map(async (locator) => {
              return locator.evaluate((element) => {
                return { scrollTop: element.scrollTop, scrollLeft: element.scrollLeft }
              })
            })) : []

          await test.step('Perform scroll operation', async () => {
            await elementLocator.evaluate((element, { scrollX, scrollY }) => {
              element.scrollBy(scrollX, scrollY)
            }, { scrollX, scrollY })

            await test.step('Get final scroll positions', async () => {
              const finalScrollPosition = await elementLocator.evaluate((element) => {
                return { scrollTop: element.scrollTop, scrollLeft: element.scrollLeft }
              })

              await test.step('Get final positions of elements to check', async () => {
                const finalPositionsToCheck = elementLocatorsToCheck ? 
                  await Promise.all(elementLocatorsToCheck.map(async (locator) => {
                    return locator.evaluate((element) => {
                      return { scrollTop: element.scrollTop, scrollLeft: element.scrollLeft }
                    })
                  })) : []

                await test.step('Check if the scroll positions have changed', async () => {
                  if (shouldScroll) {
                    if (direction === 'up' || direction === 'down') {
                      expect(finalScrollPosition.scrollTop !== initialScrollPosition.scrollTop, 
                        `Check that vertical scroll position changed when scrolling ${direction}`).toBeTruthy()
                    } else {
                      expect(finalScrollPosition.scrollLeft !== initialScrollPosition.scrollLeft, 
                        `Check that horizontal scroll position changed when scrolling ${direction}`).toBeTruthy()
                    }
                  } else {
                    if (direction === 'up' || direction === 'down') {
                      expect(finalScrollPosition.scrollTop === initialScrollPosition.scrollTop, 
                        `Check that vertical scroll position remained unchanged when scrolling ${direction}`).toBeTruthy()
                    } else {
                      expect(finalScrollPosition.scrollLeft === initialScrollPosition.scrollLeft, 
                        `Check that horizontal scroll position remained unchanged when scrolling ${direction}`).toBeTruthy()
                    }
                  }

                  await test.step('Check that elements did not scroll', async () => {
                    for (let i = 0; i < initialPositionsToCheck.length; i++) {
                      const initialPos = initialPositionsToCheck[i]
                      const finalPos = finalPositionsToCheck[i]

                      expect(initialPos.scrollTop === finalPos.scrollTop, 
                        `Expected vertical scroll position of element ${i} to remain unchanged`).toBeTruthy()
                      expect(initialPos.scrollLeft === finalPos.scrollLeft, 
                        `Expected horizontal scroll position of element ${i} to remain unchanged`).toBeTruthy()
                    }
                  })
                })
              })
            })
          })
        })
      })
    })
  }

  /**
 * Checks the presence or absence of a scrollbar on the specified element.
 * @param elementLocator - The locator of the element to check.
 * @param direction - The direction to check for the scrollbar ('vertical' or 'horizontal').
 * @param shouldHaveScrollbar - Boolean indicating if the scrollbar should be present (true) or absent (false).
 */
  public async checkScrollbar(elementLocator: Locator, direction: 'vertical' | 'horizontal', shouldHaveScrollbar: boolean = true) {
    await test.step(`Checking that there is ${shouldHaveScrollbar ? '' : 'no '} ${direction} scrollbar on the specified element`, async () => {
      const hasScrollbar = await elementLocator.evaluate((element, direction) => {
        const style = getComputedStyle(element)
        const overflow = style.overflow
        const overflowY = style.overflowY
        const overflowX = style.overflowX

        if (direction === 'vertical') {
          return element.scrollHeight > element.clientHeight ||
               (overflow === 'scroll' || overflowY === 'scroll')
        } else if (direction === 'horizontal') {
          return element.scrollWidth > element.clientWidth ||
               (overflow === 'scroll' || overflowX === 'scroll')
        }
      }, direction)

      if (shouldHaveScrollbar) {
        expect(hasScrollbar, `Verify that ${direction} scrollbar to be present on the element`).toBeTruthy()
      } else {
        expect(!hasScrollbar, `Verify that ${direction} scrollbar to be absent on the element`).toBeTruthy()
      }
    })
  }

}
import { Locator, Page, expect, test } from '@playwright/test'
import { TableLocators } from '../elements/table.el'
import { SortingFeature, SortingOrder } from './sorting.feature'
import { GeneralUtils } from '../../../utils/generalUtils'
import { EWM3Config } from '../../service-data/config'

/**
 * Interface for parsing and storing data from UI table cells
 * @see TableRow
 * @see TableCell
 * @see TableFeature.data
 */
export interface TableCell{
    /**
     * Column name
     * Example: 'Client Name'
     */
    columnName:string

    /**
     * Column value
     * Example: 'Brooklyn Harvey'
     */
    value:string
    isFixed:boolean
    isSortable:boolean
}

/**
 * Interface for parsing and storing data from whole row of UI main or nested table
 * @see TableCell
 * @see TableFeature.data
 */
export interface TableRow {
    cell: TableCell[]
    nestedTableRow?: TableRow[]
}

/**
 * Interface for setting API-UI data parsing config
 * @see FieldConfig
 * @see TableFeature.assertDataMapping
 */
export interface TableDataConfig {
    /**
     * Array of distinct UI main table fields. It is made for match API and UI objects before mapping assert
     *
     * Example: ['Client Name', '...']
     */
    uiApiMatchFields: string[];
    /**
     * Array of field configurations
     * @see FieldConfig
     */
    fields: FieldConfig[];
    defaultSortingField: FieldConfig;
    defaultSortingOrder: SortingOrder;
    /**
     * Optional. Only in case if table has nested tables.
     * API path to table nested items object name.
     *
     * Example: 'accounts' or 'items'
     *
     * **Important:**
     *
     * Do not pass api fields in following format: 'data[*].accounts' or 'data[0].accounts' or 'data[*].accounts[*]';
     *
     * All existing API endpoints give us table items in 'data' array,
     * that's why this field is added to our assert functions
     */
    apiPathToItems?: string;
    nestedTableDataConfig?: TableDataConfig
}

/**
 * Object that has rules of API->UI fields mapping
 * @see TableDataConfig
 * @see TableFeature.assertDataMapping
 */
export interface FieldConfig {
    /** UI column name.
     *
     * Example: 'Client Name'
     */
    columnName: string;
    /**
     * API field name.
     *
     * Example: 'clientName'
     *
     * **Important:**
     *
     * Do not pass api fields in following format: 'data[*].client' or 'data[0].client'
     *
     * All existing API endpoints give us table items in 'data' array,
     * that's why this field is added to our assert functions
     */
    apiField: string;

    /**
     * Optional. API value transforming rules to match UI format. For example GeneralUtils.normalizeCurrencyValue
     *
     * **USAGE:**
     *
     * Use some of GeneralUtils tools for modifying/normalizing/formatting:
     * ```js
     * ...
     * transform: GeneralUtils.normalizeCurrencyValue,
     * ...
     * ```
     *
     * Use custom transforming rules:
     * ```js
     * ...
     * transform: transform: (value) => `123 ${value} ABC`,
     * ...
     * ```
     *
     * @see GeneralUtils.normalizeCurrencyValue
     * @see GeneralUtils.normalizePercentValue
     * @see GeneralUtils.convertDate
     */
    apiDataTransform?: (value: any) => any;
    /** CMS column capabilities*/
    frozen?: boolean;
    hidden?: boolean;
    enable_hiding?: boolean;
    enable_sorting?: boolean;
    platforms?: string[]
    /** It is like apiDataTransform but for sorting UI data */
    sortingDataTransform?: (value: any) => any;
}
/**
 * Represents data for a BIC accounts API file 
 * 
 * @interface BicAccountData
 */
export interface BicAccountData {
  data: {
    id: string;
    name: string;
    status: string;
    registrationType: string[];
    isBICIneligible: boolean;
    inEligibilityReason: string;
    tmsEligible: boolean;
    marketValue: number;
    productId: string;
    allocation: number;
    sleeves: {
      sleeveProductId: string;
      productName: string;
      allocation: number;
    }[];
    accountNumber: string[];
    requiresSuitabilityCheck: boolean;
  }[];
  error: {
    message: string;
    code: number;
  };
}

/**
 * Generic table feature class.
 * This class provides following table features:
 * - to work with table elements
 * - parse table data from UI table to TableRow array
 * - validate API->UI fields mapping
 * */
export class TableFeature {

  readonly locators = new TableLocators(this.page, this.container)
  readonly sorting = new SortingFeature(this.page, this.container)
  constructor(protected page: Page, protected container: Locator) {
  }

  /**
     * Expands nested tables
     *
     * **IMPORTANT:**
     * As of now, this func does not validate if nested table already expanded,
     * so it also can collapse nested tables
     *
     * @param expandRowsCount - how many rows should be expanded
     *
     */
  public async expandNestedTable(expandRowsCount:number = 5) {
    await this.expandSpecificRowNestedTable(this.locators.rowsMainOnly, expandRowsCount)
  }

  public async expandSpecificRowNestedTable(row: Locator, expandRowsCount:number = 5) {
    await test.step(`Opening nested columns`, async () => {
      const rowCount = await row.count()
      if (rowCount === 1) {
        if (await this.locators.expandNestedTableButton(row).count() === 1 && await this.locators.expandNestedTableButton(row).isVisible()) {
          await this.locators.expandNestedTableButton(row).click()
        }
      } else if (rowCount > 1) {
        for (let i = 0; i < rowCount; i++) {
          if (expandRowsCount!==0) {
            if (await this.locators.expandNestedTableButton(row.nth(i)).count() === 1 && await this.locators.expandNestedTableButton(row.nth(i)).isVisible()) {
              await this.locators.expandNestedTableButton(row.nth(i)).click()
              expandRowsCount --
            }
          } else {
            break
          }
        }
      }
    })
  }

  /**
     * **Usage**
     *
     * Get data from main table
     * ```js
     * const table = new Table(page, tile);
     * const tableData = await table.data();
     * console.log(tableData[0].cell[1].value) // get value from 1 row, and 2 column
     * console.log(tableData[0].cell[1].columnName) // get 2 column name
     * ```
     * Get data from nested table. Use only in case, if nested table exists, and it is expanded(visible/opened)
     * ```js
     * const table = new Table(page, tile);
     * const tableData = await table.data();
     * console.log(tableData[1].nestedTableRow[2].cell[1].value) // get value from main table row 2 that has nested table row 3, column 2
     * console.log(tableData[2].nestedTableRow[2].cell[1].columnName) // get 2 nested column name
     * ```
     * @return TableRow[] - array of table rows with parsed data from UI table
     * */
  public async data(): Promise<TableRow[]> {
    return await test.step(`Table data parsing`, async () => {

      const headersArray: string [] = await this.locators.tableHeaders.allInnerTexts()
      const isFixedArray: boolean[] = []
      const isSortableArray: boolean[] = []
      const headersCount = await this.locators.tableHeaders.count()

      let nestedHeadersArray: string [] = []
      const nestedIsFixedArray: boolean[] = []
      const nestedIsSortableArray: boolean[] = []
      let nestedHeadersCount = 0

      //parse main tables sorting/dragging capabilities

      for (let i = 0; i < headersCount; i++) {
        isFixedArray.push(await this.locators.isColumnHeaderFixed(this.locators.tableHeaders.nth(i)))
        isSortableArray.push(await (this.locators.sortingButton(this.locators.tableHeaders.nth(i))).count()>0)
      }
      const tableData: TableRow[] = []
      const rowsCount = await this.locators.rowsAll.count()
      for (let i = 0; i < rowsCount; i++) {
        // if row is regular (does not contain nested table), then adding data to main table
        if (await this.locators.nestedTable(this.locators.rowsAll.nth(i)).count() === 0) {
          const valuesArray: string[] = await this.locators.columns(this.locators.rowsAll.nth(i)).allInnerTexts()
          const cellArray: TableCell[] = []
          // pushing each cell's in a row data
          for (let j = 0; j < headersArray.length; j++) {
            cellArray.push(
              {
                columnName: headersArray[j],
                value: valuesArray[j],
                isFixed: isFixedArray[j],
                isSortable: isSortableArray[j]
              }
            )
          }
          // pushing cells array and empty nested table rows array to the main TableRow array
          tableData.push(
            {
              cell: cellArray,
              nestedTableRow: []
            }
          )
        } else {
          // in case if row is nested table row, then adding data to nested table of previous row
          const nestedTable = this.locators.nestedTable(this.locators.rowsAll.nth(i))
          const nestedRows = this.locators.nestedTableRows(nestedTable)
          if (nestedIsFixedArray.length === 0 || nestedIsSortableArray.length === 0){
            nestedHeadersArray = await this.locators.nestedTableHeaders(nestedTable).allInnerTexts()
            nestedHeadersCount = await this.locators.nestedTableHeaders(nestedTable).count()
            //parse nested tables sorting/dragging capabilities
            for (let i = 0; i < nestedHeadersCount; i++) {
              nestedIsFixedArray.push(await this.locators.isColumnHeaderFixed(this.locators.nestedTableHeaders(nestedTable).nth(i)))
              nestedIsSortableArray.push(await (this.locators.sortingButton(this.locators.nestedTableHeaders(nestedTable).nth(i))).count()>0)
            }
          }
          // Going through each row in nested table
          const nestedRowsCount = await nestedRows.count()
          for (let k = 0; k < nestedRowsCount; k++) {
            const nestedValuesArray: string[] = await this.locators.columns(nestedRows.nth(k)).allInnerTexts()
            const nestedCellArray: TableCell[] = []
            // pushing each nested cell's in a row data
            for (let l = 0; l < nestedHeadersArray.length; l++) {
              nestedCellArray.push(
                {
                  columnName: nestedHeadersArray[l],
                  value: nestedValuesArray[l],
                  isFixed: nestedIsFixedArray[l],
                  isSortable: nestedIsSortableArray[l]
                }
              )
            }
            // pushing nested table's row to the previous main table row
            tableData[tableData.length - 1]?.nestedTableRow?.push(
              {
                cell: nestedCellArray,
              }
            )
          }
        }
      }
      return tableData
    })
  }

  public getRandomValueByColumnName(tableRows: TableRow[], columnName: string): string {
    // Create an array to store all matching values for the specified column name
    const matchingValues: string[] = []

    // Iterate through the table rows
    for (const row of tableRows) {
      for (const cell of row.cell) {
        if (cell.columnName === columnName && cell.value.trim() !== '') {
          matchingValues.push(cell.value)
        }
      }

      // If there are nested table rows, recursively search them
      if (row.nestedTableRow && row.nestedTableRow.length > 0) {
        try {
          const nestedValue = this.getRandomValueByColumnName(row.nestedTableRow, columnName)
          matchingValues.push(nestedValue)
        } catch (e) { /* empty */ }
      }
    }

    // Return a random value from the matching values, or undefined if none were found
    if (matchingValues.length > 0) {
      const randomIndex = Math.floor(Math.random() * matchingValues.length)
      return matchingValues[randomIndex]
    } else throw new Error(`Could not generate random value for column ${columnName}`)
  }

  /**
     * Asserts data mapping API->UI
     *
     * **USAGE**
     *
     * ```
     *     // set "waitForResponse"
     *     const responsePromise = page.waitForResponse('your_api_response_url');
     *     await page.goto('your_webpage_url')
     *     // catch response body
     *     const responseBody = await (await responsePromise).json()
     *     // define new instance of table class
     *     const table = new Table(page, someTileClass)
     *     // make sure, that table data is visible
     *     await expect(table.table).toBeVisible();
     *     // you can also expand nested tables (if they are presented). Then nested tables data will be also validated
     *     await table.expandNestedTable();
     *     // parse table data
     *     const tableData = await table.data()
     *     // assert data mapping
     *     table.assertDataMapping(responseBody, tableData, mappingConfig);
     * ```
     *
     * @param apiResponseBody - API response body that contains corresponding widget's data
     * @param tableRowArray - parsed table data from UI table to TableRow[]
     * @see data
     * @param mappingConfig - specific mapping config
     * @see TableDataConfig
     */
  public async assertDataMapping(apiResponseBody: any, tableRowArray: TableRow[], mappingConfig: TableDataConfig) {
    await test.step(`Making mapping API->UI assert`,  async () => {
      // Define array for matching errors
      const missMatchingArray: string[] = await this.compareAPIAndTableRows(apiResponseBody, tableRowArray, mappingConfig)
      const isMappingCorrect = missMatchingArray.length === 0
      const assertionMessage = isMappingCorrect
        ? 'Mapping assert passed'
        : `Mapping assert failed: ${missMatchingArray.join('\n')}`
      // expect that mapping is correct. Throws an error in case of any miss matches
      expect(isMappingCorrect, assertionMessage).toBeTruthy()
    })
  }

  protected async compareAPIAndTableRows(apiResponseBody: any, tableRowArray: TableRow[], mappingConfig: TableDataConfig, isNested:boolean = false, mainRowNumber?:number){
    const missMatchingArray: string[] = []
    /*
         * Loop. Using UI table length.
         * In case when tableRowArray won't contain all API items - test will pass.
         * It was made because of front end pagination
         */
    for (let i = 0; i < tableRowArray.length; i++) {
      const dataUI = tableRowArray[i]
      // Define API item/object. It is made because of front end data sorting
      //if (mappingConfig.)
      //const apiData = apiResponseBodyItems.find((data: any) => {
      let apiItems:any[] = []
      if (mappingConfig.apiPathToItems){
        const path = mappingConfig.apiPathToItems.split('.')
        if (path.length === 1) apiItems = apiResponseBody[mappingConfig.apiPathToItems]
        else if (path.length === 2) apiItems = apiResponseBody[path[0]][path[1]]
      } else apiItems = apiResponseBody['data']
      const apiData = apiItems.find((data: any) => {
        // matching all necessary distinct fields from mappingConfig
        return mappingConfig.uiApiMatchFields.every((matchField) => {
          // define specific FieldConfig from array, that matches mappingConfig rules
          const fieldConfig = mappingConfig.fields.find((mapping) => mapping.columnName === matchField)
          const apiField = fieldConfig?.apiField
          const apiValue = fieldConfig? this.normalizeApiValue(data, fieldConfig): data
          // get matching value from UI
          const uiValue = dataUI.cell.find((c) => c.columnName === matchField)?.value
          // compare UI and API distinct fields
          return apiField? uiValue === apiValue : false
        })
      })
      // if apiData define is successful then perform API->UI mapping assert (using all fields from mappingConfig)
      if (apiData) {
        if (isNested) await this.checkFieldMappings(dataUI, apiData, mappingConfig.fields, mainRowNumber, missMatchingArray, isNested, i)
        else await this.checkFieldMappings(dataUI, apiData, mappingConfig.fields, i, missMatchingArray)
      } else {
        if (isNested) missMatchingArray.push(`Main table row #${mainRowNumber}, Nested table row #${i}. Matching nested API data not found.`)
        else missMatchingArray.push(`Main table row #${i}. Matching API data not found.`)
        continue
      }

      /*
             * Nested table is not necessary. It can be collapsed and not parsed into tableRowArray
             * So starting to assert nested tables mapping only in case when UI nested tables data is presented
             */
      if (dataUI.nestedTableRow && dataUI.nestedTableRow.length > 0) {
        if(mappingConfig?.nestedTableDataConfig?.apiPathToItems && mappingConfig.nestedTableDataConfig.fields && apiData[mappingConfig.nestedTableDataConfig.apiPathToItems]){
          missMatchingArray.push(...await this.compareAPIAndTableRows(apiData, dataUI.nestedTableRow, mappingConfig.nestedTableDataConfig, true, i))
          // Make sure that API and UI item arrays length is the same
          if (apiData[mappingConfig.nestedTableDataConfig.apiPathToItems].length !== dataUI.nestedTableRow.length) {
            missMatchingArray.push(`Main table row #${i}. Nested table count mismatch.
                            Expected API nested items count: ${apiData[mappingConfig.nestedTableDataConfig.apiPathToItems].length}
                            Actual UI nested items count: ${dataUI.nestedTableRow.length}
                        `)
          }
        } else missMatchingArray.push(`Main table row #${i}.
                Nested table is presented but there is no nested table config or config is invalid. Please check mapping config.`)
      }
    }
    return missMatchingArray
  }

  /**
     * Check filed mapping rules. Reusable function for assertDataMapping()
     *
     * @param tableRow - one TableRow or TableRowNested object that has parsed data from UI table
     * @param apiObject - part of API response body that contains array of items. Like data[*] or data[*].items[*]
     * @param fields - FieldConfig[] object, that has rules of API->UI fields mapping
     * @param mainIndex - index of main table row
     * @param missMatchingArray - string array, that stores all miss matches that occur
     * @param isNested - optional. Used to define is current check for nested or main table
     * @param nestedIndex - optional. Index of nested table row
     * @see FieldConfig
     * @see TableDataConfig
     * @see assertDataMapping
     * @protected
     */
  protected async checkFieldMappings(tableRow: TableRow, apiObject: any, fields: FieldConfig[], mainIndex: number, missMatchingArray: string[], isNested?: boolean, nestedIndex?: number) {
    fields.forEach((config) => {
      if (config.hidden==true && config.enable_hiding==false){
        return
      }

      if (config.platforms != null && !config.platforms.includes(EWM3Config.PLATFORM)) {
        return
      }

      const uiField = config.columnName
      // define UI cell value, using column name
      const uiValue = tableRow.cell.find((cell) => cell.columnName === uiField)?.value
      // apply transforming/formatting rules in case if they are presented
      const apiValue = this.normalizeApiValue(apiObject, config)
      const informationText = `Main table row #${mainIndex}${isNested ? `, Nested table row #${nestedIndex}` : ''}. Mapping of "${uiField}"`

      test.step(`${informationText}. Compare ${config.apiDataTransform? 
        `API value raw: "'${apiObject[config.apiField]}"; API value normalized: "${apiValue}"`: 
        `API value: "${apiValue}"`} ; UI value: "${uiValue}"`,  async () => {
        // When values are equal, then nothing happens. If API and UI data is not equal error message will be added
        if (uiValue !== apiValue) {
          missMatchingArray.push(`${informationText} is incorrect.
                Expected API: ${apiValue}
                Actual UI: ${uiValue}
                `)
        }
      })
    })
  }

  private normalizeApiValue(apiObject:any, fieldConfig:FieldConfig):any{
    const apiField = fieldConfig.apiField
    const transform = fieldConfig.apiDataTransform
    const apiValueRaw = apiObject[apiField] ? apiObject[apiField] : ''
    return transform ? transform(apiObject[apiField]) :
      typeof apiValueRaw === 'string' ? GeneralUtils.removeTrailingSpaces(apiValueRaw) : apiValueRaw
  }

  /**
     * Asserts that current table state is default corresponding config.
     *
     * Asserts that:
     * 1) Order of columns is correct
     * 2) Column names' equality
     * 3) Is column fixed/frozen
     * 4) Is column sortable
     * 5) Should column be hidden
     *
     * @param tableDataConfig - config file as a reference for assert
     * @param tableRow - parsed data from UI. It can be any of table rows
     * */
  private async assertDefaultTableState(tableDataConfig: TableDataConfig, tableRow: TableRow) {
    const missMatchArray:string[] = [] // Array for error collecting
    // Remove columns without names from parsed UI data
    const cellArray = tableRow.cell.filter(cell => cell.columnName !== '')
    // Loop. Using count of fields in table config for validating actual UI table data
    const fields = tableDataConfig.fields.filter(f => f.platforms == null || f.platforms.includes(EWM3Config.PLATFORM))
    for (let i = 0, j = 0; i < fields.length; i++) {
      await test.step(`Column #${i} "${fields[i].columnName}"`,  async () => {
        if (!fields[i].hidden) {
          // Using try/catch for soft assert. An error will be thrown after all columns have been validated.
          try {
            if (cellArray[j]) {
              //TODO: replace with expect.soft
              expect(cellArray[j].columnName,
                `Expect that column #${i} name is "${fields[i].columnName}"`
              ).toEqual(fields[i].columnName)
              //TODO: remove that assert. Use assertTableColumnCapabilities()
              expect(cellArray[j].isFixed,
                `Assert column #${i} "${fields[i].columnName}" is fixed/frozen: "${fields[i].frozen}"`
              ).toEqual(fields[i].frozen)
              //TODO: remove that assert. Use assertTableColumnCapabilities()
              expect(cellArray[j].isSortable,
                `Assert column #${i} "${fields[i].columnName}" is sortable: "${fields[i].enable_sorting}"`
              ).toEqual(fields[i].enable_sorting)
              // If cell array has no item with such index, then it seems that column is not presented
            } else missMatchArray.push(`\n Error: Column #${i} "${fields[i].columnName}" is not presented`)
          } catch (error) {
            missMatchArray.push(`\n`+ error)
          }
          j++
        } else {
          try {
            //making sure that hidden  columns are not presented in UI table
            expect(cellArray.every(cell => cell.columnName!== fields[i].columnName),
              `Expect that column #${i} "${fields[i].columnName}" is hidden`).toBeTruthy()
          } catch (error) {
            missMatchArray.push(error)
          }
        }
      })
    }
    
    // Using try/catch for customize error message
    try {
      expect(missMatchArray.length,
        `${missMatchArray.length===0 ? 'Assert passed' : 'Assert failed'}`
      ).toEqual(0)
    } catch (error){
      throw new Error(
        `'Errors count: '${missMatchArray.length}
                
                ${missMatchArray.join('\n')}`)
    }
  }

  /**
     * Asserts that current main table state is default corresponding config.
     *
     * **CAUTION**
     * This void does not make table state default, it only asserts
     *
     * @param tableDataConfig - config file as a reference for assert
     * @param table - parsed main table data from UI
     * @see this.assertDefaultTableState
     * @see CustomizeColumnsFormFeature.resetToDefault
     * */
  public async assertMainTableDefaultState(tableDataConfig: TableDataConfig, table?: TableRow[]){
    await test.step(`Assert that main table is in its default state`,  async () => {
      const tableRow: TableRow = table? table[0]: (await this.data())[0]
      await this.assertDefaultTableState(tableDataConfig, tableRow)
    })
  }

  /**
     * Asserts that current nested table state is default corresponding config.
     *
     * **CAUTION**
     * This void does not make table state default, it only asserts
     *
     * @param tableDataConfig - config file as a reference for assert
     * @param table - parsed nested table data from UI
     * @see this.assertDefaultTableState
     * @see CustomizeColumnsFormFeature.resetToDefault
     * */
  public async assertNestedTableDefaultState(tableDataConfig: TableDataConfig, table?: TableRow[]) {
    await test.step(`Assert that nested table is in its default state`,  async () => {
      let tableRows: any
      if (table) tableRows = table
      else {
        //if table is not passed then we need to expand nested table and then parse data
        await this.expandNestedTable(1)
        // using only that row that has nested data
        tableRows = (await this.data()).find(row => row.nestedTableRow !== undefined)?.nestedTableRow
      }
      await this.assertDefaultTableState(tableDataConfig, tableRows[0])
    })
  }

  /**
   * Assert all table column capabilities:
   *
   * Should column be sortable
   *
   * Should column be fixed (frozen)
   *
   * @param tableDataConfig - config for table assert
   * @param table - row or
   * @param isNested - is asserting nested table
   * @throws Error - assert error. Asserts are soft - you will get complete list of errors
   */
  public async assertTableColumnCapabilities(tableDataConfig: TableDataConfig, table: TableRow | TableRow[], isNested: boolean = false){
    await test.step(`Assert all ${isNested? 'nested' : 'main'} table column capabilities`,  async () => {

      const cellArray = Array.isArray(table) ?
        table[0].cell.filter(cell => cell.columnName !== '')
        : table.cell.filter(cell => cell.columnName !== '')

      for (const fieldConfig of tableDataConfig.fields) {
        if (fieldConfig.hidden && !fieldConfig.enable_hiding) continue
        const cell = cellArray.find(cell => cell.columnName === fieldConfig.columnName)
        expect.soft(cell,
          `Expect to find column: "${fieldConfig.columnName}" in ${isNested? 'nested' : 'main'} table`
        ).toBeDefined()
        if (cell){
          //dividing nested and main because they can have different list of capabilities
          if(isNested) this.listOfNestedColumnCapabilitiesAsserts(cell, fieldConfig, isNested)
          else this.listOfColumnCapabilitiesAsserts(cell, fieldConfig, isNested)
        }
      }
    })
  }

  protected listOfColumnCapabilitiesAsserts(cell: TableCell, fieldConfig: FieldConfig, isNested: boolean){
    expect.soft(cell.isSortable,
      `Expect ${isNested? 'nested' : 'main'} table column: "${fieldConfig.columnName}" to be sortable: ${fieldConfig.enable_sorting}`
    ).toEqual(fieldConfig.enable_sorting)
    expect.soft(cell.isFixed,
      `Expect ${isNested? 'nested' : 'main'} table column: "${fieldConfig.columnName}" to be fixed: ${fieldConfig.frozen}`
    ).toEqual(fieldConfig.frozen)
  }

  protected listOfNestedColumnCapabilitiesAsserts(cell: TableCell, fieldConfig: FieldConfig, isNested: boolean){
    this.listOfColumnCapabilitiesAsserts(cell, fieldConfig, isNested)
  }

}
import {Locator, Page, expect, test} from '@playwright/test'
import {BaseClientSectionPage} from '../pages/base-client-section-page'
import {EWM3Config} from '../../../ewm3/service-data/config'
import { GeneralUtils } from '../../../utils/generalUtils'
import {HouseholdConfig} from '../../../ewm3/service-data/client-section-configs/household.config'

export interface LinksConfig {
  [index: string]: ActionLink[]
}

export interface ParametrMap {
  [index: string]: string
}

export interface ActionLink {
  uid: string;
  title: string;
  order: number;
  url: string;
  isInternal: boolean
  target: string;
}

export interface UIActionLink {
  title: string
  order: number
  url: string
  locator: Locator
}

export interface ClientLinkParams {
  clientId: string
  clientWebId: string
  agentId: string
  clientAplId: string
}

export interface AccountLinkParams {
  clientWebId: string
  agentId: string
  accountId: string
  clientAplId: string
}

export enum UrlTarget {
  SAME_PAGE = '_self',
  NEW_PAGE = '_new'
}

class ActionLinksLocators {
  constructor(private page: Page) {
  }

  readonly actionMenuItems = this.page.locator('//div[contains(@class, "base-Popup-root") and contains(@class, "base--expanded")]//*[contains(@role, "menuitem")]')
  readonly actionMenu = this.page.locator('//div[contains(@class, "base-Popup-root") and contains(@class, "base--expanded")]')
}

abstract class ActionLinksFeature {
  constructor(protected page: Page, protected csPage: BaseClientSectionPage) {
  }

  public locators = new ActionLinksLocators(this.page)

  abstract clickOnActionButton(): void
  abstract clickAndCompareConfigLinks(configLinkItem: ActionLink): void
  
  public async getUIActionLinks(): Promise<UIActionLink[]> {
    const uiLinks: UIActionLink[] = []

    const rowsCount = await this.locators.actionMenuItems.count()
    for (let i = 0; i < rowsCount; i++) {
      const title = await this.locators.actionMenuItems.nth(i).textContent()
      const url = await this.locators.actionMenuItems.nth(i).getAttribute('href')  
      uiLinks.push(
        {
          title: title ?? '',
          order: i++,
          url: url ?? '',
          locator: this.locators.actionMenuItems.nth(i)
        }
      )
    }
    return uiLinks
  }

  public async getUIActionLinkByTitle(linkTitle: string): Promise<UIActionLink | null> {
    const rowsCount = await this.locators.actionMenuItems.count()
    for (let i = 0; i < rowsCount; i++) {
      const title = await this.locators.actionMenuItems.nth(i).textContent()
      const url = await this.locators.actionMenuItems.nth(i).getAttribute('href') 
      if (linkTitle===title){
        const uiLink: UIActionLink = 
        {
          title: title,
          order: i+1,
          url: url?? '',
          locator: this.locators.actionMenuItems.nth(i)
        }
        return uiLink
      } 
    }
    return null
  }

  public async compareConfigLinksWithUi(configLinkItem: ActionLink, parameterMap: ParametrMap ): Promise<Locator|null> {
    let configAltUrl = GeneralUtils.constructResultString(configLinkItem.url?? '', parameterMap)
    if (configAltUrl.includes('internal:')) {
      configAltUrl = configAltUrl.replace('internal:', '')
    }
    const uiLink = await this.getUIActionLinkByTitle(configLinkItem.title)
    expect.soft(configLinkItem.title, `Assert link title`).toEqual(uiLink?.title)
    expect.soft(configLinkItem.order, `Assert link order`).toEqual(uiLink?.order)
    expect.soft(configAltUrl, `Assert link url`).toEqual(uiLink?.url)
    if (uiLink?.locator) {
      return uiLink?.locator
    } else {
      return null
    }
  }

  public async compareConfigLinksWithUiByClicking(configLinkItem: ActionLink, parameterMap: ParametrMap, linkLocator: Locator ) {
    await test.step(`Compare config Links with UI by clicking the link`,  async () => {

      let configUrlClickPattern = GeneralUtils.constructResultString(configLinkItem.url?? '', parameterMap)
      if (configUrlClickPattern.includes('internal:')) {
        configUrlClickPattern = configUrlClickPattern.replace('internal:', EWM3Config.BASE_URL??'')
      }
      let targetURL = ''
      if (configLinkItem.isInternal){
        targetURL = await this.clickOnEwm30LinkAndReturnUrl(linkLocator)??''
      }
      else {
        targetURL = await this.clickOnEwm20LinkAndReturnUrl(linkLocator, configUrlClickPattern)??''
      }
      expect.soft(targetURL, `Assert link url`).toContain(configUrlClickPattern)
      await expect.soft(this.locators.actionMenu).toBeHidden()
    })
  }

  public async clickOnEwm20LinkAndReturnUrl(link: Locator, pattern: string): Promise<string | null> {
    try{
      const requestPromise = this.page.waitForRequest(resp => resp.url().includes(pattern), {timeout: EWM3Config.API_RESPONSE_TIMEOUT})            
      if (await link.isVisible()) {                
        try {
          await link.click()
          const request = await requestPromise
          return request.url()
        } catch (error) {
          console.error(`Request ${pattern} not fulfilled within the specified timeout: ${error.message}`)
          return ''
        }
      }
      else {
        console.error(`Provided link is not visiable`)
        return ''
      }
    } catch (error) {
      console.error('Povided link is NOT clickable. Error: ', error)
      return ''
    }
  }
  
  public async clickOnEwm30LinkAndReturnUrl(link: Locator): Promise<string | null> {
    try{
      await link.click()
      await this.page.waitForLoadState()
      return this.page.url()
    } catch (error) {
      console.log('Povided link is NOT clickable. Error: ', error)
      return null
    }
  }
}

export class ToolbarActionLinksFeature extends ActionLinksFeature{
  constructor(page: Page, csPage: BaseClientSectionPage) {
    super(page, csPage)
  }

  public async clickOnActionButton() {
    await this.csPage.toolbar.openToolbarActionsMenu()
  }

  public async clickAndCompareConfigLinks(configLinkItem: ActionLink) {
    const parameterMap: ParametrMap = {
      BASE_URL_20: EWM3Config.BASE_URL_2_0?? '',
    }
    await this.clickOnActionButton()
    const linkLocator = await this.compareConfigLinksWithUi(configLinkItem, parameterMap)
    if (linkLocator) {
      await this.compareConfigLinksWithUiByClicking(configLinkItem, parameterMap, linkLocator)
    } else {
      throw new Error(`Can't compare ConfigLinks With Ui ByClicking - Link locator is not provided`)
    }
  }
}

export class MainTableActionLinksFeature extends ActionLinksFeature{
  constructor(page: Page, csPage: BaseClientSectionPage) {
    super(page, csPage)
  }

  public async clickOnActionButton() {
    const currentRow = this.csPage.table.getAllMainTableRows().nth(0)
    await this.csPage.table.clickOnMainRowActionButton(currentRow)
  }

  public async clickOnRowActionButton(row: Locator) {
    await this.csPage.table.clickOnMainRowActionButton(row)
  }

  /**
 * Method that returns Household main table api link parameters 
 * @param clientName - client name 
 * @param mv - client market value
 */
  public async returnHHMainTableApiLinkParams (clientName: string, mv: number): Promise<ClientLinkParams> {
    const responseBody = await (await this.csPage.responsePromise).json()
    const data = responseBody?.data.data
    const selectedElement = data.find(item => item.clientName === clientName && Number(item.marketValue.toFixed(2)) === mv)
    if (selectedElement){
      return {
        clientId: selectedElement.id,
        clientWebId: selectedElement.clientWebId,
        agentId: selectedElement.advisorIdentifier,
        clientAplId: selectedElement.clientAplId
      }
    }else {
      throw new Error(`Can't find appropriate Client name ${clientName} with MV ${mv} in API Response`)
    }
  }

  public async clickAndCompareConfigLinks(configLinkItem: ActionLink) {
    const rowsCount = await this.csPage.table.getAllMainTableRows().count()
    let rowForClicking: Locator|null = null
    let parameterMapForClicking: ParametrMap|null = null
    let linkLocatorForClicking: Locator|null = null
    let currentClientName: string
    let currentMvStr: string
    const headersArray = await this.csPage.table.getMainHeadersArray()
    for (let i = 0; i < rowsCount; i++) {
      const currentRow = this.csPage.table.getAllMainTableRows().nth(i)
      if (headersArray) {
        currentClientName = await this.csPage.table.getColumnValue(currentRow, (HouseholdConfig.COLUMN_NAMES.client_name as string), headersArray)??''
        currentMvStr = await this.csPage.table.getColumnValue(currentRow, (HouseholdConfig.COLUMN_NAMES.market_value as string), headersArray)??''        
      } else {
        currentClientName = ''
        currentMvStr = ''
      }
      const currentMv = GeneralUtils.parseDollarAmountToFloat(currentMvStr)
      const currentLinkParams = await this.returnHHMainTableApiLinkParams(currentClientName as unknown as string, currentMv)
      const parameterMap: ParametrMap = {
        BASE_URL_20: EWM3Config.BASE_URL_2_0?? '',
        CLIENT_WEB_ID: currentLinkParams.clientWebId,
        AGENT_ID: currentLinkParams.agentId,
        CLIENT_APL_ID: currentLinkParams.clientAplId
      }
      await this.clickOnRowActionButton (currentRow)
      const linkLocator = await this.compareConfigLinksWithUi(configLinkItem, parameterMap)
      if(!rowForClicking && currentLinkParams.clientWebId && currentLinkParams.agentId && linkLocator){
        rowForClicking = currentRow
        parameterMapForClicking = parameterMap
        linkLocatorForClicking = linkLocator
      }
      await this.csPage.search.locators.searchInput.click()

    }    
    if (rowForClicking && parameterMapForClicking && linkLocatorForClicking) {
      await this.clickOnRowActionButton (rowForClicking)
      await this.compareConfigLinksWithUiByClicking(configLinkItem, parameterMapForClicking, linkLocatorForClicking)
    } else {
      throw new Error(`Can't compare ConfigLinks With UI ByClicking - No one Client has Data for correct link`)
    }
  }
}

export class NestedAccountActionLinksFeature extends ActionLinksFeature{
  constructor(page: Page, csPage: BaseClientSectionPage) {
    super(page, csPage)
  }

  public async clickOnActionButton() {
    await this.csPage.table.expandNestedTable(1)
    const currentRow = this.csPage.table.getAllNestedTableRows().nth(0)
    await this.csPage.table.clickOnNestedRowActionButton(currentRow)
  }

  public async clickOnRowActionButton(row: Locator) {
    await this.csPage.table.clickOnNestedRowActionButton(row)
  }

  /**
 * Method that returns Household main table api link parameters 
 * @param accountTitle - account name 
 * @param mv - account market value
 * @param accountNumber - bank account number
 */
  public async returnHHNestedTableApiLinkParams (accountTitle: string, mv: number, accountNumber: string): Promise<AccountLinkParams> {
    const responseBody = await (await this.csPage.responsePromise).json()
    const data = responseBody?.data.data
    const selectedClient = accountNumber ==''? data.find(item => item.accounts.find(account => account.title === accountTitle && Number(account.marketValue.toFixed(2)) === mv)): data.find(item => item.accounts.find(account => account.title === accountTitle && Number(account.marketValue.toFixed(2)) === mv&& account.bankAccountNumber === accountNumber))
    
    if (selectedClient){
      const selectedAccount = accountNumber ==''? selectedClient.accounts.find(account => account.title === accountTitle && Number(account.marketValue.toFixed(2)) === mv): selectedClient.accounts.find(account => account.title === accountTitle && Number(account.marketValue.toFixed(2)) === mv && account.bankAccountNumber === accountNumber)
      
      let apiApplicationId = selectedAccount.applicationId

      if (apiApplicationId.includes('|')) {
        apiApplicationId = 'unknown'// TO DO: add apiApplicationId = apiApplicationId.replace('|', '%7C') - at the moment we don't have clear requirments. Defect - https://assetmark.atlassian.net/browse/EWM30CS-773
      }
      return {
        clientWebId: selectedClient.clientWebId,
        agentId: selectedClient.advisorIdentifier,
        accountId: apiApplicationId,
        clientAplId: selectedClient.clientAplId
      }

    }else {
      throw new Error(`Can't find appropriate Client with Account title: ${accountTitle}, MV: ${mv} in API Response`)
    }

  }

  public async clickAndCompareConfigLinks(configLinkItem: ActionLink) {
    await this.csPage.table.expandNestedTable(10)
    const rowsCount = await this.csPage.table.getAllNestedTableRows().count()
    let rowForClicking: Locator|null = null
    let parameterMapForClicking: ParametrMap|null = null
    let linkLocatorForClicking: Locator|null = null
    let currentAccountTitle: string = ''
    let currentAccountNumber: string = ''
    let currentMvStr: string = ''
    const headersArray = await this.csPage.table.getNestedHeadersArray()
    for (let i = 0; i < rowsCount; i++) {
      const currentRow = this.csPage.table.getAllNestedTableRows().nth(i)

      if (headersArray) {
        currentAccountTitle = await this.csPage.table.getColumnValue(currentRow, (HouseholdConfig.COLUMN_NAMES.nested as { [index: string]: string }).account_title, headersArray)??''
        currentMvStr = await this.csPage.table.getColumnValue(currentRow, (HouseholdConfig.COLUMN_NAMES.nested as { [index: string]: string }).market_value, headersArray)??''
        currentAccountNumber= await this.csPage.table.getColumnValue(currentRow, (HouseholdConfig.COLUMN_NAMES.nested as { [index: string]: string }).account_number, headersArray)??''
      } else {
        currentAccountTitle = ''
        currentMvStr = ''
      }
      const currentMv = GeneralUtils.parseDollarAmountToFloat(currentMvStr)
      const currentLinkParams = await this.returnHHNestedTableApiLinkParams(currentAccountTitle, currentMv, currentAccountNumber)

      if (currentLinkParams.accountId === 'unknown') { // TO DO: Delete this after Defect is fixed - https://assetmark.atlassian.net/browse/EWM30CS-773
        console.log('Breaking the checking for Account: ${currentAccountTitle} - accountId contains |')
        continue 
      }

      const parameterMap: ParametrMap = {
        BASE_URL_20: EWM3Config.BASE_URL_2_0?? '',
        CLIENT_WEB_ID: currentLinkParams.clientWebId,
        AGENT_ID: currentLinkParams.agentId,
        ACCOUNT_ID: currentLinkParams.accountId,
        CLIENT_APL_ID: currentLinkParams.clientAplId
      }
      await this.clickOnRowActionButton(currentRow)
      const linkLocator = await this.compareConfigLinksWithUi(configLinkItem, parameterMap)
      if(!rowForClicking && currentLinkParams.clientWebId && currentLinkParams.agentId && currentLinkParams.accountId && linkLocator){
        rowForClicking = currentRow
        parameterMapForClicking = parameterMap
        linkLocatorForClicking = linkLocator
      }
      await this.csPage.search.locators.searchInput.click()

    }    
    if (rowForClicking&& parameterMapForClicking && linkLocatorForClicking) {
      await this.clickOnRowActionButton (rowForClicking)
      await this.compareConfigLinksWithUiByClicking(configLinkItem, parameterMapForClicking, linkLocatorForClicking)
    } else {
      throw new Error(`Can't compare ConfigLinks With UI ByClicking - No one Client has Data for correct link`)
    }
  }
}

export class AccountsActionLinksFeature extends ActionLinksFeature{
  constructor(page: Page, csPage: BaseClientSectionPage) {
    super(page, csPage)
  }

  public async clickOnActionButton() {
    const currentRow = this.csPage.table.getAllMainTableRows().nth(0)
    await this.csPage.table.clickOnMainRowActionButton(currentRow)
  }

  public async clickOnRowActionButton(row: Locator) {
    await this.csPage.table.clickOnMainRowActionButton(row)
  }

  /**
 * Method that returns Household main table api link parameters 
 * @param accountTitle - account name 
 * @param mv - account market value
 * @param accountNumber - bank account number
 */
  public async returnAccountMainTableApiLinkParams (accountTitle: string, mv: number, accountNumber: string): Promise<AccountLinkParams> {
    const responseBody = await (await this.csPage.responsePromise).json()
    const data = responseBody?.data.data
    const selectedElement = accountNumber ==''? data.find(item => item.title === accountTitle && Number(item.marketValue.toFixed(2)) === mv): data.find(item => item.title === accountTitle && Number(item.marketValue.toFixed(2)) === mv&& item.bankAccountNumber === accountNumber)
    if (selectedElement){   
      let apiApplicationId = selectedElement.applicationId
      if (apiApplicationId.includes('|')) {
        apiApplicationId = 'unknown'// TO DO: add apiApplicationId = apiApplicationId.replace('|', '%7C') - at the moment we don't have clear requirments. Defect - https://assetmark.atlassian.net/browse/EWM30CS-773
      }
      return {
        clientWebId: selectedElement.clientWebId,
        agentId: selectedElement.advisorIdentifier,
        accountId: apiApplicationId,
        clientAplId: selectedElement.clientAplId
      }
    }else {
      throw new Error(`Can't find appropriate Client with Account title: ${accountTitle}, MV: ${mv} in API Response`)
    }
  }

  public async clickAndCompareConfigLinks(configLinkItem: ActionLink) {
    const rowsCount = await this.csPage.table.getAllMainTableRows().count()
    let rowForClicking: Locator|null = null
    let parameterMapForClicking: ParametrMap|null = null
    let linkLocatorForClicking: Locator|null = null
    let currentAccountTitle: string = ''
    let currentAccountNumber: string = ''
    let currentMvStr: string = ''
    const headersArray = await this.csPage.table.getMainHeadersArray()
    for (let i = 0; i < rowsCount; i++) {
      const currentRow = this.csPage.table.getAllMainTableRows().nth(i)
      
      if (headersArray) {
        currentAccountTitle = await this.csPage.table.getColumnValue(currentRow, (HouseholdConfig.COLUMN_NAMES.nested as { [index: string]: string }).account_title, headersArray)??''
        currentMvStr = await this.csPage.table.getColumnValue(currentRow, (HouseholdConfig.COLUMN_NAMES.nested as { [index: string]: string }).market_value, headersArray)??''
        currentAccountNumber= await this.csPage.table.getColumnValue(currentRow, (HouseholdConfig.COLUMN_NAMES.nested as { [index: string]: string }).account_number, headersArray)??''
      } else {
        currentAccountTitle = ''
        currentMvStr = ''
      }
      const currentMv = GeneralUtils.parseDollarAmountToFloat(currentMvStr)
      const currentLinkParams = await this.returnAccountMainTableApiLinkParams(currentAccountTitle, currentMv, currentAccountNumber)

      if (currentLinkParams.accountId === 'unknown') { // TO DO: Delete this after Defect is fixed - https://assetmark.atlassian.net/browse/EWM30CS-773
        console.log('Breaking the checking for Account: ${currentAccountTitle} - accountId contains |')
        continue 
      }

      const parameterMap: ParametrMap = {
        BASE_URL_20: EWM3Config.BASE_URL_2_0?? '',
        CLIENT_WEB_ID: currentLinkParams.clientWebId,
        AGENT_ID: currentLinkParams.agentId,
        ACCOUNT_ID: currentLinkParams.accountId,
        CLIENT_APL_ID: currentLinkParams.clientAplId
      }
      await this.clickOnRowActionButton(currentRow)
      const linkLocator = await this.compareConfigLinksWithUi(configLinkItem, parameterMap)
      if(!rowForClicking && currentLinkParams.clientWebId && currentLinkParams.agentId && currentLinkParams.accountId && linkLocator){
        rowForClicking = currentRow
        parameterMapForClicking = parameterMap
        linkLocatorForClicking = linkLocator
      }
      await this.csPage.search.locators.searchInput.click()

    }    
    if (rowForClicking && parameterMapForClicking && linkLocatorForClicking) {
      await this.clickOnRowActionButton (rowForClicking)
      await this.compareConfigLinksWithUiByClicking(configLinkItem, parameterMapForClicking, linkLocatorForClicking)
    } else {
      throw new Error(`Can't compare ConfigLinks With UI ByClicking - No one Client has Data for correct link`)
    }
  }
}


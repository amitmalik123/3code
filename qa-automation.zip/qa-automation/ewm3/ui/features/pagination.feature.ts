import {Locator, Page, expect, test} from '@playwright/test'
import {PaginationLocators} from '../elements/pagination.el'
import {TableFeature} from './table.feature'
import {GeneralUtils} from '../../../utils/generalUtils'

/** Available page switch triggers*/
export enum PageSwitchTrigger {
    ARROW_BUTTON = 'Click on the arrow button',
    PAGE_NUMBER_BUTTON = 'Click on the page number button',
}

/**
 * Interface for pagination feature configuration options.
 * This interface defines optional settings that can be passed to the PaginationFeature
 * class to customize its behavior. 
 *
 * @property {boolean} hasRowsPerPage - Indicates whether the pagination feature
 * allows for changing the number of rows displayed per page. Default is true.
 *
 * @property {number} rowsPerPageCount - Specifies the default number of rows to be displayed per page.
 * This value is used when hasRowsPerPage is true. 
 */

interface PaginationFeatureOptions {
  hasRowsPerPage: boolean,
  rowsPerPageCount: number
}

/** Pagination feature class.
 * Provide opportunity to:
 * switch pages
 * switch rows per page
 * assert pagination is correct
 * */

export class PaginationFeature{
  readonly locators = new PaginationLocators(this.page, this.container)
  private options: Partial<PaginationFeatureOptions>
  constructor(protected page: Page, private container: Locator, private table: TableFeature, options?: Partial<PaginationFeatureOptions>) {
    this.options = {
      hasRowsPerPage: true,
      rowsPerPageCount: 10,
      ...options
    }
  }

  /**
     * Switch page to the next page
     *
     * @param trigger - Optional. way to switch page
     * @param needAssert - Optional. Perform asserts after page switching = true OR not = false
     * @see PageSwitchTrigger
     * @see switchPage
     * */
  public async nextPage(trigger?:PageSwitchTrigger, needAssert?:boolean){
    await test.step(`I go to the next page`, async () => {
      const lastPageNumber = await this.lastPageNumber()
      const nextPageNumber = +(await this.locators.currentPageNumberButton.innerText()) + 1
      if (lastPageNumber >= nextPageNumber){
        await this.switchPage(nextPageNumber, trigger, needAssert)
      } else throw new Error(`Could not switch to the next page. 
            Total pages count: ${lastPageNumber}. Next page: ${nextPageNumber} does not exist`)
    })
  }

  /**
     * Switch page to the previous page
     *
     * @param trigger - Optional. way to switch page
     * @param needAssert - Optional. Perform asserts after page switching = true OR not = false
     * @see PageSwitchTrigger
     * @see switchPage
     * */
  public async prevPage(trigger?:PageSwitchTrigger, needAssert?:boolean){
    await test.step(`I go to the previous page`, async () => {
      const currentPageNumber = +(await this.locators.currentPageNumberButton.innerText())
      if (currentPageNumber>1){
        const prevPageNumber = +(await this.locators.currentPageNumberButton.innerText()) - 1
        await this.switchPage(prevPageNumber, trigger, needAssert)
      } else throw new Error(`Could not switch to the previous page. Current page is 1. There is no previous pages`)

    })
  }

  /**
     * Switch page to the first page
     *
     * @param trigger - Optional. way to switch page
     * @param needAssert - Optional. Perform asserts after page switching = true OR not = false
     * @see PageSwitchTrigger
     * @see switchPage
     */
  public async firstPage(trigger?:PageSwitchTrigger, needAssert?:boolean){
    await test.step(`I go to the first page`, async () => {
      await this.switchPage(1, trigger, needAssert)
    })
  }

  /**
     * Switch page to the last page
     *
     * @param trigger - Optional. way to switch page
     * @param needAssert - Optional. Perform asserts after page switching = true OR not = false
     * @see PageSwitchTrigger
     * @see switchPage
     */
  public async lastPage(trigger?:PageSwitchTrigger, needAssert?:boolean){
    await test.step(`I go to the last page`, async () => {
      await this.switchPage(await this.lastPageNumber(), trigger, needAssert)
    })
  }

  /**
     * @returns - last page number
     */
  public async lastPageNumber(): Promise<number> {
    return +(
      await this.locators.pageNumberButtons.nth(
        await this.locators.pageNumberButtons.count() - 1).innerText()
    )
  }

  /**
     * Switch page to the specific page
     *
     * @param pageNumber - number of the page to switch to
     * @param trigger - Optional. way to switch page
     * @param needAssert - Optional. Perform asserts after page switching = true OR not = false
     * @see PageSwitchTrigger
     * @see switchPage
     */
  public async goToThePage(pageNumber:number, trigger?:PageSwitchTrigger, needAssert?:boolean){
    await test.step(`I go the specific page #${pageNumber}`, async () => {
      await this.switchPage(pageNumber, trigger, needAssert)
    })
  }

  /**
     * General page switching function
     *
     * @param expectedPageNumber - number of the page to switch to
     * @param trigger - way to switch page
     * @param needAssert - perform asserts after page switching = true OR not = false
     * @private
     * @see PageSwitchTrigger
     * @see assertDisplayedItemsNumber
     * @see assertAmountOfItemsInfo
     * @see assertArrowsButtonVisibility
     * */
  private async switchPage(expectedPageNumber: number, trigger?:PageSwitchTrigger, needAssert?:boolean){
    await this.locators.currentPageNumberButton.waitFor({state:'visible'})
    const currentPageNumber = +(await this.locators.currentPageNumberButton.innerText())

    await test.step(`I switch current page #${currentPageNumber} to the #${expectedPageNumber} page, 
        using trigger: "${trigger}"`, async () => {
      //parse data before page switching in case if needAssert is true
      const tableRows = needAssert? await this.table.data() : []
      const amountOfItemsInfo = needAssert? await this.locators.amount.innerText() : ''
      switch (trigger) {
      case PageSwitchTrigger.ARROW_BUTTON:
        // define difference to understand how much times I need to click arrow button
        const difference = expectedPageNumber - currentPageNumber
        if (difference > 0) {
          for (let i = 0; i < difference; i++) {
            await this.locators.nextArrowButton.click()
          }
        } else if (difference < 0) {
          for (let i = 0; i > difference; i--) {
            await this.locators.prevArrowButton.click()
          }
        }
        break
      default:
      case PageSwitchTrigger.PAGE_NUMBER_BUTTON:
        if(expectedPageNumber != currentPageNumber){
          await this.locators.pageNumberButton(expectedPageNumber).click()
        }
        break
      }
      if(needAssert){
        await test.step(`I assert that page #${currentPageNumber} was switched to #${expectedPageNumber}`, async () => {
          // assert that current table items are not equal to the prev
          await this.assertDisplayedItemsNumber(expectedPageNumber)
          // assert that current table items are not equal to the prev
          //todo: add sorting assert (to assert that items order is correct)
          if(expectedPageNumber != currentPageNumber) {
            const currentTableState = await this.table.data()
            expect(GeneralUtils.arraysHaveNoEqualValues(tableRows, currentTableState),
              `Expect that current table has new items(no equal values with last page`
            ).toBeTruthy()
          }
          // assert that amount if items info is correct(1-5 of 20 in the left bottom corner)
          await this.assertAmountOfItemsInfo(expectedPageNumber, GeneralUtils.extractDigitsFromStringToArray(amountOfItemsInfo)[2])
          // assert arrow buttons presence or absence
          await this.assertArrowsButtonVisibility(expectedPageNumber)
        })
      }
    })
  }

  /**
     * Rows per page switching function
     *
     * @param newRowsPerPage - number of rows per page to switch to
     * @param needAssert - perform asserts after page switching = true OR not = false
     * */
  public async switchRowsPerPage(newRowsPerPage:number, needAssert?:boolean){
    await test.step(`I switch rows per page to #${newRowsPerPage}`, async () => {
      const currentRowsPerPage = +(await this.locators.rowsPerPageSelector.innerText())
      const totalAmountOfItems = GeneralUtils.extractDigitsFromStringToArray((await this.locators.amount.innerText()))[2]
      // if new row per page value is not equal to the prev then current(selected) page will be reset to 1
      const pageNumberAfterRowsSwitching =
                currentRowsPerPage === newRowsPerPage ?
                  +(await this.locators.currentPageNumberButton.innerText()): 1 
      // switch rows per page
      await this.locators.rowsPerPageSelector.click()
      await this.locators.rowsPerPageOption(newRowsPerPage).click()
      // assert if it is necessary
      if(needAssert){
        await test.step(`I assert that rows per page switched to to #${newRowsPerPage}`, async () => {
          await expect(this.locators.rowsPerPageOptionDropdown).toBeHidden()
          await this.assertAmountOfItemsInfo(pageNumberAfterRowsSwitching, totalAmountOfItems)
          await this.assertDisplayedItemsNumber(pageNumberAfterRowsSwitching)
        })
      }
    })
  }

  /**
     * Asserts:
     *
     * displayed number of items,
     * current(selected) page number
     * @private
     * @param pageNumber - number of page to assert. This page should be already opened
     * */
  private async assertDisplayedItemsNumber(pageNumber:number){
    await test.step(`I assert current items count is correct and that page #${pageNumber} is current(selected)`, async () => {
      const tableRowsCount = await this.table.locators.rowsMainOnly.count()
      // Determine rowsPerPage based on the presence of the rows per page option
      const rowsPerPage = this.options?.hasRowsPerPage ? +(await this.locators.rowsPerPageSelector.innerText()) : this.options?.rowsPerPageCount 
      // assert that current (selected) page number is correct
      expect(await this.locators.currentPageNumberButton.innerText(),
        `Expect that current page number is #${pageNumber}`)
        .toEqual(`${pageNumber}`)
      // assert that number of rows displayed on the current page is correct
      if(pageNumber === await this.lastPageNumber()){
        expect(tableRowsCount <= rowsPerPage && tableRowsCount >= 1,
          `Expect that number of rows on the current (last) page is <= ${rowsPerPage} and >= 1`
        ).toBeTruthy()
      } else {
        expect(tableRowsCount,
          `Expect that number of rows on the current page is = ${rowsPerPage}`
        ).toEqual(rowsPerPage)
      }
    })
  }

  /**
     * Asserts that amount of items info(in the left bottom corner "1-5 of 20") displays correct information
     *
     * @param pageNumber - number of page to assert. This page should be already opened
     * @param totalItemsAmount - Optional. Total amount of items. You can get this value from api response
     * OR from `locators.amount` text
     * */
  public async assertAmountOfItemsInfo(pageNumber:number, totalItemsAmount?:number){
    await test.step(`I assert that amount of items info (in the left bottom corner) displays correct information`, async () => {
      // text "1-5 of 20" is divided to [1,5,20]
      const currentAmountOfItemsInfo = GeneralUtils.extractDigitsFromStringToArray((await this.locators.amount.innerText()))
      const rowsPerPage = this.options?.hasRowsPerPage ? +(await this.locators.rowsPerPageSelector.innerText()) : this.options?.rowsPerPageCount 
      const tableRowsCount = await this.table.locators.rowsMainOnly.count()

      let from: number = 1
      let to: number = 1 === await this.lastPageNumber() ? tableRowsCount : rowsPerPage
      for (let i = 1; i < pageNumber; i++) {
        from = from + rowsPerPage
        // if it is the last page, then + number of rows on last page
        if (i + 1 === await this.lastPageNumber()){
          to += tableRowsCount
        } else {
          //in other cases + number of rows to "to" number
          to += rowsPerPage
        }
      }

      expect(currentAmountOfItemsInfo[0], `Expect that "from" value is correct = ${from}`)
        .toEqual(from)
      expect(currentAmountOfItemsInfo[1], `Expect that "to" value is correct = ${to}`)
        .toEqual(to)
      if (totalItemsAmount){
        expect(currentAmountOfItemsInfo[2], `Expect that "of" value equals ${totalItemsAmount}`)
          .toEqual(totalItemsAmount)
      }
    })
  }

  /**
     * Asserts that arrow buttons are displayed or hidden depending on current page - pageNumber
     * @private
     * @param pageNumber - number of page to assert. This page should be already opened
     * */
  private async assertArrowsButtonVisibility(pageNumber:number){
    if (await this.locators.pageNumberButtons.count() > 1) {
      if (pageNumber === 1) {
        await expect(this.locators.nextArrowButton,
          'Expect next page arrow button is visible'
        ).toBeVisible()
        await expect(this.locators.prevArrowButton,
          'Expect next page arrow button is visible'
        ).toBeVisible()
        await expect(this.locators.prevArrowButton,
          'Expect next page arrow button is enabled'
        ).toBeEnabled()
      } else if (pageNumber === await this.lastPageNumber()) {
        await expect(this.locators.nextArrowButton,
          'Expect next page arrow button is visible'
        ).toBeVisible()
        await expect(this.locators.nextArrowButton,
          'Expect next page arrow button is enabled'
        ).toBeEnabled()
        await expect(this.locators.prevArrowButton,
          'Expect prev page arrow button is visible'
        ).toBeVisible()
      } else {
        await expect(this.locators.nextArrowButton,
          'Expect next page arrow button is visible'
        ).toBeVisible()
        await expect(this.locators.prevArrowButton,
          'Expect prev page arrow button is visible'
        ).toBeVisible()
      }
    } else {
      await expect(this.locators.nextArrowButton,
        'Expect next page arrow button is hidden'
      ).toBeHidden()
      await expect(this.locators.prevArrowButton,
        'Expect prev page arrow button is hidden'
      ).toBeHidden()
    }
  }

  public async assertCurrentPageNumber(pageNumber: number) {
    expect(+(await this.locators.currentPageNumberButton.innerText()), 'Assert that current page is an expected page').toEqual(pageNumber)
  }
}

import { Page, expect, test } from '@playwright/test'
import { InvestmentsConfig } from '../../service-data/tile-config/investments.config'
import { TableTile } from './table-tile'
import { DashboardConfig } from '../../service-data/tile-config/dashboard.config'
import { BicPage } from '../pages/bic-page'
import { InvestmentsTableFeature } from '../features/investments.table.feature'

interface ChartLegendItem {
  color: string
  itemName:string
  currentAllocation:string
}

export class InvestmentsTile extends TableTile {

  readonly table = new InvestmentsTableFeature(this.page, this.tile)
  readonly strategiesTab = this.tile.getByRole('tab', { name: InvestmentsConfig.tabs.strategies })
  readonly investmentsApproachTab = this.tile.getByRole('tab', { name: InvestmentsConfig.tabs.investment_approach })
  readonly strategyNames = this.tile.locator('//span[@class="textEllipsis"]')

  public async openStrategiesTab() {
    await this.openTab(InvestmentsConfig.tabs.strategies)
  }

  public async openInvestmentsApproachTab() {
    await this.openTab(InvestmentsConfig.tabs.investment_approach)
  }

  private readonly chartLegendItem = this.tile.locator('//div[contains(@class, "ChartLegendItem-module__item")]')
  private readonly chartLegendItemColor = this.page.locator('//div[contains(@class, "ChartLegendItemColor-module__color")]')
  private readonly chartLegendItemTitle = this.page.locator('//div[contains(@class, "ChartLegendItem-module__label")]')
  private readonly chartLegendItemCurrentAllocation = this.page.locator('//p[contains(., "%")]') 
  protected readonly strategyActionButton = this.tile.locator('//button[@title="Strategy Actions"]') 
  protected readonly openBicButton = this.page.locator('//div[contains(@class, "expanded")]//a[.="Initiate Strategy Change"]')
  protected readonly bicPage = new BicPage(this.page)
  
  constructor(page: Page) {
    super(page,  DashboardConfig.tiles.investments.name)
  }
    
  /**
     * Parse chart legend, that has legend colors, title, and current allocation
     *
     * @return Promise<ChartLegendItem[]> - array of ChartLegendItem that is parsed from tile
     * @see ChartLegendItem
     */
  private async parseChartLegend(){
    return  await test.step(`I parse chart legend`, async () => {
      const chartLegendArray: ChartLegendItem[] = []
      for (let i = 0; i < await this.chartLegendItem.count(); i++) {
        const chartLegend: ChartLegendItem = {
          color: await this.chartLegendItem.nth(i).locator(this.chartLegendItemColor).evaluate(
            el => getComputedStyle(el).backgroundColor
          ),
          itemName: await this.chartLegendItem.nth(i).locator(this.chartLegendItemTitle).innerText(),
          currentAllocation: await this.chartLegendItem.nth(i).locator(this.chartLegendItemCurrentAllocation).innerText(),
        }
        chartLegendArray.push(chartLegend)
      }
      return chartLegendArray
    })
  }

  /**
     *
     * @return Promise<sting[]> - array of strategies/approach table colors that are in strategies/approach column
     */
  private async parseTableRowColors(){
    return  await test.step(`I parse legend item colors from table`, async () => {
      const colorsArray: string[] = []
      for (let i = 0; i < await this.table.locators.rowsMainOnly.count(); i++) {
        const color = await this.table.locators.rowsMainOnly.nth(i).locator(this.chartLegendItemColor).evaluate(
          el => getComputedStyle(el).backgroundColor
        )
        colorsArray.push(color)
      }
      return colorsArray
    })
  }

  /**
     * Compares color, title and current allocation for chart legend items and table rows.
     *
     * Sorting is not assert. Item and row are matched by common item name
     *
     */
  public async compareParseChartLegendAndTable() {
    // Todo: EWMPM-6001

    return  await test.step(`I compare chart legend with table data`, async () => {
      await this.pagination.switchRowsPerPage(15)
      const tableRows = await this.table.data()
      const tableRowColors = await this.parseTableRowColors()
      const chartLegendItems = await this.parseChartLegend()

      for (let i = 1; i < chartLegendItems.length; i++) {
        const chartLegendItem = chartLegendItems.find(item => item.itemName === tableRows[i].cell[0].value)
        expect(chartLegendItem,
          `Expect that chart legend item ${tableRows[i].cell[0].value} is presented`
        ).toBeDefined()
        expect(chartLegendItem?.color,
          `Expect that ${chartLegendItem?.itemName} color ${chartLegendItem?.color} is the same as in table`
        ).toEqual(tableRowColors[i])
        expect(chartLegendItem?.currentAllocation,
          `Expect that ${chartLegendItem?.itemName} current allocation ${chartLegendItem?.currentAllocation} 
            the same as in table`
        ).toEqual(tableRows[i].cell?.find(cell =>
          cell.columnName === InvestmentsConfig.columnNamesStrategies.current_allocation
        )?.value)
      }
      for (let i = 0; i < chartLegendItems.length; i++) {
        expect(chartLegendItems[i].color,
          `Expect that colors are presented in correct order:
            #${i} color should be ${InvestmentsConfig.graphColorsArray[i]}`
        ).toEqual(InvestmentsConfig.graphColorsArray[i])
      }
    })
  }

  /**
 * Opens the nth eligible strategy on the Investments tile and drills down to the BIC
 *
 * This method iterates through the available strategies in the Investments widget. It skips eligible strategies 
 * until it reaches the nth eligible strategy specified and opens the BIC button for that strategy.
 *
 * @param {number} [n=1] - The position of the eligible strategy to open (default is the first eligible strategy)
 * @throws {Error} If the nth eligible BIC strategy is not found after iterating through all strategies
 */
  async openBic(n: number = 1): Promise<number> {
    await expect(this.table.locators.table, 'Waiting Investment tile table is visible').toBeVisible()
    return await test.step(`Opening the ${n}th eligible strategy on Investments widget and drilling down to the BIC`, async () => {
      let eligibleStrategyCount = 0

      for (let i = 0; i < await this.strategyActionButton.count(); i++) {
        await this.strategyActionButton.nth(i).click()

        if (await this.openBicButton.isVisible()) {
          eligibleStrategyCount++
          if (eligibleStrategyCount === n) {
            await this.openBicButton.click()
            return i
          }
        }
      }

      throw new Error(`The ${n}th eligible BIC strategy was not found after iterating through all strategies`)
    })
  }

  /**
 * Opens the first strategy with the highest number of accounts on the Investments widget and drills down to the BIC.
 *
 * @param {[number, number][]} totalAccountsValuesWithIndex - An array of arrays where each sub-array contains the "Total Accounts" value and its index in the original table
 * @returns {Promise<number>} A promise that resolves to the index of the opened strategy
 * @throws {Error} Throws an error if the BIC button is not found after iterating through all strategies
 */
  public async openBicForStrategyWithLargestAmountOfAccounts(totalAccountsValuesWithIndex: [number, number][]): Promise<number> {
    return await test.step('Opening the strategy with the highest number of accounts on Investments widget and drilling down to the BIC', async () => {
      for (const [_, index] of totalAccountsValuesWithIndex) {
        await this.strategyActionButton.nth(index).click()
        if (await this.openBicButton.isVisible()) {
          await this.openBicButton.click()
          return index
        }
      }

      throw new Error('BIC button was not found after iterating through all strategies')
    })
  }

  /**
 * Asserts that the BIC button is not available for all strategies on Investments tile.
 * Iterates through all strategies and verifies that the BIC button is hidden for each strategy.
 */
  public async assertAllStrategiesAreBicIneligible() {
    await test.step('Iterating through all strategies and Verifying that BIC button is Not available', async () => {
      const numberOfStrategies = await this.strategyActionButton.count()
      for (let i = 0; i < numberOfStrategies; i++) {
        await this.strategyActionButton.nth(i).click()
        await expect.soft(this.openBicButton, 'Verify that BIC button is Not available in all strategies').toBeHidden()
      }
    })
  }

  async assertBicClosed() {
    await expect(this.bicPage.baseContainer, 'Expect that Destination Investment modal window is hidden').toBeHidden()
    await expect(this.tile, 'Expect that Investment Widget is visible in the Dashboard area').toBeVisible()
    await expect(this.openBicButton, 'Expect that Strategy Action menu is closed').toBeHidden()
  }

}

import {InsightsLiteBaseTile} from './insights-base-tile'
import {expect} from '../../../fixtures/base-ui-fixture'
import {GeneralUtils} from '../../../../utils/generalUtils'

export class LineChartBaseTile extends InsightsLiteBaseTile{

  readonly chartValues = this.tile.locator('//*[@y="-6"]')
  readonly xScaleValues = this.tile.locator('//*[@y="10"]')
  readonly yScaleValues = this.tile.locator('')

  public async assertDataMapping(responseBody: { data: any }){
    await expect(this.tile).toBeAttached({timeout: 60000})
    const chartDataFromTile = GeneralUtils.combineArraysIntoObject(await this.xScaleValues.allTextContents(), await this.chartValues.allTextContents())
    const chartDataFromResponse = GeneralUtils.formatFinancialNumbers(GeneralUtils.sumMarketValuesByYear(responseBody.data))
    expect(chartDataFromTile,'THEN the data red from tile (UI) matches teh date returned by API').toEqual(chartDataFromResponse)
  }

}
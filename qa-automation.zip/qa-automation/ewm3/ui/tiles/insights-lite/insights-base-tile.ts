import { expect, test} from '@playwright/test'
import { Tile } from '../base-tile'

export class InsightsLiteBaseTile extends Tile{
  readonly pageGridLayout = this.page.locator('//h3[.="Advisor Insights"]/following-sibling::div/div[contains(@class, "react-grid-layout")]')
  readonly tile = this.page.locator(`//h3[contains(text(), "${this.name}")]/ancestor::div[contains(@class, "react-grid-item")]`)
  readonly expandCollapseButton = this.tile.getByTestId('button-expand-collapse')
  readonly tileOptionsButton = this.tile.getByTestId('button-tile-menu')
  readonly resizeHandle = this.tile.locator('//p[contains(@class, "resizeHandle")]')
  readonly drillDownTooltip = this.page.locator('//span[text()="DRILL DOWN INTO"]/ancestor::div[@role="tooltip"]')
  readonly drillDownTooltipTitles = (name: string) => this.page.locator(`//div[text()="${name}"]`) 
  readonly detailsTitle = (name: string) => this.page.locator(`//div[contains(text(), "${name}")]`) 
  readonly resetGraphButton = this.tile.locator('//span[contains(text(), "Reset Graph")]/ancestor::span') 
  readonly feeAnalysisTableCells = this.page.locator('//td[@data-testid="table-first-column"]')

  async tileIsVisible(){
    await test.step('WHEN the advisor wants to see data', async () => {
      await expect(this.tile,'THEN the widget is visible').toBeAttached()
    })
  }

  /**
 * Clicks on the chart area within a given tile until a tooltip appears
 *
 */
  async clickOnChart() {
    const box = await this.tile.boundingBox()
    const increment = 50
    const elements = 5
    const coordinateX = Array.from({ length: elements }, (_, n) => {
      return box!.x + (n * increment)
    })
    const coordinateY = Array.from({ length: elements }, (_, n) => {
      return box!.y + (n * increment) + (box!.height / 2)
    })

    let clickSuccessful = false

    for (let attemptOnY = 0; attemptOnY < coordinateY.length; attemptOnY++){
      for (let attemptOnX = 0; attemptOnX < coordinateX.length; attemptOnX++){
        await test.step('Click and wait for a moment to allow tooltip appearing', async () => {
          await this.page.mouse.click(coordinateX[attemptOnX], coordinateY[attemptOnY], { delay: 100 })
        })
        await test.step('If the tooltip is visible, exit the function successfully', async () => {
          if (await this.drillDownTooltip.isVisible()) {
            clickSuccessful = true // Update flag to true as click was successful
            return // This return only exits the current async callback
          }
        })
        if (clickSuccessful) break // Break the loop if click was successful
      }
      if (clickSuccessful) break // Break the loop if click was successful
    }
  }

  /**
 * Iteratively drills down into all chart details for a given chart tile
 * For each tooltip details, it clicks on the chart, triggers the tooltip, checks for visibility,
 * and then resets the graph to its original state
 *
 * @param tileDrillDownTooltip - Array of a tooltip title names
 */
  async drillDownToAllChartDetails(tileDrillDownTooltip: object | undefined) {
    await test.step('Loop through all tooltip details', async () => {
      if (tileDrillDownTooltip){
        const tileDrillDownTooltipArray = Object.values(tileDrillDownTooltip)
        for (const drilldown of tileDrillDownTooltipArray) {
          await test.step('Click on the chart, drilling down into tooltip details', async () => {
            await this.clickOnChart()
            await this.drillDownTooltipTitles(drilldown).click()
            // Expect the details title corresponding to the tooltip details name to be visible
            await expect(this.detailsTitle(drilldown)).toBeVisible()
          })
          await test.step('Going back to the initial graph state, expect details title and reset button to be hidden', async () => {
            await this.resetGraphButton.click()
            await expect(this.detailsTitle(drilldown)).toBeHidden()
            await expect(this.resetGraphButton).toBeHidden()
          })
        }
      }
    })
  }

}

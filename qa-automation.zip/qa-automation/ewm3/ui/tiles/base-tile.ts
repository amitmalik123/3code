import { Locator, Page, expect, test } from '@playwright/test'
import { InsightsConfig } from '../../service-data/tile-config/insights.config'
import { GeneralUtils } from '../../../utils/generalUtils'

/** Abstract base class for tiles (widgets) that we have in eWM3.0*/
export abstract class Tile {
  /* todo: 
    Replace locators with better ones after task EWMPM-3503 will be done
  */
  readonly title = this.page.locator(`//h3[contains(text(), "${this.name}")]`)
  readonly tile = this.page.locator(Tile.getTileLocatorByName(this.name))
  readonly visibleItem = this.page.locator('//div[not(contains(@style, "visibility: hidden;"))]')
  readonly resizeHandle = this.tile.locator('//p[contains(@class, "resizeHandle")]')
  readonly expandCollapseButton = this.tile.locator('//button[@data-testid="button-expand-collapse"]')
  readonly tileOptionsButton = this.tile.locator('//button[@data-testid="button-expand-collapse"]//following-sibling::button')
  readonly menuOptionRemoveTile = this.visibleItem.locator('//button[contains(@aria-label, "Remove Tile")]')
  readonly menuOptions = this.visibleItem.locator('//li[contains(@class, "MenuItem-module")]')
  readonly tileGrid = this.tile.locator('//parent::div[contains(@class, "elevationDashWidget")]')

  constructor (protected page: Page, public readonly name: string) {
  }

  static getTileLocatorByName(name: string) {
    return `//h3[contains(text(), "${name}")]/ancestor::div[contains(@class, "Tile-module__tile")]`
  }

  async clickTileOptionByText(text: string) {
    return await this.menuOptions.filter({hasText: text}).click()
  }

  async removeTile() {
    await test.step(`Remove tile ${this.name} through tile actions menu`, async () => {
      await this.tileOptionsButton.click()
      await expect(this.menuOptionRemoveTile, 'Expect that tile action option "Remove Tile" is visible').toBeVisible()
      await this.menuOptionRemoveTile.click()
    })
    await test.step(`Validates tile ${this.name} was removed`, async () => {
      await expect(this.menuOptionRemoveTile, 'Expect that tile action option "Remove Tile" is not visible').toBeHidden()
      await expect(this.tile, `Expect that the tile ${this.name} is not visible`).toBeHidden()
    })
  }

  async validateTileMenuOptions(options: string[]) {
    await test.step('Then tile menu options should be displayed', async () => {
      for (let i = 0; i < options.length; i++) {
        await expect(this.menuOptions.nth(i), `Expecting menu item ${options[i]} to be present at position ${i}`)
          .toContainText(options[i], {useInnerText: true, ignoreCase: true})
      }
    })
  }

  async validateTileSize(size: string) {
    // Todo: Add screenshot tests, improve validations
    const smallTileText = 'tileSmall'
    const tileClass = await this.tileGrid.getAttribute('class')
    await test.step(`Validates widget is in "${size}" size`, async () => {
      switch (size.toLocaleLowerCase()) {
      case 'small':
        expect(tileClass, 'Validating element is set to small size').toContain(smallTileText)
        break
      case 'large':
        expect(tileClass, 'Validating element is at full size').not.toContain(smallTileText)
        break
      default:
        throw new Error(`"${size}" is not valid tile size.`)
      }
    })
  }

  /**
   * Increase or Decreases the size of a widget by simulating a drag-and-drop action on its resize handle
   * The method calculates target positions based on the original size of the widget, moves the resize handle to these positions,
   * and then verifies that the widget's new size is smaller/bigger than its original size
   *
   */
  async resize() {
    const tileSize = await this.tile.boundingBox();
    (tileSize!.width > InsightsConfig.minimumTileSize) ? await this.decreaseSize() : await this.increaseSize()
  }

  async increaseSize() {
    await test.step('WHEN the advisor wants to resize the widget bigger', async () => {
      const originalStyleState = await this.tile.boundingBox()
      const targetPosX = originalStyleState!.width * 3
      const targetPosY = originalStyleState!.height * 2
      await this.mouseDragAndDropAt(this.resizeHandle,targetPosX, targetPosY)
      const newStyleState = await this.tile.boundingBox()

      expect(newStyleState!.width, 'Verify the new width of the widget is greater than the original width').toBeGreaterThan(originalStyleState!.width)
      expect(newStyleState!.height, 'Verify the new height of the widget is less greater or equal to the original height').toBeGreaterThan(originalStyleState!.height)
    })
  }

  async decreaseSize() {
    await test.step('WHEN the advisor wants to resize the widget smaller', async () => {
      const originalStyleState = await this.tile.boundingBox()
      const targetPosX = originalStyleState!.width / 3
      const targetPosY = originalStyleState!.height / 3
      await this.mouseDragAndDropAt(this.resizeHandle, targetPosX, targetPosY)
      const newStyleState = await this.tile.boundingBox()

      expect(newStyleState!.width, 'Verify the new width of the widget is less than the original width').toBeLessThan(originalStyleState!.width)
      expect(newStyleState!.height, 'Verify the new height of the widget is less than or equal to the original height').toBeLessThanOrEqual(originalStyleState!.height)
    })
  }

  /**
 * Simulates expanding and collapsing a widget on the page through user interaction
 * This method checks that the widget's size correctly changes in response to clicking
 * an expand/collapse button twice: first to expand, then to collapse
 * It verifies that the widget expands upon the first click and returns to a size
 * less than or equal to the original size upon the second click
 *
 */
  async expandCollapse() {
    if(!await this.isTileExpanded()){ //If the tile state is collapsed
      await this.expand()
      await this.collapse()
    }else{
      await this.collapse()
      await this.expand()
    }
  }

  async expand() {
    await test.step('WHEN the advisor wants to expand the widget', async () => {
      const originalStyleState =  await this.tile.boundingBox()
      await this.expandCollapseButton.click()
      const newStyleState=  await this.tile.boundingBox()
      if (newStyleState!.width == originalStyleState!.width){
        expect(newStyleState!.height, `Verify the widget's height has increased after expansion`).toBeGreaterThan(originalStyleState!.height)
      }else if (newStyleState!.height == originalStyleState!.height){
        expect(newStyleState!.width, `Verify the widget's width has increased after expansion`).toBeGreaterThan(originalStyleState!.width)
      }else{
        expect(newStyleState!.width, `Verify the widget's width has increased after expansion`).toBeGreaterThan(originalStyleState!.width)
        expect(newStyleState!.height, `Verify the widget's height has increased after expansion`).toBeGreaterThan(originalStyleState!.height)
      }
      expect(await this.isTileExpanded()).toBeTruthy()
    })
  }

  async collapse() {
    await test.step('WHEN the advisor wants to collapse the widget', async () => {
      const originalStyleState =  await this.tile.boundingBox()
      await this.expandCollapseButton.click()
      const newStyleState=  await this.tile.boundingBox()
      if (newStyleState!.width == originalStyleState!.width){
        expect(newStyleState!.height, `Verify the widget's height has decreased after collapsing`).toBeLessThan(originalStyleState!.height)
      }else if (newStyleState!.height == originalStyleState!.height){
        expect(newStyleState!.width, `Verify the widget's width has decreased after collapsing`).toBeLessThan(originalStyleState!.width)
      }else{
        expect(newStyleState!.width, `Verify the widget's width has decreased after collapsing`).toBeLessThan(originalStyleState!.width)
        expect(newStyleState!.height, `Verify the widget's height has decreased after collapsing`).toBeLessThan(originalStyleState!.height)
      }
      expect(await this.isTileExpanded()).toBeFalsy()
    })
  }

  /**
 * Simulates the action of dragging and dropping a widget on the page
 * The method initiates by hovering over the widget's title, then simulates a mouse down action to 'grab' the widget,
 * moves it to a new location by dragging it horizontally across the page, and finally 'releases' the widget by simulating a mouse up action
 * After the drag and drop, the method verifies that the widget has moved horizontally by checking the transformation in the X direction,
 * while ensuring the Y position remains unchanged, indicating a successful horizontal drag and drop
 */
  async dragAndDrop() {
    await test.step('WHEN the advisor wants to drag and drop the widget', async () => {
      const originalStyleState =  await this.tile.boundingBox()
      const targetPosX = originalStyleState!.width * 2
      const targetPosY = originalStyleState!.y // The target Y position remains unchanged to simulate purely horizontal movement

      await test.step(`Drag and drop the widget`, async () => {
        await this.mouseDragAndDropAt(this.title, targetPosX, targetPosY)
      })
      const newStyleState = await this.tile.boundingBox()
      expect(newStyleState!.x, 'Verify the widget has been dragged horizontally by checking the transformation in the X direction').toBeGreaterThan(originalStyleState!.x)
      //TODO: There is a difference in Y position after dragging and drop that makes the assertion fails. Commented for further investigation
      //expect(newStyleState!.y, 'Ensure the Y position remains unchanged, indicating no vertical movement during the drag').to(originalStyleState!.y)
    })
  }

  /**
   * Hover the mouse to the locator, clicks and hold the mose button, move to the desired position and then release mouse button,
   * simulating a mouse drag and drop action
   *
   * @param locator - Element's locator that will be dragged and drop
   * @param targetPosX - X coordinate of element's final position
   * @param targetPosY - Y coordinate of element's final position
   *
   */
  private async mouseDragAndDropAt(locator: Locator, targetPosX: number, targetPosY: number) {
    await locator.hover()
    await this.page.mouse.down()
    await this.page.mouse.move(targetPosX, targetPosY)
    await this.page.mouse.up()
  }

  /**
   * Returns tile's expanded/collapsed state
   */
  private async isTileExpanded(): Promise<boolean> {
    const state = await this.expandCollapseButton.getAttribute('data-expanded')
    if (state) return GeneralUtils.parseBoolean(state)
    else throw new Error(`Failed to parse the expanded/collapsed state of the tile. The value of the 'data-expanded' attribute is '${state}'.`)
  }
}

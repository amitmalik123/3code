import { Tile } from './base-tile'
import { PaginationFeature } from '../features/pagination.feature'
import { SearchFeature } from '../features/search.feature'
import { CustomizeColumnsFormFeature } from '../features/customize-columns-form.feature'
import { expect, test } from '@playwright/test'
import { CancelSearchParamsArray, SearchParam } from '../../service-data/tile-config/types.config'
import { UiElementsStylesAssert } from '../../../utils/UIComponentsStateAssert'
import { DashboardConfig } from '../../service-data/tile-config/dashboard.config'
import { TableFeature } from '../features/table.feature'

/** Abstract class for tiles that has tables, such as Clients & Accounts, Investments, Status & Tracking*/
export abstract class TableTile extends Tile {
  readonly table = new TableFeature(this.page, this.tile)
  readonly pagination = new PaginationFeature(this.page, this.tile, this.table)
  readonly search = new SearchFeature(this.page, this.tile, this.table)
  readonly customizeColumns = new CustomizeColumnsFormFeature(this.page, this.tile, this.table)
  readonly tableRowActionsMenu = this.tile.locator('//tr[@data-testid="table-row"]//button[contains(@title, "Actions")]')
  readonly flagItemButton = this.page.locator('//button[@data-testid="button-flag"]')
  readonly flagItemButtonFill = this.flagItemButton.locator('svg > :first-child')

  public async tableRowWithValue(value: string) {
    return this.tile.locator(`//td[.="${value}"]//ancestor::tr[@data-testid="table-row"]`)
  }

  public async openTab(tabName: string) {
    await test.step(`Open tile tab: ${tabName}`, async () => {
      const tabLocator = this.tile.getByRole('tab', { name: tabName })
      await expect(tabLocator).toBeVisible()
      await tabLocator.click()
      await expect(this.table.locators.table).toBeVisible()
    })
  }

  async openRowActionsMenuForRow(rowText: string) {
    await test.step(`Opens row actions for ${rowText}`, async () => {
      await this.page.locator(`//span[contains(@data-testid, "${rowText}")]/ancestor::tr//button[contains(@title, "Actions")]`).click()
    })
  }

  async openRowActionsMenuInPosition(row: number) {
    await test.step(`Opens row actions for row in position ${row}`, async () => {
      await this.tableRowActionsMenu.nth(row).click()
    })
  }

  async validateRowActionsOptions(options: string[]) {
    for (let i = 0; i < options.length; i++) {
      await expect(this.menuOptions.nth(i), `Expecting menu item ${options[i]} to be present at position ${i}`)
        .toContainText(options[i], {useInnerText: true, ignoreCase: true})
    }
  }

  async prepareTableForSearch(param: SearchParam | CancelSearchParamsArray) {
    /** Will fail if there is no data in table */
    await test.step(`Prepare tile table for search inside tab ${param.tab}`, async () => {
      await this.openTab(param.tab)
      await this.customizeColumns.selectAllColumns()
      await expect(this.table.locators.table).toBeVisible()
    })
  }

  async verifyItemIsFlagged(flagged: boolean, itemNumber: string) {
    const flaggedColor = DashboardConfig.colors.flaggedTableItem
    const unflaggedColor = DashboardConfig.colors.unflaggedTableItem
    const element = (await this.tableRowWithValue(itemNumber)).locator(this.flagItemButtonFill)
    await test.step(`Verify if item with item number ${itemNumber} flag is set to ${flagged} through color validation`, async () => {
      if (flagged) {
        await UiElementsStylesAssert.fillColor(flaggedColor, element)
      } else {
        await UiElementsStylesAssert.fillColor(unflaggedColor, element)
      }
    })
  }

  async flagItem(itemNumber: string) {
    await test.step(`Click flag item button for item with number "${itemNumber}"`, async () => {
      await (await this.tableRowWithValue(itemNumber)).locator(this.flagItemButton).click()
    })
  }

  async validateItemIsInTable(visible: boolean, itemNumber: string) {
    await test.step(`Validates item "${itemNumber}" is present ${visible} at current table tab`, async () => {
      if (visible) {
        await expect(await this.tableRowWithValue(itemNumber)).toBeVisible()
      } else {
        await expect(await this.tableRowWithValue(itemNumber)).not.toBeVisible()
      }
    })
  }

  async validateFollowingItems() {
    const flaggedColor = DashboardConfig.colors.flaggedTableItem
    const itemCount = await this.flagItemButton.count()
    await test.step(`Validates all items inside tab are flagged as following through color validation`, async () => {
      for (let i = 0; i < itemCount; i++) {
        await UiElementsStylesAssert.fillColor(flaggedColor, this.flagItemButtonFill.nth(i))
      }
    })
  }

}

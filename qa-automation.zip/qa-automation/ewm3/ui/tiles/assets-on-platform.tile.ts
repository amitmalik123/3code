import { Page, expect } from '@playwright/test'
import { test } from '../../fixtures/base-ui-fixture'
import { GeneralUtils } from '../../../utils/generalUtils'
import { Tile } from './base-tile'
import { DashboardConfig } from '../../service-data/tile-config/dashboard.config'
import { UiElementsStylesAssert } from '../../../utils/UIComponentsStateAssert'
import { AssetsOnPlatformConfig } from '../../service-data/tile-config/assets-on-platform.config'

export class AssetsOnPlatformTile extends Tile {

  readonly timePeriodSelected = this.page.locator('//h3[.="Assets On Platform"]/ancestor::div[contains(@class,"Tile")]/descendant::div[contains(@class,"timeIndicator")]/div/h4')
  readonly metricValue = this.page.locator('//h3[.="Assets On Platform"]/ancestor::div[contains(@class,"Tile")]/descendant::div[contains(@class,"AumWidget-module__metricBlock")]/h2')
  readonly noDataAvailableMessage = this.page.locator('//h3[.="Assets On Platform"]/ancestor::div[contains(@class,"Tile")]/descendant::div[contains(@class,"full empty")]/p[.="No data available"]')
  readonly changesIndicator = this.tile.locator('//*[contains(@class,"StatusIndicator-module__status")]/h4')
  readonly timePeriodsButtons = this.tile.locator('//div[contains(@class,"aum__filters")]/button')
  readonly generalUtils: GeneralUtils

  constructor(page: Page) {
    super(page, DashboardConfig.tiles.assets_on_platform.name)
    this.generalUtils = new GeneralUtils(page)
  }

  async validateTimePeriodsAreVisible(timePeriods: string[]) {
    for (const timePeriod of timePeriods) {
      await expect.soft(this.timePeriodsButtons.filter({hasText: timePeriod}), `Validating time period "${timePeriod}" is visible`).toBeVisible()
    }
  }

  async validateTimePeriodSelected(timePeriod: string) {
    await test.step(`Validating time period selected is "${timePeriod}" through button color validation`, async () => {
      const selectedTimePeriodButtonColor = AssetsOnPlatformConfig.colors.selectedTimePeriodBackgroundColor
      await UiElementsStylesAssert.backgroundColor(selectedTimePeriodButtonColor, this.timePeriodsButtons.filter({hasText: timePeriod}))
    })
  }

  async selectTimePeriod(timePeriod: string) {
    await test.step(`Select time period "${timePeriod}" for assets on platform tile`, async () => {
      await this.timePeriodsButtons.filter({hasText: timePeriod}).click()
    })
  }

  async validateTimePeriodTag(expectedTimePeriod: string) {
    await test.step(`Validate time period tag should be "${expectedTimePeriod}"`, async () => {
      const actualTimePeriod = await this.timePeriodSelected.textContent()
      expect(actualTimePeriod).toEqual(expectedTimePeriod)
    })
  }

}

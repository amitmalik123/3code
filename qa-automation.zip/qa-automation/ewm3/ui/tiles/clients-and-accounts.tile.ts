import { Page, test } from '@playwright/test'
import { ClientsConfig } from '../../service-data/tile-config/clients.config'
import { TableTile } from './table-tile'
import { DashboardConfig } from '../../service-data/tile-config/dashboard.config'
import { CancelSearchParamsArray, SearchParam, SortingParam } from '../../service-data/tile-config/types.config'

export class ClientTile extends TableTile {

  readonly tileWidget = this.page.locator(`//div[@data-testid="${DashboardConfig.tiles.clients.id}"]`)
  readonly clientsTab = this.tile.getByRole('tab', { name: ClientsConfig.tabs.clients })
  readonly pendingFundingTab = this.tile.getByRole('tab', { name: ClientsConfig.tabs.pending_funding })
  readonly followingTab = this.tile.getByRole('tab', { name: ClientsConfig.tabs.following })
  readonly rowsPerPageString = this.page.locator(`//h3[.='${this.name}']/ancestor::div[contains(@class,'Tile')]//label[.='Rows per page:']/ancestor::div[contains(@class,'rows-per-page--HTJV4')]/descendant::button/label`)
  readonly titleOfTheCustomizeColumnForm = this.page.locator("//div[@role='tooltip']/descendant::p[.='Customize Columns']")

  constructor(page: Page) {
    super(page, DashboardConfig.tiles.clients.name)
  }

  async prepareTileOnTab(param: SortingParam, state = 'default', expandRowCount = 1) {
    await test.step(`Prepare clients tile for validation inside tab ${param.tab}`, async () => {
      await this.openTab(param.tab)
      await this.table.locators.table.waitFor({state: 'visible'})
      switch (state) {
      case 'default':
        await this.customizeColumns.resetToDefault()
        break
      case 'selectAll':
        await this.customizeColumns.selectAllColumns()
        break
      case 'deselectAll':
        await this.customizeColumns.deselectAllColumns()
        break
      default:
        throw new Error(`"${state}" is not a tile state. Please check the spelling.`)
      }
      if (param.tableConfig.nestedTableDataConfig) { 
        await this.table.expandNestedTable(expandRowCount)
      }
    })
  }

  async prepareTableForSearch(param: SearchParam | CancelSearchParamsArray) {
    await super.prepareTableForSearch(param)
    if (param.tab !== ClientsConfig.tabs.pending_funding) {
      await this.table.expandNestedTable()
    }
  }

}

import { StatusAndTrackingConfig } from '../../service-data/tile-config/status-and-tracking.config'
import { TableTile } from './table-tile'
import { Page } from '@playwright/test'
import { DashboardConfig } from '../../service-data/tile-config/dashboard.config'

export class StatusAndTrackingTile extends TableTile {
  readonly needAttentionTab = this.tile.getByRole('tab', { name: StatusAndTrackingConfig.tabs.needs_attention.name })
  readonly needAttentionCountBadge = this.tile.locator('//div[contains(@class, "BadgeCount-module")]')
  readonly openItemsTab = this.tile.getByRole('tab', { name: StatusAndTrackingConfig.tabs.open_items.name })
  readonly completedTab = this.tile.getByRole('tab', { name: StatusAndTrackingConfig.tabs.completed.name })
  readonly followingTab = this.tile.getByRole('tab', { name: StatusAndTrackingConfig.tabs.following.name })

  constructor(page: Page) {
    super(page, DashboardConfig.tiles.status_and_tracking.name)
  }

  public async openNeedAttentionTab() {
    await this.openTab(StatusAndTrackingConfig.tabs.needs_attention.name)
  }

  public async openOpenItemsTab() {
    await this.openTab(StatusAndTrackingConfig.tabs.open_items.name)
  }

  public async openCompletedTab() {
    await this.openTab(StatusAndTrackingConfig.tabs.completed.name)
  }

  public async openFollowingTab() {
    await this.openTab(StatusAndTrackingConfig.tabs.following.name)
  }
}
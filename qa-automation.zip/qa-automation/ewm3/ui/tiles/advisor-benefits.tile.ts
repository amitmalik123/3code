import test, { Page, expect } from '@playwright/test'
import { Tile } from './base-tile'
import { DashboardConfig } from '../../service-data/tile-config/dashboard.config'
import { AdvisorBenefitsConfig } from '../../service-data/tile-config/advisor-benefits.config'
import { UiElementsStylesAssert } from '../../../utils/UIComponentsStateAssert'
import { GeneralUtils } from '../../../utils/generalUtils'

export class AdvisorBenefitsTile extends Tile {
  readonly tileWidget = this.page.locator(`//div[@data-testid="${DashboardConfig.tiles.advisor_benefits.id}"]`)
  readonly currentLevel = this.tileWidget.locator('//p[contains(@class, "currentValue")]')
  readonly nextLevel = this.tileWidget.locator('//div[contains(@class, "SemiCircle-module__legendNext")]/p[contains(@class, "module__legendLabel")]')
  readonly statusBadge = this.tileWidget.locator('//p[contains(@class, "StatusBadge-module__badge")]')
  readonly tileFooter = this.tileWidget.locator('//p[contains(@class, "AdvisorBenefits-module__footerText")]')
  readonly tooltipDisclaimer = this.page.locator('//div[contains(@class, "TooltipPopper-module")]/p')
  // Todo: Improve gauge locator for id instead. This element is flaky and may cause tests to fail in the future
  readonly gaugeSemiCircle = this.page.locator('[class*="SemiCircle-module"] svg > g > :first-child')

  constructor(page: Page) {
    super(page, DashboardConfig.tiles.advisor_benefits.name)
  }

  async validateProgramLevel() {
    const currentValue = await this.currentLevel.textContent()
    const programLevels = AdvisorBenefitsConfig.programLevels
    if (currentValue === null) {
      throw new Error('Could not find assets on platform value')
    } else {
      const value = GeneralUtils.formatTextNumbers(currentValue)
      const target = programLevels.find(x => (value >= x.rangeFrom) && (x.rangeTo == null || value < x.rangeTo))
      if (target === null || undefined) {
        throw new Error(`Could not fit value ${value} into any program level`) 
      } else {
        await expect(this.statusBadge, `Expecting value "${value}" to be in program level "${target!.name}"`).toHaveText(target!.name, {ignoreCase: true})
        await this.validateProgramNextLevel(target!.name)
        await test.step(`Expecting advisor benefit level ${target!.name} to have color fill in ${target!.color}`, async () => {
          await UiElementsStylesAssert.fillColor(target!.colorCode, this.gaugeSemiCircle)
          // Todo: Add color and screenshot validation
        })
      }
    }
  }

  async validateProgramNextLevel(currentLevel: string) {
    await test.step(`Expecting next level after ${currentLevel} to be shown`, async () => {
      switch (currentLevel) {
      case 'Emerging Premier':
        await expect(this.nextLevel).toHaveText('Premier', {ignoreCase: true})
        break
      case 'Premier':
        await expect(this.nextLevel).toHaveText('Premier Elite', {ignoreCase: true})
        break
      case 'Premier Elite':
        await expect(this.nextLevel).toHaveText('Gold', {ignoreCase: true})
        break
      case 'Gold':
        await expect(this.nextLevel).toHaveText('Platinum', {ignoreCase: true})
        break
      case 'Platinum':
        await expect(this.nextLevel).toHaveText('Platinum Elite', {ignoreCase: true})
        break
      case 'Platinum Elite':
        await expect(this.nextLevel).not.toBeVisible()
        break
      default:
        throw new Error(`"${currentLevel}" is not an Advisor Benefits program level. Please check the spelling.`)
      }
    })
  }

}

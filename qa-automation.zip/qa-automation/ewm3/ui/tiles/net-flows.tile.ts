import { Page, expect, test } from '@playwright/test'
import { Tile } from './base-tile'
import { DashboardConfig } from '../../service-data/tile-config/dashboard.config'

export class NetFlows extends Tile {
  readonly metricValue = this.page.locator('//h3[.="Net Flows"]/ancestor::div[contains(@class,"Tile")]/descendant::div[contains(@class,"NetFlowsWidget")]/div/h2')
  readonly changesIndicator = this.tile.locator('//*[contains(@class,"StatusIndicator-module__status")]/h4')
  readonly timePeriodSelected = this.page.locator('//h3[.="Net Flows"]/ancestor::div[contains(@class,"Tile")]/descendant::div[contains(@class,"module__timeIndicatorContainer")]//h4')
  readonly barChart = this.page.locator('(//h3[.="Net Flows"]/ancestor::div[contains(@class,"Tile")]/descendant::div[@class="w-full h-full flex-grow"]//*[name()="path" and contains(@d, "0Z") and not(@stroke) and not(@transform) and not(contains(@fill, "C"))])[1]')
  readonly timePeriodsButtons = this.tile.locator(`//div[contains(@class,"timePeriodContainer")]/button`)
  readonly toolTipItems = this.page.locator('//div[contains(@class, "NetFlowsTooltip")]/div[contains (@class, "ChartLegendItem")]')
  readonly toolTipLabels = this.toolTipItems.locator('//div/div[2]/p[contains (@class, "ChartLegendItem")]')
  readonly toolTipValues = this.toolTipItems.locator('//div[contains (@class, "value")]//p')

  constructor(page: Page) {
    super(page, DashboardConfig.tiles.netflows.name)
  }

  async selectTimePeriodSelector( timePeriod: string ) {
    await test.step(`Select the time period ${timePeriod}`, async () => {
      await this.timePeriodsButtons.filter({hasText: timePeriod}).click()
    })
  }

  async validateToolTipLabels( items: string[] ) {
    await expect(this.toolTipLabels.first(), 'Waiting for tooltip labels to be present').toBeAttached()
    await expect (this.toolTipLabels, 'Expects amount of labels and tooltip items given to match').toHaveCount(items.length)
    await test.step(`ToolTip should have labels ${items}`, async () => {
      for (let i = 0; i < items.length; i++) {
        await expect(this.toolTipLabels.nth(i), `Expecting label ${items[i]} to be visible`).toHaveText(items[i])
      }
    })
  }

  async validateToolTipItemsCurrencyFormat( items: string[] ) {
    const arrayOfLocators = this.toolTipValues
    await expect(this.toolTipValues.first(), 'Waiting for tooltip values to be present').toBeAttached()
    await expect (this.toolTipValues, 'Expects amount of values and tooltip items given to match').toHaveCount(items.length)
    await test.step(`ToolTip values for ${items} should have correct currency format`, async () => {
      for (let i = 0; i < items.length; i++) {
        const elementText = await arrayOfLocators.nth(i).textContent()
        expect(elementText).toEqual(expect.stringMatching(/^-?\$[0-9]{1,3}(?:,?[0-9]{3})*\.[0-9]{2}$/))
      }
    })
  }

  async verifyTagForTimePeriod( expectedTimePeriod: string ) {
    await test.step('I verify that tag for the particular time selector should display the current time period', async () => {
      const actualTimePeriod = await this.timePeriodSelected.textContent()
      expect(actualTimePeriod, `Assert time period. Current time period is: "${actualTimePeriod}"`).toEqual(expectedTimePeriod)
    })
  }

}

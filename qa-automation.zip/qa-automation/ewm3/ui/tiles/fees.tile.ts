import { Locator, Page, expect, test } from '@playwright/test'
import { GeneralUtils } from '../../../utils/generalUtils'
import { DashboardConfig } from '../../service-data/tile-config/dashboard.config'
import { FeesConfig } from '../../service-data/tile-config/fees.config'
import { UiTextStylesAssert } from '../../../utils/UIComponentsStateAssert'
import { TableTile } from './table-tile'

export class FeesTile extends TableTile {
  /** Fee quarter selector. Dropdown element between Chart and Table, Available only for L2 size or bigger.*/
  readonly timePeriodSelector = this.tile.locator('//div[contains(@class, "select")]//button')
  /** Time period selector list. Contains 12 recent Quarters. Click at timePeriodSelector to view the list */
  readonly timePeriodSelectorDropDownList = this.page.locator('//ul[@class="base-Select-listbox" and not(@aria-multiselectable)] ')
  /** Time period options locators. Return 12 quarters buttons. Click at timePeriodSelector to view the option list  */
  readonly timePeriodDropdownOptions = this.timePeriodSelectorDropDownList.locator('//li')
  /** Time period selected. Contains text like "Q4" */
  readonly timePeriodSelected = this.tile.locator('//div[contains(@class, "module__timeIndicatorContainer")]//h4[contains(@class, "module__numRegular")]')
  /** Fee current period total amount. Shows amount of Fee for prior period if current is null. See EWMPM-4027*/
  readonly totalFeesValue = this.tile.locator('//div[contains(@class, "RevenueWidget")]/h2')
  readonly metricValue = this.page.locator('//h3[.="Fees"]/ancestor::div[contains(@class,"Tile")]/descendant::div[contains(@class,"RevenueWidget-module__metricContainer")]/div/h2')
  readonly changesIndicator = this.tile.locator('//div[contains(@class, "StatusIndicator")]//h4')
  readonly barChart = this.page.locator('(//h3[.="Fees"]/ancestor::div[contains(@class,"Tile")]/descendant::div[@class="w-full h-full flex-grow"]//*[name()="path" and not(contains(@fill,"none")) and contains(@stroke,"rgb(255")])[1]')
  readonly toolTip = this.page.locator('//div[@role="tooltip"]')
  readonly toolTipFeesList = this.tile.locator('//div[@role="tooltip"]//div[contains(@class,"ChartLegendItem-module__value")]')
  /** Table. No content stub for the selected quarter. Available only for L2 or bigger size */
  readonly tableNoContentStub = this.tile.locator('//*[contains(@class, "emptyTableContainer")]')
  // Todo: Verify if we can use table methods for the following
  readonly averageRevenuePerClient = this.tile.getByTestId('table-column-header-averageRevenue')
  readonly averageRevenuePerClientValues = this.tile.getByTestId('data-testid="table-cell-averageRevenue"')
  readonly numberOfClientsValues = this.tile.getByTestId('table-cell-clientsBilled')
  readonly revenueValues = this.tile.getByTestId('table-cell-revenue')

  constructor(page: Page) {
    super(page, DashboardConfig.tiles.fees.name)
  }

  async validateAmountFormat(list: Locator) {
    const count = await list.count()
    for (let i = 0; i < count; i++) {
      const text = await list.nth(i).textContent()
      if (text === null || undefined) { 
        throw new Error('Could not get value')
      }
      await this.validateFeeValueFormat(text)
    }
  }

  async validateDefaultQuarter() {
    const textRecentQuarter = await this.timePeriodSelected.textContent()
    const defaultTimePeriodSelector = await this.timePeriodSelector.textContent()
    expect(defaultTimePeriodSelector).toContain(textRecentQuarter)
  }

  async verifyRecentQuarterAtTheTop(trendDate:string) {
    const recentQuarter = await this.timePeriodDropdownOptions.nth(0).textContent()
    expect(recentQuarter).toEqual(GeneralUtils.convertDateToQuarterAndYear(trendDate))
  }
  
  async validaFontFormats() {
    await test.step('Validate font format for total value, time period and changes text', async () => {
      const font = FeesConfig.font
      await UiTextStylesAssert.fontSize(this.totalFeesValue, font.totalValue.fontSize)
      await UiTextStylesAssert.fontName(this.totalFeesValue, font.totalValue.fontFamily)
    
      await UiTextStylesAssert.fontSize(this.timePeriodSelected, font.timePeriod.fontSize)
      await UiTextStylesAssert.fontName(this.timePeriodSelected, font.timePeriod.fontFamily)

      await UiTextStylesAssert.fontSize(this.changesIndicator, font.changesIndicator.fontSize)
      await UiTextStylesAssert.fontName(this.changesIndicator, font.changesIndicator.fontFamily)
    })
  }

  async verifyTableHeadersForfeesWidget(expectedHeaders: string[]) {
    let i = 0
    for (const header of expectedHeaders) {
      await expect(this.table.locators.tableHeaders.nth(i), `Verify header item in position ${i} has text ${header}`).toHaveText(header)
      i ++
    }
  }

  async validateFeeValueFormat(text: string) {
    await test.step(`Verify formating of amount text: ${text}`, async () => {
      expect(text).toEqual(expect.stringMatching(/^-?\$[0-9]{1,3}(?:,?[0-9]{3})*\.[0-9]{2}$/))
    })
  }

  async verifyCurrentTimePeriod(expectedTimePeriod:string) {
    await test.step('I verify that tag for the particular time selector should display the current time period', async () => {
      const actualTimePeriod = await this.timePeriodSelected.textContent()
      expect(actualTimePeriod, `Assert time period. Current time period is: "${actualTimePeriod}"`).toEqual(expectedTimePeriod)
    })
  }

}

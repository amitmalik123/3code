import test, { Page, expect } from '@playwright/test'

export class MarketingCarousel {
  readonly marketingCarousel = this.page.locator('//div[@class= "slick-track"]')
  readonly marketingCarouselFirstArrowButton = this.page.locator('//button[@class="marketingPromo_arrowButton"]').first()
  readonly marketingCarouselLastArrowButton = this.page.locator('//button[@class="marketingPromo_arrowButton"]').last()
  readonly marketingCarouselTiles = this.page.locator('//div[@class="slick-track"]/div[contains(@class, "slick-slide")]')
  readonly marketingCarouselTilesDisplayed = this.page.locator('//div[contains(@class,"slick-slide") and (@aria-hidden="false")]')
  readonly showMoreLink = this.page.locator('//a[text()="Show more"]')
  readonly showLessLink = this.page.locator('//a[text()="Show less"]')
  readonly marketingCarouselPaginationDots = this.page.locator('//ul[@class="slick-dots"]/li')

  constructor(public page: Page) {
  }

  async validateTilesAutoscroll() {
    await test.step('Validating automatic scroll', async () => {
      // Tiles should autoscroll every 5 seconds to the next one
      await expect(this.marketingCarouselTilesDisplayed.first()).toHaveAttribute('data-index', '1')
      await expect(this.marketingCarouselTilesDisplayed.first()).toHaveAttribute('data-index', '2')
      await expect(this.marketingCarouselTilesDisplayed.first()).toHaveAttribute('data-index', '3')
    })
  }

  async validateNextAndBackButtonsOnMarketingCarousel() {
    await test.step('Validating that next and back button moves the tiles back and forth', async () => {
    // Clicking next on the marketing carousel should take you forward 3 tiles
      await this.marketingCarouselLastArrowButton.click()
      await expect(this.marketingCarouselTilesDisplayed.first()).toHaveAttribute('data-index', '3')
      // todo: Find a way to wait for the animation to be completed instead of waiting for timeout directly
      await this.page.waitForTimeout(1500)
      // Going back should take you to tile zero again
      await this.marketingCarouselFirstArrowButton.click()
      await expect(this.marketingCarouselTilesDisplayed.first()).toHaveAttribute('data-index', '0')
    })
  }

  async clickOnMarketingCarouselDotByPosition(position: number) {
    await test.step(`Clicking on carousel pagination dot in position: "${position}"`, async () => {
      await this.marketingCarouselPaginationDots.nth(position).click()
    })
  }

  async validateTilesAre(state: 'collapsed' | 'expanded') {
    await test.step(`Validating that tiles are: "${state}"`, async () => {
      let elementClassName
      if (state.toLocaleLowerCase() == 'collapsed') {
        elementClassName = await this.marketingCarouselTilesDisplayed.locator('//div[contains(@class, "flex-row")][2]').first().getAttribute('class')
      } else if (state.toLocaleLowerCase() == 'expanded') {
        elementClassName = await this.marketingCarouselTilesDisplayed.locator('//div[contains(@class, "flex-row")][1]').first().getAttribute('class')
      }
      expect(elementClassName).toContain('hidden')
    })
  }

}

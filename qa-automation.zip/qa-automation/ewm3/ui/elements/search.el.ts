import { Locator, Page } from '@playwright/test'

export class SearchLocators {
  constructor(protected page: Page, private container: Locator) {
  }

  /** search input locator */
  readonly searchInput = this.container.locator('#search-input')
  /** search box locator. It is search input parent. We use it to validate whole search box state: focus/active */
  public readonly searchBox = this.container.locator('//input[@id="search-input"]/..')
  /** magnifying glass icon/button locator.
     * Located inside search input. If you click on it, then search will be performed
     **/
  readonly magnifyingGlassButton  = this.container.locator('//*[contains(@class, "magnifierButton")]')
  /** Cross button locator. Located inside search input. Appears in case when search input contains >0 chars */
  readonly crossButton = this.container.getByLabel('clear input')
  /** Suggest popup locator. Appears only in case when you entered >=2 chars in search input */
  readonly suggestPopup = this.page.locator('#search-input-listbox')
  /** Suggest popup options multiple locators. Appears only in case when you entered >=2 chars in search input */
  readonly suggestOptions = this.suggestPopup.getByRole('option') 
  /** Tooltip locator. Appears only in case when you entered <2 chars in search input and start searching*/
  readonly tooltip  = this.page.getByRole('tooltip') 

  /**
     * @param suggestOption - specific suggest option
     * @return Locator - highlighted part of the suggest option text
     * */
  public suggestHighlightedText(suggestOption: Locator): Locator {
    return suggestOption.locator('//mark')
  }

  /**
     * @param suggestOption - specific suggest option
     * @return Locator - whole suggest option text
     * */
  public suggestText(suggestOption: Locator): Locator {
    return suggestOption.locator('//p')
  }
}

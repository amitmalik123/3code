import test, { Page, expect } from '@playwright/test'
import { DashboardConfig } from '../../service-data/tile-config/dashboard.config'

export class TileManager {
  readonly manageTilesSidebar = this.page.locator('//aside')
  readonly openedManageTilesMenu = this.page.locator('//div[contains(@class, "DashboardTileLibrary")]/h3')
  readonly manageTilesHeader = this.manageTilesSidebar.locator('//p[contains(@class, "DashboardTileLibrary-module__description")]')
  readonly manageTilesTitle = this.manageTilesSidebar.locator('//p[contains(@class, "DashboardTileLibrary-module__description")]')
  readonly closeManageTilesMenuButton = this.manageTilesSidebar.locator('//button[@data-testid="button-widget-library-close"]')
  readonly useSampleDashboard = this.manageTilesSidebar.locator('//a[.="Use Sample Dashboard"]')
  readonly manageTilesWholeModule = this.page.locator('//aside[contains(@class, "module__open")]')
  readonly sidebarTileList = this.manageTilesSidebar.locator('//li/span[contains(@class, "Text-module__text")]')
  // Toggles
  readonly sidebarAllToggles = this.manageTilesSidebar.locator("//input[@type='checkbox']")
  readonly toggleSelectAll = this.toggle('widget-item-all')
  readonly toggleAdvisorBenefitsProgram = this.toggle('widget-item-advisor_benefits')
  readonly toggleAssetsOnPlatform = this.toggle('widget-item-aum')
  readonly toggleClientsAndAccounts = this.toggle('widget-item-client_list')
  readonly toggleFees = this.toggle('widget-item-revenue')
  readonly toggleInvestments = this.toggle('widget-item-investments')
  readonly toggleNetFlows = this.toggle('widget-item-net_flows')
  readonly toggleStatusAndTracking = this.toggle('widget-item-status_tracking')
  // Tile previews
  tilePreview = this.manageTilesSidebar.locator('//div[contains(@class, "DashboardTileLibraryPreview-module")]')
  tilePreviewAdvisorBenefits = this.tilePreview.locator('//img[@alt="advisor_benefits"]')
  tilePreviewAssetsOnPlatform = this.tilePreview.locator('//img[@alt="aop"]')
  tilePreviewClients = this.tilePreview.locator('//img[@alt="clients_and_accounts"]')
  tilePreviewFees = this.tilePreview.locator('//img[@alt="Fees"]')
  tilePreviewInvestments = this.tilePreview.locator('//img[@alt="investment"]')
  tilePreviewNetflows = this.tilePreview.locator('//img[@alt="netflows"]')
  tilePreviewStatusAndTracking = this.tilePreview.locator('//img[@alt="status_and_tracking"]')

  constructor(private page: Page) {
  }

  private toggle(id: string) {
    return this.manageTilesSidebar.locator(`//li[@id="${id}"]//input`)
  }

  async toggleTile(tileName: string) {
    await (await this.getToggleByName(tileName)).check()
    await expect(await this.getToggleByName(tileName), `Expecting for ${tileName} toggle to be checked`).toBeChecked()
  }

  async untoggleTile(tileName: string) {
    await (await this.getToggleByName(tileName)).uncheck()
    await expect(await this.getToggleByName(tileName), `Expecting for ${tileName} toggle to be not checked`).not.toBeChecked()
  }

  async getToggleByName(name: string) {
    if (name.toLocaleLowerCase() === 'all') {
      return this.toggleSelectAll
    }
    const tiles = DashboardConfig.tiles
    switch (name) {
    case tiles.advisor_benefits.name:
      return this.toggleAdvisorBenefitsProgram
    case tiles.assets_on_platform.name:
      return this.toggleAssetsOnPlatform
    case tiles.clients.name:
      return this.toggleClientsAndAccounts
    case tiles.fees.name:
      return this.toggleFees
    case tiles.investments.name:
      return this.toggleInvestments
    case tiles.netflows.name:
      return this.toggleNetFlows
    case tiles.status_and_tracking.name:
      return this.toggleStatusAndTracking
    default:
      throw new Error(`"${name}" is not a tile. Please check the spelling.`)
    }
  }

  // Will start from whatever state the toggles were at the moment this method is called: if they were checked - will uncheck, if they were unchecked - will check
  // Needs to be used in conjoint with addAllWidgets or removeAllWidgets first
  // Does not include "Select All" toggle (i == 0)
  async toggleAllTilesOneByOne() {
    const count = await this.sidebarAllToggles.count()
    for (let i = 0; i < count; i++) {
      if (i == 0) { continue } else {
        if (await this.sidebarAllToggles.nth(i).isChecked()) {
          await this.sidebarAllToggles.nth(i).uncheck()
        } else {
          await this.sidebarAllToggles.nth(i).check()
        }
      }
    }
  }

  // Hover over trigger needs to be sent separately, this method will only validate visibility of the tile preview
  async validateTilePreviewForTile(tileName: string) {
    const tiles = DashboardConfig.tiles
    // Todo: Add screenshot validation on tile previews
    await test.step(`Validating tile preview visibility and image attribute for tile: ${tileName}`, async () => {
      switch (tileName) {
      case tiles.advisor_benefits.name:
        await expect(this.tilePreviewAdvisorBenefits).toBeVisible()
        break
      case tiles.assets_on_platform.name:
        await expect(this.tilePreviewAssetsOnPlatform).toBeVisible()
        break
      case tiles.clients.name:
        await expect(this.tilePreviewClients).toBeVisible()
        break
      case tiles.fees.name:
        await expect(this.tilePreviewFees).toBeVisible()
        break
      case tiles.investments.name:
        await expect(this.tilePreviewInvestments).toBeVisible()
        break
      case tiles.netflows.name:
        await expect(this.tilePreviewNetflows).toBeVisible()
        break
      case tiles.status_and_tracking.name:
        await expect(this.tilePreviewStatusAndTracking).toBeVisible()
        break
      default:
        throw new Error(`"${tileName}" is not a tile. Please check the spelling.`)
      }
    })
  }

  async validateToggleChecked(checked: boolean, toggles: string[] | string) {
    if (typeof(toggles) === 'string') { toggles = [toggles] }
    for (const toggle of toggles) {
      if (checked) {
        await expect(await this.getToggleByName(toggle), 
          `Expecting for ${toggle} toggle to be checked`).toBeChecked()
      } else {
        await expect(await this.getToggleByName(toggle), 
          `Expecting for ${toggle} toggle to not be checked`).not.toBeChecked()
      }
    }
  }

}

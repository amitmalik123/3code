import { Page } from '@playwright/test'

export class Footer {

  constructor(private page: Page) {
  }

  readonly footer = this.page.locator('//footer[.//p[contains(., "Terms of Use")]]')
  readonly footerAssetMarkLogo = this.page.locator('footer img[alt="AssetMark"]')

  public async clickAssetMarkLogo() {
    await this.footerAssetMarkLogo.click()
  }
}

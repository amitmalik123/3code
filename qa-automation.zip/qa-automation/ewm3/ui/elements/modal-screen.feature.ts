import test, { Page, expect } from '@playwright/test'
import { ModalContent } from '../../service-data/tile-config/types.config'
import { UiTextStylesAssert } from '../../../utils/UIComponentsStateAssert'
import { DashboardConfig } from '../../service-data/tile-config/dashboard.config'

/**
 * Available close modal triggers enum
 */
export enum CloseModalTrigger {
  CLICK_CLOSE_BUTTON = 'Clicking the close button',
  CLICK_OUTSIDE_MODAL = 'Clicking outside the modal screen',
  CLICK_X_CORNER_BUTTON = 'Clicking "X" in the corner of the modal'
}

export class ModalFeature {

  readonly actionModal = this.page.locator('//div[contains(@class, "ActionModal-module__container")]')
  readonly actionModalTitle = this.page.getByTestId('action-modal-title')
  readonly actionModalContent = this.page.getByTestId('action-modal-content')
  readonly actionModalClose = this.page.getByTestId('action-modal-button-close')
  readonly actionModalCornerX = this.page.getByTestId('action-modal-button-x')

  constructor(private page: Page) {
  }

  /**
     * Will close the modal screen through specified trigger
     *
     * @param trigger - trigger of type CloseModalTrigger to close modal screen
     */
  async closeModal(trigger: CloseModalTrigger) {
    switch (trigger) {
    case CloseModalTrigger.CLICK_CLOSE_BUTTON:
      await this.actionModalClose.click()
      await expect(this.actionModal, 'Expecting modal to be closed after clicking close button').not.toBeVisible()
      break
    case CloseModalTrigger.CLICK_OUTSIDE_MODAL:
      await this.page.locator('//div[@id="logo"]').click({force: true})
      await expect(this.actionModal, 'Expecting modal to be closed after clicking outside the modal').not.toBeVisible()
      break
    case CloseModalTrigger.CLICK_X_CORNER_BUTTON:
      await this.actionModalCornerX.click()
      await expect(this.actionModal, 'CExpecting modal to be closed after clicking the corner X button').not.toBeVisible()
      break
    default:
      throw new Error(`"${trigger}" is not a valid trigger. Please check the spelling.`)
    }
  }

  async validateActionModalContent(tileContent: ModalContent) {
    await expect(this.actionModal, 'Waiting for modal to be visible').toBeVisible()
    const titleText = await this.actionModalTitle.textContent()
    const contentText = await this.actionModalContent.textContent()
    const actionModalTitleText = titleText?.replace(/[\r\n]+/gi, '')
    const actionModalContentText = contentText?.replace(/[\r\n]+/gi, '')
    await test.step('Validating modal content', async () => {
      expect (actionModalTitleText).toEqual(tileContent.title)
      expect (actionModalContentText).toEqual(tileContent.content)
    })
    await test.step('Validating modal close button design', async () => {
      await UiTextStylesAssert.fontSize(this.actionModalClose, DashboardConfig.font.secondaryCloseButton.fontSize)
      await UiTextStylesAssert.fontName(this.actionModalClose, DashboardConfig.font.secondaryCloseButton.fontFamily)
    })
  }

}

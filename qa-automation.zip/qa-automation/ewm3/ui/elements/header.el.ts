import test, { Page, expect } from '@playwright/test'

export class Header {

  constructor(private page: Page) {
  }

  readonly view = this.page.locator('div.bg-brand-primary-dark')
  readonly profileIcon = this.page.locator('[role="img"][aria-labelledby="Left Icon"]')
  readonly profile = this.page.locator('//p[contains(text(), "Hello, ")]')
  readonly clientsLink = this.page.locator('//div[@role="tablist"]//a[@href="/clients"]')
  readonly userDropdownMenu = this.page.locator('//ul[@id="simple-menu" and contains(@class, "expanded")]')
  readonly userDropdownMenuItems = this.userDropdownMenu.locator('//li[@role="menuitem"]')
  readonly navigationBar = this.page.getByTestId('page-navigation')
  readonly headerLinks = this.navigationBar.locator('//a[contains(@data-testid,"nav-tab")]')
  readonly advisorWorkstation = this.page.locator('//p[.="Advisor Workstation"]')
  readonly homeButton = this.page.locator('//div[@title="Home"]')
  readonly homeButtonDropDown = this.page.locator('#home-menu')
  readonly myDashboardDropdownOption = this.page.locator('//span[.="My Dashboard"]/ancestor::li')
  readonly classicHomePageDropdownOption = this.page.locator('//span[.="Classic Homepage"]/ancestor::li')

  public async openProfileMenu() {
    await this.profile.click()
    await expect(this.userDropdownMenu).toBeVisible()
  }

  async validateDropdownItems(userMenuDropdownItems: string[]) {
    await expect(this.navigationBar, 'Waiting for navigation bar to appear').toBeVisible()
    const menuItemsLength = await this.userDropdownMenuItems.count()
    expect(menuItemsLength, 'Expecting list of items counts to match').toEqual(userMenuDropdownItems.length)
    const validationPromises = userMenuDropdownItems.map(async (item, i) => 
      await test.step(`Validating header dropdown menu item "${item}" at position ${i}`, async () => {
        await expect.soft(this.userDropdownMenuItems.nth(i)).toContainText(userMenuDropdownItems[i])        
      }))
    await Promise.all(validationPromises)
  }

  async clickProfileMenuOption(option: string) {
    await test.step(`Opening profile menu item "${option}"`, async () => {
      await this.openProfileMenu()
      await this.userDropdownMenuItems.filter({hasText: option}).click()
    })
  }

  async validateHeaderLinksPresent(links: string[]) {
    await expect(this.navigationBar, 'Waiting for navigation bar to appear').toBeVisible()
    const validationPromises = links.map(async (link, i) => 
      await test.step(`Validating header menu item "${link}" at position ${i}`, async () => {
        await expect.soft(this.headerLinks.nth(i)).toHaveText(link, { useInnerText: true, timeout: 5000 })        
      }))
    await Promise.all(validationPromises)
  }

  async validateHeaderLinksNotPresent(links: string[]) {
    await expect(this.navigationBar, 'Waiting for navigation bar to appear').toBeVisible()
    const validationPromises = links.map(async link =>
      await test.step(`Validating header menu item "${link}" is not present`, async () => {
        await expect.soft(this.headerLinks.filter({hasText: link}),
          `Expect that header menu item "${link}" is not presented`
        ).not.toBeAttached({timeout: 5000})
      })
    )
    await Promise.all(validationPromises)
  }

}

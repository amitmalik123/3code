import {BaseCustomizeMenuLocators} from '../base-customize-menu.el'
import {Locator, Page} from '@playwright/test'

export class CSToolbarMetricMenuLocators extends BaseCustomizeMenuLocators {

  constructor(page: Page, container: Locator) {
    super(page, container)
  }

  /** Toolbar button. After click appears toolbar metrics menu */
  public readonly openMenuButton = this.page.locator('*[data-testid*="toolbar-metric-label"]').nth(0)
  /** Total metrics tooltip. Apply button */
  readonly applyButton = this.menu.locator('//button[.="Apply"]')
}


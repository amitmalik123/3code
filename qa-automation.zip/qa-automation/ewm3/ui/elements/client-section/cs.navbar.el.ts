import {Locator, Page} from '@playwright/test'

export class CSNavbarbarLocators {

  constructor(protected page: Page, private container: Locator) {
  }

  readonly navBar = this.container.locator('//div[contains(@class, "Navbar-module__headline")]')
  readonly pageMenuItems = this.container.locator('//div[contains(@class, "base-TabsList-horizontal")]/button')
  public pageMenuItemByName(itemName:string){
    return this.container.locator(`//div[contains(@class, "base-TabsList-horizontal")]/button[contains(., "${itemName}")]`)
  }
}
import {Locator, Page} from '@playwright/test'
import {CustomizeColumnsFormLocators} from '../customizeColumnsForm.el'

export class CSCustomizeColumnsFormLocators extends CustomizeColumnsFormLocators{
  constructor(page: Page, container: Locator) {
    super(page, container)
  }

  public readonly openMenuButton = this.container.locator('//div[contains(@class, "Navbar-module__tools")]//div/button[@aria-haspopup="menu"]')
}

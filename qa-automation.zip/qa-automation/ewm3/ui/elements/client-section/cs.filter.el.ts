import {Locator, Page} from '@playwright/test'

export class BaseCSFilterLocators{
  constructor(protected page: Page, public tooltip = page.locator('//div[@role="tooltip"]')) {
  }
  /** Open filter button. Filters tooltip will be displayed after click */
  public openButton: Locator
}

export class CSFilterLocators extends BaseCSFilterLocators{
  constructor(protected page: Page) {
    super(page)
  }

  /** Open filter button. Filters tooltip will be displayed after click */
  public openButton = this.page.getByTestId('multi-filter-button')
  /** Badge with number of applied filters. Does not exist if filters not applied */
  readonly filterCountBadge = this.openButton.locator('//div[contains(@class, "badgeCount")]')
  /** Close button inside Filters tooltip. Filters tooltip will be closed after click */
  readonly closeButton = this.tooltip.locator('//button[not(@data-testid)]')
  /** Delete all button inside Filters tooltip. Resets all filtering settings. Disabled by default*/
  readonly deleteAllButton = this.tooltip.getByTestId('multi-filter-reset-button')
  /** Apply button inside Filters tooltip. Applies filter settings. Disabled by default */
  readonly applyButton = this.tooltip.getByTestId('multi-filter-submit-button')
  /** Open (expand) filter item locator. Inside filters tooltip */
  readonly openFilterItem = this.tooltip.locator('//div[contains(@class, "ExpandableContainer-module__container")]')

  /**
   * Range filter locators
   * @param openFilterItem - filtered by text openFilterItem locator
   */
  rangeFilter(openFilterItem: Locator){
    return new CSRangeFilterLocators(this.page, openFilterItem)
  }
  readonly checkboxFilter = new CSCheckboxFilterLocators(this.page)

}

export class CSTableFilterLocators extends BaseCSFilterLocators{
  constructor(page: Page, public columnHeader: Locator, tooltip?: Locator) {
    super(page, tooltip)
  }
  readonly rangeFilter = new CSRangeFilterLocators(this.page)
  readonly checkboxFilter = new CSCheckboxFilterLocators(this.page)
  /**
   * Filtering button in column header
   * @returns Locator - filtering button locator
   */
  public openButton = this.columnHeader.locator('//button[contains(@class, "filterButton")]')
  /** Apply filter button */
  readonly applyButton = this.tooltip.locator('//button[.="Apply"]')
  /** Clear filter button */
  readonly clearButton = this.tooltip.locator('//button[.="Clear Filter"]')
}

class BaseCSRangeFilterLocators extends BaseCSFilterLocators{
  constructor(page: Page, container?: Locator) {
    super(page, container)
  }
  /** Input from */
  readonly fromInput = this.tooltip.locator('//div[@data-testid="range-slider-input"][1]//input')
  /** Input to */
  readonly toInput = this.tooltip.locator('//div[@data-testid="range-slider-input"][2]//input')

}

/** Range filter inside all filters tooltip */
export class CSRangeFilterLocators extends BaseCSRangeFilterLocators{

  /** Delete filter button. Deletes filter and closes expanded */
  readonly deleteButton = this.tooltip.locator('//button[.="Delete"]')

}

/** Checkbox filter locators */
export class CSCheckboxFilterLocators extends BaseCSFilterLocators{
  constructor(page: Page, tooltip?: Locator) {
    super(page, tooltip)
  }

  /** Close button inside Filters tooltip. Cross "X" icon. Filters tooltip will be closed after click */
  readonly closeButton = this.tooltip.locator('//div[contains(@class, "ActionsPopoverContent-module__header")]//button')
  /** Filter item locator. Click to choose item/check item checkbox */
  readonly item = this.tooltip.locator('//div[contains(@class, "module__item")]')
  /** Apply filter button */
  readonly applyButton = this.tooltip.getByTestId('checkbox-list-submit-button')
  itemCheckbox(item: Locator){
    return item.locator('//input')
  } 
}
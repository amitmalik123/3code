import {Locator} from '@playwright/test'
import {TableLocators} from '../table.el'
import {CSTableFilterLocators} from './cs.filter.el'

export class ClientSectionTableLocators extends TableLocators {

  readonly tableEmptyState = this.page.locator('//div[contains(@class, "ClientSectionWidgetEmptyState-module__container")]')

  public filter(columnHeader: Locator){
    return new CSTableFilterLocators(this.page, columnHeader)
  }

  public mainRowActionButton(row: Locator): Locator {
    const abSelector = `button[title*="Actions"]`
    return row.locator(abSelector)
  }

  public nestedRowActionButton(row: Locator): Locator {
    const abSelector = `button[title*="Account Actions"]`
    return row.locator(abSelector)
  }

  public columnByPosition(row: Locator, position: number): Locator {
    const tdSelector = `td:nth-child(${position})`
    return row.locator(tdSelector)
  }

  /** Empty state locators when search or filtering gives no results */
  public filterEmptystateTitle = this.page.locator('//p[contains(@class, "ClientSectionWidgetEmptyState-module__title")]')
  public filterEmptystateMessage = this.page.locator('//p[contains(@class, "ClientSectionWidgetEmptyState-module__message")]')
  public filterEmptystateIcon = this.page.locator('//div[contains(@class, "ClientSectionWidgetEmptyState-module__icon")]')
}
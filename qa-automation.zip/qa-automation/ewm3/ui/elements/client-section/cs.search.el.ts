import {Locator, Page} from '@playwright/test'
import {SearchLocators} from '../search.el'

export class CSSearchLocators extends SearchLocators {
  constructor(page: Page, container: Locator) {
    super(page, container)
  }

  readonly magnifyingGlassButton  = this.page.locator('//*[contains(@class, "SearchInput-module__magnifierButton")]')

  public suggestHighlightedText(suggestOption: Locator): Locator {
    return suggestOption.locator('//*[contains(@class, "SuggestionWithSlug-module__overflowContainer") and not(contains(@class, "SuggestionWithSlug-module__right"))]//mark')
  }

  public suggestText(suggestOption: Locator): Locator {
    return suggestOption.locator('//*[contains(@class, "SuggestionWithSlug-module__overflowContainer") and not(contains(@class, "SuggestionWithSlug-module__right"))]//p')
  }

  public suggestAccountHighlightedText(suggestOption: Locator): Locator {
    return suggestOption.locator('//*[contains(@class, "SuggestionWithSlug-module__right")]//mark')
  }

  public suggestAccountText(suggestOption: Locator): Locator {
    return suggestOption.locator('//*[contains(@class, "SuggestionWithSlug-module__right")]//p')
  }
}
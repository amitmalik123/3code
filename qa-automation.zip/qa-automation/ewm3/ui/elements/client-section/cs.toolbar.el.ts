import {Locator, Page} from '@playwright/test'

export class CSToolbarLocators {

  constructor(protected page: Page, private container: Locator) {
  }

  /** Page title*/
  readonly title = this.container.locator('//*[@data-testid="toolbar-title"]')
  /** Toolbar metrics. Returns all toolbar metrics */
  protected readonly metrics = this.container.locator('*[data-testid*="toolbar.metrics"]')
  /** Toolbar metric names. Returns all toolbar metric names */
  readonly metricNames = this.page.locator('//div[contains(@data-testid, "app-container")]//div[contains(@data-testid, "toolbar-metric-label")]')
  /** Toolbar metric values. Returns all toolbar metric values */
  readonly metricValues = this.page.locator('//div[contains(@data-testid, "app-container")]//div[contains(@data-testid, "toolbar-metric-value")]')
  /** Toolbar actions. Returns locator with child history and toolbar actions menu buttons */
  protected readonly actionsWrapper = this.container.locator('//*[contains(@class, "Toolbar-module__actions")]')
  /** Toolbar history button. Suitcase icon. After click opens client navigation history */
  readonly historyButton = this.container.locator('//*[@data-testid="visit-history-button"]')
  /** Toolbar actions button. Meatballs icon. After click opens toolbar actions menu */
  readonly actionsMenuButton = this.page.locator('//*[@data-testid="toolbar-action-menu"]')
  /** Visit history menu */
  readonly navigationHistoryMenu = this.page.locator('//*[@role="menu" and contains(@class, "VisitHistory")]')
  /** Toolbar actions menu */
  readonly actionsMenu = this.page.locator('//*[@role="menu" and contains(@class, "Toolbar-module")]')
  /** Toolbar actions menu items */
  readonly actionsMenuItems = this.actionsMenu.locator('//*[@role="menuitem"]')
  /** Toolbar tooltip for long metric value */
  public metricTooltipValueByName(itemName:string){
    return this.page.locator(`//div[contains(@class, "TooltipPopper") and .//p[contains(., "${itemName}")]]`)
  }
  public metricValueByName(itemName:string){
    return this.page.locator(`//div[contains(@data-testid, "app-container")]//*[contains(@data-testid, "toolbar.metrics") and .//p[contains(., "${itemName}")]]//*[contains(@data-testid, "toolbar-metric-value")]/p`)
  }
}
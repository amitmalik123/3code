import { Locator, Page } from '@playwright/test'
export class TableLocators {

  constructor(protected page: Page, protected container: Locator) {
  }

  /** Main Table locator*/
  readonly table = this.container.locator('//div[not(contains(@class, "innerTableRoot"))]/table')
  readonly tableScrollContainer = this.table.locator('xpath=..')
  /** Main table headers Locators */
  readonly tableHeaders = this.container.locator('//div[not(contains(@class, "innerTableRoot"))]/table/thead//th[not(contains(@class, "TableCell-module__fillerCell"))]')
  readonly tableHeader = this.tableHeaders.locator('xpath=..')
  /** Only main table rows Locators */
  readonly rowsMainOnly = this.container.locator('//tr[@data-testid="table-row"]')
  readonly rowsMainWithNestedTable = this.container.locator('//tr[.//*[contains(@class, "clientSectionHouseholdColumns-module__caret")]]')
  readonly allNestedTableHeaders = this.container.locator('td[class*="cellWithChildTable"] table thead')
  readonly rowsNestedOnly = this.container.locator('//tr[@data-testid="nested-table-row"]')
  /** Main table rows and nested table ancestor rows(not an actual row from nested table) */
  readonly rowsAll = this.container.locator('//div[not(contains(@class, "innerTableRoot"))]/table/tbody/tr')
  readonly descendingSorting = this.page.locator('//*[contains(@data-testid, "sorter-desc")]')
  readonly ascendingSorting = this.page.locator('//*[contains(@data-testid, "sorter-asc")]')
  readonly headerColumn = this.page.locator('th')
  readonly tmsTableCell = this.page.locator('//span[@data-testid="table-cell-tms"]') 

  /**
     * @param row - row in the main table that contains expand button
     * @return Locator - expand nested table button for the specified row
     */
  public expandNestedTableButton(row: Locator): Locator {
    const expandSelector = 'div[class*="actionsStart"] svg'
    return row.locator(expandSelector)
  }
  
  /**
     * @param row - row in the main table that contains expanded(visible/opened) nested table
     * @return Locator - nested table locator that is located under the row(that passed in params)
     */
  public nestedTable(row: Locator): Locator {
    const tableSelector = 'td[class*="cellWithChildTable"] table'
    return row.locator(tableSelector)
  }
  /**
     * Sorting button inside column heading (in case when column is sortable)
     * @param tableHeader - table header (column name/title)
     * @return Promise<Locator> - promise of sorting button locator
     */
  public sortingButton(tableHeader: Locator): Locator {
    return tableHeader.locator('//*[contains(@class, "sort-handle")]')
  }

  /**
     * Dragging button inside column heading (in case when column is not fixed)
     * @param tableHeader - table header (column name/title)
     * @return Promise<Locator> - promise of drag button locator
     */
  public dragButton(tableHeader: Locator): Locator {
    return tableHeader.locator('//*[@data-testid="dragIcon"]')
  }

  /**
     * @param nestedTable - nested table locator
     * @return Locator - nested table column headings locators
     */
  public nestedTableHeaders(nestedTable: Locator): Locator {
    return nestedTable.locator('thead th')
  }

  /**
     * @param nestedTable - nested table locator
     * @return Locator - nested table column headings locators
     */
  public nestedTableRows(nestedTable: Locator): Locator {
    return nestedTable.locator('tbody tr')
  }

  /**
     * @param row - row locator in main/nested table
     * @return Locator - all column elements in corresponding row
     */
  public columns(row: Locator): Locator {
    return row.locator('td')
  }

  public cellContent(): Locator {
    return this.page.locator('//div[contains(@class, "titleWrapper")]')
  }

  public async isColumnHeaderFixed(tableHeader: Locator): Promise<boolean> {
    return await tableHeader.and(this.table.locator('//th[contains(@class, "TableCell-module__pinned")]')).count()>0
  }
}

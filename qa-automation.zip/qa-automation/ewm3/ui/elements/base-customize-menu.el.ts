import { Locator, Page } from '@playwright/test'

export abstract class BaseCustomizeMenuLocators {
  protected constructor(protected page: Page, protected container: Locator) {
  }

  /** Open menu button */
  public readonly openMenuButton: Locator
  /** Menu */
  readonly menu = this.page.locator('//*[@role="tooltip" and contains(@class, "module__popper")]')
  /** Customize columns form description (comes from CMS) */
  readonly description = this.page.locator('//div[contains(@class, "SortableMenu-module__heade")]/p[contains(@class, "description")]')
  /** Tooltip header */
  readonly header = this.page.locator('*[data-testid*="actions-popover-title-table-columns"]')
  /** Tooltip footer */
  readonly footerActions = this.page.locator('//div[contains(@class, "ActionsPopoverContent-module__footer")]')
  /** Reset to Default */
  readonly resetToDefault = this.footerActions.locator('//button[contains(@class, "reset")]')
  /** Cancel button */
  readonly cancel = this.footerActions.locator('//button[contains(@class, "Button-module__secondary")]')
  readonly closeButton = this.page.locator('*[data-testid*="actions-popover-close-button"]')
  /** Menu items (lines with column headings/names/titles and checkboxes)*/
  public readonly menuItems = this.page.locator('//li[contains(@class, "SortableMenuItem-module__container")]')

  /** Specific item from menu that filtered by text or RegExp
     * @param itemName - string or regular expression that matches with text inside specific item
     * @return Promise<Locator> - column item locator
     * */
  public menuItem(itemName:string|RegExp): Locator {
    return this.menuItems.filter({hasText: itemName})
  }
  
  /** Customize columns form option "All"*/
  public readonly allItem = this.page.locator('//label[contains(@data-testid, "all_checkbox_list")]')
  /** Specific item's checkbox from menu
     * @param menuItem - column option locator which checkbox you want to get
     * @return Promise<Locator> - column option checkbox locator. It can be used to get checkbox state (isChecked/isEnabled)
     * */

  public checkbox(menuItem:Locator) {
    return menuItem.locator('//div[contains(@class, "CheckboxBase-module__checkbox")]')
  }

  public dragButton(menuItem:Locator) {
    return menuItem.locator('//div[contains(@class, "module__drag-handle")]')
  }

  public dragButtonByName(itemName:string) {
    return this.page.locator(`//li[.//span[contains(., "${itemName}")]]/div[contains(@class, "SortableMenuItem-module__dragHandle")]`)
  }

  /** Menu item below the  blue line separator indicator */
  public readonly menuItemAfterSeparator = this.page.locator('//div[contains(@class, "dropSeparator")]/following-sibling::*[1]')
  /** Menu item above the  blue line separator indicator */
  public readonly menuItemBeforeSeparator = this.page.locator('//div[contains(@class, "dropSeparator")]/preceding-sibling::*[1]')
  /** Menu items Drop Separator: blue line separator indicator */
  public readonly menuDropSeparator = this.page.locator('//div[contains(@class, "dropSeparator")]')
}
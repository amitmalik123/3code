import { Page, expect, test } from '@playwright/test'
import { CookiesConfig } from '../../service-data/tile-config/privacy-popup.config'

export class PrivacyPopup {

  constructor(private page: Page) {
  }

  readonly privacyAndPreferencesPopup = this.page.locator('//div[@id="onetrust-pc-sdk"]')
  readonly savePreferencesButton = this.privacyAndPreferencesPopup.locator('//button[contains(@class, "save-preference-btn-handler")]')
  readonly allowAllButton = this.privacyAndPreferencesPopup.locator('//button[@id="accept-recommended-btn-handler"]')
  readonly linkMoreInformation = this.privacyAndPreferencesPopup.locator('//a[@class="privacy-notice-link"]')
  readonly rejectAllButton = this.privacyAndPreferencesPopup.locator('//button[@class="ot-pc-refuse-all-handler"]')
  readonly cookiePreferenceList = this.page.locator('//div[contains(@class, "ot-accordion-layout")]')
  readonly cookiePreference = this.cookiePreferenceList.locator('//h4[contains(@id, "header")]')

  async getDescriptionForPreference(preference: string) {
    return this.page.locator(`//h4[.="${preference}"]/ancestor::div[@data-optanongroupid]//p[contains(@class, "ot-category-desc")]`)
  }

  async getToggleForPreference(preference: string) {
    return this.page.locator(`//h4[.="${preference}"]//following-sibling::div[@class="ot-tgl"]`)
  }

  public async checkPopupAndClose() {
    await test.step('Handling the privacy and preferences pop up', async () => {
      if (await this.privacyAndPreferencesPopup.isVisible()) {
        await this.savePreferencesButton.click()
        await this.privacyAndPreferencesPopup.waitFor({state: 'hidden'})
      }
    })
  }

  async validateCookieOptions() {
    await test.step('Validating cookie options and descriptions show as expected', async () => {
      for (const preference of Object.values(CookiesConfig.preferences)) {
        await expect(this.cookiePreference.filter({hasText: preference.name}), 
          `Expecting preference "${preference.name}" to be visible`).toBeVisible()
        await this.cookiePreference.filter({hasText: preference.name}).click({force: true})
        const descriptionText = await (await this.getDescriptionForPreference(preference.name)).textContent()
        const description = descriptionText?.replace(/[\r\n]+/gi, ' ')
        expect(description, 
          `Validates preference description for cookie setting "${preference.name}"`).toContain(preference.description)
      }
      await expect(this.allowAllButton, 'Validating "allow all" button is within view in cookies modal').toBeVisible()
      await expect(this.linkMoreInformation, 'Validating link for more information is within view in cookies modal').toBeVisible()
      await expect(this.rejectAllButton, 'Validating "reject all" button is within view in cookies modal').toBeVisible()
      await expect(this.savePreferencesButton, 'Validating save preferences button is within view in cookies modal').toBeVisible()
    })
  }

  async toggleCookieOptions(preferences: string[] | string) {
    if (typeof(preferences) === 'string') {preferences = [preferences]}
    for (const preference of preferences) {
      await (await this.getToggleForPreference(preference)).scrollIntoViewIfNeeded()
      await test.step(`Toggling on cookie preference setting "${preference}" and closes the cookie modal`, async () => {
        await (await this.getToggleForPreference(preference)).click()
        await this.validateToggleIsChecked(preference, true)
      })
    }
    await this.checkPopupAndClose()
  }

  async validateToggleIsChecked(preference:string, checked: true | false) {
    await test.step(`Validate toggle for setting "${preference}" checked state is ${checked}`, async () => {
      const actualToggleState = await ((await this.getToggleForPreference(preference)).locator('//input')).isChecked()
      expect(actualToggleState).toEqual(checked)
    })
  }

}

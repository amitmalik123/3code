import {Locator, Page} from '@playwright/test'

export class PaginationLocators{
  constructor(protected page: Page, private container: Locator) {
  }

  /** Root locator. Pagination container */
  readonly paginationModule = this.container.locator('//div[contains(@class, "Pagination-module__full")]')

  /**
     * Text element. Displays current items numbers and total amount of items
     *
     * Example: "1-5 of 20"
     */
  readonly amount = this.paginationModule.getByTestId('text_undefined_pages')

  /** Rows per page selector*/
  readonly rowsPerPageSelector = this.paginationModule.getByTestId('select_undefined')

  /** Popup with List of rows per page options: 5, 10, 15 */
  readonly rowsPerPageOptionDropdown = this.page.locator('//div[not(contains(@style, "visibility: hidden;"))]//*[@role="listbox"]')

  /** Options locators: 5, 10, 15 */
  readonly rowsPerPageOptions = this.page.locator('//div[not(contains(@style, "visibility: hidden;"))]//li[@role="option"]')

  /**
     * **Usage:**
     * ```js
     * await this.rowsPerPageSelector.click();//open options dropdown
     * await this.rowsPerPageOption(5).click();//select specific option
     * ```
     * @param numberOfRows - number of rows per page: 5, 10, 15
     * @return Locator - option locator that corresponds passed numberOfRows
     * */
  public rowsPerPageOption(numberOfRows: string|number): Locator {
    return this.rowsPerPageOptions.filter({has: this.page.locator(`//span[.="${numberOfRows}"]`)})
  }

  /** Root locator for buttons. Pagination buttons container */
  private readonly paginationButtonsModule = this.paginationModule.locator('//div[contains(@class, "Pagination-module__buttons")]')

  /** Next page arrow button ">". Visible on every page except last */
  readonly nextArrowButton = this.paginationButtonsModule.getByTestId('button_undefined_next')

  /** Prev page arrow button "<". Visible on every page except first */
  readonly prevArrowButton = this.paginationButtonsModule.getByTestId('button_undefined_prev')

  /** List of page number buttons */
  readonly pageNumberButtons = this.paginationButtonsModule.locator('//*[contains(@data-testid, "page")]')

  /** Current page number buttons */
  readonly currentPageNumberButton = this.paginationButtonsModule.locator('//*[contains(@class, "ButtonSection-module__current")]')

  /**
     * @param pageNumber - page number
     * @return Locator - page number button locator that corresponds passed pageNumber
     * */
  public pageNumberButton(pageNumber: string|number): Locator {
    return this.pageNumberButtons.filter({ has: this.page.locator(`text="${pageNumber}"`) })
  }
}

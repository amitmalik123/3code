import test, { type Page, expect } from '@playwright/test'
import { GeneralUtils } from '../../../utils/generalUtils'
import { DashboardConfig } from '../../service-data/tile-config/dashboard.config'

export class DashboardElement {
  readonly dashboardSelected = this.page.locator('#input-dashboard-name')
  readonly dashboardListDropdownTrigger = this.page.locator('//div[contains(@class, "DashboardForm-module")]/div/div')
  readonly dashboardList = this.page.locator('#dashboard-form_dashboard-select')
  readonly dashboardListOptions = this.dashboardList.locator('//div[contains(@class, "DashboardSelectOption-module__option--")]')
  readonly dashboardListAddNewDashboard = this.dashboardList.locator('//button[.="+ Add New Dashboard"]')
  readonly dashboardListCopyDashboard = this.dashboardListOptions.locator('//div[contains(@class, "option-main-actions")]/div[1]')
  readonly dashboardListCopyDashboardButton = this.dashboardListCopyDashboard.locator('//button')
  readonly dashboardListDeleteDashboard = this.dashboardListOptions.locator('//div[contains(@class, "option-main-actions")]/div[2]/button')
  readonly dashboardListDashboardName = this.dashboardListOptions.locator('//div[contains (@class, "option-description")]/span')
  readonly dashboardActionSuccessMessage = this.page.locator('//div[contains(@class, "notificationSuccess")]//span')
  readonly dashboardActionModal = this.page.locator('//div[@data-testid="sentinelStart"]/following-sibling::div[contains(@class, "relative")]')
  readonly dashboardActionModalText = this.dashboardActionModal.locator('//p[contains(@class, "text")]')
  readonly dashboardCreatedName = this.dashboardList.locator('//div[contains(@class, "option-extra-actions") and .= "Set as default"]//preceding-sibling::div//span')
  readonly modalCancelOption = this.dashboardActionModal.getByTestId('button-modal-discard-cancel')
  readonly modalConfirmOption = this.dashboardActionModal.getByTestId('button-modal-discard-save')
  readonly dashboardBody = this.page.locator('//div[contains(@class, "DashboardPage-module__gridContainer")]/div[contains(@class, "items-center")]')
  readonly generalUtils: GeneralUtils

  constructor(public page: Page) {
    this.page = page
    this.generalUtils = new GeneralUtils(page)
  }

  async switchToDashboardInPosition(position: number) {
    await this.dashboardListDropdownTrigger.click()
    const dashboardName = await this.dashboardListDashboardName.nth(position).textContent()
    await test.step(`Switches to dashboard in position ${position}`, async () => {
      await this.dashboardListDashboardName.nth(position).click()
      await expect(this.dashboardSelected, `Validating dashboard ${dashboardName} was selected`).toHaveValue(`${dashboardName}`)
    })
  }

  async switchToDashboardByName(name: string) {
    await this.dashboardListDropdownTrigger.click()
    await test.step(`Switches to dashboard in with name ${name}`, async () => {
      await this.dashboardListDashboardName.filter({ hasText: name }).click()
      await expect(this.dashboardSelected, `Validating dashboard ${name} was selected`).toHaveValue(`${name}`)
    })
  }

  // Will check if copy dashboard buttons are disabled. Call this after max amount of dashboards have been created.
  async validateCannotCopyDashboards() {
    const dashboardsCount = await this.dashboardListDashboardName.count()
    for (let i = 0; i < dashboardsCount; i++) {
      await expect(this.dashboardListCopyDashboardButton.nth(i), 
        `Validating dashboard ${await this.dashboardListDashboardName.nth(i).textContent()} cannot be copied`).toBeDisabled()
      await expect(this.dashboardListCopyDashboard.nth(i),
        'Validating tooltip text for copy button').toHaveAttribute('aria-label', 'You cannot duplicate once you reach your limit', {ignoreCase: true})
    }
  }

  async copyDashboardInPosition(position: number) {
    const dashboardName = await this.dashboardListDashboardName.nth(position).textContent()
    await test.step(`Copying dashboard in position ${dashboardName}`, async () => {
      await this.dashboardListCopyDashboardButton.nth(position).click()
      await expect(this.dashboardActionModalText, 'Expecting dashboard modal text to include the name of the dashboard being copied')
        .toHaveText(`Are you sure you want to duplicate this Dashboard: ${dashboardName}?`, {ignoreCase: true})
      await this.modalConfirmOption.click()
    })
    await test.step(`Validates dashboard was copied`, async () => {
      await expect(this.dashboardActionSuccessMessage, 'Validating success notification icon for dashboard successfully copied')
        .toHaveText(DashboardConfig.dashboardMessages.dashboardCopied, {ignoreCase: true})
      await this.validateDashboardIsPresentInDashboardList(`[COPY] ${dashboardName}`)
    })
  }

  async deleteDashboardInPosition(position: number) {
    const dashboardName = await this.dashboardListDashboardName.nth(position).textContent()
    await test.step(`Deletes dashboard ${dashboardName} in position ${position}`, async () => {
      await this.dashboardListDeleteDashboard.nth(position).click()
      await expect(this.dashboardActionModalText, 'Expecting dashboard modal text to include the name of the dashboard being deleted')
        .toHaveText(`Are you sure you want to delete this Dashboard: ${dashboardName}?`, {ignoreCase: true})
      await this.modalConfirmOption.click()
    })
    await test.step(`Validates dashboard deletion`, async () => {
      await expect(this.dashboardActionSuccessMessage, 'Validating success notification icon for dashboard successfully deleted')
        .toHaveText(DashboardConfig.dashboardMessages.dashboardDeleted, {ignoreCase: true})
      await expect(this.dashboardListDashboardName.filter({hasText:`${dashboardName}`}),
        `Expecting dashboard ${dashboardName} to not be visible`).not.toBeVisible()
    })
  }

  async validateDashboardListSortedAlphabetically() {
    const dashboardsCount = await this.dashboardListDashboardName.count()
    const dashboardNames: string[] = []
    for (let i = 0; i < dashboardsCount; i++) {
      const dashboardName = await this.dashboardListDashboardName.nth(i).textContent()
      if (dashboardName === null) {
        throw new Error('Could not get dashboard name')
      } else {
        dashboardNames.push(dashboardName)
      }
    }
    expect(GeneralUtils.arrayIsAlphabeticallySorted(dashboardNames), 'Expecting dashboard list to be alphabetically sorted').toBeTruthy()
  }

  async validateDashboardIsPresentInDashboardList(givenDashboardName: string) {
    const dashboardsCount = await this.dashboardListDashboardName.count()
    for (let i = 0; i < dashboardsCount; i++) {
      const dashboardName = await this.dashboardListDashboardName.nth(i).textContent()
      // The name for dashboard is limited at 50 characters meaning any extra will be cut from the final name
      if (dashboardName === givenDashboardName.substring(0, 50)) {
        return await expect(this.dashboardListDashboardName.nth(i), 
          `Expecting dashboard with name ${givenDashboardName} to be in the dashboard list`).toBeVisible()
      } else {
        continue
      }
    }
    throw new Error(`Could not find dashboard with name "${givenDashboardName}" in the dashboard list`)
  }

  // Validates that the currently selected dashboard was named
  // The name for dashboard is limited at 50 characters meaning any extra will be cut from the final name
  async validateSelectedDashboardName(givenDashboardName: string) {
    if (givenDashboardName.length >= 50) {
      const cutDashboardName = givenDashboardName.substring(0, 50)
      await expect(this.dashboardSelected, 
        `Expecting current dashboard to be renamed ${cutDashboardName} instead of ${givenDashboardName} due to 50 character limitation`).toHaveValue(cutDashboardName)
    } else {
      await expect(this.dashboardSelected,  
        `Expecting current dashboard to be named ${givenDashboardName}`).toHaveValue(givenDashboardName)
    }
  }

  async validateDashboardIsEmpty() {
    await expect(this.dashboardBody, 'Expecting empty dashboard message to appear').toContainText('This Dashboard is Empty', {useInnerText: true, ignoreCase: true})
    await expect(this.dashboardBody, 'There is no "Use sample dashboard" link below "This Dashboard is Empty" stub').not.toContainText('Use Sample Dashboard', {useInnerText: true, ignoreCase: true})
  }

  async createNewDashboard() {
    await this.dashboardListAddNewDashboard.click()
    await test.step(`Validates dashboard was created`, async () => {
      await expect(this.dashboardActionSuccessMessage, 'Validating success notification icon for dashboard successfully created')
        .toHaveText(DashboardConfig.dashboardMessages.dashboardCreated, {ignoreCase: true})
    })
    const newDashboardName = await this.dashboardCreatedName.textContent()
    await this.dashboardListDropdownTrigger.click()
    if ( newDashboardName === null ) { throw new Error('Could not get dashboard name') }
    return newDashboardName
  }
}

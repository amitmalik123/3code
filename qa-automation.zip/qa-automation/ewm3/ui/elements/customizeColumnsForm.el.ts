import { Locator, Page } from '@playwright/test'
import {BaseCustomizeMenuLocators} from './base-customize-menu.el'

export class CustomizeColumnsFormLocators extends BaseCustomizeMenuLocators{
  constructor(protected page: Page, protected container: Locator) {
    super(page, container)
  }

  /** Gear button. Opens customize columns form. **Important** if you want to make any action with menu
     * then you need to click gear button to trigger form appearance */
  public readonly openMenuButton = this.container.locator('//div[contains(@class, "Widget-module__headline")]//div/div/button[@aria-haspopup="menu"]')
  /** Restore to default button. Click to restore table and customize columns form state to default*/
  public readonly restoreToDefaultButton = this.page.locator('//button[contains(@class, "reset")]')
}

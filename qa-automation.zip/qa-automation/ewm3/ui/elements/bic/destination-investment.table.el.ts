import { Locator } from '@playwright/test'
import { TableLocators } from '../table.el'

export class DestinationInvestmentTableLocators extends TableLocators {
  readonly expandedStrategy = this.container.locator('//div[contains(@class, "RadioSelectorTable-module__caretCol")]')
  readonly rowsWithoutNestedTable= this.container.locator('//div[contains(@class, "Radio-module__radioRoot")]/input/ancestor::tr')
  readonly rowsWithNestedTable = this.container.locator('//div[contains(@class, "RadioSelectorTable-module__caretCol")]/ancestor::tr')
  readonly nestedTableElement = '//span[@data-testid="nested-table-cell-customExpandedData"]/div/div' // Can use this selector with some prefix that point on specific nested table
  readonly hoverTooltip = this.page.locator('//div[contains(@class, "TooltipPopper")]')
  readonly favoriteStrategyButton = this.container.locator('//td[contains(@class, "ProductSelectStep-module__colFavourite")]//button')
  readonly selectedFavoriteStrategy = '//*[contains(@class, "ProductSelectStep-module__favourite")]' // Can use this selector with some prefix that point on specific favorite strategy button
  readonly unSelectedFavoriteStrategy = '//*[@stroke-linecap = "round"]' // Can use this selector with some prefix that point on specific favorite strategy button
  readonly sortingFavoriteStrategyButton = this.container.locator('//button[contains(@class, "ProductSelectStep-module__favourite")]')
  readonly investmentMin = this.container.locator('//span[@data-testid="table-cell-investmentMin"]') 
 
  public nestedTable(row: Locator): Locator {
    return row.locator('//following-sibling::tr//td[contains(@class, "cellWithChildTable")]//table') 
  }

  public radioButton(row: Locator): Locator {
    return row.locator('//input')
  }

} 

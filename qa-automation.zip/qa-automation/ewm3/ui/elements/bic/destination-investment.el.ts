import { Locator, Page, expect } from '@playwright/test'
import { PaginationFeature } from '../../features/pagination.feature'
import { SearchFeature } from '../../features/search.feature'
import { DestinationInvestmentTableFeature } from '../../features/bic/destination-investment.table.feature'
import { BicBaseTab } from './bic-base-tab.el'

export class DestinationInvestmentWidget extends BicBaseTab{

  constructor(protected page:Page, public baseContainer: Locator) { 
    super(page, baseContainer)
  }

  readonly table = new DestinationInvestmentTableFeature(this.page, this.baseContainer)
  readonly pagination = new PaginationFeature(this.page, this.baseContainer, this.table, { hasRowsPerPage: false, rowsPerPageCount: 10 })
  readonly search = new SearchFeature(this.page, this.baseContainer, this.table)

  readonly headerFromStrategyName = this.header.getByText('From:').locator('//span')
  readonly tmsTableHeaderImage = this.baseContainer.locator('//div[contains(text(), "TMS")]/parent::div').getByRole('img')
  readonly tmsIcon = this.tmsTableHeaderImage.locator('//parent::div')
  readonly favoriteImages = this.baseContainer.locator('//button[contains(@class, "Step-module__favourite")]').getByRole('img')
  readonly unselectStrategyNotification = this.page.locator('//div[@role="tooltip"]//div[@data-testid="snackbar-message-content"]')

  public async verifyEmptyStateElementsVisibility () {
    await expect(this.emptyStateImage, 'Verify that empty state image is visible').toBeVisible()
    await expect(this.emptyStateTitle, 'Verify empty state title text').toHaveText('No match, keep searching')
    await expect(this.emptyStateTip, 'Verify empty state tip text').toHaveText('Try searching for Strategy Name')
  }
}

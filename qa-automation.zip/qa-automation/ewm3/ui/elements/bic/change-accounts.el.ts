import { Locator, Page, expect, test } from '@playwright/test'
import { PaginationFeature } from '../../features/pagination.feature'
import { SearchFeature } from '../../features/search.feature'
import { DestinationInvestmentWidget } from './destination-investment.el'
import { AccountsToChangeTableFeature } from '../../features/bic/change-accounts.table.feature'
import { BicAccountData, TableRow } from '../../features/table.feature'
import { BicConfig } from '../../../service-data/tile-config/bic.config'
import { BicBaseTab } from './bic-base-tab.el'
import { UiTextStylesAssert } from '../../../../utils/UIComponentsStateAssert'
import { GeneralStyles } from '../../../service-data/generalStyles'

export class AccountsToChangeWidget extends BicBaseTab{

  constructor(protected page:Page, public baseContainer: Locator) { 
    super(page, baseContainer)
  }

  private readonly destinationInvestmentWidget = new DestinationInvestmentWidget(this.page, this.baseContainer) 
  readonly table = new AccountsToChangeTableFeature(this.page, this.baseContainer)
  readonly pagination = new PaginationFeature(this.page, this.baseContainer, this.table, { hasRowsPerPage: false, rowsPerPageCount: 10 })
  readonly search = new SearchFeature(this.page, this.baseContainer, this.table)

  readonly accountsTab = this.baseContainer.locator('//button[text()="Accounts"]')
  readonly selectedAccountsTab = this.baseContainer.locator('//button[text()="Selected Accounts"]')
  readonly inelegibleAccountsTab = this.baseContainer.locator('//button[text()= "Ineligible Accounts"]')
  readonly emptyStateContent = this.baseContainer.locator(('//div[contains(@class, "ErrorState-module__content")]'))
  readonly emptyStateImage = this.emptyStateContent.getByRole('img')
  readonly emptyStateTitle = this.emptyStateContent.locator('//h2')
  readonly emptyStateTip = this.emptyStateContent.locator('//p')
  readonly notificationBar = this.page.locator('//div[@data-testid="notification-bar"]') 
  readonly ineligibleAccountQuantityTextInNotificationBar = this.notificationBar.locator('//span[contains(text(), "was found ineligible")]')
  readonly wholeTextInNotificationBar = this.notificationBar.locator('//*[contains(text(), "see details")]')
  readonly tmsNotification = this.page.locator('//div[@data-testid="snackbar-message-local"]') 
  readonly tmsNotificationText = this.tmsNotification.locator('//span[contains(text(), "Tax Management Services")]')
  readonly tmsNotificationBar = this.tmsNotification.locator('//div[@data-testid="snackbar-message-content"]') 
  readonly tmsNotificationBarIcon = this.tmsNotification.locator('//*[@data-testid="snackbar-message-icon"]')
  readonly allocatedInfo = this.baseContainer.locator(('//div[contains(@aria-label, "Investment changes")]'))
  readonly accountsCounters = this.accountsTab.locator('//following-sibling::div')
  readonly allocationTooltipRow = this.page.locator(('//div[contains(@class, "columns-module__popperRow")]'))
  readonly errorTooltip = this.page.locator('//div[contains(@id, "snackbar-message-local-popup")]//div[@data-testid="snackbar-message-content"]') 
  readonly errorTooltipIcon = this.errorTooltip.locator('//*[@data-testid="snackbar-message-icon"]') 
  readonly errorTooltipText = this.errorTooltip.locator('//span[contains(text(), "Select an Account to proceed.")]')
  readonly exportButton = this.baseContainer.locator(('//div[contains(@class, "BicModal-module__actionButtonCol")]//button[contains(@class, "Button-module__tertiary")]'))
  readonly accountTitle = this.baseContainer.locator('//span[@data-testid="table-column-header-accountName"]') 
  readonly status = this.baseContainer.locator('//span[@data-testid="table-column-header-status"]') 
  readonly regType = this.baseContainer.locator('//span[@data-testid="table-column-header-regType"]') 
  readonly accountNumber = this.baseContainer.locator('//span[@data-testid="table-column-header-accountNumber"]') 
  readonly tms = this.baseContainer.locator('//span[@data-testid="table-column-header-tms"]') 
  readonly amountAllocated = this.baseContainer.locator('//span[@data-testid="table-column-header-marketValue"]') 
  readonly allocated = this.baseContainer.locator('//span[@data-testid="table-column-header-allocation"]') 

  async waitAccountsToChangeWindowIsReady() {
    await expect(this.baseContainer, 'Expect that Accounts to Change modal window is visible').toBeVisible()
    await expect(this.title, 'Assert title text').toHaveText('Select Your Accounts to Change')
    await expect(this.destinationInvestmentWidget.table.locators.rowsMainOnly.first(), 'Waiting first row in table').toBeVisible()
  }

  async openAccountsToChangeWindowViaMainTable() {
    await this.destinationInvestmentWidget.table.checkRadioButtonOnMainTable(0) 
    await expect(this.destinationInvestmentWidget.nextButton, 'Assert that Next button is enabled').toBeEnabled()
    const investmentMinValue = await this.destinationInvestmentWidget.table.locators.investmentMin.nth(0).textContent()
    await this.destinationInvestmentWidget.nextButton.click()
    await this.waitAccountsToChangeWindowIsReady()
    return investmentMinValue
  }

  async openAccountsToChangeWindowViaNestedTable() {
    await this.destinationInvestmentWidget.table.expandNestedTable()
    await this.destinationInvestmentWidget.table.checkRadioButtonOnNestedTable(0, 0)
    await expect(this.destinationInvestmentWidget.nextButton, 'Assert that Next button is enabled').toBeEnabled()
    await this.destinationInvestmentWidget.nextButton.click()
    await this.waitAccountsToChangeWindowIsReady()
  }  

  /**
 * Finds the row index with the lowest Risk Profile value from the main row,
 * selects the corresponding radio button in the main table, and proceeds to the Accounts to Change window
 *
 * This method performs the following steps:
 * 1. Iterates over each row in the provided table data
 * 2. Extracts the Risk Profile values from each row
 * 4. Selects the radio button in the row with the lowest Risk Profile value
 * 5. Asserts that the Next button is enabled
 * 6. Clicks the Next button to proceed to the Accounts to Change window
 *
 * @param {TableRow[]} tableData - The table data containing multiple rows
 * @returns {Promise<void>} A promise that resolves when the process is completed
 * @throws {Error} Throws an error if no row with a valid Risk Profile value is found
 */
  public async openAccountsToChangeWindowViaMainTableWithLowestRiskProfile(tableData: TableRow[]): Promise<void> {
    await test.step('Find row index with the lowest Risk Profile main row value', async () => {
      let minRiskProfile = 7
      let rowIndexWithMinRiskProfile = -1
      let index = 0

      tableData.forEach((row) => {
        const riskProfileCell = row.cell.find(cell => cell.columnName === BicConfig.destinationInvestmentColumnNames.riskProfile)
        if (riskProfileCell) {
          const riskProfileValues = riskProfileCell.value.split(/[, ]+/).map(value => value.trim())

          if (riskProfileValues.length === 1 && /^\d+$/.test(riskProfileValues[0])) {
            const num = parseInt(riskProfileValues[0], 10)
            if (!isNaN(num) && num < minRiskProfile) {
              minRiskProfile = num
              rowIndexWithMinRiskProfile = index
            }
            index++
          }
        }
      })

      if (rowIndexWithMinRiskProfile === -1) {
        throw new Error('No main row was found in the table')
      }

      await this.destinationInvestmentWidget.table.checkRadioButtonOnMainTable(rowIndexWithMinRiskProfile)
      await expect(this.destinationInvestmentWidget.nextButton, 'Assert that Next button is enabled').toBeEnabled()
      await this.destinationInvestmentWidget.nextButton.click()
      await this.waitAccountsToChangeWindowIsReady()
    })
  }

  /**
 * Navigates to a specific tab by clicking on it and verifies that the tab is in a selected state
 *
 * @param tabLocator - Locator object that targets the specific tab element to interact with
 */
  public async movingToSpecificTab(tabLocator: Locator) {
    await test.step(`Moving To Specific Tab`, async () => {
      await tabLocator.click()
      await expect(tabLocator, 'Expecting that Specific Tab has selected state').toHaveClass(/activeTab/)  
    })
  }

  public async verifyEmptyStateSelectedTabElementsVisibility () {
    await expect(this.emptyStateImage, 'Verify that empty state image is visible').toBeVisible()
    await expect(this.emptyStateTitle, 'Verify empty state title text').toHaveText('No accounts selected')
    await expect(this.emptyStateTip, 'Verify empty state tip text').toHaveText('Select an Account to continue')
  }

  /**
 * Verifies the font styles of ineligible account titles in the table
 * For each index in the `indexes` array, the following styles are checked:
 * - font-weight
 * - font-family
 * - font-size
 * - color
 *
 * If the `indexes` parameter is not provided, the method will check the styles for the first available rows (up to 10 rows)
 *
 * @param {number[]} [indexes] - Array of row indices in the table for which the title styles should be checked. Defaults to indices 0 to 9 or the available number of rows if less than 10
 */
  public async ineligibleAccountsTitleStyle(indexes?: number[]) {
  // Determine the number of rows in the table
    const rowCount = await this.table.locators.tableRows.count()
    // Default to checking up to the first 10 rows if indexes are not provided
    if (!indexes) {
      indexes = Array.from({ length: Math.min(10, rowCount) }, (_, i) => i)
    }

    for (let i = 0; i < indexes.length; i++) {
      const accountsTitleLocator = this.table.locators.tableRows.nth(indexes[i]).locator(this.table.locators.tableCellTitle)

      await test.step(`Verify Ineligible Accounts title font styles for row index ${indexes[i]}`, async () => {
        await UiTextStylesAssert.fontWeight(accountsTitleLocator, GeneralStyles.fontLight)
        await UiTextStylesAssert.fontName(accountsTitleLocator, GeneralStyles.fontFamilyRobotoSansSerif)
        await UiTextStylesAssert.fontSize(accountsTitleLocator, GeneralStyles.fontSize14)
        await UiTextStylesAssert.fontColor(accountsTitleLocator, GeneralStyles.colorTextDisabled)
      })
    }
  }

  public async verifyAllocatedTooltipText() {
    await this.allocatedInfo.hover()
    expect(await this.infoTooltip.textContent(), `Verify that tooltip text is correct`).toEqual('Investment changes will be traded to Target Allocation')
  }

  public async verifyConvergingAccountsCounters() {
    const accountsCounterValue = parseInt(await this.accountsCounters.first().textContent() ?? '0')
    const selectedAccountsCounterValue = parseInt(await this.accountsCounters.nth(1).textContent() ?? '0')
    const ineligibleAccountsCounterValue = parseInt(await this.accountsCounters.nth(2).textContent() ?? '0')

    expect(accountsCounterValue, `Verify that the number of Accounts in the counters are equal to the sum of Selected Accounts and Ineligible Accounts`)
      .toEqual(selectedAccountsCounterValue + ineligibleAccountsCounterValue)
  }
  
  /**
 * Note: Before using this method, ensure that you have clicked on the Allocated link to display the tooltip.
 * 
 * Verifies the allocation values for the specified allocated percentage.
 * 
 * This method performs the following steps:
 * 1. Finds the corresponding account in the API data based on the given allocated percentage.
 * 2. Verifies the allocation values for each sleeve in the tooltip.
 * 3. Verifies that the total API allocation for all sleeves equals 100%
 * 
 * @param {string} value - The allocated percentage value to verify, in the format "50.00%".
 * @param {BicAccountData} accountData - The account data from the API response.
 * @throws {Error} If no matching account is found for the given allocation value.
 */
  public async verifySleevesDetails(value: string, accountData: BicAccountData) {
    await test.step(`Verify allocation values for the allocated percentage: ${value}`, async () => {

      await test.step('Verify the allocation values for each sleeve in the tooltip', async () => {
        const targetAllocation = parseFloat(value.replace('%', '')) / 100
        const account = accountData.data.find(acc => acc.allocation === targetAllocation)!

        expect(account, `Expect that matching account was found for allocation value: ${value}`).toBeTruthy() 

        let totalApiAllocation = 0

        for (let i = 1; i <= account.sleeves.length; i++) {
          const sleeve = account.sleeves[i - 1]
          const productNameLocator = this.allocationTooltipRow.nth(i).locator('//p').first()
          const allocationLocator = this.allocationTooltipRow.nth(i).locator('//p').nth(1)

          const uiProductName = await productNameLocator.textContent()
          const uiAllocation = parseFloat((await allocationLocator.textContent())!.replace('%', ''))

          const apiProductName = sleeve.productName
          const apiAllocation = sleeve.allocation * 100
          totalApiAllocation += apiAllocation

          await test.step(`Verify allocation value for product: ${apiProductName}`, async () => {
            expect.soft(uiProductName?.trim(), `Verify that Product name should match for allocation value: ${value}`).toEqual(apiProductName)
            expect.soft(uiAllocation, `Verify that Allocation value for product ${apiProductName} should match`).toEqual(apiAllocation)
          })
        }
        expect(totalApiAllocation, 'Expect that total API allocation for all sleeves should be equal 100%').toEqual(100)
      })
    })
  }

  public async verifyEmptyStateElementsVisibility () {
    await expect(this.emptyStateImage, 'Verify that empty state image is visible').toBeVisible()
    await expect(this.emptyStateTitle, 'Verify empty state title text').toHaveText('No match, keep searching')
    await expect(this.emptyStateTip, 'Verify empty state tip text').toHaveText('Try searching for Account Title, Status, Account # or TMS')
  }

}

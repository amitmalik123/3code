import { Locator, Page, expect } from '@playwright/test'
import { ConfirmAndSubmitTableFeature } from '../../features/bic/confirm-and-submit.table.feature'
import { BicBaseTab } from './bic-base-tab.el'

export class ConfirmAndSubmitWidget extends BicBaseTab{

  constructor(protected page:Page, public baseContainer: Locator) { 
    super(page, baseContainer)
  }

  readonly confirmAndSubmitTable = new ConfirmAndSubmitTableFeature(this.page, this.baseContainer)

  readonly tmsTableHeaderImage = this.baseContainer.locator('//div[contains(text(), "TMS")]/parent::div').getByRole('img')
  readonly tmsTooltip = this.page.locator('//div[contains(@class, "TooltipPopper")]')
  readonly tmsIcon = this.tmsTableHeaderImage.locator('//parent::div')
  readonly submitButton = this.baseContainer.locator('//button[contains(text(), "Submit Request")]')  
  readonly checkBox = this.baseContainer.locator('//input/parent::div[contains(@class, "CheckboxBase")]')
  readonly circularLoaderIcon = this.baseContainer.locator('//div[@data-testid="circular-loader"]')

  async waitConfirmAndSubmitWidgetIsReady() {
    await expect(this.baseContainer, 'Expect that Accounts to Change modal window is visible').toBeVisible()
    await expect(this.title, 'Assert title text').toHaveText('Confirm and Submit')
    await expect(this.confirmAndSubmitTable.locators.rowsMainOnly.first(), 'Waiting first row in table').toBeVisible()
  }

}

export class SubmissionSuccessfulWidget extends BicBaseTab{

  constructor(protected page:Page, public baseContainer: Locator) { 
    super(page, baseContainer)
  }

  readonly closeButton = this.baseContainer.locator('//button[contains(text(), "Close")]') 
  readonly submissionMessage = this.baseContainer.locator('//div[@data-testid="snackbar-boundary"]') 
  readonly trackingCenterLink = this.baseContainer.locator('//a[contains(text(), "Tracking Center")]') 

  /**
 * Asserts that the submission message text is correct based on the number of selected accounts.
 * If more than one account is selected, the message will indicate multiple accounts have been submitted.
 * If only one account is selected, the message will indicate a single account has been submitted.
 * If the number of selected accounts is less than 1, an error will be thrown.
 *
 * @param {number} selectedAccounts - The number of selected accounts.
 * @throws Will throw an error if `selectedAccounts` is less than 1.
 */
  public async assertSubmissionMessageText(selectedAccounts: number) {
    if (selectedAccounts < 1) {
      throw new Error('The number of selected accounts must be at least 1')
    }
    const submissionMessageText = selectedAccounts > 1 
      ? `${selectedAccounts} accounts have been successfully submitted for processing. To view the status for each request, go to the Tracking Center.` 
      : '1 account have been successfully submitted for processing. To view the status for each request, go to the Tracking Center.'
  
    await expect(this.submissionMessage, 'Verify that submission message text is correct').toHaveText(submissionMessageText)
  }

}

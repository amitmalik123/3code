import { Locator, Page, expect, test } from '@playwright/test'
import { BicBaseTab } from './bic-base-tab.el'

export class SuitabilityCheckWidget extends BicBaseTab{

  constructor(protected page:Page, public baseContainer: Locator) { 
    super(page, baseContainer)
  }

  readonly progressBar = this.baseContainer.locator('//div[contains(@class, "ProgressBar-module__container")]')
  readonly description = this.baseContainer.locator(('//p[contains(@class, "module__description")]')) 
  readonly xButton = this.baseContainer.locator(('//button[contains(@class, "DialogCloseButton")]')) 
  readonly progressBarSelector = 'div[class*="ProgressBar-module__indicator"]'

  /**
 * Verifies that the progress bar increments from 0% to 100%, then window remains visible for 3 seconds, and then disappears
 *
 * @returns {Promise<void>} A promise that resolves when the progress bar has been verified to increment from 0% to 100%, remain visible for 3 seconds, and then disappear
 * @throws {Error} Throws an error if the progress bar does not increment correctly, does not remain visible for approximately 3 seconds after reaching 100%, or does not disappear afterward
 */
  public async verifyProgressBarIncrement(): Promise<void> {
    let previousWidthPercentage = 0
    const maxWidth = (await this.getStyleInfo(this.progressBar)).width
    let widthPercentage = 0

    await test.step('Verify progress bar increments from 0% to 100%', async () => {
      while (widthPercentage < 100) {
        const widthInPixels = await test.step('Get current width of the progress bar in pixels', async () => {
          return await this.page.evaluate((selector) => {
            const element = document.querySelector(selector) as HTMLElement
            return element ? parseInt(getComputedStyle(element).width, 10) : 0
          }, this.progressBarSelector)
        })
  
        widthPercentage = await test.step('Convert width from pixels to percentage', async () => {
          return (widthInPixels / maxWidth) * 100
        })
  
        await test.step('Assert current width percentage is greater than or equal to previous and less than or equal to 100', async () => {
          expect(widthPercentage).toBeGreaterThanOrEqual(previousWidthPercentage)
          expect(widthPercentage).toBeLessThanOrEqual(100)
        })
  
        previousWidthPercentage = widthPercentage
  
        // Adding a delay to prevent excessive resource usage
        await this.page.waitForTimeout(70)
      }
  
      await test.step('Ensure the final width is 100%', async () => {
        expect(previousWidthPercentage).toBe(100)
      })
  
      await test.step('Wait for 3 seconds (approximately) and assert the progress bar is still visible', async () => {
        await this.page.waitForTimeout(2600)
        await expect(this.page.locator(this.progressBarSelector)).toBeVisible()
      })
  
      await test.step('Assert that the progress bar disappears after 3 seconds (approximately)', async () => {
        await expect(this.page.locator(this.progressBarSelector)).toBeHidden({ timeout: 400 })
      })
    })
  }

}

import { Locator, Page } from '@playwright/test'

export class BicBaseTab {
  
  constructor(protected page:Page, public baseContainer: Locator) { 
  }

  readonly xButton = this.baseContainer.locator('//div[contains(@class, "closeButtonCol")]/button')
  readonly backButton = this.baseContainer.locator('//button[.="Back"]')
  readonly title = this.baseContainer.locator('//div[contains(@class, "Dialog-module__titleCol")]')
  readonly cancelButton = this.baseContainer.locator(('//button[text()= "Cancel"]'))
  readonly nextButton = this.baseContainer.locator('//button[contains(text(), "Next")]') 
  readonly reviewButton = this.baseContainer.locator('//button[text()="Review"]')
  readonly infoTooltip = this.page.locator('//div[contains(@class, "TooltipPopper")]')
  readonly header = this.baseContainer.locator('//div[contains(@class, "ProductSelectionHeader-module__container")]')
  readonly emptyStateContent = this.baseContainer.locator(('//div[contains(@class, "ErrorState-module__content")]'))
  readonly emptyStateImage = this.emptyStateContent.getByRole('img')
  readonly emptyStateTitle = this.emptyStateContent.locator('//h2')
  readonly emptyStateTip = this.emptyStateContent.locator('//p')

  /**
 * This method calculates the width, height, and translation values (transformX and transformY) based on the computed style
 *
 * @param locator - Locator object targeting the element whose styles are to be retrieved
 * @returns A promise that resolves to an object containing width, height, and transform properties
 */
  async getStyleInfo(locator: Locator) {
    await locator.waitFor({ state: 'visible' })
    // Evaluate the element to compute its styles directly in the browser context
    const computedStyle = await locator.evaluate(el => getComputedStyle(el))

    // Parse width and height from the computed style, converting them to integers
    const width = parseInt(computedStyle.width, 10)
    const height = parseInt(computedStyle.height, 10)

    // Extract the translate values from the transform property using a regex pattern
    // This pattern matches 'translate' values assuming the unit is pixels (px)
    const transformMatch = /translate\((\d+)px, (\d+)px\)/.exec(computedStyle.transform)
    const transformX = transformMatch ? parseInt(transformMatch[1], 10) : 0 // Default to 0 if not found
    const transformY = transformMatch ? parseInt(transformMatch[2], 10) : 0 // Default to 0 if not found

    return { width, height, transformX, transformY }
  }
}
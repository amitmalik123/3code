import { Locator } from '@playwright/test'
import { TableLocators } from '../table.el'

export class AccountsToChangeTableLocators extends TableLocators {
 
  readonly tableRows = this.container.locator('//tr[@data-testid="table-row"]')
  readonly tableHeader = this.container.locator('//thead[@data-testid="table-thead"]') 
  readonly tableCellTitle = this.page.locator('//span[@data-testid="table-cell-accountName"]//span[contains(@class, "FormControlLabel")]//span')
  readonly allocatedPercentLocator = (value: string) => this.container.locator(`//span[contains(text(), "${value}")]/parent::div`)
  readonly exportButton = this.container.locator(('//div[contains(@class, "BicModal-module__actionButtonCol")]//button[contains(@class, "Button-module__tertiary")]'))

  public checkbox(row: Locator): Locator {
    return row.locator('//input/parent::div')
  }

  public checkboxInput(row: Locator): Locator {
    return row.locator('//input')
  }
}

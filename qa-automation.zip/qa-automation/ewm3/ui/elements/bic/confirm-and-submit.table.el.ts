import { TableLocators } from '../table.el'

export class ConfirmAndSubmitTableLocators extends TableLocators {

} 

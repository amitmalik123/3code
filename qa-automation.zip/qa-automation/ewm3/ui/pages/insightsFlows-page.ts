import {InsightsLitePage} from './insightsLite-page'
import {Page} from '@playwright/test'

export class InsightsFlowsPage extends InsightsLitePage{

  constructor(page: Page) {
    super(page, '/flows')
  }
}
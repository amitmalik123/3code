import {ClientSectionHouseholdPage} from './client-section-household-page'
import {Page, expect, test} from '@playwright/test'
import {IndividualHouseholdConfig} from '../../service-data/client-section-configs/individual-household.config'
import {EWM3Config } from '../../service-data/config'
import {ToolbarMetricsMock} from '../../../ewm3/ui/mocks/toolbar-metrics-mock'

export class ClientSectionIndividualHouseholdPage extends ClientSectionHouseholdPage{

  constructor(page: Page) {
    super(page)

    this.pageConfig = IndividualHouseholdConfig
    this.responsePromise = page.waitForResponse(response =>
      response.url().includes(IndividualHouseholdConfig.ENDPOINTS.client) && response.status() === 200,
    {timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM}
    )
  }

  protected readonly toolbarContainer = this.page.locator('//div[contains(@class, "HouseholdPage-module__headerToolbar") and .//button[contains(., "Goals")]]')
  protected readonly baseContainer = this.page.locator('//*[contains(@class, "HouseholdPage-module__contentContainer")]')
  
  protected clientId = ''

  async goto(url = '') {
    if (this.clientId === ''){
      const houseHoldPage = new ClientSectionHouseholdPage(this.page)
      await houseHoldPage.goto()
      await houseHoldPage.waitPageIsReady()
      this.clientId = await houseHoldPage.returnHHMainTableApiParamByClientNum('id', 0)
    }
    await this.page.goto(this.url + `/${this.clientId}`+ url)
  }

  public async setSpecificClient (clientId: string){
    this.clientId = clientId
  }

  async waitPageIsReady() {
    await test.step('Waiting until the page is ready for use', async () => {
      await expect(this.toolbarContainer).toBeVisible()
      await this.privacyPopup.checkPopupAndClose()
    })
  }

  public async replaceToolbarMetricsWithMockLongValues () {
    await test.step(`Replace HH Toolbar Metric values with long Mock data`, async () => {
      const toolbarMetricsMock = new ToolbarMetricsMock
      const routeString = '**'+IndividualHouseholdConfig.ENDPOINTS.toolbar+'**'
      await this.page.route(routeString, async route => {
        const json = toolbarMetricsMock.longMetricsValueIndividualHH
        await route.fulfill({json})
      })
    })
  }

  public returnToolbarMetricsWithEllipsis(): string[] {
    return [IndividualHouseholdConfig.TOOLBAR_METRICS_CONFIG.find(metric => metric.uid==='ap-clients-indhh-pv-lb')?.name??'', IndividualHouseholdConfig.TOOLBAR_METRICS_CONFIG.find(metric => metric.uid==='ap-clients-indhh-cr-lb')?.name??'']

  }
}

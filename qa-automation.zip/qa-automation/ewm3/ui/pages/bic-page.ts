import { BaseWebPage } from '../../../base/base-page'
import { type Page, expect } from '@playwright/test'
import { DestinationInvestmentWidget } from '../elements/bic/destination-investment.el'
import { AccountsToChangeWidget } from '../elements/bic/change-accounts.el'
import { EWM3Config } from '../../service-data/config'
import { SuitabilityCheckWidget } from '../elements/bic/suitability-check.el'
import { ConfirmAndSubmitWidget, SubmissionSuccessfulWidget } from '../elements/bic/confirm-and-submit.el'

export class BicPage extends BaseWebPage{
  
  constructor(page: Page, private catchResponses: boolean = false, public readonly openedStrategyIndex: number = 0) {
    super(page, '/dashboard/bic')
  }

  readonly productsResponsePromise = this.catchResponses? this.page.waitForResponse(response =>
    response.url() === EWM3Config.BASE_URL + '/proposal/api/v1/bic/products' && response.status() === 200, { timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM }): undefined

  readonly baseContainer = this.page.locator('//div[contains(@class, "BicModal-module__dialogBox")]')
  readonly header = this.baseContainer.locator('//div[contains(@class, "ProductSelectionHeader-module__container")]')
  readonly destinationInvestmentWidget = new DestinationInvestmentWidget(this.page, this.baseContainer)
  readonly accountsToChangeWidget = new AccountsToChangeWidget(this.page, this.baseContainer)
  readonly suitabilityCheckWidget = new SuitabilityCheckWidget(this.page, this.baseContainer)
  readonly confirmAndSubmitWidget = new ConfirmAndSubmitWidget(this.page, this.baseContainer)
  readonly submissionSuccessfulWidget = new SubmissionSuccessfulWidget(this.page, this.baseContainer)
  
  async waitPageIsReady() {
    await expect(this.destinationInvestmentWidget.baseContainer, 'Expect that Destination Investment modal window is visible').toBeVisible()
    await expect(this.destinationInvestmentWidget.title, 'Assert title text').toHaveText('Select Your Destination Investment')
    await expect(this.destinationInvestmentWidget.table.locators.rowsMainOnly.first(), 'Waiting first row in table').toBeVisible()
  }

  public async getHeaderToStrategyName(): Promise<string> { 
    const headerToStrategyName: string = await this.header.getByText('To:').locator('//span').innerText()
    // Need to cut off last word from "To Strategy" because the last design is in updated phase and now works incorrectly
    return headerToStrategyName.substring(0, headerToStrategyName.lastIndexOf(' '))
  }

  public async getHeaderNewPlatformFeeValue(): Promise<string> { 
    return await this.header.getByText('New Platform Fee:').locator('//span').innerText() 
  } 
}


import { BaseWebPage } from '../../../base/base-page'
import { PrivacyPopup } from '../elements/privacyPopup'
import { Page, expect, test } from '@playwright/test'
import { TileManager } from '../elements/tile-manager'
import { Header } from '../elements/header.el'

export abstract class InsightsLitePage extends BaseWebPage {

  readonly manageTilesMenuButton = this.page.locator('[data-testid="button-actions-edit"]')
  readonly closeManageTilesMenuButton = this.page.locator('[data-testid="sidebar-close-button"]')
  readonly advisorInsightsTitle = this.page.locator('//h3[text()="Advisor Insights"]')
  readonly allAdvisorIdsButton = this.page.locator('//button[@data-testid="button-advisor-list"]')
  readonly emptyDashboardMessage = this.page.locator('//h2[contains(text(), "This Dashboard")]')
  readonly toggleLocatorByTileName = (name: string) => this.page.locator(`//span[contains(text(), "${name}")]/following-sibling::span/input`)

  //Sub Pages
  readonly privacyPopup = new PrivacyPopup(this.page)
  readonly tileManager = new TileManager(this.page)
  readonly header = new Header(this.page)

  protected constructor(page: Page, url: string) {
    super(page, '/insights' + url)
  }

  async waitPageIsReady() {
    await test.step('Waiting until the page is ready for use', async () => {
      await expect(this.manageTilesMenuButton).toBeAttached()
      //temporary fix. As of now popup appears every time page is loaded
      await this.privacyPopup.checkPopupAndClose()
    })
  }
  async openTileManager() {
    await this.manageTilesMenuButton.click()
    await test.step('Waiting for tile manager to be opened', async () => {
      await expect(this.tileManager.manageTilesTitle).toBeVisible()
      await expect(this.tileManager.manageTilesWholeModule).toBeVisible()
    })
  }
  async closeTileManager() {
    await expect(this.tileManager.manageTilesWholeModule).toBeVisible()
    await this.closeManageTilesMenuButton.click()
    await test.step('Waiting for tile manager to be closed', async () => {
      await expect(this.tileManager.manageTilesWholeModule).toBeHidden()
    })
  }

  // Will enable (check) all toggles one by one if they were unchecked 
  async enableAllTilesTogglesOneByOne() {
    const count = await this.tileManager.sidebarAllToggles.count()
    for (let i = 1; i < count; i++) {
      if (!await this.tileManager.sidebarAllToggles.nth(i).isChecked()) {
        await this.tileManager.sidebarAllToggles.nth(i).check()
      }
    }
  }
  // Will disable (uncheck) all toggles one by one if they were checked 
  async disableAllTilesTogglesOneByOne() {
    const count = await this.tileManager.sidebarAllToggles.count()
    for (let i = 1; i < count; i++) {
      if (await this.tileManager.sidebarAllToggles.nth(i).isChecked()) {
        await this.tileManager.sidebarAllToggles.nth(i).uncheck()
      }
    }
  }
  // Will start from whatever state the toggles were at the moment this method is called: if they were checked - will uncheck, if they were unchecked - will check
  // Needs to be used in conjoint with enableAllTilesTogglesOneByOne method first
  async toggleAllTilesOneByOne() {
    const count = await this.tileManager.sidebarAllToggles.count()
    for (let i = 1; i < count; i++) {
      if (await this.tileManager.sidebarAllToggles.nth(i).isChecked()) {
        await this.tileManager.sidebarAllToggles.nth(i).uncheck()
      } else {
        await this.tileManager.sidebarAllToggles.nth(i).check()
      }
    }
  }
  // Validates the visibility of specified tiles
  async validateTileVisibleInInsightsLight(visible: boolean, tiles: string[] | string) {
    if (typeof(tiles) === 'string') {tiles = [tiles]}
    for (const tile of tiles) {
      const locator = this.page.locator(`//h3[contains(text(), "${tile}")]`)
      expect(await locator.isVisible(), `Expecting for tile "${tile}" visibility to be ${visible}`).toEqual(visible)
    }
  }
  /**
 * Checks or unchecks a toggle based on its associated tile name and the desired state
 * 
 * If `toggleEnabling` is true, the function ensures the toggle is checked (enabled)
 * if false, it ensures the toggle is unchecked (disabled)
 * After changing the toggle state, it asserts the expected state to confirm the action
 * 
 * @param {boolean} toggleEnabling - Determines whether the toggle should be enabled (true) or disabled (false)
 * @param {string} name - The name associated with the toggle
 * 
 * @example
 * // To check (enable) the toggle for a tile named "Example Tile"
 * await checkToggleByName(true, "Example Tile")
 */
  async checkToggleByName(toggleEnabling: boolean, name: string) { 
    if (toggleEnabling) {
      await this.toggleLocatorByTileName(name).check()
      await expect(this.toggleLocatorByTileName(name), `Expecting that toggle for tile ${name} is checked`).toBeChecked()
    } else {
      await this.toggleLocatorByTileName(name).uncheck()
      await expect(this.toggleLocatorByTileName(name), `Expecting that toggle for tile ${name} is unchecked`).not.toBeChecked()
    }
  }

}
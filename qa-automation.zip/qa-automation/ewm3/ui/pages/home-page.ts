import { type Page, expect, test } from '@playwright/test'
import { FeesTile } from '../tiles/fees.tile'
import { ClientTile } from '../tiles/clients-and-accounts.tile'
import { NetFlows } from '../tiles/net-flows.tile'
import { AdvisorBenefitsTile } from '../tiles/advisor-benefits.tile'
import { AssetsOnPlatformTile } from '../tiles/assets-on-platform.tile'
import { DashboardElement } from '../elements/dashboard.el'
import { MarketingCarousel } from '../elements/marketing.el'
import { StatusAndTrackingTile } from '../tiles/status-and-tracking.tile'
import { InvestmentsTile } from '../tiles/investments.tile'
import { GeneralUtils } from '../../../utils/generalUtils'
import { BaseWebPage } from '../../../base/base-page'
import { PrivacyPopup } from  '../elements/privacyPopup'
import { TileManager } from '../elements/tile-manager'
import { DashboardConfig } from '../../service-data/tile-config/dashboard.config'
import { UiElementsStylesAssert, UiTextStylesAssert } from '../../../utils/UIComponentsStateAssert'
import { Header } from '../elements/header.el'
import { FontFormatArgument } from '../../service-data/tile-config/types.config'
import { ModalFeature } from '../elements/modal-screen.feature'
import { EWM3Config } from '../../service-data/config'
import { SampleDashboardMock } from '../mocks/sample-dashboard-mock'
import { MonitoringV1 } from '../../api/monitoring/v1/endpoints'

export class HomePage extends BaseWebPage {
  readonly manageTilesMenuButton = this.page.locator('[data-testid="button-actions-edit"]')
  readonly welcomeMessage = this.page.locator('//h3[text()="Welcome"]')

  // Tiles on main screen
  readonly tileAdvisorBenefits = new AdvisorBenefitsTile(this.page)
  readonly tileAssetsOnPlatform = new AssetsOnPlatformTile(this.page)
  readonly tileClientList = new ClientTile(this.page)
  readonly tileFees = new FeesTile(this.page)
  readonly tileInvestments = new InvestmentsTile(this.page)
  readonly tileNetFlows = new NetFlows(this.page)
  readonly tileStatusAndTracking = new StatusAndTrackingTile(this.page)
  
  // Subpages
  readonly header = new Header(this.page)
  readonly privacyPopup = new PrivacyPopup(this.page)
  readonly tileManager = new TileManager(this.page)
  readonly dashboard = new DashboardElement(this.page)
  readonly marketing = new MarketingCarousel(this.page)
  readonly modalScreen = new ModalFeature(this.page)
  readonly generalUtils = new GeneralUtils(this.page)
  
  constructor(page: Page) {
    super(page, '/')
  }

  async waitPageIsReady() {
    await test.step('Waiting until the page is ready for use', async () => {
      await expect(this.manageTilesMenuButton).toBeAttached({timeout: 60000})
      //temporary fix. As of now popup appears every time page is loaded
      await this.privacyPopup.checkPopupAndClose()
    })
  }

  async openTileManager() {
    await this.manageTilesMenuButton.click()
    await test.step('Waiting for tile manager to be opened', async () => {
      await expect(this.tileManager.manageTilesTitle).toBeVisible()
      await expect(this.tileManager.openedManageTilesMenu).toBeVisible()
    })
  }

  async validateHomeButtonHoverOptions() {
    await test.step('Validates dropdown options: My dashboard and classic homepage options', async () => {
      const colors = DashboardConfig.colors
    
      await this.header.myDashboardDropdownOption.hover()
      await UiElementsStylesAssert.backgroundColor(colors.myDashboardHoverColor, this.header.myDashboardDropdownOption)

      await this.header.classicHomePageDropdownOption.hover()
      await UiElementsStylesAssert.backgroundColor(colors.classicDashboardHoverColor, this.header.classicHomePageDropdownOption)
    })
  }

  async validateFontFormats(args: FontFormatArgument[]) {
    for (const arg of args) {
      await UiTextStylesAssert.fontSize(arg.elementLocator, arg.font.fontSize)
      await UiTextStylesAssert.fontName(arg.elementLocator, arg.font.fontFamily)
    }
  }

  async pressKey(key: string) {
    await this.page.keyboard.press(key)
  }

  // Validates the visibility of specified tiles
  async validateTileVisibleOnDashboard(visible: boolean, tiles: string[] | string) {
    if (typeof(tiles) === 'string') { tiles = [tiles] }
    for (const tile of tiles) {
      const locator = this.page.locator(`//h3[contains(text(), "${tile}")]`)
      expect(await locator.isVisible(), `Expecting for tile "${tile}" visibility to be ${visible}`).toEqual(visible)
    }
  }

  async validateDefaultDashboard(envTiles) {
    await test.step('Validate tiles that should be defaulted on are toggled', async () => {
      for (const tile of envTiles) {
        for (const [key, state] of Object.entries(tile.toggledOnSample)) {
          if (EWM3Config.PLATFORM !== key)
            continue
          if (state) {
            await this.validateTileVisibleOnDashboard(true, tile.name)
            await this.tileManager.validateToggleChecked(true, tile.name)
          } else {
            await this.validateTileVisibleOnDashboard(false, tile.name)
            await this.tileManager.validateToggleChecked(false, tile.name)
          }
          break
        }        
      }
    })
  }

  public async replaceSampleDashboard() {
    const endpoint = new MonitoringV1().cms.resources.widgetsSettings
    await test.step(`Sends mock to define sample dashboard`, async () => {
      await this.page.route(endpoint.route, async route => {
        await route.fulfill({ json: SampleDashboardMock.modifiedSampleDashboard })
      })
    })
  }

}

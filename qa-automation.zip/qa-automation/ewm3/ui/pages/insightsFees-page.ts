import { InsightsLitePage } from './insightsLite-page'
import { Page } from '@playwright/test'

export class InsightsFeesPage extends InsightsLitePage {

  constructor(page: Page) {
    super(page, '/fees')
  }

}
import {BaseWebPage} from '../../../base/base-page'
import {PaginationFeature} from '../features/pagination.feature'
import {CSSearchFeature} from '../features/client-section/cs.search.feature'
import {Header} from '../elements/header.el'
import {Footer} from '../elements/footer.el'
import {CustomizeColumnsFormFeature} from '../features/customize-columns-form.feature'
import {CSCustomizeColumnsFormLocators} from '../elements/client-section/cs.customizeColumnsForm.el'
import {ClientSectionTableFeature} from '../features/client-section/cs.table.feature'
import {expect, test} from '@playwright/test'
import {PrivacyPopup} from  '../elements/privacyPopup'
import {CSToolbarFeature} from '../features/client-section/cs.toolbar.feature'
import {CSNavBarFeature} from '../features/client-section/cs.navbar.feature'
import {CSFilterTooltipFeature} from '../features/client-section/filter/tooltip/cs.filter-tooltip.feature'
import {Response} from '@playwright/test'
import {CSPageConfig} from '../../service-data/client-section-configs/types'
import { ScrollFeature } from '../features/scroll.feature'

export interface BaseClientSectionMockData {
  get data()
  get longTitleClient()
  get itemsForFilter()
}

export abstract class BaseClientSectionPage extends BaseWebPage{
  public responsePromise: Promise<Response>
  public cmsResponsePromise: Promise<Response>
  public pageConfig: CSPageConfig
  public responseMock: BaseClientSectionMockData

  protected readonly baseContainer = this.page.locator('//*[contains(@class, "ClientsLayout")]')
  protected readonly toolbarContainer = this.page.locator('//*[contains(@class, "Toolbar-module__container")]')

  readonly header = new Header(this.page)
  readonly footer = new Footer(this.page)
  readonly table = new ClientSectionTableFeature(this.page, this.baseContainer)
  readonly pagination = new PaginationFeature(this.page, this.baseContainer, this.table)
  readonly search = new CSSearchFeature(this.page, this.baseContainer, this.table)
  readonly customizeColumns = new CustomizeColumnsFormFeature(
    this.page,
    this.baseContainer,
    this.table,
    new CSCustomizeColumnsFormLocators(this.page, this.baseContainer)
  )
  readonly privacyPopup = new PrivacyPopup(this.page)
  readonly toolbar = new CSToolbarFeature(this.page, this.toolbarContainer)
  readonly navbar = new CSNavBarFeature(this.page, this.baseContainer)
  readonly filter = new CSFilterTooltipFeature(this.page, this.baseContainer)
  readonly scroll = new ScrollFeature(this.page)

  public tab(tabName:string){
    return this.page.locator('//*[@role="tab"]').filter({hasText: tabName})
  }

  async waitPageIsReady() {
    await test.step('Waiting until the page is ready for use', async () => {
      const table = this.table.locators.table
      const emptyState = this.table.locators.filterEmptystateTitle

      await expect(table.or(emptyState)).toBeVisible()
      await this.privacyPopup.checkPopupAndClose()
    })
  }

  /**
 * Method that returns 'from' and 'to' values by given apiParam from Households api for the nasted table
 * @param apiParam - field name in API response 
 * @param useMockData - false by default, if true consume data from mocks and generate values only from the 1-st record, otherwise consume data from api response 
 * @param returnEmptyResult - false by default, if true generate values that absent for any Client and Account
 * @param useNestedTable - false by default, if true generate values considering data from the nested table
 */
  public async returnFromAndToValuesByApiParam (apiParam: string, useMockData: boolean = false, returnEmptyResult: boolean = false, useNestedTable: boolean = false): Promise<string[]> {
    const valuesArray: (number | string)[] = [] 
    let responseBody
    if (useMockData) {
      responseBody = this.responseMock.itemsForFilter 
    } else {
      responseBody = await (await this.responsePromise).json()
    }
    const data = responseBody?.data.data
    if (!useNestedTable || returnEmptyResult){
      const mainValuesArray = data.map(item => item[apiParam]).filter(value => value !== null && value !== undefined && ((typeof value === 'number' && value>=0)||(typeof value === 'string')))
      valuesArray.push(...mainValuesArray)
    }

    if (useNestedTable){
      for (const clientRecord of data) {
        const nestedRecords = clientRecord.accounts
        const currentValuesArray = nestedRecords.map(item => item[apiParam]).filter(value => value !== null && value !== undefined && ((typeof value === 'number' && value>=0)||(typeof value === 'string')))
        valuesArray.push(...currentValuesArray)
      }
    }
  
    if (valuesArray.length===0){
      throw new Error(`Can't find not null values for ${apiParam} fileld in the API response`)
    }
  
    if (returnEmptyResult){
      return this.returnFromAndToValuesFromArrayEmptyResult(valuesArray as number[])
    } else {
      if (useMockData) {
        return [valuesArray[0].toString(), valuesArray[0].toString()]
      } else {
        return this.returnFromAndToValuesFromArray(valuesArray)
      }
    }
  }

  public returnFromAndToValuesFromArray (valuesArray: Array<string | number>): string[] {
    if (valuesArray.length===0){
      return []
    }
    const uniqueArray = valuesArray.filter((value, index) => valuesArray.indexOf(value) === index)
    const sortArr =uniqueArray.sort((a, b) => a - b)
      
    // to get a further filtered result that is not very numerous, we take values from the middle of the array with a small spread
    let i = Math.round(sortArr.length/2)-2
    i = i < 0 ? 0 : i
    let j = Math.round(sortArr.length/2)+2
    j = j > (sortArr.length-1)? sortArr.length-1:j
    const finalResult = [
      sortArr[i].toString(), 
      sortArr[j].toString()
    ]
    return finalResult
  }

  public returnFromAndToValuesFromArrayEmptyResult (valuesArray: Array<number>): string[] {
    let finalResult

    function findIndexWithDifferenceGreaterThanThreshold(array: number[], threshold: number): number | undefined {
      for (let i = 0; i < array.length - 1; i++) {
        const difference = array[i + 1] - array[i]
        if (difference >= threshold && array[i]>0 ) {
          return i
        }
      }
      return undefined
    }

    function getDiff (item: number): number {
      let diff: number
      if (Math.abs(item)<=1) {
        diff = 0.001
      }
      else if (Math.abs(item)>1 && Math.abs(item)<=10){
        diff = 0.1
      }
      else {
        diff = 1
      }
      return diff
    }

    if (valuesArray.length===0){
      return []
    }
    const uniqueArray = valuesArray.filter((value, index) => valuesArray.indexOf(value) === index)
    const sortArr =uniqueArray.sort((a, b) => a - b)
    const itemIndexWithDifference = findIndexWithDifferenceGreaterThanThreshold(sortArr, 0.002)
    
    if (itemIndexWithDifference!== undefined){
      const diff = getDiff(sortArr[itemIndexWithDifference])
      finalResult = [
        (sortArr[itemIndexWithDifference]+diff).toString(), 
        (sortArr[itemIndexWithDifference+1]-diff).toString()
      ]
    } else {
      const lastSortElement = sortArr.length-1
      const diff = getDiff(sortArr[lastSortElement])
      finalResult = [
        (sortArr[lastSortElement]+diff).toString(), 
        (sortArr[lastSortElement]+2*diff).toString()
      ]
    }
    return finalResult
  }

  abstract returnCmsMetricLabels (): Promise<string[]>
  abstract replaceToolbarMetricsWithMockLongValues ()
  abstract returnToolbarMetricsWithEllipsis(): string[]
  abstract returnColumnNameToOpenIndividualPage(): string
}
import {type Page, test} from '@playwright/test'
import {BaseClientSectionPage} from './base-client-section-page'
import {EWM3Config } from '../../service-data/config'
import {AccountsConfig} from '../../service-data/client-section-configs/accounts.config'
import {ToolbarMetricsMock} from '../../../ewm3/ui/mocks/toolbar-metrics-mock'
import {AccountsListMock} from '../../../ewm3/ui/mocks/accounts-list-mock'
import {BackendAccountData} from '../features/client-section/cs.search.feature'

export class ClientSectionAccountsPage extends BaseClientSectionPage{
  
  constructor(page: Page) {
    super(page, '/clients/accounts')

    this.responsePromise = page.waitForResponse(response =>
      response.url().includes(AccountsConfig.ENDPOINTS.accounts) && response.status() === 200,
    {timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM}
    )
    this.cmsResponsePromise = page.waitForResponse(response =>
      response.url().endsWith(AccountsConfig.ENDPOINTS.cms) && response.status() === 200,
    {timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM}
    )
    this.pageConfig = AccountsConfig
    this.responseMock = new AccountsListMock
  }

  /**
 * Method that returns given apiParam from Accounts api
 * @param apiParam - field name in API response 
 * @param accountNum - account serial number in API response
 */
  public async returnAccountsApiParamByAccountNum (apiParam: string, accNum: number): Promise<string> {
    const responseBody = await (await this.responsePromise).json()
    const data = responseBody?.data.data
    const selectedElement = data[accNum]
    if (selectedElement){
      return selectedElement[apiParam]
    }else {
      throw new Error(`Can't find appropriate Account by num ${accNum} in API Response`)
    }
  }

  public async getAccountList (): Promise<BackendAccountData[]> {
    const backendAccountsData: BackendAccountData[] = [] 
    const responseBody = await (await this.responsePromise).json()
    const accountRecords = responseBody?.data.data
    for (const accountRecord of accountRecords) {
      const title:string = accountRecord.title
      const accountNumber: string|null = accountRecord.bankAccountNumber??null
      const backendAccountRecord: BackendAccountData = {
        title,
        accountNumber
      }
      backendAccountsData.push(backendAccountRecord)
    }
    return backendAccountsData
  }

  public async returnCmsMetricLabels (): Promise<string[]> {
    const cmsMetricLabels: string[] = []
    const responseBody = await (await this.cmsResponsePromise).json()
    const data = responseBody?.data
    if (data){
      const selectedElement = data.find(item => item.uid === 'ap-clients')
      const selectedTab = selectedElement?.tabs.find(item => item.uid === 'ap-clients-ac')
      const toolbarLabels = selectedTab?.labels
      toolbarLabels?.forEach(cmslabel => cmsMetricLabels.push(cmslabel.value))
      return cmsMetricLabels
    }else {
      throw new Error(`Can't find data in Account Metrics cms API Response`)
    }
  }

  public async replaceToolbarMetricsWithMockLongValues () {
    await test.step(`Replace Accounts Toolbar Metric values with long Mock data`, async () => {
      const toolbarMetricsMock = new ToolbarMetricsMock
      await this.page.route('**'+AccountsConfig.ENDPOINTS.toolbar, async route => {
        const json = toolbarMetricsMock.longMetricsValueHHAccounts
        await route.fulfill({json})
      })
    })
  }

  public async replaceResponseWithLongValues () {
    await test.step(`Replace Clients Backend Response with long Mock data`, async () => {
      const clientResponseMock = new AccountsListMock
      const routeString = '**'+AccountsConfig.ENDPOINTS.accounts+'**'
      await this.page.route(routeString, async route => {
        const json = clientResponseMock.longTitleClient
        await route.fulfill({json})
      })
    })
  }

  public async replaceResponseWithFilterValues () {
    await test.step(`Replace Clients Backend Response with long Mock data`, async () => {
      const clientResponseMock = new AccountsListMock
      const routeString = '**'+AccountsConfig.ENDPOINTS.accounts+'**'
      await this.page.route(routeString, async route => {
        const json = clientResponseMock.itemsForFilter
        await route.fulfill({json})
      })
    })
  }

  public returnToolbarMetricsWithEllipsis(): string[] {
    return [AccountsConfig.TOOLBAR_METRICS_CONFIG.find(metric => metric.uid === 'ap-clients-ac-pf-lb')?.name ?? '', AccountsConfig.TOOLBAR_METRICS_CONFIG.find(metric => metric.uid === 'ap-clients-ac-pa-lb')?.name ?? '']
  }

  public returnColumnNameToOpenIndividualPage(): string {
    return AccountsConfig.COLUMN_NAMES.account_title as string
  }
}
import { InsightsLitePage } from './insightsLite-page'
import { Page } from '@playwright/test'
import { LineChartBaseTile } from '../tiles/insights-lite/line-chart-tile'
import { InsightsConfig } from '../../service-data/tile-config/insights.config'

export class InsightsAssetsPage extends InsightsLitePage {

  readonly aopTotalMktValue = new LineChartBaseTile(this.page, InsightsConfig.assetsTilesInfo.marketValue.name)

  constructor(page: Page) {
    super(page, '/assets')
  }

}
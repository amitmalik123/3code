import {ClientSectionAccountsPage} from './client-section-accounts-page'
import {Page, expect, test} from '@playwright/test'
import {IndividualAccountConfig} from '../../service-data/client-section-configs/individual-account.config'
import {EWM3Config } from '../../service-data/config'
import {ToolbarMetricsMock} from '../../../ewm3/ui/mocks/toolbar-metrics-mock'

export class ClientSectionIndividualAccountPage extends ClientSectionAccountsPage{
  constructor(page: Page) {
    super(page)

    this.pageConfig = IndividualAccountConfig
    this.responsePromise = page.waitForResponse(response =>
      response.url().includes(IndividualAccountConfig.ENDPOINTS.account) && response.status() === 200,
    {timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM}
    )
  }
  protected readonly toolbarContainer = this.page.locator('//div[contains(@class, "AccountPage-module__headerToolbar") and .//button[contains(., "Account")]]')
  protected readonly baseContainer = this.page.locator('//*[contains(@class, "AccountPage-module__contentContainer")]')
  
  protected accountId = ''

  async goto(url = '') {
    if (this.accountId === ''){
      const accountPage = new ClientSectionAccountsPage(this.page)
      await accountPage.goto()
      await accountPage.waitPageIsReady()
      this.accountId = await accountPage.returnAccountsApiParamByAccountNum('id', 0)
    }
    await this.page.goto(this.url + `/${this.accountId}`+ url)
  }

  public async setSpecificAccount (clientId: string){
    this.accountId = clientId
  }

  async waitPageIsReady() {
    await test.step('Waiting until the page is ready for use', async () => {
      await expect(this.toolbarContainer).toBeVisible()
      await this.privacyPopup.checkPopupAndClose()
    })
  }

  public async replaceToolbarMetricsWithMockLongValues () {
    await test.step(`Replace HH Toolbar Metric values with long Mock data`, async () => {
      const toolbarMetricsMock = new ToolbarMetricsMock
      const routeString = '**'+IndividualAccountConfig.ENDPOINTS.toolbar+'**'
      await this.page.route(routeString, async route => {
        const json = toolbarMetricsMock.longMetricsValueIndividualAccount
        await route.fulfill({json})
      })
    })
  }

  public returnToolbarMetricsWithEllipsis(): string[] {
    return [IndividualAccountConfig.TOOLBAR_METRICS_CONFIG.find(metric => metric.uid==='ap-accounts-indac-av-lb')?.name??'', IndividualAccountConfig.TOOLBAR_METRICS_CONFIG.find(metric => metric.uid==='ap-accounts-indac-cr-lb')?.name??'', IndividualAccountConfig.TOOLBAR_METRICS_CONFIG.find(metric => metric.uid==='ap-accounts-indac-ban-lb')?.name??'']

  }
}

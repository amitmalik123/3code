import { type Page, expect } from '@playwright/test'
import { BaseWebPage } from '../../../base/base-page'
import { Platforms } from '../../service-data/config'

export class LoginPage extends BaseWebPage {
  readonly userNameField = this.page.locator('#username')
  readonly passwordField = this.page.locator('#password')
  readonly submitButton = this.page.locator('#kc-login')

  // Cheetah login page locators
  readonly userNameFieldCheetah = this.page.locator('//input[@autocomplete="username"]')
  readonly passwordFieldCheetah = this.page.locator('//input[@autocomplete="current-password"]')
  readonly submitButtonCheetah = this.page.locator('//button[@type="submit"]')

  constructor(page: Page) {
    super(page, '/')
  }

  async waitPageIsReady() {
    await expect(this.userNameField).toBeAttached()
  }

  async makeLogin(userName: string, password: string) {
    await this.goto()
    if (process.env.PLATFORM === Platforms.CHEETAH) {
      this.loginCheetah(userName, password)
    } else { this.loginStandard(userName, password) }
  }

  async loginStandard(userName: string, password: string) {
    await this.userNameField.fill(userName)
    await this.passwordField.fill(password)
    await this.submitButton.click()
  }

  async loginCheetah(userName: string, password: string) {
    await this.userNameFieldCheetah.fill(userName)
    await this.passwordFieldCheetah.fill(password)
    await this.submitButtonCheetah.click()
  }

}

import { test } from './base-ui-fixture'
import {HomePage} from '../ui/pages/home-page'
import {EWM3ApiHelpers} from '../api/api-helpers'
import {DashboardElement} from '../ui/elements/dashboard.el'
import {EWM3Config} from '../service-data/config'
import {MonitoringV1} from '../api/monitoring/v1/endpoints'
export * from '@playwright/test'

export const distinctDashboardTest = test.extend({

  homePage: async ({ apiHelpers, page, }, use) => {
    const parallelIndex = test.info().parallelIndex
    await apiHelpers.createMaxDashboards()
    const endpoint = new MonitoringV1().dashboard.dashboardsByUser
    const responsePromise = page.waitForResponse(response =>
      response.url().includes(endpoint.route) && response.status() === 200,
    { timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM }
    )
    const homePage = new HomePage(page)
    const dashboardPage = new DashboardElement(page)
    await homePage.goto()
    await homePage.waitPageIsReady()
    const responseBody = await (await responsePromise).json()
    const dashboardApiDataArray: any[] = []
    for (const dashboard of responseBody.data) {
      if (!dashboard.isDefault){
        dashboardApiDataArray.push(dashboard)
      }
    }
    let dashboardIndex = parallelIndex
    if (!dashboardApiDataArray[parallelIndex]?.name) dashboardIndex = 0
    const dashboardName = dashboardApiDataArray[dashboardIndex].name
    await dashboardPage.dashboardListDropdownTrigger.click()
    await dashboardPage.dashboardListDashboardName.filter(
      {hasText: `${dashboardName}`}
    ).click()
    await use(homePage)
  },

  apiHelpers: async ({ requestContext}, use) => {
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    await use(apiHelpers)
  },

  initDashboardData: async ({ requestContext}, use) => {
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    await apiHelpers.initDashboardsData()
    await use(apiHelpers)
  },

  removeAllWidgets: async ({ requestContext}, use) => {
    const parallelIndex = test.info().parallelIndex
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    await apiHelpers.createMaxDashboards()
    const responseBody = await (await apiHelpers.endpoints.getAllUsersDashboards()).json()
    const dashboardApiDataArray: any[] = []
    for (const dashboard of responseBody.data) {
      if (!dashboard.isDefault){
        dashboardApiDataArray.push(dashboard)
      }
    }
    let dashboardIndex = parallelIndex
    if (!dashboardApiDataArray[parallelIndex]?.name) dashboardIndex = 0
    const dashboardId = dashboardApiDataArray[dashboardIndex].id
    await apiHelpers.removeAllWidgetsFromDashboard(dashboardId)
    await use(apiHelpers)
  },

  addAllWidgets: async ({ requestContext}, use) => {
    const parallelIndex = test.info().parallelIndex
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    await apiHelpers.createMaxDashboards()
    const responseBody = await (await apiHelpers.endpoints.getAllUsersDashboards()).json()
    const dashboardApiDataArray: any[] = []
    for (const dashboard of responseBody.data) {
      if (!dashboard.isDefault){
        dashboardApiDataArray.push(dashboard)
      }
    }
    let dashboardIndex = parallelIndex
    if (!dashboardApiDataArray[parallelIndex]?.name) dashboardIndex = 0
    const dashboardId: string = dashboardApiDataArray[dashboardIndex].id
    await apiHelpers.addAllWidgetsOnDashboard({dashboardId:dashboardId})
    await use(apiHelpers)
  },

})

export { expect } from '@playwright/test'
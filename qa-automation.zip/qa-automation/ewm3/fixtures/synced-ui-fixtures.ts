import { test } from './base-ui-fixture'
import { EWM3Config } from '../service-data/config'
import {HomePage} from '../ui/pages/home-page'
import {LoginPage} from '../ui/pages/login-page'
import {request as apiContext} from 'playwright-core'
export * from '@playwright/test'

/** This fixture should be user in case if your test is supposed to change server state,
 * for example you need to delete all dashboards.
 * So this fixture helps you to isolate such test cases isolation
 * and helps you to avoid issues when one test affecting another one
 * */
export const syncedTest = test.extend<object, { workerStorageState: string}>({
  // Use the same storage state for all tests in this worker.
  storageState: ({ workerStorageState }, use) => use(workerStorageState),

  // Authenticate once per worker with a worker-scoped fixture.
  workerStorageState: [async ({ browser}, use) => {
    const fs = require('fs')
    const path = require('path')
    const shardIndex = process.env.SHARD ? +(process.env.SHARD) : 0
    // Use parallelIndex as a unique identifier for each worker.
    const parallelIndex = syncedTest.info().parallelIndex
    let userArray: string[] = []

    userArray = EWM3Config.USERNAMES_ARRAY
    const fileName = path.resolve(syncedTest.info().project.outputDir, `${EWM3Config.AUTH_FILES_PATH}${shardIndex}_${parallelIndex}_browser_storage_state.json`)

    if (fs.existsSync(fileName)) {
      // Reuse existing authentication state if any.
      await use(fileName)
      return
    }

    // Important: make sure we authenticate in a clean environment by unsetting storage state.
    const page = await browser.newPage(
      {
        storageState: undefined,
        baseURL: EWM3Config.BASE_URL
      }
    )

    // Acquire a unique account, for example create a new one.
    // Alternatively, you can have a list of precreated accounts for testing.
    // Make sure that accounts are unique, so that multiple team members
    // can run tests at the same time without interference.
    //const account = await acquireAccount(id);

    // Perform authentication steps
    const loginPage = new LoginPage(page)
    const homePage = new HomePage(page)
    await loginPage.makeLogin(
      userArray[parallelIndex],
      EWM3Config.PASSWORD
    )
    await homePage.goto()
    await homePage.waitPageIsReady()
    // End of authentication steps.
  
    await homePage.page.context().storageState({ path: fileName })
    await homePage.page.close()
    await use(fileName)
  }, { scope: 'worker' }],
  requestContext: async ({ page }, use) => {
    // I open home page
    await page.goto('/')
    // Each time when main page open then token request is triggered. We will catch the response
    const responsePromise = page.waitForRequest(request =>
      request.url().includes('/monitoring/api/v1'),
    { timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM })
    const token = await (await responsePromise).headerValue('Authorization')
    // I use token from response as header for api request context
    const context = await apiContext.newContext({
      extraHTTPHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `${token}`,
      },
      baseURL: EWM3Config.BASE_URL
    })
    // Use the fixture value in the test.
    await use(context)

    // Clean up the fixture.
    // do smth
  },

})
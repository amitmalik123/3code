import {type APIRequestContext, test as base, request} from '@playwright/test'
import {EWM3ApiHelpers} from '../api/api-helpers'
import {EWM3Config} from '../service-data/config'
import {FlagTypes, MonitoringV1} from '../api/monitoring/v1/endpoints'
import {DashboardArrayResponse} from '../api/monitoring/v1/types'
import {InsightsLite} from '../api/insights-lite/endpoints'

// Declare the types of your fixtures.
type MyFixtures = {
    baseApiFixture: EWM3ApiHelpers;
    dashboardsFixture: EWM3ApiHelpers;
    widgetsFixture: EWM3ApiHelpers;
    unauthorizedFixture: EWM3ApiHelpers;
    requestContext: APIRequestContext;
    unauthorizedContext: APIRequestContext;
    expiredTokenContext: APIRequestContext;
    preparedDashboardsContext: APIRequestContext;
    widgetsContext: APIRequestContext;
    noFlagsContext: APIRequestContext;
    noClientFlagsContext: APIRequestContext;
    noStatusAndTrackingFlagsContext: APIRequestContext;
    insightsLiteContext: APIRequestContext
};

// Extend base test by providing "todoPage" and "settingsPage".
// This new "test" can be used in multiple test files, and each of them will get the fixtures.
export const test = base.extend<MyFixtures>({

  requestContext: async ({  }, use) => {
    // Set up the fixture.
    const context = await request.newContext({
      timeout: EWM3Config.API_RESPONSE_TIMEOUT,
      extraHTTPHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `${EWM3Config.parseJsonWithToken(EWM3Config.AUTH_API_PATH)}`,
      }
    })
    // Use the fixture value in the test.
    await use(context)

    // Clean up the fixture.
    // do smth
  },
  baseApiFixture: async ({ requestContext }, use) => {
    // Set up the fixture.
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    // await apiHelpers.endpoints.setHeaders()
    // Use the fixture value in the test.
    await use(apiHelpers)

    // Clean up the fixture.
    // do smth
  },

  dashboardsFixture: async ({ requestContext }, use) => {
    // Set up the fixture.
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    //await apiHelpers.endpoints.setHeaders()
    const allDashboardsResponseBody = await (await apiHelpers.endpoints.getAllUsersDashboards()).json()
    if (allDashboardsResponseBody.data.length == 5){
      await apiHelpers.endpoints.deleteDashboard(allDashboardsResponseBody.data[0].id)
    }
    // Use the fixture value in the test.
    await use(apiHelpers)

    // Clean up the fixture.
    // do smth
  },

  widgetsFixture: async ({ requestContext }, use) => {
    // Set up the fixture.
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    // await apiHelpers.endpoints.setHeaders()
    // remove all tiles from dashboard
    await apiHelpers.endpoints.postAddWidgetsOnDashboard(
      await apiHelpers.firstDashboardId(),
      []
    )
    // Use the fixture value in the test.
    await use(apiHelpers)

    // Clean up the fixture.
    // do smth
  },

  unauthorizedFixture: async ({  }, use) => {
    const context = await request.newContext({
      timeout: EWM3Config.API_RESPONSE_TIMEOUT,
      extraHTTPHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    })
    const apiHelpers = new EWM3ApiHelpers(context)
    await use(apiHelpers)
  },

  unauthorizedContext: async ({ }, use) => {
    const context = await request.newContext({
      timeout: EWM3Config.API_RESPONSE_TIMEOUT,
      extraHTTPHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    })

    await use(context)
  },

  expiredTokenContext: async ({ }, use) => {
    const context = await request.newContext({
      timeout: EWM3Config.API_RESPONSE_TIMEOUT,
      extraHTTPHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJzTFAzNWM4cU95UDBlb29RdmhGeEI3MFRhOHhVQnlTSGVydkZ1Zm1VcDRvIn0.eyJleHAiOjE3MDM2NzI0NTQsImlhdCI6MTcwMzY3MjE1NCwiYXV0aF90aW1lIjoxNzAzNjY0OTgzLCJqdGkiOiIwNDc3NDUxZC1lMDdhLTQ2N2ItODY5OS00YzU3ZTgxYjQ1MjUiLCJpc3MiOiJodHRwczovL3Rlc3QudGVuYW50MS5hdXRoLmV3bTMuYXNzZXRtYXJrLm5ldC9yZWFsbXMvZVdNIiwiYXVkIjoiYWNjb3VudCIsInN1YiI6IjY0NzUzNWU4LTIwOTEtNDU1Yi1iMTUyLWFjMGEyNDA0ZTJkNiIsInR5cCI6IkJlYXJlciIsImF6cCI6ImVXTUF1dGgiLCJzZXNzaW9uX3N0YXRlIjoiOGIzMWI1YTktNmVhYi00ODA1LWJhNTctMmI2MTYxNTBmMWMxIiwiYWNyIjoiMCIsImFsbG93ZWQtb3JpZ2lucyI6WyIqIl0sInJlYWxtX2FjY2VzcyI6eyJyb2xlcyI6WyJkZWZhdWx0LXJvbGVzLWV3bSIsIm9mZmxpbmVfYWNjZXNzIiwidW1hX2F1dGhvcml6YXRpb24iXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJzY29wZSI6Im9wZW5pZCBlbWFpbCBwcm9maWxlIiwic2lkIjoiOGIzMWI1YTktNmVhYi00ODA1LWJhNTctMmI2MTYxNTBmMWMxIiwic3NvaWQiOiI3RDdBQjM2MS1BMkRGLTQwOTUtOEFCQy1FN0E0QkZFMjU5NDIiLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsIm5hbWUiOiJTYW1wbGUgQWR2aXNvcjExIiwibG9naW5yb2xlcyI6WyI3RDdBQjM2MS1BMkRGLTQwOTUtOEFCQy1FN0E0QkZFMjU5NDJ8QWR2aXNvclJlcENvZGUiXSwib3JncyI6WyI3RDdBQjM2MS1BMkRGLTQwOTUtOEFCQy1FN0E0QkZFMjU5NDJ8UHJpbWFyeXxBZHZpc29yUmVwQ29kZSJdLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJzYW1wbGVhZHZpc29yMTEiLCJnaXZlbl9uYW1lIjoiU2FtcGxlIiwiZmFtaWx5X25hbWUiOiJBZHZpc29yMTEiLCJlbWFpbCI6InNhbXBsZS5hZHZpc29yMTFAYXNzZXRtYXJrLmNvbSJ9.TROoLht32VFSO3bPdg28siBZISp2bXp8qnu8Tj1nwDoIgjqUw4D49649-Yv5A_NZW6SFEUnp5q2YMN9tz5Pu-FxgVpdhsDzVDKqaS1eFo9LaCvEBd2T96uou2N5J1V1TlxJdG7LmrZxYmPSixQ16qgkEZH_5FJMC4RBCAWRJpiE_RNR_ToDUx8hwpBeXxxQv7lzt6Q7__lWZi3U4aRVFV7DfESMg4gawVcsJXFRmLZqWFCJ3y9F7_0VdFixSUWIlnHa6P-Azdd5U2X-88QWeThcBevSBIMF38raiia21J32725LIz_cmun-k2ynDvWNTIiub4qiJp_borOopvyf6Yw'
      }
    })

    await use(context)
  },

  preparedDashboardsContext: async ({ requestContext }, use) => {
    const api = new EWM3ApiHelpers(requestContext)
    const endpoints = new MonitoringV1().dashboard
    const allDashboardsResponseBody: DashboardArrayResponse = await (await api.makeRequest(endpoints.dashboardsByUser)).json()

    if (allDashboardsResponseBody.data.length == 5){
      endpoints.deleteDashboard.pathParameters = allDashboardsResponseBody.data[0].id
      await api.makeRequest(endpoints.deleteDashboard)
    }

    await use(requestContext)
  },

  widgetsContext: async ({ requestContext }, use) => {
    const api = new EWM3ApiHelpers(requestContext)
    const endpoint = new MonitoringV1().widget.addToDashboard
    endpoint.pathParameters = await api.firstDashboardId()
    endpoint.body = []

    await api.makeRequest(endpoint)

    await use(requestContext)
  },

  noFlagsContext: async ({ requestContext }, use) => {
    const api = new EWM3ApiHelpers(requestContext)
    await api.unFlagItems(FlagTypes.CLIENT)
    await api.unFlagItems(FlagTypes.WORK_ITEM)

    await use(requestContext)
  },

  noClientFlagsContext: async ({ requestContext }, use) => {
    const api = new EWM3ApiHelpers(requestContext)
    await api.unFlagItems(FlagTypes.CLIENT)

    await use(requestContext)
  },

  noStatusAndTrackingFlagsContext: async ({ requestContext }, use) => {
    const api = new EWM3ApiHelpers(requestContext)
    await api.unFlagItems(FlagTypes.WORK_ITEM)

    await use(requestContext)
  },

  insightsLiteContext: async ({ requestContext }, use) => {
    const api = new EWM3ApiHelpers(requestContext)
    const response = await api.makeRequest(new InsightsLite().agentID)
    await api.responseIs200(response)
    const respJSON = await response.json()
    const codes = JSON.stringify(JSON.parse(respJSON).map(obj => obj['sourceId']).join(','))
    const context = await request.newContext({
      timeout: EWM3Config.API_RESPONSE_TIMEOUT,
      extraHTTPHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `${EWM3Config.parseJsonWithToken(EWM3Config.AUTH_API_PATH)}`,
        'Ewm-Advisors-Codes': `${codes}`
      }
    })
    // Use the fixture value in the test.
    await use(context)

    // Clean up the fixture.
    // do smth
  },
})
export  *  from '@playwright/test'
import { test as baseTest, request } from './base-api-fixture'
import {EWM3ApiHelpers} from '../api/api-helpers'
import {EWM3Config} from '../service-data/config'
import {APIRequestContext} from '@playwright/test'
export * from '@playwright/test'

export const test = baseTest.extend<{}, { headersPerWorker: APIRequestContext }>({
  // Use the same storage state for all tests in this worker.
  extraHTTPHeaders: ({ headersPerWorker }, use) => use(this),

  // Authenticate once per worker with a worker-scoped fixture.
  headersPerWorker: [async ({}, use) => {
    // Use parallelIndex as a unique identifier for each worker.
    const id = test.info().parallelIndex

    if (id > EWM3Config.USERNAMES_ARRAY.length - 1){
      throw new Error(`USERNAMES_ARRAY declared in the config.ts doesn't contain enough users to run tests parallel`)
    }

    // Important: make sure we authenticate in a clean environment by unsetting storage state.
    const context = await request.newContext({
      extraHTTPHeaders: undefined ,
      baseURL: EWM3Config.BASE_URL
    })

    // Acquire a unique account
    // Send authentication request.
    const apiHelpers = new EWM3ApiHelpers(context)

    const response = await apiHelpers.endpoints.postMakeLogin(
      EWM3Config.USERNAMES_ARRAY[id],
      EWM3Config.PASSWORD
    )
    const data = await response.json()
    EWM3Config.userTokensArray[id] = `Bearer ${data.access_token}`
    //await context.dispose();
    await use(context)
  }, { scope: 'worker' }],

  requestContext: async ({  }, use) => {
    const id = test.info().parallelIndex
    // Set up the fixture.
    const context = await request.newContext({
      timeout: EWM3Config.API_RESPONSE_TIMEOUT,
      extraHTTPHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `${EWM3Config.userTokensArray[id]}`,
      },
      baseURL: EWM3Config.BASE_URL
    })
    // Use the fixture value in the test.
    await use(context)

    // Clean up the fixture.
    // do smth
  },
})
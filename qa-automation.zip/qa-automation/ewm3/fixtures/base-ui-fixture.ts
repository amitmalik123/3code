import { APIRequestContext, test as base } from '@playwright/test'
import { EWM3Config } from '../service-data/config'
import { LoginPage } from '../ui/pages/login-page'
import { HomePage } from '../ui/pages/home-page'
import { EWM3ApiHelpers } from '../api/api-helpers'
import { GeneralUtils } from '../../utils/generalUtils'
import { request as apiContext } from 'playwright-core'
import { ClientSectionHouseholdPage } from '../ui/pages/client-section-household-page'
import { ClientSectionAccountsPage } from '../ui/pages/client-section-accounts-page'
import { BicPage } from '../ui/pages/bic-page'
import { InsightsAssetsPage } from '../ui/pages/insightsAssets-page'
import { InsightsFeesPage } from '../ui/pages/insightsFees-page'
import { InsightsFlowsPage } from '../ui/pages/insightsFlows-page'
import {InsightsLiteApiHelpers} from '../api/insights-lite-api-helpers'
import { FlagTypes } from '../api/monitoring/v1/endpoints'
import fs from 'fs'

// Declare the types of your fixtures.
type MyFixtures = {
  loginPage: LoginPage
  homePage: HomePage
  apiHelpers: EWM3ApiHelpers
  addAllWidgets: EWM3ApiHelpers
  initDashboardData: EWM3ApiHelpers
  initEmptyDashboard: EWM3ApiHelpers
  removeAllWidgets: EWM3ApiHelpers
  createMaxDashboards: EWM3ApiHelpers
  unflagAllItemsWorkItem: EWM3ApiHelpers
  requestContext: APIRequestContext
  generalUtils: GeneralUtils
  houseHoldPage: ClientSectionHouseholdPage
  accountsPage: ClientSectionAccountsPage
  bicPage: BicPage
  bicDashboardPage: BicPage
  insightsAssetsPage: InsightsAssetsPage
  insightsFeesPage: InsightsFeesPage
  insightsFlowsPage: InsightsFlowsPage
  insightsAssetsMockedPage: InsightsAssetsPage
}

// Extend base test by providing "todoPage" and "settingsPage".
// This new "test" can be used in multiple test files, and each of them will get the fixtures.
export const test = base.extend<MyFixtures>({

  page: async ({ page }, use, testInfo) => {
    await use(page)
    if (testInfo.status !== testInfo.expectedStatus) {
      // Get a unique place for the screenshot.
      const screenshotPath = testInfo.outputPath(`failure_${testInfo.title}.png`)
      // Add it to the report.
      testInfo.attachments.push({ name: 'screenshot', path: screenshotPath, contentType: 'image/png' })
      // Take the screenshot itself.
      await page.screenshot({ path: screenshotPath, timeout: 5000, fullPage: true  })
    }
  },

  loginPage: async ({ page }, use) => {
    // Set up the fixture.
    const loginPage = new LoginPage(page)

    // Use the fixture value in the test.
    await use(loginPage)

    // Clean up the fixture.
    // do smth
  },

  generalUtils: async ({ page }, use) => {
    // Set up the fixture.
    const generalUtils = new GeneralUtils(page)

    // Use the fixture value in the test.
    await use(generalUtils)

    // Clean up the fixture.
    // do smth
  },

  homePage: async ({ page, addAllWidgets}, use) => {
    const homePage = new HomePage(page)
    await homePage.goto()
    page.waitForRequest(
      request => request.url().includes('/monitoring/api/v1'),
      { timeout: EWM3Config.ACTION_TIMEOUT_LONG })
      .then(response => response.headerValue('Authorization')
        .then(headerValue => process.env['API_TOKEN '] = headerValue))
    await homePage.waitPageIsReady()
    await use(homePage)
  },

  requestContext: async ({page }, use) => {
    if (!process.env['API_TOKEN ']){
      // I open home page
      await page.goto('/')
      // Each time when main page open then token request is triggered. We will catch the response
      await page.waitForRequest(request =>
        request.url().includes('/monitoring/api/v1'),
      { timeout: EWM3Config.ACTION_TIMEOUT_MEDIUM }
      ).then(async request => process.env['API_TOKEN '] = await request.headerValue('Authorization'))
    }

    // I use token from response as header for api request context
    const context = await apiContext.newContext({
      extraHTTPHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `${process.env['API_TOKEN ']}`,
      },
      baseURL: EWM3Config.BASE_URL
    })

    // Use the fixture value in the test.
    await use(context)

    // Clean up the fixture.
    // do smth
  },

  apiHelpers: async ({ requestContext }, use) => {
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    await use(apiHelpers)
  },

  initDashboardData: async ({ requestContext }, use) => {
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    await apiHelpers.initDashboardsData()
    await use(apiHelpers)
  },

  initEmptyDashboard: async ({ requestContext }, use) => {
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    await apiHelpers.initEmptyDashboard()
    await use(apiHelpers)
  },

  removeAllWidgets: async ({ requestContext }, use) => {
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    await apiHelpers.removeAllWidgetsFromDashboard()
    await use(apiHelpers)
  },

  createMaxDashboards: async ({ requestContext }, use) => {
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    await apiHelpers.createMaxDashboards()
    await use(apiHelpers)
  },

  addAllWidgets: async ({ requestContext }, use) => {
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    await apiHelpers.addAllWidgetsOnDashboard()
    await use(apiHelpers)
  },

  unflagAllItemsWorkItem: async ({ requestContext }, use) => {
    const apiHelpers = new EWM3ApiHelpers(requestContext)
    await apiHelpers.unFlagItems(FlagTypes.WORK_ITEM)
    await use(apiHelpers)
  },

  houseHoldPage: async ({ page, requestContext}, use) => {
    await requestContext.put('/monitoring/api/v2/preferences',
      {data: [
        {
          'uid': 'clients.households.table',
          'description': 'Client Section Households Table',
          'schemaVersion': 1,
          'parameters': {
            'householdInitialColumnFilters': [],
            'householdColumnSorting': [],
          }
        }
      ]
      }
    )
    const houseHoldPage = new ClientSectionHouseholdPage(page)
    await houseHoldPage.goto()
    await houseHoldPage.waitPageIsReady()
    await use(houseHoldPage)
  },

  accountsPage: async ({ page, requestContext}, use) => {
    await requestContext.put('/monitoring/api/v2/preferences',
      {data: [
        {
          'uid': 'clients.accounts.table',
          'description': 'Client Section Households Table',
          'schemaVersion': 1,
          'parameters': {
            'accountInitialColumnFilters': [],
            'accountColumnSorting': [],
          }
        }
      ]
      }
    )

    const accountsPage = new ClientSectionAccountsPage(page)
    await accountsPage.goto()
    await accountsPage.waitPageIsReady()
    await use(accountsPage)
  },

  bicPage: async ({homePage}, use) => {
    const openedStrategyIndex = await homePage.tileInvestments.openBic()
    const bicPage = new BicPage(homePage.page, true, openedStrategyIndex)
    await bicPage.waitPageIsReady()
    await use(bicPage)
  }, 

  bicDashboardPage: async ({homePage}, use) => {
    const bicDashboardPage = new BicPage(homePage.page)
    await use(bicDashboardPage)
  }, 

  insightsAssetsPage: async ({ requestContext, page}, use) => {
    const api = new InsightsLiteApiHelpers(requestContext)
    await api.manageDashboardTiles('assets', {active: true})
    const insightsAssetsPage = new InsightsAssetsPage(page)
    await insightsAssetsPage.goto()
    await insightsAssetsPage.waitPageIsReady()
    await use(insightsAssetsPage)
  },

  insightsFeesPage: async ({ requestContext, page}, use) => {
    const api = new InsightsLiteApiHelpers(requestContext)
    await api.manageDashboardTiles('fees', {active: true})
    const insightsFeesPage = new InsightsFeesPage(page)
    await insightsFeesPage.goto()
    await insightsFeesPage.waitPageIsReady()
    await use(insightsFeesPage)
  },

  insightsFlowsPage: async ({ requestContext, page}, use) => {
    const api = new InsightsLiteApiHelpers(requestContext)
    await api.manageDashboardTiles('flows', {active: true})
    const insightsFlowsPage = new InsightsFlowsPage(page)
    await insightsFlowsPage.goto()
    await insightsFlowsPage.waitPageIsReady()
    await use(insightsFlowsPage)
  },

  //TODO: General solution for mocked tests
  insightsAssetsMockedPage: async ({ page}, use) => {
    const insightsAssetsMockedPage = new InsightsAssetsPage(page)
    await insightsAssetsMockedPage.page.route('**/insights-light/graphql', async route => {
      await route.fulfill({
        headers: {
          'Content-Type': 'application/json',
        },
        body: fs.readFileSync('ewm3/ui/mocks/insights-lite/aopTotalMktValue_14yHistMockData.json', 'utf-8')
      })
    })
    await insightsAssetsMockedPage.goto()
    await insightsAssetsMockedPage.waitPageIsReady()
    await use(insightsAssetsMockedPage)
  },

})

export { expect } from '@playwright/test'


export interface AccountsResponse {
  data:  AccountsData
  error: Error
}

export interface AccountMetricResponse {
  data:  AccountMetricData
  error: Error
}

export interface ClientResponse {
  data:  ClientData
  error: Error
}

export interface ClientMetricResponse {
  data:  ClientMetricData
  error: Error
}

export interface AdvisorMetricsResponse {
  data:  AdvisorMetricsResponseData
  error: Error
}

export interface AdvisorMetricsResponseData {
  accounts:       number
  households:     number
  pendingFunds:   number
  platformAssets: number
}

export interface ClientMetricData {
  accounts:       AccountMetricObject[]
  accountsCount:  number
  applicationId?: string
  clientRisk:     string
  id:             string
  name:           string
  portfolioValue: number
  webId?:         string
}

export interface ClientData {
  data?: ClientDataArray[]
  limit: number
  start: number
  total: number
}

export interface ClientDataArray {
  accounts?:                  AccountElement[]
  advisorIdentifier?:         string
  annualizedPerformance?:     number
  assetAllocations?:          AssetAllocationElement[]
  clientAplId?:               string
  clientName:                 string
  clientWebId?:               string
  id:                         string
  establishedDate?:           string //  Phase 2 - Out of scope
  marketValue:                number
  netInvestment?:              number
  numberOfAccounts:           number
  proposed?:                  number // EWM30CS-193
  webAccess:                  boolean
  ytdPerformance?:            number
  expectedAmount?:            number
  qtdPerformance?:            number // Phase 2 - EWM30CS-196
  oneYearPerformance?:        number
  threeYearPerformance?:      number
  fiveYearPerformance?:       number
  cumulativeReturn?:          number
}

export interface AccountElement {
  alerts:                     string[]
  annualizedPerformance?:     number
  applicationId?:             string
  assetAllocations?:          AssetAllocationElement[]
  bankAccountNumber?:         string
  id:                         string
  inceptionDate?:             string
  investmentProduct?:         string
  marketValue:                number
  expectedAmount?:            number
  cumulativeReturn?:          number
  qtdPerformance?:            number // Phase 2 - EWM30CS-196
  status:                     string
  title:                      string
  ytdPerformance?:            number
  oneYearPerformance?:        number
  threeYearPerformance?:      number
  fiveYearPerformance?:       number
}

export interface AccountMetricData {
  accountValue:       number
  applicationId?:     string
  bankAccountNumber?: string
  client:             ClientMetricObject
  clientRisk:         string
  id:                 string
  title:              string
}

export interface ClientMetricObject {
  accounts:       AccountMetricObject[]
  applicationId?: string
  id:             string
  name:           string
  webId?:         string
}

export interface AccountMetricObject {
  applicationId?:     string
  bankAccountNumber?: string
  id:                 string
  title:              string
}

export interface AccountsData {
  data?: AccountsDataArray[]
  limit: number
  start: number
  total: number
}

export interface AccountsDataArray {
  advisorIdentifier?:         string
  alerts?:                     string[]
  annualizedPerformance?:     number
  applicationId?:             string
  approach?:                   Approach // Phase 2
  assetAllocations?:          AssetAllocationElement[]
  bankAccountNumber?:         string
  clientAplId?:               string
  clientId:                   string
  clientName:                 string
  clientWebId?:               string
  custodian?:                 string
  id:                         string
  inceptionDate?:             string
  investmentProduct?:         string
  marketValue?:                number
  cumulativeReturn?: number
  qtdPerformance?:            number // Phase 2
  registrationType?:          string
  status:                     string
  title:                      string
  ytdPerformance?:            number
  oneYearPerformance?:        number
  threeYearPerformance?:      number
  fiveYearPerformance?:       number
  expectedAmount?:            number
  netInvestment?:              number
}

export enum Approach {
  AdditionalInvestments = 'AdditionalInvestments',
  BondsAndBondAlternatives = 'BondsAndBondAlternatives',
  CoreMarkets = 'CoreMarkets',
  EnhancedReturnFocus = 'EnhancedReturnFocus',
  EquityAlternatives = 'EquityAlternatives',
  LimitLossFocus = 'LimitLossFocus',
  Undefined = 'Undefined',
}

export interface AssetAllocationElement {
  allocationWeight: number
  assetClass:       AssetClass
}

export enum AssetClass {
  AlternativeInvestments = 'AlternativeInvestments',
  Cash = 'Cash',
  CashAlternatives = 'CashAlternatives',
  Equity = 'Equity',
  FixedIncome = 'FixedIncome',
}

export interface Error {
  code:     number
  message?: string
}

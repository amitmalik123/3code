import {BaseApiClass, BaseApiEndpoint, HttpMethod} from '../../../../base/base-endpoint'

export class AccountDataV1 extends BaseApiClass{
  constructor(route: string = '/accountdata/api/v1', packagePath: string = 'ewm3/api/accountdata/v1') {
    super(route, packagePath)
  }
  public readonly accounts: Accounts = new Accounts(`${this.route}/accounts`, this.packagePath)
  public readonly advisorMetrics: AdvisorMetrics = new AdvisorMetrics(`${this.route}/advisormetrics`, this.packagePath)
  public readonly clients: Clients = new Clients(`${this.route}/clients`, this.packagePath)
}
class Accounts extends BaseApiClass{

  accountList(body?: any | null): BaseApiEndpoint {
    return {
      method: HttpMethod.POST,
      route: `${this.route}`,
      body: body,
      schema: this.getSchema('accounts-response'),
      title: `Get accounts list`
    }
  }

  metrics(accountId: string = '{accountId}'): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}/metrics`,
      pathParameters: accountId,
      schema: this.getSchema('account-metrics-response'),
      title: `Get account metrics`
    }

  }

}

class AdvisorMetrics extends BaseApiClass{

  getMetrics(queryParameters: {advisors: string | string[]}): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}`,
      queryParameters,
      schema: this.getSchema('advisor-metrics'),
      title: `Get advisor metrics`
    }
  }
}

class Clients extends BaseApiClass{

  clientList(body?: any | null): BaseApiEndpoint {
    return {
      method: HttpMethod.POST,
      route: `${this.route}`,
      body: body,
      schema: this.getSchema('clients-response'),
      title: `Get clients/Household list`
    }

  }

  metrics(householdId: string = '{householdId}'): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}/metrics`,
      pathParameters: householdId,
      schema: this.getSchema('client-metrics-response'),
      title: `Get client/household metrics`
    }

  }

}
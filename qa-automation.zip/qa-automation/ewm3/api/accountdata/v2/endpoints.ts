import { BaseApiClass, BaseApiEndpoint, HttpMethod } from '../../../../base/base-endpoint'

export class AccountDataV2 extends BaseApiClass{
  constructor(route: string = '/accountdata/api/v2', packagePath: string = 'ewm3/api/accountdata/v2') {
    super(route, packagePath)
  }
  public readonly bicAccounts: BicAccounts = new BicAccounts(`${this.route}/bicaccounts`, this.packagePath)
  public readonly products: Products = new Products(`${this.route}/products`, this.packagePath)
}

class BicAccounts extends BaseApiClass{

  bicAccount(queryParameters?: { [key: string]: string | number | boolean; }): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}`,
      queryParameters: queryParameters,
      schema: this.getSchema('account-dto'),
      title: `Get BIC accounts list`
    }
  }
}

class Products extends BaseApiClass{

  products(): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}`,
      schema: this.getSchema('product-group-dto'),
      title: `Get product`
    }
  }

}
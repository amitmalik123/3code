import {InsightsLite} from './endpoints'
import {EWM3ApiHelpers} from '../api-helpers'
import {GeneralUtils} from '../../../utils/generalUtils'

export interface QueryInterface{
    queryBody: string
    title: string
    schema: string
    dependency?: (api: EWM3ApiHelpers)=> Promise<string>
}

export interface DummyQueryInterface{
  queryBody: string
  title: string
  schema: string
  sql: string
}

export class Queries {
  //widget queries
  get totalMarketValue(): QueryInterface  { //AOP stands for 'Assets On Platform'
    return{
      queryBody: 'query GET_YEARLY_MARKETVALUES_TEN_YEARS @page(number: 1) { marketValues @calendarDateFilter(by: YEAR) @aggregation(by: ["date"]) { date @calendarDateFilter(by: YEAR, last: 10) marketValue @sum __typename } }',
      title:'Total Market Value Widget Query',
      schema:'aopTotalMarketValue-graphQL',
    }
  }

  get dummyTotalMarketValue(): DummyQueryInterface{
    return{
      queryBody: 'query GET_YEARLY_MARKETVALUES_TEN_YEARS @page(number: 1) { marketValues @calendarDateFilter(by: YEAR) @aggregation(by: ["date"]) { date @calendarDateFilter(by: YEAR, last: 10) marketValue @sum __typename } }',
      title:'Total Market Value Widget Query',
      schema:'aopTotalMarketValue-graphQL',
      sql:'SELECT [dw].[market_value].[date], sum(market_value) as market_value FROM [dw].[market_value] INNER JOIN [dw].[date] ON ( [dw].[market_value].[date] = [dw].[date].[date] ) WHERE [dw].[date].[calendar_end_of_year] = 1 AND dw.date.date >= dateadd( year, -10, getdate() ) AND [advisor_rep_code_id] IN (45460) GROUP BY [dw].[market_value].[date] ORDER BY [dw].[market_value].[date] OFFSET 0 ROWS FETCH NEXT 10000 ROWS ONLY'
    }
  }

  get aopCAGR(): QueryInterface  { //Compound Annual Growth Rate
    return{
      queryBody: 'query GET_YEARLY_MARKETVALUES_WITH_CAGR @page(number: 1) { marketValues @aggregation(by: ["date"]) { marketValue @sum @cagr(by: 4) date @calendarDateFilter(by: YEAR, last: 10) __typename } }',
      title:'Compound Annual Growth Rate Widget Query',
      schema:'aopTotalMarketValue-graphQL',
    }
  }
  get aopByLOB(): QueryInterface {
    return{
      queryBody: 'query GET_YEARLY_MARKETVALUES_LAST_YEAR@page(number: 1) { marketValues @calendarDateFilter(by: YEAR, last: 1) { date @calendarDateFilter(by: YEAR, last: 1) marketValue virtualAccountId virtualAccount { lineOfBusiness __typename } __typename } }',
      title:'AOP By Line of Business Widget Query',
      schema:'aopByLOB-graphQL',
    }
  }
  get aopByLOB1DrillDown_byInvestManager(): QueryInterface {
    const query = 'query GET_YEARLY_MARKETVALUES_LAST_YEAR @page(number: 1) { marketValues @calendarDateFilter(by: YEAR, last: 1) { date @calendarDateFilter(by: YEAR, last: 1) marketValue virtualAccountId virtualAccount { lineOfBusiness @where(op: "in", value: "") __typename } productId product { investmentManager __typename } __typename } }'
    return{
      queryBody: query,
      title:'AOP By Line of Business - 1st Drill Down by Investment Manager',
      schema:'aopLOBDDInvestManager-graphQL',
      dependency:  async (api: EWM3ApiHelpers) => {
        const endpoint = new InsightsLite().graphQL(this.aopByLOB)
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        const dependencyResp = await response.json()
        const uniqueLineOfBusinessSet = new Set()
        dependencyResp.data.marketValues.forEach(marketValue => {
          uniqueLineOfBusinessSet.add(marketValue.virtualAccount.lineOfBusiness)
        })
        const uniqueLineOfBusinessArray = Array.from(uniqueLineOfBusinessSet)
        return query.replace('value: ""', `value: "${uniqueLineOfBusinessArray[GeneralUtils.getRandomNumber(uniqueLineOfBusinessArray.length)]}"`)
      }

    }
  }
  get aopByInvestmentManager(): QueryInterface  {
    return{
      queryBody: 'query GET_YEARLY_MARKETVALUES_LAST_YEAR @page(number: 1) { marketValues @calendarDateFilter(by: YEAR, last: 1) { date @calendarDateFilter(by: YEAR, last: 1) marketValue productId product { investmentManager __typename } __typename } }',
      title:'AOP by Investment Manager Widget Query',
      schema:'aopByInvestmentManager-graphQL',
    }
  }
  get aopIM1DrillDown_byProductName(): QueryInterface  {
    const query = 'query GET_YEARLY_MARKETVALUES_LAST_YEAR @page(number: 1) { marketValues @calendarDateFilter(by: YEAR, last: 1) { date @calendarDateFilter(by: YEAR, last: 1) marketValue productId product { investmentManager @where(op: "in", value: "") __typename } productId product { name __typename } __typename } }'
    return{
      queryBody: query,
      title:'AOP by Investment Manager - 1st Drill Down by Product Name',
      schema:'aopIM1DrillDown_byProdName-graphQL',
      dependency:  async (api: EWM3ApiHelpers) => {
        const endpoint = new InsightsLite().graphQL(this.aopByInvestmentManager)
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        const dependencyResp = await response.json()
        const uniqueInvestmentManagerSet = new Set()
        dependencyResp.data.marketValues.forEach(marketValue => {
          uniqueInvestmentManagerSet.add(marketValue.product.investmentManager)
        })
        const uniqueInvestmentManagerArray = Array.from(uniqueInvestmentManagerSet)
        return query.replace('value: ""', `value: "${uniqueInvestmentManagerArray[GeneralUtils.getRandomNumber(uniqueInvestmentManagerArray.length)]}"`)
      }
    }
  }
  get aopByInvestmentApproach(): QueryInterface  {
    return{
      queryBody: 'query GET_YEARLY_MARKETVALUES_LAST_YEAR @page(number: 1) { marketValues @calendarDateFilter(by: YEAR, last: 1) { date @calendarDateFilter(by: YEAR, last: 1) marketValue productId productAllocationWeights { productId allocation weight @where(op: ">", value: 0) __typename } __typename } }',
      title:'AOP Investment Approach Widget Query',
      schema:'aopByInvestmentApproach-graphQL',
    }
  }
  get aopIA1DrillDown_byInvestManager(): QueryInterface  {
    const query = 'query GET_YEARLY_MARKETVALUES_LAST_YEAR @page(number: 1) { marketValues @calendarDateFilter(by: YEAR, last: 1) { date @calendarDateFilter(by: YEAR, last: 1) marketValue productId product { investmentManager __typename } productId productAllocationWeights { productId allocation @where(op: "in", value: "") weight @where(op: ">", value: 0) __typename } __typename } }'
    return{
      queryBody: query,
      title:'AOP IA Bar Chart - 1st Drill Down by Investment Manager',
      schema:'aopIA1DrillDown_byInvestManager-graphQL',
      dependency:  async (api: EWM3ApiHelpers) => {
        const endpoint = new InsightsLite().graphQL(this.aopByInvestmentApproach)
        const response = await api.makeRequest(endpoint)
        await api.responseIs200(response)
        const dependencyResp = await response.json()
        const uniqueAllocationSet = new Set()
        dependencyResp.data.marketValues.forEach(marketValue => {
          if (marketValue.productAllocationWeights) {
            marketValue.productAllocationWeights.forEach(allocationWeight => {
              uniqueAllocationSet.add(allocationWeight.allocation)
            })
          }
        })
        const uniqueAllocationArray = Array.from(uniqueAllocationSet)

        return query.replace('value: ""', `value: "${uniqueAllocationArray[GeneralUtils.getRandomNumber(uniqueAllocationArray.length)]}"`)
      }
    }
  }
  get feesByHouseHoldSize(): QueryInterface  {
    return{
      queryBody: 'query GET_LAST_QUARTER_FEES_VALUES @page(number: 1) { fees @datePart(part: QUARTER) @aggregation(by: ["billedDate", "clientHouseholdId", "virtualAccountId"]) { billedDate @datePart(part: QUARTER) @where(op: "between", value: ["2024-01-01","2024-03-31"]) amount @sum basis @avg clientHouseholdId virtualAccountId __typename } feesHist: feeBasisByClientHousehold @datePart(part: QUARTER) @aggregation(by: ["billedDate", "clientHouseholdId"]) { billedDate @datePart(part: QUARTER) @where(op: "between", value: ["2024-01-01","2024-03-31"]) clientHouseholdId basis @sum __typename } }',
      title:'Fees by Household Size Widget Query',
      schema:'feesByHouseHoldSize-graphQL',
    }
  }
  get feesType(): QueryInterface  {
    return{
      queryBody: 'query FEESTYPE @page(number: 1) { fees @aggregation(by: ["name", "billedDate"]) @datePart(part: YEAR) { amount @sum name billedDate @datePart(part: YEAR) @where(op: "year", value: ["2023"]) __typename } }',
      title:'Fee Type Widget Query',
      schema:'feesType-graphQL',
    }
  }
  get feesYoYGrowth(): QueryInterface  {
    return{
      queryBody: 'query GET_YOY_FEES @page(number: 1) { fees @datePart(part: YEAR) @aggregation(by: "billedDate") { billedDate @datePart(part: YEAR) @where(op: ">=", value: "2020") amount @sum @growth __typename } }',
      title:'YOY Growth % of Fees Widget Query',
      schema:'feesYoYGrowth-graphQL',
    }
  }
  get feesTotalAdvisory(): QueryInterface  {
    return{
      queryBody: 'query GET_FEES_LAST_FIVE_YEARS @page(number: 1) { fees @datePart(part: YEAR) @aggregation(by: "billedDate") { amount @sum billedDate @datePart(part: YEAR) @where(op: ">=", value: "2020") __typename } }',
      title:'Fee for Last 5 Years Bar Chart Widget Query',
      schema:'feesYoYGrowth-graphQL',//It uses the same schema for Fees YoY % Growth
    }
  }
  get feesTab1DrillDown_byHouseholdName(): QueryInterface {
    return{
      queryBody: 'query GET_LAST_QUARTER_FEES_VALUES @page(number: 1) { fees @datePart(part: QUARTER) @aggregation(by: ["billedDate", "clientHouseholdId", "virtualAccountId"]) { billedDate @datePart(part: QUARTER) @where(op: "between", value: ["2024-01-01", "2024-03-31"]) amount @sum basis @avg clientHouseholdId virtualAccountId clientHousehold { name __typename } __typename } feesHist: feeBasisByClientHousehold @datePart(part: QUARTER) @aggregation(by: ["billedDate", "clientHouseholdId"]) { billedDate @datePart(part: QUARTER) @where(op: "between", value: ["2024-01-01", "2024-03-31"]) clientHouseholdId basis @sum @where(op: "between", value:[100000.01, 250000]) __typename } }',
      title: 'Fees by Household Size Table - 1st Drill Down by Household Name (100k to 250k)',
      schema: 'feesTab1DrillDown_byHouseholdName-graphQL',
    }
  }
  get netFlowsDetails(): QueryInterface {
    return{
      queryBody: 'query FLOWS @page(number: 1) { flows @datePart(part: YEAR) @aggregation(by: ["flowDate", "subtype"]) { flowDate @datePart(part: YEAR) subtype amount @sum __typename } }',
      title: 'Net Flows Details Widget Query',
      schema: 'netFlowsDetails-graphQL',
    }
  }
  get inflowsOutflows(): QueryInterface {
    return{
      queryBody: 'query FLOWS_VS_MARKET_VALUE @page(number: 1) { flowMarketValues @aggregation(by: ["endOfPeriodDate", "clientHouseholdId", "productId"]) @calendarDateFilter(by: YEAR) { inflow @sum outflow @sum netflow @sum endOfPeriodDate @calendarDateFilter(by: YEAR, last: 5) __typename } marketValues @aggregation(by: ["date", "clientHouseholdId"]) @calendarDateFilter(by: YEAR) { marketValue @sum date @calendarDateFilter(by: YEAR) __typename } }',
      title: 'Inflows Outflows Widget Query',
      schema: 'inflowsOutflows-graphQL',
    }
  }
  get inflowsOutflowsDrillDown () {
    return{
      queryBody: 'query FLOWS_VS_MARKET_VALUE @page(number: 1) { flowMarketValues @aggregation(by: ["endOfPeriodDate", "clientHouseholdId", "productId"]) @calendarDateFilter(by: YEAR) { inflow @sum outflow @sum netflow @sum endOfPeriodDate @calendarDateFilter(by: YEAR, last: 5) @where(op: "in", value: "2023-12-31") productId product { name __typename } __typename } marketValues @aggregation(by: ["date", "clientHouseholdId"]) @calendarDateFilter(by: YEAR) { marketValue @sum date @calendarDateFilter(by: YEAR) @where(op: "in", value: "2023-12-31") __typename } }',
      title: 'Inflows Outflows Widget Query - 1st Drilldown by Product Name',
      //TODO schemas
      schema: 'inflowsOutflows-graphQL',
    }
  }
  get flowsYoYGrowth(): QueryInterface {
    return{
      queryBody: 'query FLOWS_YOY @page(number: 1) { flows @datePart(part: YEAR) @aggregation(by: ["flowDate"]) { flowDate @datePart(part: YEAR) amount @sum @growth __typename } }',
      title: 'YOY Growth % of Flows Widget Query',
      schema: 'flowsYoYGrowth-graphQL',
    }
  }

  //Queries for dimensions' endpoint
  get dimAdvisorRepCode(): QueryInterface  {
    return{
      queryBody: '{marketValues { date @calendarDateFilter(by: YEAR) advisorRepCode { advisorRepCodeId code name platformCode updateTimestamp __typename } __typename } }',
      title: 'Query Request for GraphQL Dimensions\' Endpoint - AdvisorRepCode',
      schema: 'advisorRepCode-graphQL',
    }
  }

  get dimClientHousehold(): QueryInterface {
    return {
      queryBody: '{ marketValues { date @calendarDateFilter(by: YEAR) clientHousehold { clientHouseholdId code name updateTimestamp __typename } __typename }}',
      title: 'Query Request for GraphQL Dimensions\' Endpoint - Client Household',
      schema: 'clientHousehold-graphQL',
    }
  }

  get dimProdAllocationWeight(): QueryInterface  {
    return{
      queryBody: '{marketValues { date @calendarDateFilter(by: YEAR) productAllocationWeights { productId allocationset allocation weight updateTimestamp __typename } __typename }}',
      title: 'Query Request for GraphQL Dimensions\' Endpoint - Product Allocation Weight',
      schema: 'prodAllocationWeight-graphQL',
    }
  }

  get dimProduct(): QueryInterface  {
    return{
      queryBody: '{ marketValues { date @calendarDateFilter(by: YEAR) product { investmentManager name code productFamily productId __typename } __typename }}',
      title: 'Query Request for GraphQL Dimensions\' Endpoint - Product',
      schema: 'product-graphQL',
    }
  }

  get dimVirtualAccount(): QueryInterface  {
    return{
      queryBody: '{ marketValues { date @calendarDateFilter(by: QUARTER) marketValue virtualAccount { virtualAccountId lineOfBusiness code name updateTimestamp __typename } __typename }}',
      title: 'Query Request for GraphQL Dimensions\' Endpoint - Virtual Account',
      schema: 'virtualAccount-graphQL',
    }
  }

  get dimDate(): QueryInterface  {
    return{
      queryBody: '{dates { date calendarEndOfMonth calendarEndOfQuarter calendarEndOfYear businessEndOfMonth businessEndOfQuarter businessEndOfYear __typename }}',
      title: 'Query Request for GraphQL Dimensions\' Endpoint - Date',
      schema: 'date-graphQL',
    }
  }

  //Negative test cases
  get invalidQuery(): QueryInterface  {
    return {
      queryBody: '{ }',
      title: 'Invalid Query Request',
      schema: 'queryError-graphQL',
    }
  }
}

import {QueryInterface} from './queries'
import {BaseApiClass, BaseApiEndpoint, HttpMethod} from '../../../base/base-endpoint'

export class InsightsLite extends BaseApiClass{

  constructor(route: string = '/advisorinsightsexp/graphql', packagePath: string = 'ewm3/api/insights-lite') {
    super(route, packagePath)
  }

  readonly agentID: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: '/advisorinsights/api/v1/agentid/agent',
    title: 'Get advisors code'
  }

  graphQL(queryRequest: QueryInterface): BaseApiEndpoint{
    return{
      method: HttpMethod.POST,
      route: `${this.route}`,
      body: {query: queryRequest.queryBody},
      schema: this.getSchema(queryRequest.schema),
      title: queryRequest.title
    }
  }
}

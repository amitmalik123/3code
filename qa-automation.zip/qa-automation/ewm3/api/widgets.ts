import { v4 as uuid } from 'uuid'
import { GeneralUtils } from '../../utils/generalUtils'
import { DashboardConfig } from '../service-data/tile-config/dashboard.config'
export class Widgets {
  constructor(private dashboardId?:string) {
  }

  getRandomWidget(dashboardId?:string){
    const widgetArray = Object.values(this.getWidgets(dashboardId))
    const i = GeneralUtils.getRandomNumber(widgetArray.length)
    return widgetArray[i]
  }

  getAllWidgets(dashboardId?:string){
    return Object.values(this.getWidgets(dashboardId))
  }

  getWidgets(dashboardId?:string) {
    return {
      status_tracking: {
        id: uuid(),
        dashboardId: dashboardId || this.dashboardId,
        cmsId: DashboardConfig.tiles.status_and_tracking.cmsId,
        coordinateX: 0,
        coordinateY: 12,
        height: 2,
        width: 3,
        settings: {
          allColumnsSelected: false
        }
      },
      revenue: {
        id: uuid(),
        dashboardId: dashboardId || this.dashboardId,
        cmsId: DashboardConfig.tiles.fees.cmsId,
        coordinateX: 0,
        coordinateY: 10,
        height: 2,
        width: 2,
        settings: {
          allColumnsSelected: false,
          additional: {}
        }
      },
      net_flows: {
        id: uuid(),
        dashboardId: dashboardId || this.dashboardId,
        cmsId: DashboardConfig.tiles.netflows.cmsId,
        coordinateX: 0,
        coordinateY: 8,
        height: 2,
        width: 2,
        settings: {
          allColumnsSelected: false,
          additional: {}
        }
      },
      investments: {
        id: uuid(),
        dashboardId: dashboardId || this.dashboardId,
        cmsId: DashboardConfig.tiles.investments.cmsId,
        coordinateX: 0,
        coordinateY: 6,
        height: 4,
        width: 3,
        settings: {
          allColumnsSelected: false
        }
      },
      client_list: {
        id: uuid(),
        dashboardId: dashboardId || this.dashboardId,
        cmsId: DashboardConfig.tiles.clients.cmsId,
        coordinateX: 0,
        coordinateY: 4,
        height: 2,
        width: 2,
        settings: {
          allColumnsSelected: false,
          additional: {}
        }
      },
      aum: {
        id: uuid(),
        dashboardId: dashboardId || this.dashboardId,
        cmsId: DashboardConfig.tiles.assets_on_platform.cmsId,
        coordinateX: 0,
        coordinateY: 2,
        height: 2,
        width: 2,
        settings: {
          allColumnsSelected: false,
          additional: {}
        }
      },
      advisor_benefits: {
        id: uuid(),
        dashboardId: dashboardId || this.dashboardId,
        cmsId: DashboardConfig.tiles.advisor_benefits.cmsId,
        coordinateX: 0,
        coordinateY: 0,
        height: 2,
        width: 2,
        settings: {
          allColumnsSelected: false,
          additional: {}
        }
      }
    }
  }
}
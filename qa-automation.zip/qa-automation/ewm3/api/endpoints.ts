import { type APIRequestContext } from '@playwright/test'
import { test } from '../fixtures/base-ui-fixture'
import { BaseApiRequests } from '../../base/base-api-requests'
import { EWM3Config } from '../service-data/config'
import { ClientsConfig } from '../service-data/tile-config/clients.config'
export class EWM3Endpoints extends BaseApiRequests{

  constructor(request: APIRequestContext) {
    super(request)
  }

  async postMakeLogin(userName: string, password: string) {
    return await test.step('Given: the user logs in', async () => {
      return await this.postRequest(
        `${EWM3Config.KEYCLOAK_BASE_URL}/realms/eWM/protocol/openid-connect/token`,
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          form: {
            username: userName,
            password: password,
            grant_type: 'password',
            client_id: 'eWMAuth'
          }
        }
      )
    })
  }

  async getAdvisorBenefits(options?: object) {
    return await this.getRequest('/advisormetrics/api/v2/metrics/advisorbenefits', options)
  }

  async getAUM(period: string, options?: object) {
    return await this.getRequest(`/advisormetrics/api/v2/metrics/aum/${period}`, options)
  }

  async getNetFlows(period: string, options?: object) {
    return await this.getRequest(`/advisormetrics/api/v2/metrics/netflow/${period}`, options)
  }

  async getClients(options?: object) {
    return await this.getRequest(ClientsConfig.endpoints.clients, options)
  }

  async getClientsPendingFunding(options?: object) {
    return await this.getRequest(ClientsConfig.endpoints.pending_funding, options)
  }

  async getClientsFollowing(options?: object) {
    return await this.getRequest(ClientsConfig.endpoints.following, options)
  }

  async getRevenue(options?: object) {
    return await this.getRequest('/advisormetrics/api/v2/metrics/revenue', options)
  }

  async getStatusAndTracking(filter?:string, options?: object) {
    return await this.getRequest(`/advisormetrics/api/v2/workitem/${filter}`, options)
  }

  async getStatusAndTrackingNeedsAttention(options?: object) {
    return await this.getRequest('/advisormetrics/api/v2/workitem/needattention', options)
  }

  async getStatusAndTrackingOpen(options?: object) {
    return await this.getRequest('/advisormetrics/api/v2/workitem/open', options)
  }

  async getStatusAndTrackingCompleted(options?: object) {
    return await this.getRequest('/advisormetrics/api/v2/workitem/completed', options)
  }

  async getStatusAndTrackingFollowing(options?: object) {
    return await this.getRequest('/advisormetrics/api/v2/workitem/following', options)
  }

  /**
     * @param type - type of investments: strategy/approach
     * @param options - additional options for api request
     * */
  async getInvestments(type:string, options?: object) {
    return await this.getRequest(`/advisormetrics/api/v2/metrics/investments/${type}`, options)
  }

  async getInvestmentsStrategy(options?: object) {
    return await this.getRequest('/advisormetrics/api/v2/metrics/investments/strategy', options)
  }

  async getInvestmentsApproach(options?: object) {
    return await this.getRequest('/advisormetrics/api/v2/metrics/investments/approach', options)
  }

  async deleteWorkItemFlags(entityId: string ) {
    return await this.deleteRequest('/monitoring/api/v1/flags', {params:{
      entityId:entityId,
      entityType:'WORKITEM'
    }})
  }

  async postWorkItemFlags(entityId: string) {
    return await this.postFlags(entityId, 'WORKITEM')
  }

  async postClientFlags(entityId: string) {
    return await this.postFlags(entityId, 'CLIENT')
  }

  async postFlags(entityId: string, entityType: string) {
    return await this.postRequest('/monitoring/api/v1/flags',
      {
        data: {
          entityId:entityId,
          entityType:entityType,
          id:'',
          userId:''
        }
      })
  }

  async deleteDashboard(dashboardUid: string, options?: object) {
    return await this.deleteRequest(`/monitoring/api/v1/dashboard/${dashboardUid}`, options)
  }

  async postCreateDashboard(body: object) {
    return await this.postRequest(`/monitoring/api/v1/dashboard`,
      {
        data: body
      })
  }

  async putUpdateDashboard(body: object) {
    return await this.putRequest(`/monitoring/api/v1/dashboard`,
      {
        data: body
      })
  }

  async getDashboard(dashboardUid: string, options?: object) {
    return await this.getRequest(`/monitoring/api/v1/dashboard/${dashboardUid}`, options)
  }

  async getAllUsersDashboards(options?: object) {
    return await this.getDashboard('byuser', options)
  }

  async patchSetDefaultDashboard(dashboardUid: string) {
    return await this.patchRequest(`/monitoring/api/v1/dashboard/default`,
      {
        data: '"'+ dashboardUid + '"'
      }
    )
  }

  async getEwmMetadata(metadataType: string, options?: object) {
    return await this.getRequest(`/monitoring/api/v1/cms/ewm-metadata/${metadataType}`, options)
  }

  async postAddWidgetsOnDashboard(dashboardUid: string, body: object[]) {
    return await this.postRequest(`/monitoring/api/v1/widget/addtodashboard/${dashboardUid}`, {
      data: body
    })
  }

  async getEwmAdvisorsCodes(options?: object) {
    return await this.getRequest('/advisormetrics/api/v2/metrics/advisors', options)
  }

}
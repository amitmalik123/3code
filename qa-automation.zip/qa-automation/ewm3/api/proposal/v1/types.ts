
export type ProposalProductsBody = {
  sourceProductId: string,
  advisorIds: string[]
}

export type ProposalAccountsBody = {
  sourceProductId: string,
  targetProductId: string,
  advisorIds: string[]
}

export type ProposalSuitabilityCheckBody = {
  sourceProductId: string,
  targetProductId: string,
  accounts: string[]
}

export type ProposalInvestmentChangeBody = {
  sourceProductId: string,
  targetProductId: string,
  accounts: string[],
  advisorIds: string[]
}

export interface ProposalProductsResponseBody {
  data:  ProposalProductsDataItem[];
  error: Error;
}

export interface ProposalProductsDataItem {
  id:          string;
  groupName:   string;
  isFavourite: boolean;
  products:    Product[];
}

 interface Product {
  id:                        string;
  name:                      string;
  riskProfile:               number;
  profileName:               string;
  fee:                       number;
  displayInvestmentMinimum:  string;
  enforcedInvestmentMinimum: number;
  currency:                  string;
  tmsEligibility:            boolean;
  bicEligibility:            boolean;
}

interface Error {
  message: string;
  code:    number;
}

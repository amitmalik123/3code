import { BaseApiClass, BaseApiEndpoint, HttpMethod } from '../../../../base/base-endpoint'
import { ProposalAccountsBody, ProposalInvestmentChangeBody, ProposalProductsBody, ProposalSuitabilityCheckBody } from './types'

export class ProposalV1 extends BaseApiClass{
  constructor(route: string = '/proposal/api/v1/bic', packagePath: string = 'ewm3/api/proposal/v1') {
    super(route, packagePath)
  }
  public readonly accounts: Accounts = new Accounts(`${this.route}/accounts`, this.packagePath)
  public readonly products: Products = new Products(`${this.route}/products`, this.packagePath)
}

class Accounts extends BaseApiClass{

  accounts(body?: ProposalAccountsBody | any | null): BaseApiEndpoint {
    return {
      method: HttpMethod.POST,
      route: `${this.route}`,
      body: body,
      schema: this.getSchema('account-dto-i-enumerable-response'),
      title: `Post BIC proposal accounts list`
    }
  }
  investmentChange(body?: ProposalInvestmentChangeBody | any | null): BaseApiEndpoint {
    return {
      method: HttpMethod.POST,
      route: `${this.route}/investmentchange`,
      body: body,
      schema: this.getSchema('investment-change-request-dto'),
      title: `Post BIC proposal investmentchange accounts list`
    }
  }
  suitabilityCheck(body?: ProposalSuitabilityCheckBody | any | null): BaseApiEndpoint {
    return {
      method: HttpMethod.POST,
      route: `${this.route}/suitabilitycheck`, 
      body: body,
      schema: this.getSchema('account-with-suitability-check-i-enumerable-response'),
      title: `Post BIC proposal suitabilitycheck accounts list`
    }
  }
}

class Products extends BaseApiClass{

  products(body?: ProposalProductsBody | any | null): BaseApiEndpoint {
    return {
      method: HttpMethod.POST,
      route: `${this.route}`,
      body: body,
      schema: this.getSchema('product-group-dto-i-enumerable-response'),
      title: `Post proposal product`,
    }
  }
  getProduct(productId: string = '{productId}'): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}`,
      pathParameters: productId,
      schema: this.getSchema('product-dto-response'),
      title: `Get product via id`
    }
  }
  patchProduct(productGroup: string = '{productGroup}'): BaseApiEndpoint {
    return {
      method: HttpMethod.PATCH,
      route: `${this.route}/favorite`,
      pathParameters: productGroup,
      title: `Patch product via product group`
    }
  } 
  deleteProduct(productGroup: string = '{productGroup}', queryParameters: { [key: string]: string | number | boolean } = {id: '{productId}'}): BaseApiEndpoint {
    return {
      method: HttpMethod.DELETE,
      route: `${this.route}/favorite`,
      pathParameters: productGroup,
      queryParameters: queryParameters,
      title: `Delete product via product group`
    }
  } 
}
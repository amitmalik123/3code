import { APIRequestContext } from '@playwright/test'
import { AdvisorMetricsV2 } from './advisormetrics/v2/endpoints'
import { EWM3ApiHelpers } from './api-helpers'
import { ProposalV1 } from './proposal/v1/endpoints'

export class ParametersGenerator {

  /** Retrieves a list of advisor IDs
  * @param requestContext - The appropriate fixture
  * @returns A promise that resolves to an array of advisor IDs
  */
  static async advisorId(requestContext: APIRequestContext) {
    const api = new EWM3ApiHelpers(requestContext)
    const endpoint = new AdvisorMetricsV2().metrics.advisors
    const response = await api.makeRequest(endpoint)
    await api.responseIs200(response)
    const responseData = await response.json()
    return responseData.data
  }
  /**
   * Retrieves the primary strategy ID
   * @param requestContext - The appropriate fixture
   * @returns  A promise that resolves to the primary strategy ID
   */
  static async strategyId(requestContext: APIRequestContext) { 
    const api = new EWM3ApiHelpers(requestContext)
    const endpoint = new AdvisorMetricsV2().metrics.investmentsStrategy
    const response = await api.makeRequest(endpoint)
    await api.responseIs200(response)
    const responseData = await response.json()
    return responseData.data
  }
  /**
   * Retrieves product ID and group ID based on the strategy ID and advisor IDs
   * @param requestContext - The appropriate fixture
   * @returns A promise that resolves to an array containing the product ID and group ID
   */
  static async productAndGroupId(requestContext: APIRequestContext) {  
    const api = new EWM3ApiHelpers(requestContext)
    const endpoint = new ProposalV1().products.products()
    endpoint.body = {'sourceProductId': (await this.strategyId(requestContext))[0].strategyId ,'advisorIds':  (await this.advisorId(requestContext)).map(item => item.id)}
    const response = await api.makeRequest(endpoint)
    await api.responseIs200(response)
    const responseData = await response.json()
    return responseData.data 
  }
  /**
   * Retrieves IDs of accounts that are eligible under BIC 
   * @param requestContext - The appropriate fixture
   * @returns A promise that resolves to an array of eligible account IDs
   */
  static async accountsId(requestContext: APIRequestContext) {  
    const api = new EWM3ApiHelpers(requestContext)
    const endpoint = new ProposalV1().accounts.accounts()
    endpoint.body = {
      'sourceProductId': (await this.strategyId(requestContext))[0].strategyId , 
      'targetProductId': ((await this.productAndGroupId(requestContext))[0].products[0].id),
      'advisorIds':  (await this.advisorId(requestContext)).map(item => item.id)
    }
    const response = await api.makeRequest(endpoint)
    await api.responseIs200(response)
    const responseData = await response.json()
    return responseData.data
  }
  /**
   * Retrieves IDs of accounts that have passed the suitability check
   * @param requestContext - The appropriate fixture
   * @returns A promise that resolves to an array of account IDs that passed the suitability check
   */
  static async suitabilityCheckedAccountsId(requestContext: APIRequestContext) {  
    const api = new EWM3ApiHelpers(requestContext)
    const endpoint = new ProposalV1().accounts.suitabilityCheck()
    endpoint.body = {
      'sourceProductId': (await this.strategyId(requestContext))[0].strategyId , 
      'targetProductId': ((await this.productAndGroupId(requestContext))[0].products[0].id),
      'accounts': (await this.accountsId(requestContext)).filter(item => item.isBICIneligible === false).map(item => item.id)
    }
    const response = await api.makeRequest(endpoint)
    await api.responseIs200(response)
    const responseData = await response.json()
    return responseData.data
  }

}
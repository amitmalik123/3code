export interface GoalCreationRequest {
  householdId: string,
  title: string,
  type: GoalType,
  planDetails: GoalPlanDetails,
  accountIds: string[]
}

export enum GoalType {
  General = 'General',
  Retirement = 'Retirement',
}

export enum GoalStatus {
  OnTrack = 'OnTrack',
  AtRisk = 'AtRisk',
  OffTrack = 'OffTrack',
}

export enum GoalContributionPeriod {
  Daily = 'Daily',
  Monthly = 'Monthly',
  Quarterly = 'Quarterly',
  Yearly = 'Yearly',
}

export interface GoalPlanDetails {
  startDate: string,
  startMarketValue: number,
  targetDate: string,
  targetMarketValue: number,
  periodicContribution: number,
  periodicity: GoalContributionPeriod
}

export interface GoalResponse {
  id: string,
  name: string,
  type: GoalType,
  status: GoalStatus,
  planDetails: GoalPlanDetails,
  currentMarketValue: number,
  currentExpectedMarketValue: number,
  totalPrincipal: number,
  totalInterest: number,
  accounts: GoalAccount[]
}

export interface GoalAccount {
  id: string,
  title: number,
  bankAccountNumber : string,
  marketValue: number,
  eligibleForGoalTypes: GoalType[]
}

export interface GoalData {
  name: string,
  type: GoalType,
  planDetails: GoalPlanDetails,
  householdId: string,
  accountIds: string[],
  goalProgress: number,
  currentMarketValue: number,
  currentExpectedMarketValue: number,
}

export interface GoalDBStructure {
  goalid: string,
  name: string,
  type: string,
  startDate: string,
  startValue: number,
  targetDate: string,
  targetValue: number,
  periodicFlow: number,
  periodicity: string
  annualRoR: number,
}

export interface GoalParameters{
  /**
   * goalProgress - goal progress status fraction that reflect the ratio of actual daily market value to current day target value, e.g. 0.85. 
   * goalProgress parameter can be adjusted during calculations if spreadRoR can't be calculated with existing options.
   */
  goalProgress: number
  /**
   * monthsFromTodayToStart - how many months ago from today to goal start. 
   * monthsFromTodayToStart parameter can be adjusted during calculations if the data of the earliest market value for selected account is not late enough.
   */
  monthsFromTodayToStart: number
  /**
   * goalDuration - duration of the goal in months. Default value is 36
   */
  goalDuration: number
  /**
   * clientId - Client ID for Goal as it is stored in the DB in the cmd.organization table in the field 'organizationid'. Example: '5EEA3FE7-140F-435F-8F20-79D7BE5A0C3A-000D'. 
   * If not specified then the first Client found in the DB with the appropriate numOfAcc suitable for Goal creation will be used
   */
  clientId?: string
  /**
   * numOfAcc - number of Accounts for Goal creation. Default value is 1
   */
  numOfAcc?: number
  /**
   * advisors - string with the list of advisor IDs separated with ','. Example: 'C5B78A40-E22E-4E34-94C0-173605DB647D', 'a2e9e709-8313-4c4a-bee3-0de7a4954cfc-00ODFA'
   */
  advisors: string
  /**
   * periodicContribution - periodic Contribution in $. Default value is 0
   */
  periodicContribution?: number
  /**
   * goalName - name of the goal.  Default value is 'AutoTests Goal'
   */  
  goalName?: string
  /**
   * goalType - type of the Goal: 'General'or 'Retirement'. Default value is GoalType.General
   */  
  goalType?: GoalType
  /**
   * GoalProgressAutoadjustment - true if goalProgress parameter is allowed to be adjusted during calculations. Default value is true
   */   
  goalProgressAutoadjustment?: boolean
}
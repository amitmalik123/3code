import {BaseApiClass, BaseApiEndpoint, HttpMethod} from '../../../../base/base-endpoint'
import {GoalCreationRequest} from '../v1/types'

export class GoalsV1 extends BaseApiClass{
  constructor(route: string = '/goals/api/v1', packagePath: string = 'ewm3/api/goals/v1') {
    super(route, packagePath)
  }
  public readonly goals: Goals = new Goals(`${this.route}/goals`, this.packagePath)
}

class Goals extends BaseApiClass{
  postCreateGoal(body: GoalCreationRequest): BaseApiEndpoint {
    return {
      method: HttpMethod.POST,
      route: `${this.route}`,
      body: body,
      schema: this.getSchema('goal'),
      title: 'Post create goal'
    }
  }

  readonly deleteGoal: BaseApiEndpoint = {
    method: HttpMethod.DELETE,
    route: `${this.route}`,
    pathParameters: '{id}',
    schema: this.getSchema('string-response'),
    title: 'Delete specific goal id'
  }
}


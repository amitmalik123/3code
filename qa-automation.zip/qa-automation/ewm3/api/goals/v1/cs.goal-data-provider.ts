import { APIRequestContext, expect } from '@playwright/test'
import { GeneralUtils } from '../../../../utils/generalUtils'
import { CSAccountsDbQueries } from '../../../db-access/client-section/cs.accounts-db-queries'
import { CSDbInfoConfig } from '../../../db-access/client-section/cs.base-db-queries'
import { CSGoalsDbQueries } from '../../../db-access/client-section/cs.goals-db-queries'
import { GoalAccount, GoalContributionPeriod, GoalCreationRequest, GoalData, GoalParameters, GoalResponse, GoalStatus, GoalType } from './types'
import { EWM3ApiHelpers } from '../../api-helpers'
import { GoalsV1 } from './endpoints'

export class CSGoalDataProvider {

  readonly goalsDbQueries = new CSGoalsDbQueries(CSDbInfoConfig.goalsDataBaseName)
  readonly accountsDbQueries = new CSAccountsDbQueries(CSDbInfoConfig.goalsDataBaseName)

  determineGoalStatus(goalProgress: number): GoalStatus {
    if (goalProgress >= 0.845) {
      return GoalStatus.OnTrack
    } else if (goalProgress >= 0.695) {
      return GoalStatus.AtRisk
    } else {
      return GoalStatus.OffTrack
    }
  }

  /**
 * Calculates the rate of return (RoR) using the Newton-Raphson method based on the formula:
 * expectedMV = startMV(1 + i)^contributionNumber + (periodicContribution((1 + i)^contributionNumber - 1) / i)
 * 
 * @param expectedMV - Expected market value
 * @param startMV - Start market value
 * @param periodicContribution - Periodic contribution amount
 * @param contributionNumber - Number of contributions
 * @param initialGuess - Initial guess for the rate of return (default is 0.1)
 * @param tolerance - Tolerance level for convergence (default is 1e-7)
 * @param maxIterations - Maximum number of iterations to perform (default is 1000)
 * @returns The calculated rate of return
 * @throws Error if the Newton-Raphson method does not converge within the given iterations
 */
  calculate_ror(expectedMV: number, startMV: number, periodicContribution: number, contributionNumber: number, initialGuess: number = 0.1, tolerance: number = 1e-8, maxIterations: number = 1000): number {
    // Initialize the rate of return with the initial guess
    let i = initialGuess
    let iteration = 0

    // Iterate using the Newton-Raphson method until the maximum number of iterations is reached
    while (iteration < maxIterations) {
      // Calculate the function value f(i)
      // f(i) = startMV(1 + i)^contributionNumber + (periodicContribution((1 + i)^contributionNumber - 1) / i) - expectedMV
      const f = (startMV * Math.pow(1 + i, contributionNumber)) + (periodicContribution * (Math.pow(1 + i, contributionNumber) - 1) / i) - expectedMV
      if (f===0){
        return i < 0? 0.0001: i
      }
      // Calculate the derivative of the function df/di
      // df(i) = startMV * contributionNumber * (1 + i)^(contributionNumber - 1) + 
      //         periodicContribution * ((1 + i)^contributionNumber - 1) / i^2 - 
      //         periodicContribution * contributionNumber * (1 + i)^(contributionNumber - 1) / i
      const df = (startMV * contributionNumber * Math.pow(1 + i, contributionNumber - 1)) + (periodicContribution * (Math.pow(1 + i, contributionNumber) - 1) / Math.pow(i, 2)) - (periodicContribution * contributionNumber * Math.pow(1 + i, contributionNumber - 1) / i)

      // Update the value of i using the Newton-Raphson method
      // new_i = i - f(i) / df(i)
      const new_i = i - f / df

      // Check if the result has converged
      // If the absolute difference between the new and old value of i is less than the tolerance, return the new value
      if (Math.abs(new_i - i) < tolerance) { 
        return new_i < 0? 0.0001: new_i
      }

      i = new_i
      iteration++
    }
    // When RoR can'n be calculated  in the giving  maximum number of iterations return this avarage value
    return 0.1 
  }

  returnEligibleForGoalTypesByAccountStatus(status: string): GoalType[] {
    let goalTypes: GoalType[]
    if (status.toLowerCase() === 'active' ) {
      goalTypes = [GoalType.General, GoalType.Retirement]
    } else {
      goalTypes = []
    }
    return goalTypes
  }

  public async getGoalAccountDetails(accountId: string): Promise<GoalAccount> {
    const dbAccountSourceData = (await this.accountsDbQueries.returnSourceAccountDataByAccountId(accountId))[0]
    const dbAccountData = (await this.accountsDbQueries.returnAccountById(accountId))[0]
    const goalAccount: GoalAccount = {
      id: accountId,
      title: dbAccountData?.name,
      bankAccountNumber: dbAccountSourceData?.bankaccountnumber,
      marketValue: parseFloat((await this.accountsDbQueries.returnLastMvByAccountId(accountId))[0]?.resultmv),
      eligibleForGoalTypes: this.returnEligibleForGoalTypesByAccountStatus(dbAccountData?.status)
    }
    return goalAccount
  }

  /**
 * Method that returns calculated Goal's parameters for Create Goal Request and Response
 * @param goalProgress - goal progress status fraction that reflect the ratio of actual daily market value to current day target value, e.g. 0.85. 
 *                       goalProgress parameter can be adjusted during calculations if spreadRoR can't be calculated with existing options.
 * @param monthsFromTodayToStart - how many months ago from today to goal start 
 *                                 monthsFromTodayToStart parameter can be adjusted during calculations if the data of the earliest market value for selected account is not late enough.
 * @param goalDuration - duration of the goal in months. Default value is 36
 * @param clientId - Client ID for Goal as it is stored in the DB in the cmd.organization table in the field 'organizationid'. Example: '5EEA3FE7-140F-435F-8F20-79D7BE5A0C3A-000D'. If not specified then the first Client found in the DB with the appropriate numOfAcc suitable for Goal creation will be used
 * @param numOfAcc - number of Accounts for Goal creation. Default value is 1
 * @param advisors - string with the list of advisor IDs separated with ','. Example: 'C5B78A40-E22E-4E34-94C0-173605DB647D', 'a2e9e709-8313-4c4a-bee3-0de7a4954cfc-00ODFA'
 * @param periodicContribution - periodic Contribution in $. Default value is 0
 * @param goalName - name of the goal.  Default value is 'AutoTests Goal'
 * @param goalType - type of the Goal: 'General'or 'Retirement'. Default value is GoalType.General
 * @param goalProgressAutoadjustment - true if goalProgress parameter is allowed to be adjusted during calculations. Default value is true
 * @return GoalData - structure with Goal's data
 */
  public async calculateGoalData (options?: GoalParameters): Promise<GoalData> {

    const { goalProgress = 0.85, monthsFromTodayToStart = 6, goalDuration = 36, clientId, numOfAcc = 1, advisors='', periodicContribution = 0, goalName = 'AutoTests Goal', goalType = GoalType.General, goalProgressAutoadjustment = true} = options || {}
    const responseClientIds: string[] = []
    let minValuationdate = new Date()
    let periodicContributionCorrected = 0

    let accountIdsArray: string[] = []
    let earliestAccountsIds: string[] = []

    let targetDate = new Date()
    let actualStartDate = new Date()
    let finalStartDate = new Date()
    let daysSinceStart = 0
    let startMV = 0
    let factMV = 0
    let expectMV = 0
    let totalGoalDays = 0
    let dailyContribution = 0
    let spreadRoR = 0
    let targetValue = 0
    let finalresponseClientId = ''

    if (clientId) {
      responseClientIds.push(clientId)
    } else {      
      earliestAccountsIds = await this.goalsDbQueries.getEarliestAccountForGoalByAdvisor(advisors, numOfAcc)
      for (const earliestAccountsId of earliestAccountsIds) {
        responseClientIds.push((await this.goalsDbQueries.returnClientByAccountId(earliestAccountsId))[0]?.parentid)
      }
    }

    if (responseClientIds.length === 0){
      throw new Error('Can not find Client appropriate for Goal creation for Advisors: '+ advisors)
    }

    for (let i = 0; i < responseClientIds.length; i++) {
      accountIdsArray = []
      if (earliestAccountsIds.length > 0){
        accountIdsArray.push(earliestAccountsIds[i])
      }

      let accountIds = accountIdsArray.map(id => `'${id}'`).join(', ')
      if (numOfAcc-accountIdsArray.length > 0){
        accountIdsArray.push(...await this.goalsDbQueries.returnAccountsForGoalByClientId(responseClientIds[i], numOfAcc-accountIdsArray.length, accountIds))
      }

      for (const accountId of accountIdsArray) {
        const currentDate = await this.accountsDbQueries.returnEarliestMvValuationDateByAccountId(accountId)
        minValuationdate = currentDate < minValuationdate? currentDate: minValuationdate
      } 

      accountIds = accountIdsArray.map(id => `'${id}'`).join(', ')

      const currentDate = new Date()
      const startDate = new Date(currentDate)
      startDate.setMonth(startDate.getMonth() - monthsFromTodayToStart)
      startDate.toLocaleDateString('en-CA', { year: 'numeric', month: '2-digit', day: '2-digit'})
      actualStartDate = minValuationdate < startDate? startDate: minValuationdate

      if (!goalProgressAutoadjustment && goalProgress < 0.75) {
        finalStartDate = startDate
      } else {
        finalStartDate = actualStartDate
      }
      
      targetDate = new Date(finalStartDate)
      targetDate.setMonth(targetDate.getMonth() + goalDuration)
      targetDate.toLocaleDateString('en-CA', { year: 'numeric', month: '2-digit', day: '2-digit'})
    
      daysSinceStart = Math.floor( Math.abs((currentDate.getTime() - finalStartDate.getTime())/(1000 * 60 * 60 * 24)))

      startMV = await this.goalsDbQueries.returnSumMVByDateByAccounts(accountIds, actualStartDate)
      periodicContributionCorrected = (startMV === 0 && periodicContribution == 0)? 500: periodicContribution
      startMV = startMV === 0? 1: startMV // We can't create Goal with startMV = 0

      factMV = await this.goalsDbQueries.returnSumMVByDateByAccounts(accountIds, currentDate)
      expectMV = daysSinceStart > 0? factMV / goalProgress: factMV
      totalGoalDays = Math.floor( Math.abs((targetDate.getTime() - finalStartDate.getTime())/(1000 * 60 * 60 * 24)))
      dailyContribution = periodicContributionCorrected * goalDuration / totalGoalDays
      spreadRoR = this.calculate_ror(expectMV, startMV, dailyContribution, daysSinceStart)
      targetValue = startMV * Math.pow((1+spreadRoR),totalGoalDays)+ dailyContribution * (Math.pow((1+spreadRoR),totalGoalDays)-1)/spreadRoR
      finalresponseClientId = responseClientIds[i]
      
      if (goalProgressAutoadjustment || (!isNaN(targetValue) && targetValue < 900000000000)) {
        break
      }
    }

    let expectMVWithCorrection = expectMV
    let goalProgressWithCorrection = goalProgress

    if (isNaN(targetValue) || targetValue >= 900000000000) {
      if (goalProgressAutoadjustment){
        targetValue = 900000000000
        spreadRoR = this.calculate_ror(targetValue, startMV, dailyContribution, totalGoalDays)
  
        expectMVWithCorrection = startMV * Math.pow((1+spreadRoR),daysSinceStart)+ dailyContribution * (Math.pow((1+spreadRoR),daysSinceStart)-1)/spreadRoR
        goalProgressWithCorrection = factMV / expectMVWithCorrection
      }
      else {
        throw new Error(`Goal data cann't be calculate for Advisors: ${advisors} and Goal Progress: ${goalProgress}`)
      }
    }

    const goalData: GoalData = {
      name: goalName,
      type: goalType,
      goalProgress: goalProgressWithCorrection,
      planDetails: {
        startDate: GeneralUtils.formatDateToHyphenString(finalStartDate),
        startMarketValue: startMV,
        targetDate: GeneralUtils.formatDateToHyphenString(targetDate),
        targetMarketValue: targetValue,
        periodicContribution: periodicContributionCorrected,
        periodicity: GoalContributionPeriod.Monthly
      },
      currentMarketValue: factMV,
      currentExpectedMarketValue: expectMVWithCorrection,
      householdId: finalresponseClientId,
      accountIds: accountIdsArray
    }
    return goalData
  }

  /**
 * Method that returns Goal request structure by calculated data for Goal
 * @param goalData - calculated Goal's data
 * @return GoalCreationRequest - structure with Goals's data for Goal creation
 */
  public async returnRequestGoalBody (goalData: GoalData): Promise<GoalCreationRequest> {
    const requestBody: GoalCreationRequest = {
      householdId: goalData.householdId,
      title: goalData.name,
      type: goalData.type,
      planDetails: {
        startDate: goalData.planDetails.startDate,
        startMarketValue: parseFloat(goalData.planDetails.startMarketValue.toFixed(4)),
        targetDate: goalData.planDetails.targetDate,
        targetMarketValue: parseFloat(goalData.planDetails.targetMarketValue.toFixed(4)),
        periodicContribution: parseFloat(goalData.planDetails.periodicContribution.toFixed(4)),
        periodicity: goalData.planDetails.periodicity
      },
      accountIds: goalData.accountIds
    }
    return requestBody
  }

  /**
 * Method that returns Goal's respo se parameters  by calculated data for Goal
 * @param goalProgress - goal progress status fraction that reflect the ratio of actual daily market value to current day target value, e.g. 0.85
 * @param goalData - calculated Goal's data
 * @return GoalResponse - structure with Goals's data for Goal creation
 */
  public async returnResponseGoalBody (goalData: GoalData): Promise<GoalResponse> {

    const goalStatus = this.determineGoalStatus(goalData.goalProgress)
    const accountsArray: GoalAccount[] = []

    for (const accountId of goalData.accountIds){
      accountsArray.push(await this.getGoalAccountDetails(accountId))
    }

    const goalResponse: GoalResponse = {
      id: '',
      name: goalData.name,
      type: goalData.type,
      status: goalStatus,
      planDetails: {
        startDate: goalData.planDetails.startDate,
        startMarketValue: parseFloat(goalData.planDetails.startMarketValue.toFixed(4)),
        targetDate: goalData.planDetails.targetDate,
        targetMarketValue: parseFloat(goalData.planDetails.targetMarketValue.toFixed(4)),
        periodicContribution: parseFloat(goalData.planDetails.periodicContribution.toFixed(4)),
        periodicity: goalData.planDetails.periodicity
      },
      currentMarketValue: parseFloat(goalData.currentMarketValue.toFixed(4)),
      currentExpectedMarketValue: parseFloat(goalData.currentExpectedMarketValue.toFixed(4)),
      totalPrincipal: 1,
      totalInterest: 1,
      accounts: accountsArray
    }
    return goalResponse
  }

  /**
 * Method that checks if Goal exists in the Database
 * @param goalId - goal identifier
 * @return boolean - if Goal exists in the Database or not
 */
  public async goalExistsInDb (goalId: string): Promise<boolean> {
    const goal = this.goalsDbQueries.returnGoalById(goalId)
    return goal !== null
  }

  /**
 * Method that checks if specified Account is connected with specified Goal in the Database 
 * @param accountId - account identifier
 * @param goalId - goal identifier
 * @return boolean - if Goal exists in the Database or not
 */
  public async accountConnectedWithGoalInDb (accountId: string, goalId: string): Promise<boolean> {
    const goalFromDb = await this.goalsDbQueries.returnGoalByAccountId(accountId)??''
    return goalFromDb === goalId
  }

  /**
 * Method that create Goal and check the result in DB
 * @param requestContext - APIRequest
 * @param options.goalProgress - goal progress status fraction that reflect the ratio of actual daily market value to current day target value, e.g. 0.85
 * @param options.monthsFromTodayToStart - how many months ago from today start goal
 * @param options.goalDuration - duration of the goal in months
 * @param options.clientId - Client ID for Goal as it is stored in the DB in the cmd.organization table in the field 'organizationid'. Example: '5EEA3FE7-140F-435F-8F20-79D7BE5A0C3A-000D'. If not specified then the first Client found in the DB with the appropriate numOfAcc suitable for Goal creation will be used
 * @param options.numOfAcc - number of Accounts for Goal creation. Default value is 1
 * @param options.periodicContribution - periodic Contribution in $. Default value is 0
 * @return GoalData - structure with Goal's calculated data
 */
  public async createGoalAndAssertDb (requestContext: APIRequestContext, options?: GoalParameters): Promise<{goalData: GoalData, responseBody: GoalResponse, route: string}> {
    const goalData = await this.calculateGoalData(options)
    const requestBody: GoalCreationRequest = await this.returnRequestGoalBody(goalData)

    const api = new EWM3ApiHelpers(requestContext)
    const endpoint = new GoalsV1().goals.postCreateGoal(requestBody)
    const response = await api.makeRequest(endpoint)
    await api.responseIs201(response)
    const responseBody: GoalResponse = await response.json()

    for (const account of responseBody.accounts){
      const accountId = account.id 
      expect.soft(await this.accountConnectedWithGoalInDb(accountId, responseBody.id), `Assert that Accout ${accountId} is connected with Goal ${responseBody.id} in 'Goals' DB -> public.virtual_account`).toBeTruthy()
    }
    expect.soft(await this.goalExistsInDb(responseBody.id), `Assert that Goal ${responseBody.id} exists in the 'Goals' DB -> public.goal`).toBeTruthy()  
    return {goalData, responseBody, route: endpoint.route}
  }

  /**
 * Method that delete Goal
 * @param requestContext - APIRequest
 * @param goalId - goal identifier
 */
  public async deleteGoal (requestContext: APIRequestContext, goalId: string) {
    const api = new EWM3ApiHelpers(requestContext)
    const endpoints = new GoalsV1().goals

    endpoints.deleteGoal.pathParameters = goalId
    await api.responseIs200(await api.makeRequest(endpoints.deleteGoal))
  }

  /**
 * Method that create data for Goal with closed Account
 * @param advisors - string with the list of advisor IDs separated with ','. Example: 'C5B78A40-E22E-4E34-94C0-173605DB647D'
 * @return GoalData - structure with Goal data
 */
  public async calculateGoalDataClosedAccount (advisors: string): Promise<GoalData> {
    const clientIdWithClosedAcc = await this.goalsDbQueries.returnClientWithAccountForGoalAndClosedAccountByAdvisorId(advisors)

    if (!clientIdWithClosedAcc) {
      throw new Error (`Can't find Client with one Account appropriate for Goal creation and one closed Account for Advisors: ${advisors}`)
    }

    const goalData = await this.calculateGoalData({goalProgress:0.95, monthsFromTodayToStart: 5, goalDuration: 48, advisors: advisors, clientId: clientIdWithClosedAcc})
    const closedAcc = await this.accountsDbQueries.returnTerminatedAccountByClientId(clientIdWithClosedAcc)
    goalData.accountIds = [closedAcc]

    return goalData
  }

  /**
 * Method that create data for Goal without Accounts
 * @param advisors - string with the list of advisor IDs separated with ','. Example: 'C5B78A40-E22E-4E34-94C0-173605DB647D'
 * @return GoalData - structure with Goal data
 */
  public async calculateGoalDataEmptyAccounts (advisors: string): Promise<GoalData> {
    const clientId = await this.goalsDbQueries.returnClientForGoalByAdvisorId(advisors, 1)
  
    if (!clientId) {
      throw new Error (`Can't find Client with Account appropriate for Goal creation for Advisors: ${advisors}`)
    }
  
    const goalData = await this.calculateGoalData({goalProgress:0.95, monthsFromTodayToStart: 5, goalDuration: 48, advisors: advisors, clientId: clientId})
    goalData.accountIds = []
  
    return goalData
  }

  /**
 * Method that creates data for Goal by modification of the corret Response
 * @param advisors - string with the list of advisor IDs separated by ','. Example: 'C5B78A40-E22E-4E34-94C0-173605DB647D'
 * @param paramToChange - the property of GoalData to be modified
 * @param valueToChange - the value to set for the specified property
 * @return GoalData - structure with Goal data
 */
  public async calculateGoalModifiedData<K extends keyof GoalData>(advisors: string, paramToChange: K, valueToChange: GoalData[K]): Promise<GoalData> {
    const clientId = await this.goalsDbQueries.returnClientForGoalByAdvisorId(advisors, 1)
  
    if (!clientId) {
      throw new Error(`Can't find Client with Account appropriate for Goal creation for Advisors: ${advisors}`)
    }
  
    const goalData = await this.calculateGoalData({goalProgress: 0.95, monthsFromTodayToStart: 5, goalDuration: 48, advisors: advisors, clientId: clientId})
    goalData[paramToChange] = valueToChange
  
    return goalData
  }

}
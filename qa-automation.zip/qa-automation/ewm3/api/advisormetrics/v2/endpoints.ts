import { BaseApiClass, BaseApiEndpoint, HttpMethod } from '../../../../base/base-endpoint'

export enum Periods {
  MTD = 'mtd',
  QTD = 'qtd',
  YTD = 'ytd'
}

export class AdvisorMetricsV2 extends BaseApiClass {
  constructor(route: string = '/advisormetrics/api/v2', packagePath: string = 'ewm3/api/advisormetrics/v2') {
    super(route, packagePath)
  }
  public readonly cms: Cms = new Cms(`${this.route}/cms`, this.packagePath)
  public readonly metrics: Metrics = new Metrics(`${this.route}/metrics`, this.packagePath)
  public readonly workItems: WorkItems = new WorkItems( `${this.route}/workitem`, this.packagePath)
}
class Cms extends BaseApiClass {

  readonly ewmMetadata: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/ewm-metadata`,
    pathParameters: ['{resource}', '{id}'],
    schema: this.getSchema('string-response'),
    title: `Get cms ewm metadata`
  }

  readonly advisorWorkstation: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/ewm-metadata/menu_items/advisor-workstation`,
    title: `Get advisor workstation cms items`
  }

}

class Metrics extends BaseApiClass {

  readonly investmentsStrategy: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/investments/strategy`,
    schema: this.getSchema('investment-strategies'),
    title: 'Get investment strategies'
  }

  readonly investmentsApproach: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/investments/approach`,
    schema: this.getSchema('investment-approaches'),
    title: 'Get investment approaches'
  }

  netFlows(queryParameters?: { [key: string]: string | number | boolean } | { advisor: string | string[]}): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}/netflow`,
      pathParameters: '{period}',
      queryParameters: queryParameters,
      schema: this.getSchema('netflows'),
      title: 'Get net flows'
    }
  }

  readonly aop: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/aum`,
    pathParameters: '{period}',
    schema: this.getSchema('aop'),
    title: 'Get assets on platform'
  }

  readonly fees: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/revenue`,
    schema: this.getSchema('fees'),
    title: 'Get fees'
  }

  readonly advisors: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/advisors`,
    schema: this.getSchema('advisors'),
    title: 'Get advisors'
  }

  readonly clients: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/clients`,
    schema: this.getSchema('clients'),
    title: 'Get clients list'
  }

  readonly clientsFlagged: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/clients/flagged`,
    schema: this.getSchema('clients'),
    title: 'Get flagged clients list'
  }

  readonly accounts: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/accounts`,
    schema: this.getSchema('accounts'),
    title: 'Get accounts list'
  }

  readonly advisorBenefits: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/advisorbenefits`,
    schema: this.getSchema('advisor-benefits'),
    title: 'Get advisor benefits program'
  }

}

class WorkItems extends BaseApiClass {

  readonly all: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}`,
    schema: this.getSchema('work-items'),
    title: 'Get all work items'
  }

  readonly open: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/open`,
    schema: this.getSchema('work-items-open'),
    title: 'Get open work items'
  }

  readonly needAttention: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/needattention`,
    schema: this.getSchema('work-items-need-attention'),
    title: 'Get need attention work items'
  }

  readonly completed: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/completed`,
    schema: this.getSchema('work-items-completed'),
    title: 'Get completed work items'
  }

  readonly following: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/following`,
    schema: this.getSchema('work-items-following'),
    title: 'Get following work items'
  }

}

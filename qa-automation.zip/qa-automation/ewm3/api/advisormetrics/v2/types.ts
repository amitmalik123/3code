export interface StatusAndTrackingResponse {
  data:  StatusAndTrackingData[]
  error: Error
}

export interface StatusAndTrackingData {
  id:          string
  name:        string
  openDate:    string
  requestType: string
  status:      Status
  statusLabel: StatusLabel
  description: string
  flagged:     boolean
}

export enum Status {
  NEW = 'New',
  IN_PROCESS = 'InProcess',
  AWAITING_ACTION = 'AwaitingAction',
  COMPLETED = 'Completed',
  CANCELLED = 'Cancelled'
}

export enum StatusLabel {
  CLOSE = 'Close',
  IN_PROCESS = 'InProcess',
  REQUEST_CANCELED = 'Request Canceled',
}

export interface ClientListResponse {
  data:  ClientListData[]
  error: Error
}

export interface FeeResponse {
  history:      FeeHistory[]
  period:       Period
  totalsByName: TotalsByNameElement[]
  trendValue?:  TrendValue
}

export interface FeeHistory {
  data?:     FeeData
  key?:      string
  startDate: string
}

export interface FeeData {
  details:          FeeDetail[]
  numberOfAccounts: number
  numberOfClients:  number
  revenueTotal:     number
}

export interface FeeDetail {
  byBilledDate:     FeeByBilledDate[]
  name:             string
  numberOfAccounts: number
  numberOfClients:  number
  revenue:          number
}

export interface FeeByBilledDate {
  advisorId:        string
  billedDate:       string
  feeBillingType:   FeeBillingType
  fees:             number
  numberOfAccounts: number
  numberOfClients:  number
}

export enum FeeBillingType {
  Monthly = 'Monthly',
  Quarterly = 'Quarterly',
}

export enum Period {
  Qtd = 'qtd',
}

export interface TotalsByNameElement {
  name:    string
  revenue: number
}

export interface TrendValue {
  comparePercentage: number
  compareValue:      number
  revenue:           number
  startOfPeriod:     string
}

export interface ClientListData {
  clientName:        string
  marketValue:       number
  netInvestments:    number
  ytdPerformance:    number
  inceptionDate:     string
  advisorIdentifier: string
  id:                string
  flagged:           boolean
  clientAplId:       string
  sourceSystem:      string
  accounts:          Account[]
  webAccess?:        string
}

export interface Account {
  id:                  string
  accountRegistration: string
  alert:               Alert
  alerts:              Alert[]
  accountNumber?:      string
  accountStatus:       AccountStatus
  marketValue:         number
  investmentStrategy:  string
  sourceAccounts:      SourceAccount[]
  accountAplId:        string
  pendingAmount:       number
  pendingDays:         number
  advisorIdentifier:   string
  sourceSystem:        string
}

export enum AccountStatus {
  Active = 'Active',
  PendingFunding = 'Pending Funding',
}

export enum Alert {
  AccountNotTrading = 'Account Not Trading',
  Empty = '',
  RestrictedCash = 'Restricted Cash',
  RestrictedSecurities = 'Restricted Securities',
  RestrictedSecuritiesAccountNotTrading = 'Restricted Securities, Account Not Trading',
}

export interface SourceAccount {
  sourceID:        string
  sourceSystem:    string
  sourceAccountId: string
}

export interface Error {
  message: string
  code:    number
}

export interface AdvisorBenefitResponseBody {
  data:  AdvisorBenefitsData
  error: Error
}

export interface AdvisorBenefitsData {
  qualifyingAssets:           number
  level:                      string
  grossContributionsMTD:      number
  grossContributionsQTD:      number
  grossContributionsYTD:      number
  asOfDate:                   string
  benefitStatusEffectiveDate: string
  benefitStatusAccommodation: string
  serviceTier:                string
}

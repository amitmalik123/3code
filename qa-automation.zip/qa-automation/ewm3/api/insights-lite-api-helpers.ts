import {type APIRequestContext, test} from '@playwright/test'
import {BaseApiHelpers} from '../../base/base-api-helpers'
import {
  GetDashboardResponseBody,
  GetDashboardResponseBodyItemTile,
  PatchDashboardRequestBodyTile
} from './monitoring/v2/types'
import {MonitoringV2} from './monitoring/v2/endpoints'
import {getDashboardTile} from './monitoring/v2/test-data-generator'

export class InsightsLiteApiHelpers extends BaseApiHelpers {
  constructor(request: APIRequestContext) {
    super(request)
  }

  private readonly monitoringV2 = new MonitoringV2()

  /**
   * Method defines if current dashboard tiles state is the same as new
   * @return boolean - new and current tiles settings are equal or not
   * */
  private assertDashboardContainsAllTiles(newTiles: PatchDashboardRequestBodyTile[], currentTiles: GetDashboardResponseBodyItemTile[]): boolean {
    // Compare count of tiles
    if (newTiles.length !== currentTiles.length) {
      return false
    } else {
      // Comparing every tile one by one
      for (const currentTile of currentTiles) {
        // Find new tile object from newTiles that matches with currentTile object by widgetUid
        const matchingNewTile = newTiles.find(newTile => newTile.widgetUid === currentTile.widgetUid)
        // If matching tile is missing then assert failed
        if (!matchingNewTile) {
          return false
        } else if (
          // Assert that layout settings and tile activity state is the same
          !(matchingNewTile.layout.height === currentTile.layout.height &&
            matchingNewTile.layout.width === currentTile.layout.width &&
            matchingNewTile.preference.parameters.active === currentTile.preference.parameters.active)
        ) return false
      }
    }
    return true
  }

  /**
   * Manage Insights dashboard tiles preferences
   *
   * @param dashboardId - dashboard ID assets/fees/flows/
   * @param options - options for dashboard tiles preferences
   * @param options.active - show/hide tiles. Default is true
   * @param options.height - The height of the tiles (1, 2, 3, or 4). Default is 2.
   * @param options.width - The width of the tiles (1, 2, or 3). Default is 2.
   * @param options.tiles - An array of PatchDashboardRequestBodyTile objects representing the tiles to manage.
   *
   * @example
   * // Default usage
   * const api = new InsightsLiteApiHelpers(requestContext)
   * await api.manageDashboardTiles('assets')
   * // All assets tiles are added on dashboard
   * // Tiles height and width is 2(medium)
   *
   * @example
   * // Hide all tiles
   * const api = new InsightsLiteApiHelpers(requestContext)
   * await api.manageDashboardTiles('assets', {active: false})
   *
   * @example
   * // Set custom size
   * const api = new InsightsLiteApiHelpers(requestContext)
   * await api.manageDashboardTiles('assets', {height: 4, width: 3})
   *
   * @example
   * // Manage specific tile
   * const api = new InsightsLiteApiHelpers(requestContext)
   * await api.manageDashboardTiles('assets', {height: 4, width: 3, tiles: [getDashboardTile().insights.assets.market_value]})
   *
   * */
  async manageDashboardTiles(
    dashboardId: 'assets' | 'fees' | 'flows',
    options?: {
      active?: boolean,
      height?: 1 | 2 | 3 | 4 ,
      width?: 1 | 2 | 3,
      tiles?: PatchDashboardRequestBodyTile[]
    }
  ) {
    await test.step(`Manage dashboard tiles preferences using Monitoring v2 API`, async () => {

      // Set up defaults
      const {
        active = true,
        height = 2,
        width = 2,
        tiles = Object.values(getDashboardTile(active).insights[dashboardId]) as PatchDashboardRequestBodyTile[]
      } = options || {}

      // Apply height/width and coordinates to tiles
      for (let i = 0; i < tiles.length; i++) {
        tiles[i].layout.coordinateX = 0
        tiles[i].layout.coordinateY = i * height
        tiles[i].layout.height = height
        tiles[i].layout.width = width
      }

      // Make current dashboard state get request
      const currentDashboardResponse = await this.makeRequest(
        this.monitoringV2.dashboard.getDashboard({
          dashboardId,
          storageName: 'INSIGHTS'
        }))

      if (currentDashboardResponse.status() === 200) {
        const responseBody: GetDashboardResponseBody = await currentDashboardResponse.json()
        // If tiles count or layout settings are different
        if (!this.assertDashboardContainsAllTiles(tiles, responseBody.data.tiles)) {
          await test.step(`Current and new State are different. Deleting dashboard current`, async () => {
            await this.makeRequest(this.monitoringV2.dashboard.deleteDashboard({
              dashboardId,
              storageName: 'INSIGHTS'
            }))
          })
        } else return // If current dashboard tiles state is the same then method is over
      }
      await test.step(`Making request to push desirable tiles on dashboard`, async () => {
        await this.makeRequest(this.monitoringV2.dashboard.patchDashboard({
          name: dashboardId,
          tiles
        }, {dashboardId, storageName: 'INSIGHTS'}))
      })

    })
  }

}
import {type APIRequestContext, APIResponse, expect} from '@playwright/test'
import {test} from '../fixtures/base-ui-fixture'
import {EWM3Endpoints} from './endpoints'
import {Widgets} from './widgets'
import {GeneralUtils} from '../../utils/generalUtils'
import {BaseApiHelpers} from '../../base/base-api-helpers'
import {FlagTypes, MonitoringV1} from './monitoring/v1/endpoints'
import {ClientListResponse, StatusAndTrackingResponse} from './advisormetrics/v2/types'
import {FlagArrayResponse} from './monitoring/v1/types'
import {AdvisorMetricsV2} from './advisormetrics/v2/endpoints'

export class EWM3ApiHelpers extends BaseApiHelpers{
  endpoints: EWM3Endpoints
  widgets: Widgets
  constructor(request: APIRequestContext) {
    super(request)
    this.widgets = new Widgets()
    this.endpoints = new EWM3Endpoints(request)
  }

  async firstDashboardId() {
    const response = await this.endpoints.getAllUsersDashboards()
    const responseBody = await response.json()
    const id: string = responseBody.data[0].id
    return id
  }

  async defaultDashboardId() {
    const response = await this.endpoints.getAllUsersDashboards()
    const responseBody = await response.json()
    let id: string = ''
    for (const data of responseBody.data) {
      if(data.isDefault == true) {
        id = data.id
        break
      }
    }
    return id
  }

  async deleteAllDashboards(qtdToKeep: number = 1) {
    const response = await this.endpoints.getAllUsersDashboards()
    const responseBody = await response.json()
    for (let i = 0; i < responseBody.data.length - qtdToKeep; i++) {
      await this.endpoints.deleteDashboard(responseBody.data[i].id)
    }
  }

  async initEmptyDashboard() {
    // remove all dashboards
    await this.deleteAllDashboards(0)
  }

  async initDashboardsData() {
    await test.step(`Deleting all dashboards except last and removing all tiles from last dashboard`, async () => {
      // remove all dashboards except 1
      await this.deleteAllDashboards()
      const dashboardId = await this.firstDashboardId()
      // set the last 1 dashboard as a default
      await this.endpoints.patchSetDefaultDashboard(dashboardId)
      // remove all tiles from default dashboard
      await this.endpoints.postAddWidgetsOnDashboard(
        dashboardId,
        []
      )
    })
  }

  async setDefaultDashboard() {
    await test.step(`Deleting all dashboards except last and removing all tiles from last dashboard`, async () => {
      const dashboardId = await this.defaultDashboardId()
      // set the last 1 dashboard as a default
      if (!dashboardId){
        await this.endpoints.patchSetDefaultDashboard(
          await this.firstDashboardId()
        )
      }
    })
  }

  async createMaxDashboards() {
    await test.step(`Create max count of empty dashboards`, async () => {
      const currentDashboard = await (await this.endpoints.getAllUsersDashboards()).json()
      for (let i =  currentDashboard.data.length; i < 5; i++) {
        await this.endpoints.postCreateDashboard(
          {
            name :`Dashboard ${GeneralUtils.generateRandomAlphanumericString(15)}`,
            widgets:[]
          }
        )
      }
    })
  }

  /**
     * Adds all existing widgets to your dashboard
     *
     * **Usage**
     *
     * Add all default sized widgets on default dashboard
     * ```js
     * const apiHelpers = new ApiHelpers(request);
     * await apiHelpers.addAllWidgetsOnDashboard();
     * ```
     * Smallest size
     * ```js
     * await apiHelpers.addAllWidgetsOnDashboard({height: 1, width: 1});
     * ```
     * Largest size
     * ```js
     * await apiHelpers.addAllWidgetsOnDashboard({height: 4, width: 3});
     * ```
     * Use not default dashboardId
     * ```js
     * await apiHelpers.addAllWidgetsOnDashboard({dashboardId: anotherDashboardId});
     * ```
     * 
     * @param options - options for adding all widgets. Optional
     * @param options.height - Has widget height. Available values: 1,2,3,4
     * @param options.width - widget width. Available values:  1,2,3
     * @param options.dashboardId - dashboard id where widgets will be added
     * @return APIResponse - API response result
     * */
  async addAllWidgetsOnDashboard(options?:{height?:number, width?:number, dashboardId?: string}) {
    const response = await this.endpoints.getAllUsersDashboards()
    const responseBody = await response.json()
    let id: string = ''
    let dashboardIndex = 0
    if (!options?.dashboardId){
      for (let i = 0; i < responseBody.data.length; i++) {
        if(responseBody.data[i].isDefault == true) {
          id = responseBody.data[i].id
          dashboardIndex = i
          break
        }
      }
    } else {
      id = options.dashboardId
      dashboardIndex = await responseBody.data.findIndex(data => data.id === id)
    }
    const widgetArray = Object.values(this.widgets.getWidgets(id))
    function assertContainsAllWidgets(allWidgetsArray:any[], apiResponseWidgetArray:any[]): boolean {
      if (allWidgetsArray.length !== apiResponseWidgetArray.length){
        return false
      } else {
        for (const apiResponseWidget of apiResponseWidgetArray) {
          const matchingWidget = allWidgetsArray.find(widget => widget.cmsId === apiResponseWidget.cmsId)
          if (!matchingWidget ||
                        matchingWidget.height !== apiResponseWidget.height ||
                        matchingWidget.width !== apiResponseWidget.width ) {
            return false
          }
        }
      }
      return true
    }
    if(options?.height || options?.width) {
      for (let i = 0; i < widgetArray.length; i++) {
        widgetArray[i].height = options.height ? options.height : widgetArray[i].height
        widgetArray[i].width = options.width ? options.width : widgetArray[i].width
      }
    }
    if (!assertContainsAllWidgets(widgetArray, responseBody.data[dashboardIndex].widgets)) {
      return await this.endpoints.postAddWidgetsOnDashboard(
        id,
        widgetArray
      )
    }

  }

  /**
     * Adds widget to your dashboard
     *
     * **Usage**
     *
     * Add default sized widgets array on default dashboard
     * ```js
     * const apiHelpers = new ApiHelpers(request);
     * const widgetArray = [apiHelpers.widgets.getWidgets().net_flows, apiHelpers.widgets.getWidgets().aum];
     * await apiHelpers.addWidgetsOnDashboard(widgetArray[]);
     * ```
     *
     *
     * Add default sized widgets array on default dashboard
     * ```js
     * const apiHelpers = new ApiHelpers(request);
     * const widget = await apiHelpers.widgets.getWidgets().net_flows;
     * await apiHelpers.addWidgetOnDashboard(widget);
     * ```
     * Smallest size
     * ```js
     * await apiHelpers.addWidgetOnDashboard(widget, {height: 1, width: 1});
     * ```
     * Largest size
     * ```js
     * await apiHelpers.addWidgetOnDashboard(widget, {height: 4, width: 3});
     * ```
     * Use not default dashboardId
     * ```js
     * await apiHelpers.addWidgetOnDashboard(widget, {dashboardId: anotherDashboardId});
     * ```
     * @param widget - widget or widget array that will be added to your dashboard
     * @param options - options for adding all widgets. Optional
     * @param options.height - widget height. Available values: 1,2,3,4
     * @param options.width - widget width. Available values:  1,2,3
     * @param options.dashboardId - dashboard id where widgets will be added
     * @return APIResponse - API response result
     * */
  async addWidgetOnDashboard(widget: any|any[], options?:{height?:number, width?:number, dashboardId?: string}) {
    const widgetsArray = Array.isArray(widget) ? widget : [widget]
    for (let i = 0; i < widgetsArray.length; i++) {
      widgetsArray[i].height = options?.height ? options.height : widgetsArray[i].height
      widgetsArray[i].width = options?.width ? options.width : widgetsArray[i].width
      widgetsArray[i].dashboardId = options?.dashboardId? options.dashboardId : widgetsArray[i].dashboardId || await this.defaultDashboardId()
    }
    return await this.endpoints.postAddWidgetsOnDashboard(
      widgetsArray[0].dashboardId,
      widgetsArray
    )
  }

  async removeAllWidgetsFromDashboard(dashboardId?: string) {
    const id = dashboardId? dashboardId : await this.defaultDashboardId()
    return  await this.endpoints.postAddWidgetsOnDashboard(
      id,
      []
    )
  }

  async mathValidationTotal(currentTotalValue:number, lastPeriodValue: number) {
    await test.step(`Then: I check that Total value equals last period value`, async () => {
      expect(currentTotalValue).toEqual(lastPeriodValue)
    })
  }

  async mathValidationCompareValue(compareValue:number, lastPeriodValue: number, onePeriodBeforeLastValue: number) {
    await test.step(`Then: I check that "compareValue" value equals last period value-1 period before last`, async () => {
      expect(compareValue.toFixed(2)).toEqual(
        (
          lastPeriodValue-onePeriodBeforeLastValue
        ).toFixed(2)
      )
    })
  }

  async mathValidationComparePercent(comparePercentage:number, lastPeriodValue: number, onePeriodBeforeLastValue: number) {
    await test.step(`Then: I check that "comparePercentage" value equals % diff last period value-1 period before last`, async () => {
      if (onePeriodBeforeLastValue != 0 ){
        const difference = lastPeriodValue - onePeriodBeforeLastValue
        expect(comparePercentage.toFixed(6)).toEqual(
          (difference/Math.abs(onePeriodBeforeLastValue))
            .toFixed(6)
        )
      }
    })
  }

  async mathValidation(currentTotalValue:any, compareValue:any, comparePercentage:any, lastPeriodValue: any, onePeriodBeforeLastValue: any){
    await this.mathValidationTotal(currentTotalValue, lastPeriodValue)
    await this.mathValidationCompareValue(compareValue, parseFloat(<string>(lastPeriodValue)), parseFloat(<string>(onePeriodBeforeLastValue)))
    await this.mathValidationComparePercent(comparePercentage, parseFloat(<string>(lastPeriodValue)), parseFloat(<string>(onePeriodBeforeLastValue)))
  }

  async flagSomeClientsItemIfEmpty(flagCount:number = 1) {
    const getFollowing = await this.endpoints.getClientsFollowing()
    if (getFollowing.status() === 204) {
      await test.step(`Then: add ${flagCount} client items to following tab (flag them)`, async () => {
        const response = await this.endpoints.getClients()
        await this.responseIs200(response)
        const responseBody = await response.json()

        // Initialize an array to keep track of flagged items
        const flaggedItems: number[] = []

        for (let i = 0; i < flagCount; i++) {
          let randomIndex: number
          do {
            randomIndex = GeneralUtils.getRandomNumber(responseBody.data.length)
          } while (flaggedItems.includes(randomIndex)) // Check if the item is already flagged

          const clientToFlag = responseBody.data[randomIndex]
          flaggedItems.push(randomIndex) // Add the flagged item to the list
          await this.endpoints.postClientFlags(clientToFlag.id)
        }
      })
    }
  }

  async flagItems(flagType: FlagTypes = FlagTypes.WORK_ITEM, itemsToFlagCount:number = 1) {
    await test.step(`Then: flagging ${itemsToFlagCount} items by type: ${flagType}`, async () => {
      let itemsListEndpoint
      switch (flagType) {
      case(FlagTypes.CLIENT):
        itemsListEndpoint = new AdvisorMetricsV2().metrics.clients
        break
      case(FlagTypes.WORK_ITEM):
      default:
        itemsListEndpoint = new AdvisorMetricsV2().workItems.all
        break
      }
      const flagEndpoints = new MonitoringV1().flag
      const response = await this.makeRequest(itemsListEndpoint)
      let responseBody: StatusAndTrackingResponse | ClientListResponse
      if (response.status() === 200) {
        responseBody = await response.json()
        const indexToFlagArray: number[] = []

        const maxAttempts = itemsToFlagCount * 10 // Set your desired maximum attempts

        for (let i = 0; i < itemsToFlagCount; i++) {
          let randomIndex: number
          let attempts = 0

          do {
            randomIndex = GeneralUtils.getRandomNumber(responseBody.data.length)
            attempts++

            // Check if the item is already flagged
          } while (
            (indexToFlagArray.includes(randomIndex) || responseBody.data[randomIndex].flagged) &&
                        attempts < maxAttempts
          )

          // Add the flagged item to the list if it was successfully flagged
          if (attempts < maxAttempts) {
            indexToFlagArray.push(randomIndex)
          } else {
            // Handle the case where the maximum attempts limit is reached
            console.error(`Unable to find a suitable random index after ${maxAttempts} attempts.`)
          }
        }

        await Promise.all(indexToFlagArray.map((index) => this.makeRequest(flagEndpoints.postFlags(
          {entityId: responseBody.data[index].id, entityType: flagType, userId: ''}
        ))))
      } else {
        throw new Error('There is no items to flag')
      }
    })
  }

  async unFlagItems(flagType: FlagTypes) {
    await test.step(`Then: removing all flagged items by type: ${flagType}`, async () => {
      const flagEndpoints = new MonitoringV1().flag
      const response = await this.makeRequest(flagEndpoints.flagsByType(flagType))
      if (response.status() === 200) {
        const responseBody: FlagArrayResponse = await response.json()
        await Promise.all(responseBody.data.map((item) => this.makeRequest(flagEndpoints.deleteFlagsById(item.id))))
      }
    })
  }

}
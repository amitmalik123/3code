import { BaseApiClass, BaseApiEndpoint, HttpMethod } from '../../../../base/base-endpoint'
import { ClientsSectionPreferences, DashboardQueryParams, PatchDashboardRequestBody, PutDashboardStoragesRequestBody } from './types'

export class MonitoringV2 extends BaseApiClass {

  constructor(route: string = '/monitoring/api/v2', packagePath: string = 'ewm3/api/monitoring/v2') {
    super(route, packagePath)
  }

  public readonly preferences: Preferences = new Preferences(`${this.route}/preferences`, this.packagePath)
  public readonly dashboard: Dashboard = new Dashboard(`${this.route}/dashboards`, this.packagePath)
  public readonly dashboardStorages: DashboardStorages = new DashboardStorages(`${this.route}/dashboards/storages`, this.packagePath)
}

class Preferences extends BaseApiClass {
  
  getPreferences(uid?: string): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}`,
      queryParameters: { uid: uid! },
      schema: this.getSchema('preference-dto-array-response'),
      title: 'Get user preferences'
    }
  }

  deletePreferences(uid?: string): BaseApiEndpoint {
    return {
      method: HttpMethod.DELETE,
      route: `${this.route}`,
      queryParameters: { uid: uid! },
      schema: this.getSchema('response'),
      title: 'Delete specific preference'
    }
  }

  putPreferences(body?: ClientsSectionPreferences): BaseApiEndpoint {
    return {
      method: HttpMethod.PUT,
      route: `${this.route}`,
      body: [body],
      schema: this.getSchema('preference-update-dto'),
      title: 'Put new preference'
    }
  }

}

class Dashboard extends BaseApiClass {

  getDashboard(queryParameters?: DashboardQueryParams | {[key: string]: string}): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}`,
      queryParameters,
      title: `Get dashboard`
    }
  }

  patchDashboard(body?: PatchDashboardRequestBody | any | null , queryParameters?: DashboardQueryParams |  {[key: string]: string}): BaseApiEndpoint {
    return {
      method: HttpMethod.PATCH,
      route: `${this.route}`,
      body,
      queryParameters,
      title: `Patch dashboard`
    }
  }

  deleteDashboard(queryParameters?: DashboardQueryParams | {[key: string]: string}): BaseApiEndpoint {
    return {
      method: HttpMethod.DELETE,
      route: `${this.route}`,
      queryParameters,
      title: `Delete dashboard`
    }

  }
}

class DashboardStorages extends BaseApiClass {

  getStorages(queryParameters?: DashboardQueryParams | {[key: string]: string}): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}`,
      queryParameters,
      title: `Get dashboard storages`
    }
  }

  putStorages(body?: PutDashboardStoragesRequestBody | any | null, queryParameters?: DashboardQueryParams | {[key: string]: string}): BaseApiEndpoint {
    return {
      method: HttpMethod.PUT,
      route: `${this.route}`,
      body,
      queryParameters,
      title: `Put dashboard storages`
    }

  }
}
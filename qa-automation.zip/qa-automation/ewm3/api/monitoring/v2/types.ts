export interface DashboardQueryParams {
  dashboardId: string,
  storageName?: string | 'INSIGHTS',
  [key: string]: string | number | boolean
}

export interface DashboardStorageQueryParams {
  storageName?: string | 'INSIGHTS',
  [key: string]: string | number | boolean
}

export interface PatchDashboardRequestBody {
  name:  string;
  tiles: PatchDashboardRequestBodyTile[];
}

export interface PatchDashboardRequestBodyTile {
  widgetUid:  string;
  layout:     DashboardTileLayout;
  preference: DashboardTilePreference;
}

export interface DashboardTileLayout {
  coordinateX: number;
  coordinateY: number;
  height:      number;
  width:       number;
}

export interface DashboardTilePreference {
  uid:           string;
  description:   string;
  schemaVersion: number;
  parameters:    Parameters;
}

export interface PutDashboardStoragesRequestBody {
  defaultDashboardId: string
}

export interface GetDashboardResponseBody {
  data:  GetDashboardResponseBodyItem;
  error: Error;
}

export interface GetDashboardResponseBodyItem {
  id:                 string;
  dashboardStorageId: string;
  name:               string;
  tiles:              GetDashboardResponseBodyItemTile[];
}

export interface GetDashboardResponseBodyItemTile {
  tileId:      string;
  dashboardId: string;
  widgetUid:   string;
  layout:      DashboardTileLayout;
  preference:  DashboardTilePreference;
}

interface Parameters {
  active: boolean;
}

interface Error {
  msg:  string;
  code: number;
}

export interface ClientsSectionPreferences {
  uid: string;
  description: string;
  schemaVersion: number;
  parameters: {
    metricsVisibility?: {
      [key: string]: boolean;
    };
    metricsOrder?: string[];
    initialColumnFilters?: { id: string; value: number[] | string[] }[];
    columnSorting?: string[];
    columnOrder?: string[];
    columnVisibility?: Record<string, boolean>;
    initialPageSize?: number;
  };
}

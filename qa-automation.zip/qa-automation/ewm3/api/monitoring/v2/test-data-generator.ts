import { ClientsSectionPreferences, DashboardTileLayout, DashboardTilePreference, PatchDashboardRequestBodyTile} from './types'
import {createHash} from 'node:crypto'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../utils/random'

function layout(): DashboardTileLayout{
  return {
    coordinateX: 0,
    coordinateY: 0,
    height: 2,
    width: 2
  }
}
function preference(widgetId: string, active: boolean):DashboardTilePreference {
  return {
    uid: createHash('md5').update(widgetId.replace(/\s+/g, '')).digest('hex'),
    description: 'this is a dump preferences here',
    schemaVersion: 0,
    parameters: {
      active
    }
  }
}

function tile(widgetUid: string, active: boolean): PatchDashboardRequestBodyTile {
  return {
    widgetUid,
    layout: layout(),
    preference: preference(widgetUid, active)
  }
}

export function getDashboardTile(active: boolean = true) {
  return {
    insights: {
      assets: {
        market_value: tile('widget-market-value', active),
        aop_lob: tile('widget-aop-lob', active),
        growth_rate: tile('widget-growth-rate', active),
        aop_investment_manager: tile('widget-aop-investment-manager', active),
        aop_investment_approach: tile('widget-aop-investment-approach', active)
      },
      fees: {
        analysis: tile('widget-fee-analysis', active),
        type: tile('widget-fees-type', active),
        yoy: tile('widget-fees-yoy', active),
        last_five_years: tile('fee-last-five-years-widget', active),
        analysis_table: tile('widget-fee-analysis-table', active),
      },
      flows: {
        analysis: tile('flow-analysis-widget', active),
        compare_inflows_outflows_mv: tile('compare-inflows-outflows-mv', active),
        yoy: tile('flows-yoy-widget', active),
        netflows_details: tile('widget-netflows-details', active),
      }
    }
  }
} 

/**
 * Generates toolbar preferences for a given UID.
 *
 * This function generates a set of preferences for the toolbar metrics, tailored to the specific UID provided.
 * The UID determines the structure and naming of the metrics. 
 * - If the UID includes 'households.household', metrics will be related to accounts count, portfolio value, and risk level.
 * - If the UID includes 'accounts.account', metrics will be related to account number, account value, and risk level.
 * - For other UIDs, metrics will be related to count, total assets value, and total pending funds value.
 *
 * @param {string} uid - The unique identifier for which the toolbar preferences are generated.
 * @returns {ClientsSectionPreferences} An object representing the toolbar metrics preferences.
 *
 * @example
 * const preferences = generateToolbarPreferences('clients.households.toolbar');
 * console.log(preferences);
 */
export function generateToolbarPreferences(uid: string): ClientsSectionPreferences {
  let countMetric: string
  let valueMetric: string
  let riskLevelMetric: string

  if (uid.includes('households.household')) {
    countMetric = `${uid}.metrics.accounts_count`
    valueMetric = `${uid}.metrics.portfolio_value`
    riskLevelMetric = `${uid}.metrics.risk_level`
  } else if (uid.includes('accounts.account')) {
    countMetric = `${uid}.metrics.account_number`
    valueMetric = `${uid}.metrics.account_value`
    riskLevelMetric = `${uid}.metrics.risk_level`
  } else {
    countMetric = `${uid}.metrics.${uid.split('.')[1] }_count`
    valueMetric = `${uid}.metrics.total_assets_value`
    riskLevelMetric = `${uid}.metrics.total_pending_funds_value`
  }

  return {
    uid: uid,
    description: `Clients Section Table Toolbar Metrics`,
    schemaVersion: 1,
    parameters: {
      metricsVisibility: {
        [countMetric]: faker.datatype.boolean(),
        [valueMetric]: faker.datatype.boolean(),
        [riskLevelMetric]: faker.datatype.boolean()
      },
      metricsOrder: Random.shuffleArray([
        countMetric,
        valueMetric,
        riskLevelMetric
      ])
    }
  }
}

/**
 * Generates column filters and preferences for a given UID.
 * 
 * This function creates and returns a preferences object containing filters, column order, column visibility,
 * and initial page size based on the provided UID. The function determines if the UID is for households or accounts
 * and sets the parameters accordingly.
 * 
 * @param {string} uid - The unique identifier for the preferences to be generated.
 * @returns {ClientsSectionPreferences} An object representing the preferences for the specified UID.
 */
export function generateColumnFilters(uid: string): ClientsSectionPreferences {
  const isHousehold = uid.includes('households')

  const formatNumber = (num: number) => parseFloat(num.toFixed(2))

  const filters = isHousehold
    ? [
      { id: 'fiveYearPerformance', value: [formatNumber(faker.number.float({ min: 0, max: 0.85 })), formatNumber(faker.number.float({ min: 0.86, max: 1 }))] },
      { id: 'accountStatus', value: faker.helpers.arrayElements(['Proposed', 'Pending Funding', 'Funded', 'Closed']) },
      { id: 'ytdPerformance', value: [formatNumber(faker.number.float({ min: 0, max: 0.11 })), formatNumber(faker.number.float({ min: 0.12, max: 1 }))] },
      { id: 'oneYearPerformance', value: [formatNumber(faker.number.float({ min: 0, max: 0.33 })), formatNumber(faker.number.float({ min: 0.34, max: 1 }))] },
      { id: 'threeYearPerformance', value: [formatNumber(faker.number.float({ min: 0, max: 0.86 })), formatNumber(faker.number.float({ min: 0.87, max: 1 }))] },
      { id: 'cumulativeReturn', value: [formatNumber(faker.number.float({ min: 0, max: 0.10 })), formatNumber(faker.number.float({ min: 0.11, max: 1 }))] },
      { id: 'annualizedPerformance', value: [formatNumber(faker.number.float({ min: 0, max: 0.25 })), formatNumber(faker.number.float({ min: 0.26, max: 1 }))] },
      { id: 'marketValue', value: [faker.number.int({ min: 0, max: 423728 }), faker.number.int({ min: 423729, max: 10000000 })] }
    ]
    : [
      { id: 'ytdPerformance', value: [formatNumber(faker.number.float({ min: 0, max: 0.86 })), formatNumber(faker.number.float({ min: 0.87, max: 1 }))] },
      { id: 'oneYearPerformance', value: [formatNumber(faker.number.float({ min: 0, max: 0.84 })), formatNumber(faker.number.float({ min: 0.85, max: 1 }))] },
      { id: 'cumulativeReturn', value: [formatNumber(faker.number.float({ min: 0, max: 0.29 })), formatNumber(faker.number.float({ min: 0.3, max: 1 }))] },
      { id: 'annualizedPerformance', value: [formatNumber(faker.number.float({ min: 0, max: 0.83 })), formatNumber(faker.number.float({ min: 0.84, max: 1 }))] },
      { id: 'marketValue', value: [faker.number.int({ min: 0, max: 423728 }), faker.number.int({ min: 423729, max: 10000000 })] }
    ]

  const columnOrder = isHousehold
    ? [
      'clientName', 'advisorIdentifier', 'proposed', 'numberOfAccounts', 'marketValue', 'netInvestments', 'establishedDate',
      'ytdPerformance', 'expectedAmount', 'qtdPerformance', 'cumulativeReturn', 'annualizedPerformance', 'assetAllocations',
      'webAccess', 'oneYearPerformance', 'threeYearPerformance', 'fiveYearPerformance', 'actionsEnd'
    ]
    : [
      'accountTitle', 'clientName', 'advisorIdentifier', 'registrationType', 'accountNumber', 'accountStatus',
      'investmentProduct', 'approach', 'marketValue', 'custodian', 'inceptionDate', 'qtdPerformance', 'ytdPerformance',
      'cumulativeReturn', 'annualizedPerformance', 'assetAllocations', 'expectedAmount', 'netInvestments', 'oneYearPerformance',
      'threeYearPerformance', 'fiveYearPerformance', 'actionsEnd'
    ]

  const columnVisibility: Record<string, boolean> = {
    clientName: true,
    advisorIdentifier: true,
    proposed: isHousehold,
    numberOfAccounts: isHousehold,
    marketValue: true,
    netInvestments: true,
    expectedAmount: true,
    establishedDate: isHousehold,
    qtdPerformance: true,
    ytdPerformance: true,
    cumulativeReturn: true,
    annualizedPerformance: true,
    oneYearPerformance: true,
    threeYearPerformance: true,
    fiveYearPerformance: true,
    assetAllocations: true,
    webAccess: isHousehold,
    actionsEnd: true,
    accountTitle: !isHousehold,
    registrationType: !isHousehold,
    accountNumber: !isHousehold,
    accountStatus: !isHousehold,
    investmentProduct: !isHousehold,
    approach: !isHousehold,
    custodian: !isHousehold,
    inceptionDate: !isHousehold
  }

  const initialPageSize = 25

  const parameters = {
    initialColumnFilters: filters,
    columnSorting: [],
    columnOrder,
    columnVisibility,
    initialPageSize
  }

  return {
    uid,
    description: `Clients Section Filtred Table`,
    schemaVersion: 1,
    parameters
  }
}

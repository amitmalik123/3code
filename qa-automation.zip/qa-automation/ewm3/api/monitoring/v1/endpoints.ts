import { BaseApiClass, BaseApiEndpoint, HttpMethod } from '../../../../base/base-endpoint'
import { FlagBody } from './types'

export class MonitoringV1 extends BaseApiClass {

  constructor(route: string = '/monitoring/api/v1', packagePath: string = 'ewm3/api/monitoring/v1') {
    super(route, packagePath)
  }

  public readonly cms: Cms = new Cms(`${this.route}/cms`, this.packagePath)
  public readonly dashboard: Dashboard = new Dashboard(`${this.route}/dashboard`, this.packagePath)
  public readonly flag: Flag = new Flag(`${this.route}/flags`, this.packagePath)
  public readonly widget: Widget = new Widget(`${this.route}/widget`, this.packagePath)
}

class Cms extends BaseApiClass {
  metadata: Metadata = new Metadata(`${this.route}/ewm-metadata`, this.packagePath) 
  resources: Resources = new Resources(`${this.route}/resources`, this.packagePath) 
}

class Metadata extends BaseApiClass {
  base(pathParameter: string | string[] | undefined, schemaName: string = 'string-response'): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}`,
      pathParameters: ['{resource}', '{id}'],
      schema: this.getSchema(schemaName),
      title: `Get cms ewm metadata: ${pathParameter}`
    }
  }

  readonly advisorProfile: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/menu_items/advisor-profile`,
    schema: this.getSchema('string-response'),
    title: 'Get advisor profile'
  }

  readonly advisorWorkstation: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/menu_items/advisor-advisor-workstation`,
    schema: this.getSchema('string-response'),
    title: 'Get advisor workstation'
  }

  readonly headerItems: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/menu_items/main`,
    schema: this.getSchema('string-response'),
    title: 'Get cms header data'
  }

  readonly widgets: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/widgets`,
    schema: this.getSchema('string-response'),
    title: 'Get cms widgets data'
  }

  readonly sidebar: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/side_bar`,
    schema: this.getSchema('string-response'),
    title: 'Get cms sidebar data'
  }

  readonly metadata: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/metadata`,
    schema: this.getSchema('string-response'),
    title: 'Get raw metadata'
  }

}

class Resources extends BaseApiClass {
  base(pathParameter: string | string[] | undefined, schemaName: string = 'string-response'): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}`,
      pathParameters: pathParameter,
      schema: this.getSchema(schemaName),
      title: `Get CMS resources: ${pathParameter}`
    }
  } 

  clients: BaseApiEndpoint = this.base(
    'clients',
    'resources-clients-response'
  )
  
  readonly siteModals: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/site_modals`,
    schema: this.getSchema('site-modals'),
    title: 'Get site modals'
  }

  readonly siteAlerts: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/sitealerts`,
    schema: this.getSchema('site-alerts'),
    title: 'Get site alerts'
  }

  readonly widgetsSettings: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/widgets_settings`,
    schema: this.getSchema('widgets-settings'),
    title: 'Get widget settings'
  }

  readonly ewmMarketing: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/ewm_marketing`,
    schema: this.getSchema('marketing'),
    title: 'Get ewm marketing'
  }

  readonly ewmMetadata: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/ewm_metadata`,
    schema: this.getSchema('ewm-metadata'),
    title: 'Get ewm_metadata'
  }

}

class Dashboard extends BaseApiClass {

  readonly dashboardsByUser: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/byuser`,
    schema: this.getSchema('dashboards-by-user'),
    title: 'Get all user dashboards'
  }

  readonly getDashboard: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}`,
    pathParameters: '{id}',
    schema: this.getSchema('dashboards-by-id'),
    title: 'Get specific dashboard id'
  }

  readonly deleteDashboard: BaseApiEndpoint = {
    method: HttpMethod.DELETE,
    route: `${this.route}`,
    pathParameters: '{id}',
    schema: this.getSchema('string-response'),
    title: 'Delete specific dashboard id'
  }

  readonly postCreateDashboard: BaseApiEndpoint = {
    method: HttpMethod.POST,
    route: `${this.route}`,
    body: {
      id: 'string',
      userId: 'string',
      name: 'string',
      isDefault: true,
      widgets: [
        {
          id: 'string',
          dashboardId: 'string',
          cmsId: 'string',
          coordinateX: 0,
          coordinateY: 0,
          height: 0,
          width: 0,
          settings: {
            schemaVersion: 0,
            allColumnsSelected: true,
            columns: [
              {
                id: 'string',
                position: 0,
                selected: true
              }
            ],
            clients: [
              {
                id: 'string',
                advisorId: 'string',
                clientName: 'string'
              }
            ],
            additional: {
              schemaVersion: 0,
              additionalProp1: 'string',
              additionalProp2: 'string',
              additionalProp3: 'string'
            }
          }
        }
      ]
    },
    schema: this.getSchema('dashboards-by-id'),
    title: 'Post create dashboard'
  }
  readonly putChangeDashboard: BaseApiEndpoint = {
    method: HttpMethod.PUT,
    route: `${this.route}`,
    body: {
      data: {
        id: 'string',
        userId: 'string',
        name: 'string',
        isDefault: true,
        widgets: [
          {
            id: 'string',
            dashboardId: 'string',
            cmsId: 'string',
            coordinateX: 0,
            coordinateY: 0,
            height: 0,
            width: 0,
            settings: {
              schemaVersion: 0,
              allColumnsSelected: true,
              columns: [
                {
                  id: 'string',
                  position: 0,
                  selected: true
                }
              ],
              clients: [
                {
                  id: 'string',
                  advisorId: 'string',
                  clientName: 'string'
                }
              ],
              additional: {
                schemaVersion: 0,
                additionalProp1: 'string',
                additionalProp2: 'string',
                additionalProp3: 'string'
              }
            }
          }
        ]
      },
      error: {
        msg: 'string',
        code: 0
      }
    },
    schema: this.getSchema('dashboards-by-id'),
    title: 'Put specific dashboard'
  }

  readonly setDefaultDashboard: BaseApiEndpoint = {
    method: HttpMethod.PATCH,
    route: `${this.route}/default`,
    body: 'dashboardId',
    schema: this.getSchema('string-response'),
    title: 'Set default dashboard id'
  }

}

export enum FlagTypes {
    CLIENT = 'CLIENT',
    ACCOUNT = 'ACCOUNT',
    WORK_ITEM = 'WORKITEM'
}
class Flag extends BaseApiClass {

  flagsByType(pathParameters?: string ): BaseApiEndpoint {
    return {method: HttpMethod.GET,
      route: `${this.route}`,
      pathParameters: pathParameters ?? '{flag_type}',
      schema: this.getSchema(`flag-array${pathParameters? '-by-'+pathParameters.toLowerCase() : ''}`),
      title: 'Get flags by type'}

  }

  readonly flagsByClientType: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/clients`,
    schema: this.getSchema('flag-array-by-client'),
    title: 'Get flags by client type(specific endpoint with filter)'
  }

  deleteFlagsById(pathParameters?: string ): BaseApiEndpoint {
    return {
      method: HttpMethod.DELETE,
      route: `${this.route}`,
      pathParameters: pathParameters ?? '{flag_id}',
      schema: this.getSchema('flag-single'),
      title: 'Delete flag by id'
    }
  }

  deleteFlags(queryParameters?: {[key: string]: string}): BaseApiEndpoint {
    return {
      method: HttpMethod.DELETE,
      queryParameters: queryParameters ?? {entityId: 'entityId', entityType: 'entityType'},
      route: `${this.route}`,
      schema: this.getSchema('flag-single'),
      title: 'Delete flags'
    }
  }

  postFlags(body: FlagBody | any = {
    id: 'string',
    userId: 'string',
    entityId: 'string',
    entityType: FlagTypes.CLIENT
  }): BaseApiEndpoint {
    return {
      method: HttpMethod.POST,
      route: `${this.route}`,
      body: body,
      schema: this.getSchema(`flag-single-by-${body.entityType.toLowerCase()}`),
      title: 'Post flag'
    }
  }
}

class Widget extends BaseApiClass {

  readonly getWidgetsByDashboardId: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}/bydashboard`,
    pathParameters: '{dashboard_id}',
    schema: this.getSchema('widget-list'),
    title: 'Get widgets by dashboard id'
  }

  readonly deleteWidgetsByDashboardId: BaseApiEndpoint = {
    method: HttpMethod.DELETE,
    route: `${this.route}/bydashboard`,
    pathParameters: '{dashboard_id}',
    schema: this.getSchema('string-response'),
    title: 'Delete widgets by dashboard id'
  }

  readonly getWidgetById: BaseApiEndpoint = {
    method: HttpMethod.GET,
    route: `${this.route}`,
    pathParameters: '{widget_id}',
    schema: this.getSchema('widget-single'),
    title: 'Get widget by id'
  }

  readonly deleteWidgetById: BaseApiEndpoint = {
    method: HttpMethod.DELETE,
    route: `${this.route}`,
    pathParameters: '{widget_id}',
    schema: this.getSchema('string-response'),
    title: 'Delete widget by id'
  }

  readonly postWidget: BaseApiEndpoint = {
    method: HttpMethod.POST,
    route: `${this.route}`,
    body: {
      id: 'string',
      dashboardId: 'string',
      cmsId: 'string',
      coordinateX: 0,
      coordinateY: 0,
      height: 0,
      width: 0,
      settings: {
        schemaVersion: 0,
        allColumnsSelected: true,
        columns: [
          {
            id: 'string',
            position: 0,
            selected: true
          }
        ],
        clients: [
          {
            id: 'string',
            advisorId: 'string',
            clientName: 'string'
          }
        ],
        additional: {
          schemaVersion: 0,
          additionalProp1: 'string',
          additionalProp2: 'string',
          additionalProp3: 'string'
        }
      }
    },
    schema: this.getSchema('widget-single'),
    title: 'Create widget'
  }

  readonly putWidget: BaseApiEndpoint = {
    method: HttpMethod.PUT,
    route: `${this.route}`,
    body: {
      id: 'string',
      dashboardId: 'string',
      cmsId: 'string',
      coordinateX: 0,
      coordinateY: 0,
      height: 0,
      width: 0,
      settings: {
        schemaVersion: 0,
        allColumnsSelected: true,
        columns: [
          {
            id: 'string',
            position: 0,
            selected: true
          }
        ],
        clients: [
          {
            id: 'string',
            advisorId: 'string',
            clientName: 'string'
          }
        ],
        additional: {
          schemaVersion: 0,
          additionalProp1: 'string',
          additionalProp2: 'string',
          additionalProp3: 'string'
        }
      }
    },
    schema: this.getSchema('widget-single'),
    title: 'Update existing widget'
  }
  readonly addToDashboard: BaseApiEndpoint = {
    method: HttpMethod.POST,
    route: `${this.route}/addtodashboard`,
    pathParameters: '{dashboard_id}',
    body: [{
      id: 'string',
      dashboardId: 'string',
      cmsId: 'string',
      coordinateX: 0,
      coordinateY: 0,
      height: 0,
      width: 0,
      settings: {
        schemaVersion: 0,
        allColumnsSelected: true,
        columns: [
          {
            id: 'string',
            position: 0,
            selected: true
          }
        ],
        clients: [
          {
            id: 'string',
            advisorId: 'string',
            clientName: 'string'
          }
        ],
        additional: {
          schemaVersion: 0,
          additionalProp1: 'string',
          additionalProp2: 'string',
          additionalProp3: 'string'
        }
      }
    }],
    schema: this.getSchema('widget-list'),
    title: 'Post add widget array to dashboard'
  }

}

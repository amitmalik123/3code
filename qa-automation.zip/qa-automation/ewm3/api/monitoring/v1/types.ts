import {FlagTypes} from './endpoints'

export interface DashboardArrayResponse {
    data:  DashboardData[];
    error: Error;
}

export interface DashboardResponse {
    data:  DashboardData;
    error: Error;
}

export interface WidgetResponse {
    data:  Widget;
    error: Error;
}

export interface WidgetArrayResponse {
    data:  Widget[];
    error: Error;
}

export interface DashboardData {
    id?:        string;
    userId?:    string;
    name:      string;
    isDefault?: boolean;
    widgets?:   Widget[];
}

export interface Widget {
    id:          string;
    dashboardId: string;
    cmsId:       string;
    coordinateX: number;
    coordinateY: number;
    height:      number;
    width:       number;
    settings?:    WidgetSettings;
}

export interface FlagArrayResponse {
    data:  FlagBody[];
    error: Error;
}
export interface FlagBody {
    id?:         string;
    userId:     string;
    entityId:   string;
    entityType: FlagTypes;
}

export interface WidgetSettings {
    allColumnsSelected: boolean;
    additional?:         AdditionalWidgetSettings | {};
}

export interface AdditionalWidgetSettings {
    schemaVersion:             number;
    advisorIds:                string[];
    clientColumnOrder?:        string[];
    clientColumnVisibility?:   ClientColumnVisibility;
    period?:                   string;
    strategyColumnOrder?:      string[];
    strategyColumnVisibility?: StrategyColumnVisibility;
    activeTab?:                string;
    columnOrder?:              string[];
    columnVisibility?:         ColumnVisibility;
}

export interface ClientColumnVisibility {
    webAccess:         boolean;
    actionsEnd:        boolean;
    clientName:        boolean;
    marketValue:       boolean;
    inceptionDate:     boolean;
    netInvestments:    boolean;
    ytdPerformance:    boolean;
    advisorIdentifier: boolean;
}

export interface ColumnVisibility {
    id:          boolean;
    name:        boolean;
    openDate:    boolean;
    actionsEnd:  boolean;
    requestType: boolean;
    statusLabel: boolean;
}

export interface StrategyColumnVisibility {
    name:              boolean;
    actionsEnd:        boolean;
    totalAssets:       boolean;
    totalAccounts:     boolean;
    currentAllocation: boolean;
}

export interface Error {
    msg:  string;
    code: number;
}

export interface ClientResourcesCmsResponse {
    data?: CmsClientData[];
    error: Error;
}

export interface CmsClientData {
    uid:         string;
    bid:         string;
    title:       string;
    description: string;
    tabs:        TabsArray[];
}

export interface TabsArray {
    uid:            string;
    bid?:           string;
    title?:         string;
    description:    string;
    labels:         LabelElement[];
    action_links?:  LinkElement[];
    tables:         CmsTableElement[];
}

export interface LabelElement {
    uid:   string;
    value: string;
}

export interface LinkElement {
    uid:   string;
    bid?: string;
    title?: string;
    action: string;
    order: number;
    parameter: LinkParametrElement[];
}

export interface LinkParametrElement {
    url:   string;
    target?: string;
    alt?: string;
}

export interface CmsTableElement {
    uid:   string;
    bid: string;
    name?: string;
    sort_header: string;
    sort_direction: string;
    headers: CmsTableHeaderElement[];
    row_actions?: LinkElement[];
    nested_table?: CmsTableElement[];
}

export interface CmsTableHeaderElement {
    uid:   string;
    name: string;
    description?: string;
    frozen: string;
    hidden: boolean;
    enable_hiding: boolean;
    enable_sorting: boolean;
    enable_filtering: boolean;
    default_order: number;
    action_link: LinkElement[];
}
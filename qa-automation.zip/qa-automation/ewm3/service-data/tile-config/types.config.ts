import { Locator } from '@playwright/test'
import { SearchCancelTrigger, SearchTrigger } from '../../ui/features/search.feature'
import { FieldConfig, TableDataConfig } from '../../ui/features/table.feature'

export type Font = {
  fontSize: string
  fontFamily: string
}

export type FontFormatArgument = {
  font: Font
  elementLocator: Locator
}

export type SearchParam = {
  tab: string
  fieldForSearchQuery: string
  searchableFieldArray: string[]
  searchTrigger: SearchTrigger
}

export type MappingParam = {
  tab: string
  endpoint: string
  mappingConfig?: TableDataConfig
}

export type SortingParam = {
  tab: string
  tableConfig: TableDataConfig
}

export type NestedSortingParam = {
  tab: string
  tableConfig?: FieldConfig[]
}

export type CustomizingColumnsParam = {
  tab: string
  tableConfig: TableDataConfig
}

export type CancelSearchParamsArray = {
  tab: string
  fieldForSearchQuery: string
  searchableFieldArray: string[]
  searchCancelTrigger: SearchCancelTrigger
}

export type ModalContent = {
  title: string
  content: string
}

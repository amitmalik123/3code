import { FieldConfig, TableDataConfig } from '../../ui/features/table.feature'
import { GeneralUtils } from '../../../utils/generalUtils'
import { SortingOrder } from '../../ui/features/sorting.feature'
import { MappingParam, ModalContent } from './types.config'

export abstract class StatusAndTrackingConfig {

  public static readonly title = 'Status & Tracking'

  public static readonly tileMenuOptions = {
    viewBenefitsDashboard: 'Access Tracking Center',
    learnAboutTile: 'Learn About This Tile',
    removeTile: 'Remove Tile'
  }

  public static readonly filters = {
    open_date: {
      name: 'Open Date',
      toggledOnSample: true,
      presentAtAllTabs: true,
      isMoveable: true,
      isSorteable: true
    },
    closed_date: {
      name: 'Closed Date',
      toggledOnSample: true,
      presentAtAllTabs: false,
      isMoveable: true,
      isSorteable: true
    },
    request_type: {
      name: 'Request Type',
      toggledOnSample: true,
      presentAtAllTabs: true,
      isMoveable: true,
      isSorteable: true
    },
    status: {
      name: 'Status',
      toggledOnSample: true,
      presentAtAllTabs: true,
      isMoveable: true,
      isSorteable: true
    },
    item_number: {
      name: 'Item Number',
      toggledOnSample: true,
      presentAtAllTabs: true,
      isMoveable: true,
      isSorteable: true
    },
    account_number: {
      name: 'Account Number',
      toggledOnSample: true,
      presentAtAllTabs: true,
      isMoveable: true,
      isSorteable: true
    },
    advisor_id: {
      name: 'Advisor ID',
      toggledOnSample: true,
      presentAtAllTabs: true,
      isMoveable: true,
      isSorteable: true
    }
  }

  public static readonly tabs = {
    needs_attention: {
      name: 'Needs Attention',
      filters: this.filters
    },
    open_items: {
      name: 'Open Items',
      filters: this.filters
    },
    completed: {
      name: 'Completed',
      filters: this.filters
    },
    following: {
      name: 'Following',
      filters: this.filters
    },
  }

  public static readonly endpoints = {
    needs_attention: '/advisormetrics/api/v2/workitem/needattention',
    open_items: '/advisormetrics/api/v2/workitem/open',
    completed: '/advisormetrics/api/v2/workitem/completed',
    following: '/advisormetrics/api/v2/workitem/following'
  }

  public static readonly columnNames = {
    name_or_registration: 'Name/Account Title',
    open_date: 'Open Date',
    request_type: 'Request Type',
    status: 'Status',
    item: 'Item Number'
  }

  public static readonly searchableFields = [
    this.columnNames.name_or_registration,
    this.columnNames.item
  ]
  private static readonly defaultSortingField: FieldConfig = {
    columnName: this.columnNames.open_date,
    apiField: 'openDate',
    apiDataTransform: GeneralUtils.convertDateFormat,
    sortingDataTransform: GeneralUtils.parseDate,
    frozen: false,
    hidden: false,
    enable_sorting: true
  }
  public static readonly tableDataConfig: TableDataConfig = {
    defaultSortingField: this.defaultSortingField,
    defaultSortingOrder: SortingOrder.DESCENDING,
    fields: [
      {
        columnName: this.columnNames.name_or_registration,
        apiField: 'name',
        frozen: true,
        hidden: false,
        enable_sorting: true
      },
      this.defaultSortingField,
      {
        columnName: this.columnNames.request_type,
        apiField: 'requestType',
        frozen: false,
        hidden: false,
        enable_sorting: true
      },
      {
        columnName: this.columnNames.status,
        apiField: 'statusLabel',
        frozen: false,
        hidden: false,
        enable_sorting: true
      },
      {
        columnName: this.columnNames.item,
        apiField: 'id',
        frozen: false,
        hidden: false,
        enable_sorting: true
      },
      // Add more mappings as needed
    ],
    uiApiMatchFields: [this.columnNames.name_or_registration, this.columnNames.item]
  }

  public static readonly mappingParamsArray: MappingParam[] = [
    {
      tab: StatusAndTrackingConfig.tabs.needs_attention.name,
      endpoint: StatusAndTrackingConfig.endpoints.needs_attention
    },
    {
      tab: StatusAndTrackingConfig.tabs.open_items.name,
      endpoint: StatusAndTrackingConfig.endpoints.open_items
    },
    {
      tab: StatusAndTrackingConfig.tabs.completed.name,
      endpoint: StatusAndTrackingConfig.endpoints.completed
    },
    {
      tab: StatusAndTrackingConfig.tabs.following.name,
      endpoint: StatusAndTrackingConfig.endpoints.following
    }
  ]

  public static readonly learnAboutThisTileProperties: ModalContent = {
    // these info are CMS driven
    title: 'About the Status & Tracking Tile',
    content: 'Update Frequency:Status & Tracking work item data is updated every 5 minutes.'
  }

}
export abstract class BicConfig {

  public static readonly destinationInvestmentColumnNames = {
    strategyName: 'Strategy Name',
    riskProfile: 'Risk Profile',
    tms: 'TMS',
    investmentMin: 'Investment Min'
  }

  public static readonly accountsToChangeColumnNames = {
    accountTitle: 'Account Title',
    status: 'Status',
    regType: 'Reg Type',
    accountNumber: 'Account #',
    tms: 'TMS',
    amountAllocated: 'Amount Allocated',
    allocated: 'Allocated'
  }

  public static readonly accountsToChangeTabsNames = {
    accounts: 'Accounts',
    selectedAccounts: 'Selected Accounts',
    ineligibleAccounts: 'Ineligible Accounts'
  }

  public static readonly ineligibleStatuses = [
    'Below Investment Minimum' ,
    'Account already holds the selected investment strategy',
    `Not suitable for client's risk profile`,
    'Model Not Eligible',
    'Ineligible due to Tax Management Services enrollment',
    'Strategy unavailable under the Advisor ID', 
    'Account Change in Progress',
    'Account Not Funded',
    'Account Closed',
    'Ineligible For Submission Due To Agreement',
    'Ineligible Registration Type'
  ]

}
import { GeneralUtils } from '../../../utils/generalUtils'
import { ModalContent } from './types.config'

export abstract class AssetsOnPlatformConfig {

  public static readonly tileMenuOptions = {
    viewAssetsData: 'View Assets Data in Advisor Insights',
    learnAboutTile: 'Learn About This Tile',
    removeTile: 'Remove Tile'
  }

  public static readonly timePeriods = {
    monthly: 'Monthly',
    quarterly: 'Quarterly',
    yearly: 'Yearly'
  }

  public static readonly font = {
    timePeriod: {
      fontSize: '18px',
      fontFamily: 'Roboto, sans-serif'
    },
    metricValue: {
      fontSize: '36px',
      fontFamily: 'Roboto, sans-serif'
    },
    changesIndicator: {
      fontSize: '18px',
      fontFamily: 'Roboto, sans-serif'
    }
  }

  public static readonly timePeriodsParams = [
    {
      timePeriod: AssetsOnPlatformConfig.timePeriods.monthly,
      label: GeneralUtils.getCurrentMonth()
    },
    {
      timePeriod: AssetsOnPlatformConfig.timePeriods.quarterly,
      label: GeneralUtils.getCurrentQuarter()
    },
    {
      timePeriod: AssetsOnPlatformConfig.timePeriods.yearly,
      label: GeneralUtils.getCurrentYear()
    }
  ]

  public static readonly sizesParams = [
    {
      size: 'XS',
      widgetHeight: 1,
      widgetWidth: 1,
      isTimePeriodVisible: false
    },
    {
      size: 'M1',
      widgetHeight: 2,
      widgetWidth: 2,
      isTimePeriodVisible: true
    },
    {
      size: 'L2',
      widgetHeight: 4,
      widgetWidth: 3,
      isTimePeriodVisible: true
    }
  ]

  public static readonly colors = {
    selectedTimePeriodBackgroundColor: 'rgb(237, 241, 245)'
  }

  public static readonly learnAboutThisTileProperties: ModalContent = {
    // these info are CMS driven
    title: 'About the Assets On Platform Tile',
    content: 'Update Frequency for the Assets On Platform Tile:Data is updated daily, reflecting information as of close of business last night'
  }

}

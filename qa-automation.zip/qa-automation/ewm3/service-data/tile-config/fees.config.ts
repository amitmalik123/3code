import { ModalContent } from './types.config'

export abstract class FeesConfig {

  public static readonly tileMenuOptions = {
    viewFeesData: 'View Fees Data in Advisor Insights',
    viewFeesPayment: 'View Fee Payments',
    learnAboutTile: 'Learn About This Tile',
    removeTile: 'Remove Tile'
  }

  public static readonly tableHeaders = [
    'Fees',
    'Number of Clients',
    'Revenue',
    'Avg Revenue per Client'
  ]

  public static readonly font = {
    totalValue: {
      fontSize: '36px',
      fontFamily: 'Roboto, sans-serif'
    },
    timePeriod: {
      fontSize: '18px',
      fontFamily: 'Roboto, sans-serif'
    },
    changesIndicator: {
      fontSize: '18px',
      fontFamily: 'Roboto, sans-serif'
    }
  }

  public static readonly learnAboutThisTileProperties: ModalContent = {
    // these info are CMS driven
    title: 'About the Fees Tile',
    content: 'Update Frequency for Tile Data: Quarterly Fees are updated once a quarter (typically between 4th and 10th of the first month)Monthly Fees are updated for the current month by the 10th business day of the following month.'
  }

}
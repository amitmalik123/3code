import { FieldConfig, TableDataConfig } from '../../ui/features/table.feature'
import { GeneralUtils } from '../../../utils/generalUtils'
import { SortingOrder } from '../../ui/features/sorting.feature'
import { SearchCancelTrigger, SearchTrigger } from '../../ui/features/search.feature'
import { CancelSearchParamsArray, CustomizingColumnsParam, MappingParam, ModalContent, NestedSortingParam, SearchParam, SortingParam } from './types.config'
import { Platforms } from '../config'

export abstract class ClientsConfig {

  public static readonly title = 'Clients & Accounts'

  public static readonly tabs = {
    clients: 'Clients',
    pending_funding: 'Pending Funding',
    following: 'Following'
  }

  public static readonly tileMenuOptions = {
    onDemandReport: 'Create On-Demand Report',
    manageAccounts: 'Manage Accounts',
    learnAboutTile: 'Learn About This Tile',
    removeTile: 'Remove Tile'
  }

  public static readonly nestedMenuOptions = {
    manageAccounts: 'Manage Accounts',
    onDemandReport: 'On-Demand Report',
    portfolioReview: 'Portfolio Review'
  }

  public static readonly endpoints = {
    clients: '/advisormetrics/api/v2/metrics/clients',
    pending_funding: '/advisormetrics/api/v2/metrics/accounts',
    following: '/advisormetrics/api/v2/metrics/clients/flagged',
  }

  public static readonly columnNamesClients = {
    name: 'Client Name',
    market_value: 'Market Value',
    net_investments: 'Net Investments',
    performance: 'YTD Performance',
    inception_date: 'Inception Date',
    advisor_id: 'Advisor ID',
    web_access: 'Web Access',
    nested: {
      account_title: 'Account Title',
      alerts: 'Alerts',
      account_number: 'Account Number',
      account_status: 'Account Status',
      registration_type: 'Registration Type',
      market_value: 'Market Value',
      investment_strategy: 'Investment Strategy',
      cheetah_account_number: 'Cheetah Account Number'
    }
  }

  public static readonly columnNamesPendingFunding = {
    account_title: 'Account Title',
    account_number: 'Account Number',
    pending_amount: 'Expected Amount',
    pending_days: 'Days Pending',
  }

  public static readonly searchableFieldsClients = [
    this.columnNamesClients.name,
    this.columnNamesClients.nested.account_title,
    this.columnNamesClients.nested.account_number
  ]

  public static readonly searchableFieldsPendingFunding = [
    this.columnNamesPendingFunding.account_title,
    this.columnNamesPendingFunding.account_number,
  ]

  private static readonly defaultSortingFieldClients: FieldConfig = {
    columnName: this.columnNamesClients.name,
    apiField: 'clientName',
    frozen: true,
    hidden: false,
    enable_sorting: true,
    platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
  }

  private static readonly defaultSortingNestedTableFieldClients: FieldConfig = {
    columnName: this.columnNamesClients.nested.account_title,
    apiField: 'accountRegistration',
    frozen: true,
    hidden: false,
    enable_sorting: true,
    platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
  }
  
  public static readonly tableDataConfigClients: TableDataConfig = {
    defaultSortingOrder: SortingOrder.ASCENDING,
    defaultSortingField: this.defaultSortingFieldClients,
    fields: [
      this.defaultSortingFieldClients,
      {
        columnName: this.columnNamesClients.market_value,
        apiField: 'marketValue',
        apiDataTransform: GeneralUtils.normalizeCurrencyValue,
        sortingDataTransform: GeneralUtils.parseDollarAmountToFloat,
        frozen: false,
        hidden: false,
        enable_sorting: true,
        platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
      },
      {
        columnName: this.columnNamesClients.net_investments,
        apiField: 'netInvestments',
        apiDataTransform: GeneralUtils.normalizeCurrencyValue,
        sortingDataTransform: GeneralUtils.parseDollarAmountToFloat,
        frozen: false,
        hidden: false,
        enable_sorting: true,
        platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
      },
      {
        columnName: this.columnNamesClients.performance,
        apiField: 'ytdPerformance',
        apiDataTransform: GeneralUtils.normalizePercentValueAlwaysTwoDecimals,
        sortingDataTransform: GeneralUtils.parsePercentToFloat,
        frozen: false,
        hidden: false,
        enable_sorting: true,
        platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
      },
      {
        columnName: this.columnNamesClients.inception_date,
        apiField: 'inceptionDate',
        apiDataTransform: GeneralUtils.convertDate,
        sortingDataTransform: GeneralUtils.parseDate,
        frozen: false,
        hidden: false,
        enable_sorting: true,
        platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
      },
      {
        columnName: this.columnNamesClients.advisor_id,
        apiField: 'advisorIdentifier',
        frozen: false,
        hidden: true,
        enable_sorting: true,
        platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
      },
      {
        columnName: this.columnNamesClients.web_access,
        apiField: 'webAccess',
        apiDataTransform: GeneralUtils.boolToYesNo,
        frozen: false,
        hidden: true,
        enable_sorting: true,
        platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
      }
      // Add more mappings as needed
    ],
    uiApiMatchFields: [this.columnNamesClients.name],
    nestedTableDataConfig: {
      defaultSortingOrder: SortingOrder.ASCENDING,
      defaultSortingField: this.defaultSortingNestedTableFieldClients,
      apiPathToItems: 'accounts',
      uiApiMatchFields:  [
        this.columnNamesClients.nested.account_title,
        this.columnNamesClients.nested.account_number
        // this.columnNamesClients.nested.investment_strategy,
      ],
      fields: [
        this.defaultSortingNestedTableFieldClients,
        {
          columnName: this.columnNamesClients.nested.alerts,
          apiField: 'alert',
          frozen: true,
          hidden: false,
          enable_sorting: true,
          platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
        },
        {
          columnName: this.columnNamesClients.nested.account_number,
          apiField: 'accountNumber',
          apiDataTransform: (value) => `${value ? value : ''}`,
          frozen: true,
          hidden: false,
          enable_sorting: true,
          platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
        },
        {
          columnName: this.columnNamesClients.nested.account_status,
          apiField: 'accountStatus',
          frozen: true,
          hidden: false,
          enable_sorting: true,
          platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
        },
        {
          columnName: this.columnNamesClients.nested.registration_type,
          apiField: 'registrationType',
          frozen: true,
          hidden: false,
          enable_sorting: true,
          platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
        },
        {
          columnName: this.columnNamesClients.nested.market_value,
          apiField: 'marketValue',
          apiDataTransform: GeneralUtils.normalizeCurrencyValue,
          sortingDataTransform: GeneralUtils.parseDollarAmountToFloat,
          frozen: true,
          hidden: false,
          enable_sorting: true,
          platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
        },
        {
          columnName: this.columnNamesClients.nested.investment_strategy,
          apiField: 'investmentStrategy',
          frozen: true,
          hidden: false,
          enable_sorting: true,
          platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
        },
        {
          columnName: this.columnNamesClients.nested.cheetah_account_number,
          apiField: 'cheetahAccountNumber',
          frozen: true,
          hidden: false,
          enable_sorting: true,
          platforms: [ Platforms.CHEETAH ]
        }
      ]
    }
  }

  private static readonly defaultSortingPendingFunding: FieldConfig = {
    columnName: this.columnNamesPendingFunding.account_title,
    apiField: 'accountRegistration',
    frozen: true,
    hidden: false,
    enable_sorting: true,
    platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
  }

  public static readonly tableDataConfigPendingFunding: TableDataConfig = {
    defaultSortingOrder: SortingOrder.ASCENDING,
    defaultSortingField: this.defaultSortingPendingFunding,
    fields: [
      this.defaultSortingPendingFunding,
      {
        columnName: this.columnNamesPendingFunding.account_number,
        apiField: 'accountNumber',
        frozen: false,
        hidden: false,
        enable_sorting: true,
        platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
      },
      {
        columnName: this.columnNamesPendingFunding.pending_amount,
        apiField: 'pendingAmount',
        apiDataTransform: GeneralUtils.normalizeCurrencyValue,
        sortingDataTransform: GeneralUtils.parseDollarAmountToFloat,
        frozen: false,
        hidden: false,
        enable_sorting: true,
        platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
      },
      {
        columnName: this.columnNamesPendingFunding.pending_days,
        apiField: 'pendingDays',
        apiDataTransform: (value) => `${value ? value : ''}`,
        sortingDataTransform: (value) => +(value),
        frozen: false,
        hidden: false,
        enable_sorting: true,
        platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
      },

    ],
    uiApiMatchFields: [this.columnNamesPendingFunding.account_title, this.columnNamesPendingFunding.account_number]
  }

  public static readonly searchTestParamsArray: SearchParam[] = [
    {
      tab: ClientsConfig.tabs.clients,
      fieldForSearchQuery: ClientsConfig.searchableFieldsClients[0],
      searchableFieldArray: ClientsConfig.searchableFieldsClients,
      searchTrigger: SearchTrigger.KEYBOARD_NAVIGATION_CHOOSE_SUGGEST_OPTION
    },
    {
      tab: ClientsConfig.tabs.clients,
      fieldForSearchQuery: ClientsConfig.searchableFieldsClients[1],
      searchableFieldArray: ClientsConfig.searchableFieldsClients,
      searchTrigger: SearchTrigger.MAGNIFYING_GLASS_BUTTON
    },
    {
      tab: ClientsConfig.tabs.clients,
      fieldForSearchQuery: ClientsConfig.searchableFieldsClients[2],
      searchableFieldArray: ClientsConfig.searchableFieldsClients,
      searchTrigger: SearchTrigger.ENTER_KEY
    },
    {
      tab: ClientsConfig.tabs.following,
      fieldForSearchQuery: ClientsConfig.searchableFieldsClients[0],
      searchableFieldArray: ClientsConfig.searchableFieldsClients,
      searchTrigger: SearchTrigger.CLICK_ON_SUGGEST_OPTION
    },
    {
      tab: ClientsConfig.tabs.following,
      fieldForSearchQuery: ClientsConfig.searchableFieldsClients[1],
      searchableFieldArray: ClientsConfig.searchableFieldsClients,
      searchTrigger: SearchTrigger.ENTER_KEY
    },
    {
      tab: ClientsConfig.tabs.following,
      fieldForSearchQuery: ClientsConfig.searchableFieldsClients[2],
      searchableFieldArray: ClientsConfig.searchableFieldsClients,
      searchTrigger: SearchTrigger.MAGNIFYING_GLASS_BUTTON
    },
    {
      tab: ClientsConfig.tabs.pending_funding,
      fieldForSearchQuery: ClientsConfig.searchableFieldsPendingFunding[0],
      searchableFieldArray: ClientsConfig.searchableFieldsPendingFunding,
      searchTrigger: SearchTrigger.ENTER_KEY
    },
    {
      tab: ClientsConfig.tabs.pending_funding,
      fieldForSearchQuery: ClientsConfig.searchableFieldsPendingFunding[1],
      searchableFieldArray: ClientsConfig.searchableFieldsPendingFunding,
      searchTrigger: SearchTrigger.KEYBOARD_NAVIGATION_CHOOSE_SUGGEST_OPTION
    }
  ]

  public static readonly mappingParamsArray: MappingParam[] = [
    {
      tab: ClientsConfig.tabs.clients,
      endpoint: ClientsConfig.endpoints.clients,
      mappingConfig: ClientsConfig.tableDataConfigClients
    },
    {
      tab: ClientsConfig.tabs.pending_funding,
      endpoint: ClientsConfig.endpoints.pending_funding,
      mappingConfig: ClientsConfig.tableDataConfigPendingFunding
    },
    {
      tab: ClientsConfig.tabs.following,
      endpoint: ClientsConfig.endpoints.following,
      mappingConfig: ClientsConfig.tableDataConfigClients
    }
  ]

  public static readonly sortingTestParamsArray: SortingParam[] = [
    {
      tab: ClientsConfig.tabs.clients,
      tableConfig: ClientsConfig.tableDataConfigClients
    },
    {
      tab: ClientsConfig.tabs.pending_funding,
      tableConfig: ClientsConfig.tableDataConfigPendingFunding
    },
    {
      tab: ClientsConfig.tabs.following,
      tableConfig: ClientsConfig.tableDataConfigClients
    }
  ]

  public static readonly nestedSortingTestParamsArray: NestedSortingParam[] = [
    {
      tab: ClientsConfig.tabs.clients,
      tableConfig: ClientsConfig.tableDataConfigClients.nestedTableDataConfig?.fields
    },
    {
      tab: ClientsConfig.tabs.pending_funding,
      tableConfig: ClientsConfig.tableDataConfigPendingFunding.nestedTableDataConfig?.fields
    },
    {
      tab: ClientsConfig.tabs.following,
      tableConfig: ClientsConfig.tableDataConfigClients.nestedTableDataConfig?.fields
    }
  ]

  public static readonly customizeColumnsParamsArray: CustomizingColumnsParam[] = [
    {
      tab: ClientsConfig.tabs.clients,
      tableConfig: ClientsConfig.tableDataConfigClients
    },
    {
      tab: ClientsConfig.tabs.pending_funding,
      tableConfig: ClientsConfig.tableDataConfigPendingFunding
    },
    {
      tab: ClientsConfig.tabs.following,
      tableConfig: ClientsConfig.tableDataConfigClients
    }
  ]

  public static readonly cancelSearchParamsArray: CancelSearchParamsArray[] = [
    {
      tab: ClientsConfig.tabs.clients,
      fieldForSearchQuery: ClientsConfig.searchableFieldsClients[0],
      searchableFieldArray: ClientsConfig.searchableFieldsClients,
      searchCancelTrigger: SearchCancelTrigger.CLICK_OUTSIDE_SEARCH
    },
    {
      tab: ClientsConfig.tabs.clients,
      fieldForSearchQuery: ClientsConfig.searchableFieldsClients[2],
      searchableFieldArray: ClientsConfig.searchableFieldsClients,
      searchCancelTrigger: SearchCancelTrigger.CLICK_CROSS_BUTTON
    },
    {
      tab: ClientsConfig.tabs.following,
      fieldForSearchQuery: ClientsConfig.searchableFieldsClients[0],
      searchableFieldArray: ClientsConfig.searchableFieldsClients,
      searchCancelTrigger: SearchCancelTrigger.CLICK_OUTSIDE_SEARCH
    },
    {
      tab: ClientsConfig.tabs.following,
      fieldForSearchQuery: ClientsConfig.searchableFieldsClients[1],
      searchableFieldArray: ClientsConfig.searchableFieldsClients,
      searchCancelTrigger: SearchCancelTrigger.CLICK_CROSS_BUTTON
    },
    {
      tab: ClientsConfig.tabs.following,
      fieldForSearchQuery: ClientsConfig.searchableFieldsClients[2],
      searchableFieldArray: ClientsConfig.searchableFieldsClients,
      searchCancelTrigger: SearchCancelTrigger.CLICK_OUTSIDE_SEARCH
    },
    {
      tab: ClientsConfig.tabs.pending_funding,
      fieldForSearchQuery: ClientsConfig.searchableFieldsPendingFunding[0],
      searchableFieldArray: ClientsConfig.searchableFieldsPendingFunding,
      searchCancelTrigger: SearchCancelTrigger.CLICK_OUTSIDE_SEARCH
    },
    {
      tab: ClientsConfig.tabs.pending_funding,
      fieldForSearchQuery: ClientsConfig.searchableFieldsPendingFunding[1],
      searchableFieldArray: ClientsConfig.searchableFieldsPendingFunding,
      searchCancelTrigger: SearchCancelTrigger.CLICK_CROSS_BUTTON
    }
  ]

  public static readonly learnAboutThisTileProperties: ModalContent = {
    // these info are CMS driven
    title: 'About The Clients & Accounts Tile',
    content: 'Update Frequency for the Client Tile:Data is updated in the Client Tile as it becomes available.The Client tile checks for new data at least daily (intraday).AMRS Account data is delivered updated monthly (approximately the 5th business day of the month) except OBS data which lags by one month.'
  }
}

import { Platforms } from '../config'

export abstract class DashboardConfig {

  public static readonly tiles = {
    advisor_benefits: {
      name: 'Advisor Benefits',
      id: 'widget-advisor-benefits',
      platforms: [ Platforms.ASSETMARK ],
      toggledOnSample: {
        assetmark: false
      },
      cmsId: 'advisor_benefits'
    },
    assets_on_platform: {
      name: 'Assets On Platform', 
      id: 'widget-aum',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ],
      toggledOnSample: {
        assetmark: true,
        cheetah: true
      },
      cmsId: 'aum'
    },
    clients: { 
      name: 'Clients & Accounts', 
      id: 'widget-clients',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ],
      toggledOnSample: {
        assetmark: true,
        cheetah: true
      },
      cmsId: 'client_list'
    },
    fees: {
      name: 'Fees',
      platforms: [ Platforms.ASSETMARK ],
      toggledOnSample: {
        assetmark: false
      },
      cmsId: 'revenue'
      // needs id
    },
    investments: {
      name: 'Investments', 
      id: 'widget-investments',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ],
      toggledOnSample: {
        assetmark: true,
        cheetah: true
      },
      cmsId: 'investments'
    },
    netflows: {
      name: 'Net Flows',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ],
      toggledOnSample: {
        assetmark: true,
        cheetah: false
      },
      cmsId: 'net_flows'
      // needs id
    },
    status_and_tracking: {
      name: 'Status & Tracking',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ],
      toggledOnSample: {
        assetmark: true,
        cheetah: true
      },
      cmsId: 'status_tracking'
      // needs id
    }
  }

  public static readonly headerLinks = {
    clients: {
      name: 'Clients',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
    },
    tracking_center: {
      name: 'Tracking Center',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
    },
    investments: {
      name: 'Investments',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
    },
    retirement: {
      name: 'Retirement',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
    },
    financial_planning: {
      name: 'Financial Planning',
      platforms: [ Platforms.ASSETMARK ]
    },
    business_consulting: {
      name: 'Business Consulting',
      platforms: [ Platforms.ASSETMARK ]
    },
    marketing: {
      name: 'Marketing',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
    },
    service_center: {
      name: 'Service Center',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
    },
    account_wizard: {
      name: 'Account Wizard',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
    }
  }

  public static readonly userMenuDropdownItems = {
    contact_us: 'Contact Us',
    preferences: 'Preferences',
    cookieSettings: 'Cookie Settings',
    logout: 'Log Out'
  }

  public static readonly advisorWorkstationDropdownItems = {
    benefits_dashboard: {
      name: 'Benefits Dashboard',
      platforms: [ Platforms.ASSETMARK ]
    },
    client_management: {
      name: 'Client Management',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
    },
    portfolio_engine: {
      name: 'Portfolio Engine',
      platforms: [ Platforms.ASSETMARK, Platforms.CHEETAH ]
    },
    wealthbuilder: {
      name: 'WealthBuilder Dashboard',
      platforms: [ Platforms.ASSETMARK ]
    }
  }

  public static readonly colors = {
    myDashboardHoverColor: 'rgb(237, 241, 245)',
    classicDashboardHoverColor: 'rgb(237, 241, 245)',
    unflaggedTableItem: 'rgb(255, 255, 255)',
    flaggedTableItem: 'rgb(0, 48, 87)'
  }
  
  public static readonly font = {
    secondaryCloseButton: {
      fontSize: '16px',
      fontFamily: 'Roboto, sans-serif'
    }
  }

  public static readonly dashboardMessages = {
    dashboardCreated: 'New Dashboard created',
    dashboardDeleted: 'Dashboard deleted',
    dashboardCopied: 'New Dashboard duplicated'
  }

  public static resizableTestParam = [
    {
      size: 'small',
      height: 1,
      width: 1
    },
    {
      size: 'large',
      height: 4,
      width: 3
    } 
  ]

}

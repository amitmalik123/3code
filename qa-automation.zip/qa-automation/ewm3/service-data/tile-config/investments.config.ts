import { FieldConfig, TableDataConfig } from '../../ui/features/table.feature'
import { SortingOrder } from '../../ui/features/sorting.feature'
import { GeneralUtils } from '../../../utils/generalUtils'
import { CustomizingColumnsParam, MappingParam, ModalContent, SearchParam, SortingParam } from './types.config'
import { SearchTrigger } from '../../ui/features/search.feature'

export abstract class InvestmentsConfig {

  public static readonly title = 'Investments'

  public static readonly tileMenuOptions = {
    accessInvestmentsOverview: 'Access Investments Overview',
    learnAboutTile: 'Learn About This Tile',
    removeTile: 'Remove Tile'
  }

  public static readonly tabs  = {
    strategies: 'Strategies',
    investment_approach: 'Investment Approach',
  }

  public static readonly endpoints  = {
    strategies: '/advisormetrics/api/v2/metrics/investments/strategy',
    investment_approach: '/advisormetrics/api/v2/metrics/investments/approach',
  }

  public static readonly columnNamesStrategies  = {
    name: 'Strategy',
    total_accounts: 'Total Accounts',
    total_assets: 'Total Assets',
    current_allocation : 'Current Allocation',
    nested:{
      account_title: 'Account Title',
      advisor_id: 'Advisor ID',
      account_number: 'Account Number',
      amount_allocated: 'Amount Allocated',
      account_allocation: 'Account Allocation',
    }
  }

  public static readonly columnNamesInvestmentApproach  = {
    account_title: 'Investment Approach',
    total_accounts: 'Total Accounts',
    total_assets: 'Total Assets',
    current_allocation : 'Current Allocation',
    nested:{
      account_title: 'Account Title',
      strategy: 'Strategy',
      advisor_id: 'Advisor ID',
      account_number: 'Account Number',
      amount_allocated: 'Amount Allocated',
      account_allocation: 'Account Allocation',
    }
  }

  public static readonly searchableFieldsStrategies = [
    this.columnNamesStrategies.name,
    this.columnNamesStrategies.nested.account_title,
    this.columnNamesStrategies.nested.account_number,
  ]

  public static readonly searchableFieldsInvestmentApproach = [
    this.columnNamesInvestmentApproach.account_title,
    this.columnNamesInvestmentApproach.nested.account_title,
    this.columnNamesInvestmentApproach.nested.account_number,
  ]
  private static readonly defaultSortingFieldStrategies: FieldConfig = {
    columnName: this.columnNamesStrategies.name,
    apiField: 'name',
    frozen: true,
    hidden: false,
    enable_sorting: true
  }
  private static readonly defaultSortingNestedFieldStrategies: FieldConfig = {
    columnName: this.columnNamesStrategies.nested.account_title,
    apiField: 'accountTitle',
    frozen: true,
    hidden: false,
    enable_sorting: true
  }
  public static readonly tableDataConfigStrategies: TableDataConfig = {
    defaultSortingOrder: SortingOrder.ASCENDING,
    defaultSortingField: this.defaultSortingFieldStrategies,
    fields: [
      this.defaultSortingFieldStrategies,
      {
        columnName: this.columnNamesStrategies.total_accounts,
        apiField: 'totalAccounts',
        apiDataTransform: (value) => `${value}`,
        sortingDataTransform: (value) => +(value),
        frozen: false,
        hidden: false,
        enable_sorting: true
      },
      {
        columnName: this.columnNamesStrategies.total_assets,
        apiField: 'totalAssets',
        apiDataTransform: GeneralUtils.normalizeCurrencyValue,
        sortingDataTransform: GeneralUtils.parseDollarAmountToFloat,
        frozen: false,
        hidden: false,
        enable_sorting: true
      },
      {
        columnName: this.columnNamesStrategies.current_allocation,
        apiField: 'currentAllocation',
        apiDataTransform: GeneralUtils.normalizePercentValueAlwaysTwoDecimals,
        sortingDataTransform: GeneralUtils.parsePercentToFloat,
        frozen: false,
        hidden: false,
        enable_sorting: true
      },
    ],
    uiApiMatchFields: [this.columnNamesStrategies.name],
    nestedTableDataConfig: {
      defaultSortingField: this.defaultSortingNestedFieldStrategies,
      defaultSortingOrder: SortingOrder.ASCENDING,
      apiPathToItems: 'items',
      uiApiMatchFields: [this.columnNamesStrategies.nested.account_title, this.columnNamesStrategies.nested.account_number],
      fields: [
        this.defaultSortingNestedFieldStrategies,
        {
          columnName: this.columnNamesStrategies.nested.advisor_id,
          apiField: 'advisorId',
          frozen: true,
          hidden: false,
          enable_sorting: true
        },
        {
          columnName: this.columnNamesStrategies.nested.account_number,
          apiField: 'accountNumber',
          frozen: true,
          hidden: false,
          enable_sorting: true
        },
        {
          columnName: this.columnNamesStrategies.nested.amount_allocated,
          apiField: 'amountAllocated',
          apiDataTransform: GeneralUtils.normalizeCurrencyValue,
          sortingDataTransform: GeneralUtils.parseDollarAmountToFloat,
          frozen: true,
          hidden: false,
          enable_sorting: true
        },
        {
          columnName: this.columnNamesStrategies.nested.account_allocation,
          apiField: 'accountAllocation',
          apiDataTransform: GeneralUtils.normalizePercentValueAlwaysTwoDecimals,
          sortingDataTransform: GeneralUtils.parsePercentToFloat,
          frozen: true,
          hidden: false,
          enable_sorting: true
        },
      ]
    }
  }

  private static readonly defaultSortingFieldInvestmentApproach: FieldConfig = {
    columnName: this.columnNamesInvestmentApproach.account_title,
    apiField: 'name',
    frozen: true,
    hidden: false,
    enable_sorting: true
  }
  private static readonly defaultSortingNestedFieldInvestmentApproach: FieldConfig = {
    columnName: this.columnNamesInvestmentApproach.nested.strategy,
    apiField: 'strategyName',
    frozen: true,
    hidden: false,
    enable_sorting: true
  }
  public static readonly tableDataConfigInvestmentApproach: TableDataConfig = {
    defaultSortingOrder: SortingOrder.ASCENDING,
    defaultSortingField: this.defaultSortingFieldInvestmentApproach,
    fields: [
      this.defaultSortingFieldInvestmentApproach,
      {
        columnName: this.columnNamesInvestmentApproach.total_accounts,
        apiField: 'totalAccounts',
        apiDataTransform: (value) => `${value}`,
        sortingDataTransform: (value) => +(value),
        frozen: false,
        hidden: false,
        enable_sorting: true
      },
      {
        columnName: this.columnNamesInvestmentApproach.total_assets,
        apiField: 'totalAssets',
        apiDataTransform: GeneralUtils.normalizeCurrencyValue,
        sortingDataTransform: GeneralUtils.parseDollarAmountToFloat,
        frozen: false,
        hidden: false,
        enable_sorting: true
      },
      {
        columnName: this.columnNamesInvestmentApproach.current_allocation,
        apiField: 'currentAllocation',
        apiDataTransform: GeneralUtils.normalizePercentValueAlwaysTwoDecimals,
        sortingDataTransform: GeneralUtils.parsePercentToFloat,
        frozen: false,
        hidden: false,
        enable_sorting: true
      },
    ],
    uiApiMatchFields: [this.columnNamesInvestmentApproach.account_title],
    nestedTableDataConfig: {
      defaultSortingOrder: SortingOrder.ASCENDING,
      defaultSortingField: this.defaultSortingNestedFieldInvestmentApproach,
      apiPathToItems: 'items',
      uiApiMatchFields: [this.columnNamesInvestmentApproach.nested.strategy, this.columnNamesInvestmentApproach.nested.account_title, this.columnNamesInvestmentApproach.nested.account_number],
      fields: [
        this.defaultSortingNestedFieldInvestmentApproach,
        {
          columnName: this.columnNamesInvestmentApproach.nested.account_title,
          apiField: 'accountTitle',
          frozen: true,
          hidden: false,
          enable_sorting: true
        },
        {
          columnName: this.columnNamesInvestmentApproach.nested.advisor_id,
          apiField: 'advisorId',
          frozen: true,
          hidden: false,
          enable_sorting: true
        },
        {
          columnName: this.columnNamesInvestmentApproach.nested.account_number,
          apiField: 'accountNumber',
          frozen: true,
          hidden: false,
          enable_sorting: true
        },
        {
          columnName: this.columnNamesInvestmentApproach.nested.amount_allocated,
          apiField: 'amountAllocated',
          apiDataTransform: GeneralUtils.normalizeCurrencyValue,
          sortingDataTransform: GeneralUtils.parseDollarAmountToFloat,
          frozen: true,
          hidden: false,
          enable_sorting: true
        },
        {
          columnName: this.columnNamesInvestmentApproach.nested.account_allocation,
          apiField: 'accountAllocation',
          apiDataTransform: GeneralUtils.normalizePercentValueAlwaysTwoDecimals,
          sortingDataTransform: GeneralUtils.parsePercentToFloat,
          frozen: true,
          hidden: false,
          enable_sorting: true
        },
      ]
    }
  }

  public static readonly graphColorsArray = [
    'rgb(0, 48, 87)',
    'rgb(28, 149, 187)',
    'rgb(92, 154, 87)',
    'rgb(212, 63, 17)',
    'rgb(138, 27, 97)',
    'rgb(54, 154, 138)',
    'rgb(97, 97, 97)',
    'rgb(216, 125, 65)',
    'rgb(59, 69, 155)',
    'rgb(11, 100, 180)',
    'rgb(158, 158, 158)'
  ]

  public static readonly searchTestParamsArray: SearchParam[] = [
    {
      tab: InvestmentsConfig.tabs.strategies,
      fieldForSearchQuery: InvestmentsConfig.searchableFieldsStrategies[0],
      searchableFieldArray: InvestmentsConfig.searchableFieldsStrategies,
      searchTrigger: SearchTrigger.KEYBOARD_NAVIGATION_CHOOSE_SUGGEST_OPTION
    },
    {
      tab: InvestmentsConfig.tabs.strategies,
      fieldForSearchQuery: InvestmentsConfig.searchableFieldsStrategies[1],
      searchableFieldArray: InvestmentsConfig.searchableFieldsStrategies,
      searchTrigger: SearchTrigger.MAGNIFYING_GLASS_BUTTON
    },
    {
      tab: InvestmentsConfig.tabs.strategies,
      fieldForSearchQuery: InvestmentsConfig.searchableFieldsStrategies[2],
      searchableFieldArray: InvestmentsConfig.searchableFieldsStrategies,
      searchTrigger: SearchTrigger.ENTER_KEY
    },
    {
      tab: InvestmentsConfig.tabs.investment_approach,
      fieldForSearchQuery: InvestmentsConfig.searchableFieldsInvestmentApproach[0],
      searchableFieldArray: InvestmentsConfig.searchableFieldsInvestmentApproach,
      searchTrigger: SearchTrigger.CLICK_ON_SUGGEST_OPTION
    },
    {
      tab: InvestmentsConfig.tabs.investment_approach,
      fieldForSearchQuery: InvestmentsConfig.searchableFieldsInvestmentApproach[1],
      searchableFieldArray: InvestmentsConfig.searchableFieldsInvestmentApproach,
      searchTrigger: SearchTrigger.ENTER_KEY
    },
    {
      tab: InvestmentsConfig.tabs.investment_approach,
      fieldForSearchQuery: InvestmentsConfig.searchableFieldsInvestmentApproach[2],
      searchableFieldArray: InvestmentsConfig.searchableFieldsInvestmentApproach,
      searchTrigger: SearchTrigger.MAGNIFYING_GLASS_BUTTON
    },
  ]

  public static readonly mappingParamsArray: MappingParam[] = [
    {
      tab: InvestmentsConfig.tabs.strategies,
      endpoint: InvestmentsConfig.endpoints.strategies,
      mappingConfig: InvestmentsConfig.tableDataConfigStrategies
    },
    {
      tab: InvestmentsConfig.tabs.investment_approach,
      endpoint: InvestmentsConfig.endpoints.investment_approach,
      mappingConfig: InvestmentsConfig.tableDataConfigInvestmentApproach
    },
  ]

  public static readonly sortingTestParamsArray: SortingParam[] = [
    {
      tab: InvestmentsConfig.tabs.strategies,
      tableConfig: InvestmentsConfig.tableDataConfigStrategies
    },
    {
      tab: InvestmentsConfig.tabs.investment_approach,
      tableConfig: InvestmentsConfig.tableDataConfigInvestmentApproach
    },
  ]

  public static readonly customizeColumnsParamsArray: CustomizingColumnsParam[] = [
    {
      tab: InvestmentsConfig.tabs.strategies,
      tableConfig: InvestmentsConfig.tableDataConfigStrategies
    },
    {
      tab: InvestmentsConfig.tabs.investment_approach,
      tableConfig: InvestmentsConfig.tableDataConfigInvestmentApproach
    },
  ]

  public static readonly learnAboutThisTileProperties: ModalContent = {
    // these info are CMS driven
    title: 'About the Investments Tile',
    content: 'Update Frequency for the Investments Tile:Data is updated daily, reflecting information as of close of business last night'
  }

}
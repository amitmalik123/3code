import { AdvisorBenefitsMock } from '../../ui/mocks/advisor-benefits-mock'
import { ModalContent } from './types.config'

export abstract class AdvisorBenefitsConfig {

  public static readonly tileMenuOptions = {
    viewBenefitsDashboard: 'View Benefits Dashboard',
    learnAboutTile: 'Learn About This Tile',
    removeTile: 'Remove Tile'
  }

  // Disclaimer info comes from cms settings. This could be changed and break tests.
  public static readonly disclaimer = 'Assets on Platform shown are updated as of prior day business close and are used to determine AssetMark Advisor Benefits eligibility only. This information does not reflect regulatory assets under management and should not be used for regulatory filings. For more about the Advisor Benefits Program, refer to the Advisor Benefits Dashboard.'

  public static readonly programLevels = [
    {
      name: 'Emerging Premier',
      rangeFrom: 0,
      rangeTo: 5000000,
      colorCode: 'rgb(229, 230, 230)',
      colorHash: '#E5E6E6',
      color: 'Light Gray',
      mockData: AdvisorBenefitsMock.emergingPremierStatus
    },
    {
      name: 'Premier',
      rangeFrom: 5000000,
      rangeTo: 20000000,
      colorHash: '#8EA6C0',
      colorCode: 'rgb(142, 166, 192)',
      color: 'Light Gray-Blue',
      mockData: AdvisorBenefitsMock.premierStatus
    },
    {
      name: 'Premier Elite',
      rangeFrom: 20000000,
      rangeTo: 35000000,
      colorCode: 'rgb(0, 79, 126)',
      colorHash: '#004F7E',
      color: 'Dark Blue',
      mockData: AdvisorBenefitsMock.premierEliteStatus
    },
    {
      name: 'Gold',
      rangeFrom: 35000000,
      rangeTo: 100000000,
      colorCode: 'rgb(248, 201, 20)',
      colorHash: '#F8C914',
      color: 'Yellow',
      mockData: AdvisorBenefitsMock.goldStatus
    },
    {
      name: 'Platinum',
      rangeFrom: 100000000,
      rangeTo: 250000000,
      colorCode: 'rgb(136, 135, 137)',
      colorHash: '#888789',
      color: 'Gray',
      mockData: AdvisorBenefitsMock.platinumStatus
    },
    {
      name: 'Platinum Elite',
      rangeFrom: 250000000,
      colorCode: 'rgb(0, 0, 0)',
      colorHash: '#000000',
      color: 'Black',
      mockData: AdvisorBenefitsMock.platinumEliteStatus
    }
  ]

  public static readonly learnAboutThisTileProperties: ModalContent = {
    // these info are CMS driven
    title: 'About the Advisor Benefits Tile',
    content: 'The Benefits Tile displays Assets On Platform associated with the Primary Advisor Benefit ID and is used to determine AMK Benefits eligibility only.Update Frequency for Tile Data: The value for Assets On Platform is updated daily, reflecting information as of close of business last night Benefit Status upgrades are updated once a quarter. Downgrades are updated once a year on 12/31.'
  }

}
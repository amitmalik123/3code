export abstract class InsightsConfig {

  public static readonly assetsTilesInfo = {
    marketValue: {name: 'Total Market Value by Yearly Date', id: 'widget-market-value'},
    growthRate: {name: 'Compound Annual Growth Rate - 3 years', id: 'widget-growth-rate'},
    aopLob: {name: 'Assets on the Platform by Line Of Business', id: 'widget-aop-lob', tooltip: {drilldownInvMng: 'Investment Manager',drilldownProdName: 'Product Name',drilldownAllocation: 'Allocation' }},
    aopByInvestmentManager: {name: 'Assets on the Platform by Investment Manager', id: '', tooltip: {drilldownProdName: 'Product Name',drilldownLOB: 'Line of Business',drilldownAllocation: 'Allocation'}},
    aopByInvestmentApproach: {name: 'Assets on the Platform by Investment Approach', id: '', tooltip: {drilldownInvMng: 'Investment Manager',drilldownProdName: 'Product Name',drilldownLOB:'Line of Business'}}
  }

  public static readonly assetsTilesInfoArray:{name: string, id: string, tooltip?: object}[] = Object.values(this.assetsTilesInfo)

  public static readonly feesTilesInfo = {
    feesHouseholdSize: {name: 'Fee Analysis by Household Size - Latest Quarter', id: 'widget-fee-analysis'},
    feeType: {name: 'Fees by Fee Type', id: ''},
    yoyFees: {name: 'YOY Growth (%) of Fees', id: 'widget-fees-yoy'},
    yearlyFees: {name: 'Yearly Fees', id: ''},
    feesHouseholdSizeTable: {name: 'Fees Analysis Details - Latest Quarter (Annualized Total Fees)', id: 'table-first-column', tooltip: {drilldownHousehold: 'Household Name', drilldownAccName: 'Account Name'}} // ToDo: Change from column id to whole tile id
  }

  public static readonly feesTilesInfoArray:{name: string, id: string, tooltip?: object}[] = Object.values(this.feesTilesInfo)

  public static readonly flowsTilesInfo = {
    netflowsDetatils: {name: 'Net Flows, Details by Type of Flows', id: 'flow-analysis-widget'},
    inflowsOutflows: {name: 'Inflows, Outflows, Netflows compared to MarketValue (%)', id: 'compare-inflows-outflows-market-value', tooltip: {drilldownProdName: 'Product Name', drilldownInvMng: 'Investment Manager'}},
    yoyFlows: {name: 'YOY Growth (%) of Flows', id: 'flows-yoy-widget'},
    netflowsSummary: {name: 'Net flows Chart Summary', id: 'widget-netflows-details'}
  }

  public static readonly flowsTilesInfoArray:{name: string, id: string, tooltip?: object}[] = Object.values(this.flowsTilesInfo)

  public static readonly minimumTileSize = 403 //px

}
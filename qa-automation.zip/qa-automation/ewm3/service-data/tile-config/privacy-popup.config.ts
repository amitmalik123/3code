export abstract class CookiesConfig {

  public static readonly preferences = {
    strictly_necessary_cookies: {
      name: 'Strictly Necessary Cookies',
      toggle: false,
      description: 'These cookies are essential for you to browse the website and use its features, such as accessing secure areas of the site. These cookies cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, logging in, or filling out forms. You can set your browser to block or alert you about these cookies, but some parts of the site may not work.'
    },
    functional_cookies: {
      name: 'Functional Cookies',
      toggle: true,
      description: 'These cookies allow a website to provide enhanced functionality and personalization. These cookies enable the website to remember choices you have made in the past, like what language you prefer, or what your user name and password are so you can automatically log in. If you do not accept these cookies then some or all of these services may not function properly.'
    },
    targeting_cookies: { 
      name: 'Targeting Cookies',
      toggle: true,
      description: 'These cookies are set through our website by third parties, such as our advertising partners. These cookies track your online activity to help advertisers build a profile of your interests, deliver more relevant advertising to you on other websites, or to limit how many times you see an ad. By accepting these cookies, you are directing us to share information collected by these cookies with the third parties who have placed the cookies, for the third party’s use. If you do not accept these cookies, you will still see advertisements, but the advertisements will not be targeted to you.'
    },
    performance_cookies: {
      name: 'Performance Cookies',
      toggle: true,
      description: 'These cookies collect information about how you engage with the website, like which pages you visited, how long you stayed on a page, and which links you clicked on. These cookies help us to know which pages are the most and least popular and see how visitors move around the website. If you do not accept these cookies, we will not know when you have visited our site.'
    },
    activity_logging: {
      name: 'Activity Logging',
      toggle: true,
      description: 'Capturing a log of your activity on our website allows us to see how you use our site, to see if you are finding what you need, and to help troubleshoot issues or bugs. We use an application from Glassbox which captures your mouse movements and selections on our website and processes it on our behalf, to help us analyze how well it is working for you and if you having any trouble. If you do not select this option, we will not collect data that shows how you use our site, and it will be hard for us to help you with technical issues you may experience.'
    }
  }

}

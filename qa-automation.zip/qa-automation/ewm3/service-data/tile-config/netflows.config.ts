import { GeneralUtils } from '../../../utils/generalUtils'
import { ModalContent } from './types.config'

export abstract class NetflowsConfig {

  public static readonly tileMenuOptions = {
    viewFlowsData: 'View Flows Data in Advisor Insights',
    learnAboutTile: 'Learn About This Tile',
    removeTile: 'Remove Tile'
  }

  public static readonly toolTipItems = [
    'Inflows',
    'Outflows',
    'Net Flows'
  ]

  public static readonly font = {
    timePeriod: {
      fontSize: '18px',
      fontFamily: 'Roboto, sans-serif'
    },
    metricValue: {
      fontSize: '36px',
      fontFamily: 'Roboto, sans-serif'
    },
    changesIndicator: {
      fontSize: '18px',
      fontFamily: 'Roboto, sans-serif'
    }
  }

  public static readonly timePeriodsParams = [
    { 
      apiPathParam: 'mtd',
      timePeriod: 'Monthly',
      labelDateFormat: GeneralUtils.getCurrentMonth
    },
    {
      apiPathParam: 'qtd',
      timePeriod: 'Quarterly',
      labelDateFormat: GeneralUtils.getCurrentQuarter
    },
    {
      apiPathParam: 'ytd',
      timePeriod: 'Yearly',
      labelDateFormat: GeneralUtils.getCurrentYear
    }
  ]

  public static readonly learnAboutThisTileProperties: ModalContent = {
    // these info are CMS driven
    title: 'About the Net Flows Tile',
    content: 'Data in the Net Flows tile is updated daily, as of last night close of business.Net Flows Calculation:The Net Flows calculation represents the total of Funding and Additions, subtracted by Withdrawals and Terminations. The Net Flows calculation does not include the amounts associated with Journal Transfers.'
  }

}

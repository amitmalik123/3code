import { BaseConfig } from '../../base/base-config'

export enum Platforms {
  CHEETAH = 'cheetah',
  ASSETMARK = 'assetmark'
}

export abstract class EWM3Config extends BaseConfig {
  public static readonly PLATFORM = process.env.PLATFORM || Platforms.ASSETMARK
  protected static PROJECT_NAME = 'ewm3'
  public static readonly USERNAME_DEFAULT = process.env.USERNAME_DEFAULT ||'sampleadvisor4' // Actual default user
  public static readonly USERNAME_ACTION_LINKS = 'sampleadvisor4'
  //  public static readonly userNameWithData = 'sampleadvisor12'; // As of now it is example User
  // public static readonly userNameWithNoData = 'sampleadvisor13'; // As of now it is example User
  //user from that array should not contain another usernames, that we use
  public static get USERNAMES_ARRAY() {
    const array = [
      //'sampleadvisor', //
      //'sampleadvisor1', // As of now user doesn't have AdvisorIds
      //'sampleadvisor2', // As of now user doesn't have any Data 
      'sampleadvisor3',
      'sampleadvisor4',
      'sampleadvisor5',
      'sampleadvisor11',
      'sampleadvisor12', 
      //'sampleadvisor13', // As of now user doesn't have any Data
      //'sampleadvisor14', // As of now user doesn't have any Data
    ]
    const valuesToExclude = [this.USERNAME_DEFAULT, this.USERNAME_ACTION_LINKS]
    return array.filter(item => !valuesToExclude.includes(item))
  }
  public static userTokensArray: string[] = []
  public static readonly PASSWORD = process.env.PASSWORD || '123456'
  public static readonly BASE_URL_2_0 = process.env['BASE_PAGE_' + (process.env.TARGET_ENV || 'dev').toUpperCase() + '2_0']
  public static readonly KEYCLOAK_BASE_URL = process.env['BASE_KEYCLOAK_URL_' + (process.env.TARGET_ENV || 'dev').toUpperCase()]
}

import {GeneralUtils} from '../../../utils/generalUtils'
import {UrlTarget} from '../../ui/features/action-links.feature'
import {CSIndividualPageConfig} from './types'

enum ToolbarMetricLabels{
  ACCOUNTS = 'Accounts',
  PORTFOLIO_VALUE = 'Portfolio Value',
  CLIENT_RISK = 'Client Risk'
}

export const IndividualHouseholdConfig: CSIndividualPageConfig = {
  TITLE: '',
  ENDPOINTS: {
    client: '/accountdata/api/v1/clients/metrics/',
    toolbar:'/accountdata/api/v1/clients/metrics/',
  },
  
  LINKS_CONFIG:
    {
      toolbar: [
        {
          uid: 'ap-clients-hh-hh-tbl-cp-ra',
          title: 'Create Proposal',
          order: 1,
          url: '{BASE_URL_20}/Portfolio/Construct?clientId={CLIENT_WEB_ID}',
          isInternal: false,
          target: UrlTarget.SAME_PAGE,
        },
        {
          uid: 'ap-clients-hh-hh-tbl-ona-ra',
          title: 'Open New Account',
          order: 2,
          url: '{BASE_URL_20}/DNeWM/NBT/Profile/Profile.aspx?clientId={CLIENT_WEB_ID}',
          isInternal: false,
          target: UrlTarget.SAME_PAGE,
        },
        {
          uid: 'ap-clients-hh-hh-tbl-codr-ra',
          title: 'Create On-Demand Report',
          order: 3,
          url: '{BASE_URL_20}/AccountsAnalysis/Clients/ClientDetail/OnDemandReport/{CLIENT_WEB_ID}',
          isInternal: false,
          target: UrlTarget.SAME_PAGE,
        },
        {
          uid: 'ap-clients-hh-hh-tbl-ma-ra',
          title: 'Manage Account',
          order: 4,
          url: '{BASE_URL_20}/DNeWM/NBT/list/listClientIntermediate.aspx?ClientID={CLIENT_WEB_ID}&AgentId={AGENT_ID}&Flag=ClientAccounts',
          isInternal: false,
          target: UrlTarget.SAME_PAGE,
        },
        {
          uid: 'ap-clients-hh-hh-tbl-vip-ra',
          title: 'View Investor Portal',
          order: 5,
          url: '{BASE_URL_20}/investorportal/overview',
          isInternal: false,
          target: UrlTarget.SAME_PAGE,
        },
      ],
    },

  TOOLBAR_METRICS_CONFIG: [
    {
      uid: 'ap-clients-indhh-ac-lb',
      name: ToolbarMetricLabels.ACCOUNTS,
      apiField: 'accountsCount',
      apiDataTransform: (value) => `${value}`
    },
    {
      uid: 'ap-clients-indhh-pv-lb',
      name: ToolbarMetricLabels.PORTFOLIO_VALUE,
      apiField: 'portfolioValue',
      apiDataTransform: (value) => {
        const roundValue = Math.round(value)
        return GeneralUtils.normalizeCurrencyValueWithFraction(roundValue, 0)}
    },
    {
      uid: 'ap-clients-indhh-cr-lb',
      name: ToolbarMetricLabels.CLIENT_RISK,
      apiField: 'clientRisk',
    },
  ],

  INDIVIDUAL_TOOLBAR_CONFIG: ['']
}
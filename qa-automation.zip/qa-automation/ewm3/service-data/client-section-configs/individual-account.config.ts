import {GeneralUtils} from '../../../utils/generalUtils'
import {UrlTarget} from '../../ui/features/action-links.feature'
import {CSIndividualPageConfig} from './types'

enum ToolbarMetricLabels{
  ACCOUNT_VALUE = 'Account Value',
  CLIENT_RISK = 'Client Risk',
  ACCOUNT_NUMBER = 'Account Number',
}

export const IndividualAccountConfig: CSIndividualPageConfig = {
  TITLE: '',
  ENDPOINTS: {
    account: '/accountdata/api/v1/accounts/metrics/',
    toolbar:'/accountdata/api/v1/accounts/metrics/',
  },
  
  LINKS_CONFIG:
    {
      toolbar: [
        {
          uid: 'ap-clients-ac-ac-tbl-codr-ra',
          title: 'Create On-Demand Report',
          order: 2,
          url: '{BASE_URL_20}/AccountsAnalysis/Clients/AccountDetail/OnDemandReport/Index/{ACCOUNT_ID}/{CLIENT_WEB_ID}',
          isInternal: false,
          target: UrlTarget.SAME_PAGE,
        },
        {
          uid: 'ap-clients-ac-ac-tbl-ma-ra',
          title: 'Manage Account',
          order: 1,
          url: '{BASE_URL_20}/DNeWM/NBT/list/listClientIntermediate.aspx?ClientID={CLIENT_WEB_ID}&AgentId={AGENT_ID}&Flag=ClientAccounts&AccountID={ACCOUNT_ID}',
          isInternal: false,
          target: UrlTarget.SAME_PAGE,
        },
        {
          uid: 'ap-clients-ac-ac-tbl-vip-ra',
          title: 'View Investor Portal',
          order: 3,
          url: '{BASE_URL_20}/investorportal/overview',
          isInternal: false,
          target: UrlTarget.SAME_PAGE,
        },
      ],
    },

  TOOLBAR_METRICS_CONFIG: [
    {
      uid: 'ap-accounts-indac-av-lb',
      name: ToolbarMetricLabels.ACCOUNT_VALUE,
      apiField: 'accountValue',
      apiDataTransform: (value) => {
        const roundValue = Math.round(value)
        return GeneralUtils.normalizeCurrencyValueWithFraction(roundValue, 0)}
    },
    {
      uid: 'ap-accounts-indac-cr-lb',
      name: ToolbarMetricLabels.CLIENT_RISK,
      apiField: 'clientRisk',
    },
    {
      uid: 'ap-accounts-indac-ban-lb',
      name: ToolbarMetricLabels.ACCOUNT_NUMBER,
      apiField: 'bankAccountNumber',
    },
  ],

  INDIVIDUAL_TOOLBAR_CONFIG: ['']
}
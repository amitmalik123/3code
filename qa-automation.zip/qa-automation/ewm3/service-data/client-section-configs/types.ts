import {CSTableDataConfig} from '../../ui/features/client-section/cs.table.feature'
import {LinksConfig} from '../../ui/features/action-links.feature'
import {ToolbarMetricConfig} from '../../ui/features/client-section/cs.toolbar.feature'

export interface NestedColumns {
  [index: string]: string
}

export interface CSPageConfig {
  TITLE: string,
  ENDPOINTS: { [index: string]: string },
  LINKS_CONFIG: LinksConfig,
  TOOLBAR_METRICS_CONFIG: ToolbarMetricConfig[]
}

export interface CSTablePageConfig extends CSPageConfig {
  COLUMN_NAMES: { [index: string]: string | NestedColumns },
  SEARCHABLE_FIELDS: string[],
  TABLE_DATA_CONFIG: CSTableDataConfig,
}

export interface CSIndividualPageConfig extends CSPageConfig {
  INDIVIDUAL_TOOLBAR_CONFIG: string[]
}

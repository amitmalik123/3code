import { AccountElement, AccountsDataArray, ClientDataArray } from '../../api/accountdata/v1/types'
import { CSClientsDbQueries } from './cs.clients-db-queries'
import { CSAccountsDbQueries } from './cs.accounts-db-queries'
import { CSDbInfoConfig } from './cs.base-db-queries'

export class CSDbDataProvider {

  readonly clientsDbQueries = new CSClientsDbQueries(CSDbInfoConfig.csDataBaseName)
  readonly accountsDbQueries = new CSAccountsDbQueries(CSDbInfoConfig.csDataBaseName)

  calculateCumulativeReturn (sip:number|undefined, asofdate: Date, inceptiondate: Date): number|undefined {
    if (inceptiondate === undefined || asofdate === undefined || sip === null || sip === undefined) {
      return undefined
    }

    if (isNaN(inceptiondate.getTime()) || isNaN(asofdate.getTime())) {
      return undefined
    }
  
    const diffTime = asofdate.getTime() - inceptiondate.getTime()
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24))
    const diffYears = diffDays/365.24
    const result = Math.pow(1 + sip, diffYears) - 1
    return result
  }

  transformPerformanceData (perfIndicator: string): number|undefined {
    let result: number|undefined = 0
  
    if (perfIndicator === null) {
      result = undefined
    } else if (perfIndicator === undefined) {
      result = undefined
    } else {
      result = parseFloat(perfIndicator) / 100
    }
    return result
  }

  /**
 * Method that returns data for specific Client
 * @param id - Client ID as it is stored in the DB in the cmd.organization table in the field 'organizationid'. Example: '5EEA3FE7-140F-435F-8F20-79D7BE5A0C3A-000D'
 * @return ClientDataArray - structure with Client's data
 */
  public async returnClientData (id: string): Promise<ClientDataArray> {
    
    const clientOutput = await this.clientsDbQueries.returnClientById(id)
    const advisorOutput = await this.clientsDbQueries.returnAdvisorByClientId(id)
    const performanceOutput = await this.clientsDbQueries.returnPerformanceById(id)
    const mvOutput = await this.clientsDbQueries.returnSumMvByClientId(id)
    const accountsNumberOutput = await this.clientsDbQueries.returnNumberOfAccountsByClientId(id)
    const expectedAmountOutput = await this.clientsDbQueries.returnExpectedAmountByClientId(id)
    const webAccessDb = (clientOutput[0]?.customattributes.amk_web_access === 'true')

    const clientData: ClientDataArray = {
      id: clientOutput[0]?.organizationid,
      advisorIdentifier: advisorOutput[0]?.sourceid,
      clientAplId: clientOutput[0]?.sourceid,
      clientName: clientOutput[0]?.name,
      clientWebId: clientOutput[0]?.customattributes.amk_web_client_id?clientOutput[0]?.customattributes.amk_web_client_id:'',
      webAccess: webAccessDb,
      annualizedPerformance: this.transformPerformanceData (performanceOutput[0]?.siperformance),
      assetAllocations: [],
      marketValue: parseFloat(mvOutput[0]?.resultmv??'0'),
      netInvestment: performanceOutput[0]?.netinvestment? parseFloat(performanceOutput[0]?.netinvestment):undefined,
      numberOfAccounts: Number(accountsNumberOutput[0]?.numberofaccounts),
      ytdPerformance: this.transformPerformanceData (performanceOutput[0]?.ytdperformance),
      expectedAmount: parseFloat((expectedAmountOutput[0]?.expectedamount??'0')),
      oneYearPerformance: this.transformPerformanceData (performanceOutput[0]?.oneyearperformance),
      threeYearPerformance: this.transformPerformanceData (performanceOutput[0]?.threeyearperformance),
      fiveYearPerformance: this.transformPerformanceData (performanceOutput[0]?.fiveyearperformance),
      cumulativeReturn: this.calculateCumulativeReturn(this.transformPerformanceData (performanceOutput[0]?.siperformance), performanceOutput[0]?.asofdate, clientOutput[0]?.platformstartdate)
    }
    return clientData
  }

  /**
 * Method that returns data for specific nested Account in the Households tab
 * @param id - Account ID as it is stored in the DB in the cmd.virtualaccount table in the field 'virtualaccountid'. Example: '8BCD0741-B245-47C4-863D-62784E4C978D-000D'
 * @return AccountElement - structure with nested Account's data
 */
  public async returnNestedAccountData (id: string): Promise<AccountElement> {
    
    const accountOutput = await this.accountsDbQueries.returnAccountById(id)
    const performanceOutput = await this.accountsDbQueries.returnPerformanceById(id)
    const mvOutput = await this.accountsDbQueries.returnLastMvByAccountId(id)
    const bankAccountNumberOutput = await this.accountsDbQueries.returnSourceAccountDataByAccountId(id)
    const ProductOutput = await this.accountsDbQueries.returnInvestmentProductByAccountId(id)

    const accountData: AccountElement = {
      id: accountOutput[0]?.virtualaccountid,
      status: accountOutput[0]?.status,
      applicationId: accountOutput[0]?.sourceid,
      title: accountOutput[0]?.name,
      annualizedPerformance: this.transformPerformanceData (performanceOutput[0]?.siperformance),
      assetAllocations: [],
      marketValue: parseFloat(mvOutput[0]?.resultmv??'0'),
      investmentProduct: ProductOutput[0]?.name,
      ytdPerformance: this.transformPerformanceData (performanceOutput[0]?.ytdperformance),
      expectedAmount: parseFloat((accountOutput[0]?.expectedfundingamount??'0')),
      oneYearPerformance: this.transformPerformanceData (performanceOutput[0]?.oneyearperformance),
      threeYearPerformance: this.transformPerformanceData (performanceOutput[0]?.threeyearperformance),
      fiveYearPerformance: this.transformPerformanceData (performanceOutput[0]?.fiveyearperformance),
      cumulativeReturn: this.calculateCumulativeReturn(this.transformPerformanceData (performanceOutput[0]?.siperformance), performanceOutput[0]?.asofdate, accountOutput[0]?.platformstartdate),
      alerts: accountOutput[0]?.restrictions,
      bankAccountNumber: bankAccountNumberOutput[0]?.bankaccountnumber,
      inceptionDate:accountOutput[0]?.platformstartdate
    }
    return accountData
  }

  /**
 * Method that returns data for specific Account in the Accounts tab
 * @param id - Account ID as it is stored in the DB in the cmd.virtualaccount table in the field 'virtualaccountid'. Example: '8BCD0741-B245-47C4-863D-62784E4C978D-000D'
 * @return AccountsDataArray - structure with Account's data
 */
  public async returnAccountData (id: string): Promise<AccountsDataArray> {

    const accountOutput = await this.accountsDbQueries.returnAccountById(id)
    const performanceOutput = await this.accountsDbQueries.returnPerformanceById(id)
    const mvOutput = await this.accountsDbQueries.returnLastMvByAccountId(id)
    const sourceAccountOutput = await this.accountsDbQueries.returnSourceAccountDataByAccountId(id)
    const ProductOutput = await this.accountsDbQueries.returnInvestmentProductByAccountId(id)
    const clientId = (await this.accountsDbQueries.returnClientByAccountId(id))[0].parentid
    const advisorOutput = await this.accountsDbQueries.returnAdvisorByClientId(clientId)
    const clientOutput = await this.clientsDbQueries.returnClientById(clientId)

    const accountData: AccountsDataArray = {
      id: accountOutput[0]?.virtualaccountid,
      status: accountOutput[0]?.status,
      applicationId: accountOutput[0]?.sourceid,
      title: accountOutput[0]?.name,
      annualizedPerformance: this.transformPerformanceData (performanceOutput[0]?.siperformance),
      assetAllocations: [],
      marketValue: parseFloat(mvOutput[0]?.resultmv??'0'),
      investmentProduct: ProductOutput[0]?.name,
      ytdPerformance: this.transformPerformanceData (performanceOutput[0]?.ytdperformance),
      expectedAmount: parseFloat((accountOutput[0]?.expectedfundingamount??'0')),
      oneYearPerformance: this.transformPerformanceData (performanceOutput[0]?.oneyearperformance),
      threeYearPerformance: this.transformPerformanceData (performanceOutput[0]?.threeyearperformance),
      fiveYearPerformance: this.transformPerformanceData (performanceOutput[0]?.fiveyearperformance),
      cumulativeReturn: this.calculateCumulativeReturn(this.transformPerformanceData (performanceOutput[0]?.siperformance), performanceOutput[0]?.asofdate, accountOutput[0]?.platformstartdate),
      alerts: accountOutput[0]?.restrictions,
      bankAccountNumber: sourceAccountOutput[0]?.bankaccountnumber,
      inceptionDate:accountOutput[0]?.platformstartdate,
      advisorIdentifier: advisorOutput[0]?.sourceid,
      clientId: clientOutput[0]?.organizationid,
      clientAplId: clientOutput[0]?.sourceid,
      clientName: clientOutput[0]?.name,
      clientWebId: clientOutput[0]?.customattributes.amk_web_client_id?clientOutput[0]?.customattributes.amk_web_client_id:'',
      custodian: sourceAccountOutput[0]?.banktype=='Custodian'?sourceAccountOutput[0]?.bank:undefined,
      registrationType: sourceAccountOutput[0]?.subtype,
      netInvestment: performanceOutput[0]?.netinvestment? parseFloat(performanceOutput[0]?.netinvestment):undefined
    }
    return accountData
  }
}
import { CSBaseDbQueries} from './cs.base-db-queries'

export class CSAccountsDbQueries extends CSBaseDbQueries {
  constructor(dbName: string) {
    super(dbName)
  }

  /**
 * As for now all Accounts requests return Accounts excluding Parent Accounts, that has sleeves
 */

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnAllAccounts (advisors: string): Promise<any[]> {
    this.dbInfo.query = `
      SELECT * FROM cmd.virtualaccount
      WHERE (
          parentid IN (
              SELECT organizationid FROM cmd.organization o
              WHERE o.parentorganizationid IN (${advisors})
          )
          AND virtualaccountid NOT IN (
              SELECT DISTINCT parentid FROM cmd.virtualaccount
              WHERE parentid IN (
                  SELECT virtualaccountid FROM cmd.virtualaccount
                  WHERE parentid IN (
                      SELECT organizationid FROM cmd.organization o
                      WHERE o.parentorganizationid IN (${advisors})
                  )
              )
          )
      )
      OR (
          parentid IN (
              SELECT virtualaccountid FROM cmd.virtualaccount
              WHERE parentid IN (
                  SELECT organizationid FROM cmd.organization o
                  WHERE o.parentorganizationid IN (${advisors})
              )
          )
      )`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnAllAccountsByClientId (id: string): Promise<any[]> {
    this.dbInfo.query = `
    SELECT *
    FROM cmd.virtualaccount
    WHERE 
      (
        parentid IN ('${id}')
        AND virtualaccountid NOT IN (
          SELECT DISTINCT parentid
          FROM cmd.virtualaccount
          WHERE parentid IN (
            SELECT virtualaccountid
            FROM cmd.virtualaccount
            WHERE parentid = '${id}'
          )
        )
      )
      OR
      (
        parentid IN (
          SELECT virtualaccountid
          FROM cmd.virtualaccount
          WHERE parentid = '${id}'
        )
      )`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnNotClosedAccountWithoutSleeves (advisors: string): Promise<any[]> {
    this.dbInfo.query = `
    SELECT virtualaccountid 
    FROM cmd.virtualaccount
    WHERE 
    (
        parentid IN (
            SELECT organizationid 
            FROM cmd.organization o
            WHERE o.parentorganizationid IN (${advisors})
        ) 
        AND (${this.notCloseStatusQuery()})
        AND virtualaccountid NOT IN (
            SELECT DISTINCT parentid 
            FROM cmd.virtualaccount
            WHERE parentid IN (
                SELECT virtualaccountid 
                FROM cmd.virtualaccount
                WHERE parentid IN (
                    SELECT organizationid 
                    FROM cmd.organization o
                    WHERE o.parentorganizationid IN (${advisors})
                )
            )
        )
    )
    limit 1`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }  

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnNotClosedSleeveAccount (advisors: string): Promise<any[]> {
    this.dbInfo.query = `
    SELECT virtualaccountid 
    FROM cmd.virtualaccount
    WHERE parentid IN (
        SELECT virtualaccountid 
        FROM cmd.virtualaccount
        WHERE parentid IN (
            SELECT organizationid 
            FROM cmd.organization o
            WHERE o.parentorganizationid IN (${advisors})
        )
    ) 
    AND (${this.notCloseStatusQuery()})    
    limit 1`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }
  
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnAMRSAccount (advisors: string): Promise<any[]> {
    this.dbInfo.query = `
    SELECT * FROM cmd.virtualaccount
    where parentid IN (Select organizationid FROM cmd.organization o
    where o.parentorganizationid IN (${advisors})) 
    AND sourcesystem = 'SFDC-AMRS'
    AND (${this.notCloseStatusQuery()}) 
    AND virtualaccountid NOT IN (
      SELECT DISTINCT parentid 
      FROM cmd.virtualaccount
      WHERE parentid IN (
          SELECT virtualaccountid 
          FROM cmd.virtualaccount
          WHERE parentid IN (
              SELECT organizationid 
              FROM cmd.organization o
              WHERE o.parentorganizationid IN (${advisors})
          )
      )
    )   
    limit 1`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnTerminatedAccount (advisors: string): Promise<any[]> {
    this.dbInfo.query = `
    SELECT * FROM cmd.virtualaccount
    where parentid IN (Select organizationid FROM cmd.organization o
    where o.parentorganizationid IN (${advisors})) 
    AND (${this.closeStatusQuery()})
    AND virtualaccountid NOT IN (
      SELECT DISTINCT parentid 
      FROM cmd.virtualaccount
      WHERE parentid IN (
          SELECT virtualaccountid 
          FROM cmd.virtualaccount
          WHERE parentid IN (
              SELECT organizationid 
              FROM cmd.organization o
              WHERE o.parentorganizationid IN (${advisors})
          )
      )
    )
    limit 1`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnAccountWithPerformanceIndicators (advisors: string): Promise<any[]> {    
    this.dbInfo.query = `
    SELECT virtualaccountid 
    FROM cmd.virtualaccount va
    LEFT JOIN cmd.summary_performance perf
        ON perf.targetid = va.virtualaccountid
    WHERE va.parentid IN (
        SELECT organizationid 
        FROM cmd.organization o
        WHERE o.parentorganizationid IN (${advisors})
    ) 
    AND perf.targetid is not null
    AND (${this.notCloseStatusQuery()})
    AND virtualaccountid NOT IN (
      SELECT DISTINCT parentid 
      FROM cmd.virtualaccount
      WHERE parentid IN (
          SELECT virtualaccountid 
          FROM cmd.virtualaccount
          WHERE parentid IN (
              SELECT organizationid 
              FROM cmd.organization o
              WHERE o.parentorganizationid IN (${advisors})
          )
      )
    )
    LIMIT 1    
    `
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnAccountWithoutPerformanceIndicators (advisors: string): Promise<any[]> {    
    this.dbInfo.query = `
    SELECT virtualaccountid 
    FROM cmd.virtualaccount va
    LEFT JOIN cmd.summary_performance perf
        ON perf.targetid = va.virtualaccountid
    WHERE va.parentid IN (
        SELECT organizationid 
        FROM cmd.organization o
        WHERE o.parentorganizationid IN (${advisors})
    ) 
    AND perf.targetid is null
    AND (${this.notCloseStatusQuery()})
    AND virtualaccountid NOT IN (
      SELECT DISTINCT parentid 
      FROM cmd.virtualaccount
      WHERE parentid IN (
          SELECT virtualaccountid 
          FROM cmd.virtualaccount
          WHERE parentid IN (
              SELECT organizationid 
              FROM cmd.organization o
              WHERE o.parentorganizationid IN (${advisors})
          )
      )
    )
    LIMIT 1    
    `
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnAccountById (id: string): Promise<any[]> {
    this.dbInfo.query = `Select * 
        FROM cmd.virtualaccount 
        where virtualaccountid = '${id}'`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }
    
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnLastMvByAccountId (id: string): Promise<any[]> {
    this.dbInfo.query = `Select mv.value as resultmv
      from cmd.marketvalue as mv join (
      Select virtualaccountid, max (valuationdate) as maxdate from cmd.marketvalue	
      where virtualaccountid = '${id}'
      group by virtualaccountid
      ) as lastmv	
      on (mv.virtualaccountid = lastmv.virtualaccountid and mv.valuationdate = lastmv.maxdate)`
    
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  public async returnEarliestMvValuationDateByAccountId (id: string): Promise<Date> {
    this.dbInfo.query = `
      Select min (valuationdate) as mindate
      from cmd.marketvalue
      where virtualaccountid ='${id}'`

    const dbResponse = await this.dbAccess.getDataFromDB(this.dbInfo)
    return dbResponse[0]?.mindate
  }
  
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnSourceAccountDataByAccountId (id: string): Promise<any[]> {
    this.dbInfo.query = `
    Select bankaccountnumber, bank, banktype, subtype FROM cmd.sourceaccount
    Where sourceaccountid in (SELECT sa->>'SourceAccountID'
    FROM cmd.virtualaccount,
         jsonb_array_elements(sourceaccounts) AS sa
    WHERE virtualaccountid = '${id}')`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnInvestmentProductByAccountId (id: string): Promise<any[]> {
    this.dbInfo.query = `
    Select name from cmd.product
    where productid in (SELECT productid FROM cmd.virtualaccount
    where virtualaccountid IN ('${id}'))`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  public async returnTerminatedAccountByClientId (clientId: string): Promise<string> {
    this.dbInfo.query = `
      SELECT virtual_account_id
      FROM public.virtual_account
      WHERE household_id IN ('${clientId}')
      AND (${this.closeStatusQuery()})
      LIMIT 1`
    
    const dbResponse = await this.dbAccess.getDataFromDB(this.dbInfo)
    return dbResponse[0]?.virtual_account_id
  }
}
import { DBAccessHelpers, DbInfo } from '../../../db/db-access-helpers'
import { DbName } from '../../../db/db-config'

export const CSDbInfoConfig = {
  csdataBaseName: DbName.accountdata,
  goalsdataBaseName: DbName.goals,
  closeStatuses: ['terminated', 'closed']
}

export class CSBaseDbQueries {

  readonly dbAccess: DBAccessHelpers
  readonly dbInfo: DbInfo

  constructor(dbName: string) {
    this.dbAccess = new DBAccessHelpers()
    this.dbInfo = {
      dataBaseName: dbName,
    }
  }

  /**
 * Method that returns the List of all clients existing for specified Advisors
 * @param advisors - string with the list of advisor IDs separated with ','. Example: 'C5B78A40-E22E-4E34-94C0-173605DB647D', 'a2e9e709-8313-4c4a-bee3-0de7a4954cfc-00ODFA', '2d9a8e38-68e9-4cd3-af68-261e3ec3beed'
 * @return json structure with DB Response
 */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnAllClients (advisors: string): Promise<any[]> {
    this.dbInfo.query = `Select * FROM cmd.organization where parentorganizationid IN (${advisors})`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnClientById (id: string): Promise<any[]> {
    this.dbInfo.query = `Select * 
      FROM cmd.organization o 
      where organizationid = '${id}'`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnClientByAccountId (id: string): Promise<any[]> {
    this.dbInfo.query = `Select parentid, parenttype 
          FROM cmd.virtualaccount 
          where virtualaccountid = '${id}'`
    const parent = await this.dbAccess.getDataFromDB(this.dbInfo)
    return parent[0].parenttype=='Organization'?parent:this.returnClientByAccountId(parent[0].parentid)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnPerformanceById (id: string): Promise<any[]> {
    this.dbInfo.query = `Select * from cmd.summary_performance
      where targetid = '${id}'`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnAdvisorByClientId (id: string): Promise<any[]> {
    this.dbInfo.query = `Select * 
      FROM cmd.organization o 
      where organizationid in (Select parentorganizationid 
      FROM cmd.organization o 
      where organizationid ='${id}')`
        
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnExternalAdvisorByAdvisorsId (advisors: string): Promise<any[]> {
    this.dbInfo.query = `
      SELECT organizationid 
      FROM cmd.organization o 
      WHERE organizationid IN (
        SELECT parentorganizationid 
        FROM cmd.organization o 
        WHERE organizationid IN (
          SELECT parentid 
          FROM cmd.virtualaccount
          WHERE parentid NOT IN (
            SELECT organizationid 
            FROM cmd.organization o
            WHERE o.parentorganizationid IN (${advisors})                     
          )
        AND (${this.notCloseStatusQuery()})
        )
      )
      LIMIT 1`
            
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  public async returnExternalClientByAdvisorsId (advisors: string): Promise<string> {
    this.dbInfo.query = `
      SELECT parentid 
      FROM cmd.virtualaccount
      WHERE parentid NOT IN (
        SELECT organizationid 
        FROM cmd.organization o
        WHERE o.parentorganizationid IN (${advisors}))
      LIMIT 1`
          
    const dbResponse = await this.dbAccess.getDataFromDB(this.dbInfo)
    return dbResponse[0]?.parentid
  }

  public async returnExternalAccountByAdvisorsId (advisors: string): Promise<string> {
    this.dbInfo.query = `
      SELECT virtualaccountid 
      FROM cmd.virtualaccount
      WHERE parentid NOT IN (
        SELECT organizationid 
        FROM cmd.organization o
        WHERE o.parentorganizationid IN (${advisors}))
      LIMIT 1`
          
    const dbResponse = await this.dbAccess.getDataFromDB(this.dbInfo)
    return dbResponse[0]?.virtualaccountid
  }

  public notCloseStatusQuery (): string {
    let notCloseStatusQuery = ''       
    const conditions = CSDbInfoConfig.closeStatuses.map(status => `status NOT ILIKE '%${status}%'`)
    notCloseStatusQuery += conditions.join(' AND ')
          
    return notCloseStatusQuery
  }

  public closeStatusQuery (): string {
    let closeStatusQuery = ''  
    const conditions = CSDbInfoConfig.closeStatuses.map(status => `status ILIKE '%${status}%'`)
    closeStatusQuery += conditions.join(' OR ')
            
    return closeStatusQuery
  }
}
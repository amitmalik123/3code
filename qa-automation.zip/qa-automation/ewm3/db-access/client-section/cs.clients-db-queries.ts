import { CSBaseDbQueries} from './cs.base-db-queries'

export class CSClientsDbQueries extends CSBaseDbQueries {
  constructor(dbName: string) {
    super(dbName)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnClientWithoutAccounts (advisors: string): Promise<any[]> {
    this.dbInfo.query = `Select * 
    FROM cmd.organization o 
    where organizationid in (SELECT o.organizationid FROM cmd.organization o left join cmd.virtualaccount acc
    on acc.parentid = o.organizationid 
    where o.parentorganizationid IN (${advisors})
    group by o.organizationid
    having count (acc.virtualaccountid)=0 limit 1)`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnClientWithAccounts (advisors: string): Promise<any[]> {
    this.dbInfo.query = `Select * 
    FROM cmd.organization o 
    where organizationid in (SELECT o.organizationid FROM cmd.organization o left join cmd.virtualaccount acc
    on acc.parentid = o.organizationid 
    where o.parentorganizationid IN (${advisors})
    group by o.organizationid
    having count (acc.virtualaccountid)>0 limit 1)`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnClientWithClosedAccounts (advisors: string): Promise<any[]> {
    this.dbInfo.query = `SELECT o.organizationid FROM cmd.organization o 
      left join 
        (
          SELECT parentid, count(virtualaccountid) as terminated FROM cmd.virtualaccount
          where parentid IN (Select organizationid FROM cmd.organization o
          where o.parentorganizationid IN (${advisors})) and (${this.closeStatusQuery()})
          group by parentid
        ) as terminatedacc
        on terminatedacc.parentid = o.organizationid 
      left join 
        (
          SELECT parentid, count(virtualaccountid) as totalacc FROM cmd.virtualaccount
          where parentid IN (Select organizationid FROM cmd.organization o
          where o.parentorganizationid IN (${advisors}))
          group by parentid
        ) as allacc
        on allacc.parentid = o.organizationid 
      where o.parentorganizationid IN (${advisors})
      AND  terminatedacc.terminated < allacc.totalacc
      limit 1`

    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnClientWithOnlyClosedAccounts (advisors: string): Promise<any[]> {
    this.dbInfo.query = `SELECT o.organizationid FROM cmd.organization o 
        left join 
          (
            SELECT parentid, count(virtualaccountid) as terminated FROM cmd.virtualaccount
            where parentid IN (Select organizationid FROM cmd.organization o
            where o.parentorganizationid IN (${advisors})) and (${this.closeStatusQuery()})
            group by parentid
          ) as terminatedacc
          on terminatedacc.parentid = o.organizationid 
        left join 
          (
            SELECT parentid, count(virtualaccountid) as totalacc FROM cmd.virtualaccount
            where parentid IN (Select organizationid FROM cmd.organization o
            where o.parentorganizationid IN (${advisors}))
            group by parentid
          ) as allacc
          on allacc.parentid = o.organizationid 
        where o.parentorganizationid IN (${advisors})
        AND  terminatedacc.terminated = allacc.totalacc
        limit 1`
  
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnClientWithOnlyActiveAccounts (advisors: string): Promise<any[]> {    
    this.dbInfo.query = `SELECT o.organizationid FROM cmd.organization o 
          left join 
            (
              SELECT parentid, count(virtualaccountid) as terminated FROM cmd.virtualaccount
              where parentid IN (Select organizationid FROM cmd.organization o
              where o.parentorganizationid IN (${advisors})) and (${this.closeStatusQuery()})
              group by parentid
            ) as terminatedacc
            on terminatedacc.parentid = o.organizationid 
          left join 
            (
              SELECT parentid, count(virtualaccountid) as totalacc FROM cmd.virtualaccount
              where parentid IN (Select organizationid FROM cmd.organization o
              where o.parentorganizationid IN (${advisors}))
              group by parentid
            ) as allacc
            on allacc.parentid = o.organizationid 
          where o.parentorganizationid IN (${advisors})
          AND  terminatedacc.terminated is null AND  allacc.totalacc>1
          limit 1`
    
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnClientWithPerformanceIndicators (advisors: string): Promise<any[]> {
    
    this.dbInfo.query = `SELECT o.organizationid FROM cmd.organization o left join cmd.summary_performance perf
    on perf.targetid = o.organizationid 
    where o.parentorganizationid IN (${advisors}) and perf.targetid is not null
    limit 1`
    
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnClientWithoutPerformanceIndicators (advisors: string): Promise<any[]> {
    
    this.dbInfo.query = `SELECT o.organizationid FROM cmd.organization o left join cmd.summary_performance perf
      on perf.targetid = o.organizationid 
      where o.parentorganizationid IN (${advisors}) and perf.targetid is null
      limit 1`
      
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnSumMvByClientId (id: string): Promise<any[]> {
    this.dbInfo.query = `SELECT sum(mv2.value) as resultmv
    FROM cmd.virtualaccount as va left join (
    Select mv.virtualaccountid, mv.value 
    from cmd.marketvalue as mv join (
    Select virtualaccountid, max (valuationdate) as maxdate from cmd.marketvalue	
    where virtualaccountid IN (SELECT va.virtualaccountid
    FROM cmd.virtualaccount va
    where va.parentid = '${id}' )
    group by virtualaccountid
    ) as lastmv	
    on (mv.virtualaccountid = lastmv.virtualaccountid and mv.valuationdate = lastmv.maxdate)
    ) as mv2
    on va.virtualaccountid = mv2.virtualaccountid
    where va.parentid = '${id}'`

    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnNumberOfAccountsByClientId (id: string): Promise<any[]> {
    this.dbInfo.query = `
    SELECT count (virtualaccountid) as numberofaccounts FROM cmd.virtualaccount
      WHERE (
          parentid IN ('${id}')
          AND virtualaccountid NOT IN (
              SELECT DISTINCT parentid FROM cmd.virtualaccount
              WHERE parentid IN (
                  SELECT virtualaccountid FROM cmd.virtualaccount
                  WHERE parentid IN ('${id}')
              )
          )
      )
      OR (
          parentid IN (
              SELECT virtualaccountid FROM cmd.virtualaccount
              WHERE parentid IN ('${id}')
          )
      )
    `
      
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async returnExpectedAmountByClientId (id: string): Promise<any[]> {
    this.dbInfo.query = `SELECT sum(expectedfundingamount) as expectedamount FROM cmd.virtualaccount
        WHERE 
      (
        parentid IN ('${id}') AND (${this.notCloseStatusQuery()})
        AND virtualaccountid NOT IN (
          SELECT distinct parentid FROM cmd.virtualaccount
          where parentid IN (SELECT virtualaccountid FROM cmd.virtualaccount
          where parentid = '${id}')
          )
      )
      OR
      (
        parentid IN (SELECT virtualaccountid FROM cmd.virtualaccount
          where parentid = '${id}') AND (${this.notCloseStatusQuery()})
      )`
    return await this.dbAccess.getDataFromDB(this.dbInfo)
  }

}
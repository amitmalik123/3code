import { CSBaseDbQueries} from './cs.base-db-queries'
import {GeneralUtils} from '../../../utils/generalUtils'
import { GoalDBStructure } from '../../api/goals/v1/types'

export class CSGoalsDbQueries extends CSBaseDbQueries {
  constructor(dbName: string) {
    super(dbName)
  }

  /**
 * Method returns AccountIds that belong to a Client with appropriate amount of Accounts suitable for Goal creation for specified Advisors and Accounts are sorted by valuationdate for Market Value asc
 * @param advisors - string with the list of advisor IDs separated with ','. Example: 'C5B78A40-E22E-4E34-94C0-173605DB647D', 'a2e9e709-8313-4c4a-bee3-0de7a4954cfc-00ODFA', '2d9a8e38-68e9-4cd3-af68-261e3ec3beed'
 * @param numOfAcc - number of Accounts that Client has for Goal creation
 * @return string - Account ID as it is stored in the DB in the cmd.ovirtual_account table in the field 'virtualaccountid'. Example: '46E5DFA7-6ADF-4642-AFB9-C87DC9728C5A-000D'
 */
  public async getEarliestAccountForGoalByAdvisor (advisors: string, numOfAcc: number): Promise<string[]> {
    this.dbInfo.query = `
      SELECT virtualaccountid, valuationdate
      FROM (
          SELECT mv.virtualaccountid, mv.valuationdate,
              RANK() OVER (PARTITION BY mv.virtualaccountid ORDER BY mv.valuationdate) AS rank 
          FROM cmd.marketvalue mv
          WHERE virtualaccountid IN (
            SELECT virtual_account_id 
            FROM (
                    SELECT va.household_id, va.virtual_account_id, 
                          RANK() OVER (PARTITION BY va.household_id ORDER BY va.virtual_account_id) AS rank  
                    FROM public.virtual_account va
                    WHERE va.advisor_id IN (${advisors}) 
                          AND va.status = 'Active' AND va.goal_id IS NULL
                  ) activeacc 
            WHERE rank >= ${numOfAcc}
          )
      ) mvv
      WHERE rank = 1 
      LIMIT 20
    `
    const dbResponse = await this.dbAccess.getDataFromDB(this.dbInfo)
    const accountIdsArray: string[] = dbResponse.map(item => item.virtualaccountid)
    return accountIdsArray
  }

  /**
 * Method that returns AccountIds for specified Client
 * @param clientId - Client ID as it is stored in the DB in the cmd.organization table in the field 'organizationid'. Example: '5EEA3FE7-140F-435F-8F20-79D7BE5A0C3A-000D'
 * @param numOfAcc - number of Accounts for Goal creation
 * @param accountIds - string with the list of already existing account IDs separated with ','.
 * @return string[] - Account IDs as stored in the DB in the cmd.virtualaccount table in the field 'virtualaccountid'. Example: '8BCD0741-B245-47C4-863D-62784E4C978D-000D'
 */
  public async returnAccountsForGoalByClientId (clientId: string, numOfAcc: number, accountIds: string = ''): Promise<string[]> {
    this.dbInfo.query = `
      SELECT virtual_account_id FROM public.virtual_account
      WHERE household_id IN ('${clientId}')
      AND (${accountIds ? `virtual_account_id NOT IN (${accountIds})` : '1=1'})
      AND goal_id IS NULL
      AND (status ILIKE 'active')
      LIMIT ${numOfAcc}`
    const dbResponse = await this.dbAccess.getDataFromDB(this.dbInfo)

    const accountsIdsArray: string[] = dbResponse.map(item => item.virtual_account_id)
    return accountsIdsArray
  }

  /**
 * Method that returns Summary Market Value for specified Account as for specified Date
 * @param accountIds - string with the list of account IDs separated with ','. Example: 'BE756FBF-27DF-44AB-A587-83F47FC95D60-000D', '989AD203-2B78-41D7-9228-E3E3FEA0B9F5-000D'
 * @param asOfDate - date on which the Market Value should be calculated
 * @return number - Summary Market Value
 */
  public async returnSumMVByDateByAccounts (accountIds: string, asOfDate: Date): Promise<number> {
    const dateAsString = GeneralUtils.formatDateToHyphenString(asOfDate)
    this.dbInfo.query = `
      SELECT SUM(mv.value) AS summv
      FROM cmd.marketvalue AS mv 
      JOIN (
          SELECT virtualaccountid, MAX(valuationdate) AS maxdate 
          FROM cmd.marketvalue
          WHERE 
              virtualaccountid IN (${accountIds})
              AND valuationdate <= '${dateAsString}'
          GROUP BY virtualaccountid
      ) AS lastmv 
      ON 
          mv.virtualaccountid = lastmv.virtualaccountid 
          AND mv.valuationdate = lastmv.maxdate`
    const dbResponse = await this.dbAccess.getDataFromDB(this.dbInfo)
    return parseFloat(dbResponse[0]?.summv)
  }

  /**
 * Method that returns ClientId with specified or more accounts eligible for Goal creation for specified Advisor
 * @param advisors - string with the list of advisor IDs separated with ','. Example: 'C5B78A40-E22E-4E34-94C0-173605DB647D', 'a2e9e709-8313-4c4a-bee3-0de7a4954cfc-00ODFA', '2d9a8e38-68e9-4cd3-af68-261e3ec3beed'
 * @param numOfAcc - number of Accounts eligable for Goal creation
 * @return string - Client ID as it is stored in the DB in the cmd.organization table in the field 'organizationid'. Example: '5EEA3FE7-140F-435F-8F20-79D7BE5A0C3A-000D'
 */
  public async returnClientForGoalByAdvisorId (advisors: string, numOfAcc: number): Promise<string> {
    this.dbInfo.query = `
      SELECT virtual_account_id, household_id
      FROM (
              SELECT va.household_id, va.virtual_account_id, 
              RANK() OVER (PARTITION BY va.household_id ORDER BY va.virtual_account_id) AS rank  
              FROM public.virtual_account va
              WHERE va.advisor_id IN (${advisors}) 
              AND va.status = 'Active' AND va.goal_id IS NULL
            ) activeacc 
      WHERE rank >= ${numOfAcc}
      LIMIT 1`
    const dbResponse = await this.dbAccess.getDataFromDB(this.dbInfo)

    return dbResponse[0]?.household_id
  }

  /**
 * Method that returns Goal by goalId
 * @param goalId - goal identificator
 * @return object - Goal structure from the DB
 */
  public async returnGoalById (goalId: string): Promise<GoalDBStructure | null> {
    this.dbInfo.query = `SELECT * FROM public.goal WHERE goal_id = '${goalId}'`
    const dbResponse = await this.dbAccess.getDataFromDB(this.dbInfo)
    if (dbResponse.length==0){
      return null
    }
    const goal: GoalDBStructure = {
      goalid: dbResponse[0]?.goal_id,
      name: dbResponse[0]?.name,
      type: dbResponse[0]?.type,
      startDate: dbResponse[0]?.start_date,
      startValue: dbResponse[0]?.start_value,
      targetDate: dbResponse[0]?.target_date,
      targetValue: dbResponse[0]?.target_value,
      periodicFlow: dbResponse[0]?.periodic_flow,
      periodicity: dbResponse[0]?.periodicity,
      annualRoR: dbResponse[0]?.annual_rate_of_return,
    }
    return goal
  }

  /**
 * Method that returns GoalId for specified Account Id
 * @param accountId - string with the account ID. Example: 'BE756FBF-27DF-44AB-A587-83F47FC95D60-000D'
 * @return string or null - Id of the Goal, connected with the Account
 */
  public async returnGoalByAccountId (accountId: string): Promise<string|null> {
    this.dbInfo.query = `
      SELECT goal_id FROM public.virtual_account
      WHERE virtual_account_id = '${accountId}'`
    const dbResponse = await this.dbAccess.getDataFromDB(this.dbInfo)
    return dbResponse[0]?.goal_id
  }

  /**
 * Method that returns ClientId with at least one account eligible for Goal creation and one closed account for specified Advisor
 * @param advisors - string with the list of advisor IDs separated with ','. Example: 'C5B78A40-E22E-4E34-94C0-173605DB647D'
 * @return string - Client ID 
 */
  public async returnClientWithAccountForGoalAndClosedAccountByAdvisorId (advisors: string): Promise<string> {
    this.dbInfo.query = `
      WITH activeacc AS (
          SELECT household_id, COUNT(virtual_account_id) AS amountactive
          FROM public.virtual_account
          WHERE household_id IN (
              SELECT organizationid 
              FROM cmd.organization o
              WHERE o.parentorganizationid IN (${advisors})
          )
          AND goal_id IS NULL
          AND status ILIKE 'active'
          GROUP BY household_id
      ),
      terminated AS (
          SELECT household_id, COUNT(virtual_account_id) AS amountterminated
          FROM public.virtual_account
          WHERE household_id IN (
              SELECT organizationid 
              FROM cmd.organization o
              WHERE o.parentorganizationid IN (${advisors})
          )
          AND goal_id IS NULL
          AND (${this.closeStatusQuery()})
          GROUP BY household_id
      )
      SELECT o.organizationid, activeacc.amountactive, terminated.amountterminated  
      FROM cmd.organization o
      JOIN activeacc ON o.organizationid = activeacc.household_id
      JOIN terminated ON o.organizationid = terminated.household_id
      WHERE o.parentorganizationid IN (${advisors})
      AND activeacc.amountactive >= 1 AND terminated.amountterminated >= 1
      LIMIT 1`
    const dbResponse = await this.dbAccess.getDataFromDB(this.dbInfo)
  
    return dbResponse[0]?.organizationid
  }

}
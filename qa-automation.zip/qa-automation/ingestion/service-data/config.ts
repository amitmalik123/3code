import {BaseConfig} from '../../base/base-config'

export abstract class IngestionConfig extends BaseConfig{
  protected static PROJECT_NAME = 'ingestion'
  public static readonly API_RESPONSE_TIMEOUT:number = process.env.API_RESPONSE_TIMEOUT ?  parseInt(process.env.API_RESPONSE_TIMEOUT) * 1000 : 15 * 1000
  public static readonly INGESTION_CLIENT_ID = process.env.INGESTION_CLIENT_ID
  public static readonly INGESTION_CLIENT_SECRET = process.env.INGESTION_CLIENT_SECRET
  public static readonly INGESTION_SCOPE = process.env.INGESTION_SCOPE
  /** 
   * Waiting time between receiving the Ingestion API response and ensuring that the data was inserted in DB. The default is 5 seconds.
   */
  public static readonly DB_DATA_INSERT_WAITING_TIME:number = process.env.DB_DATA_INSERT_WAITING_TIME ?  parseInt(process.env.DB_DATA_INSERT_WAITING_TIME) * 1000 : 5 * 1000
  /** 
   * Retry count for getting data from the database. The default is 4.
   */
  public static readonly DB_DATA_INSERT_RETRIES_COUNT:number = process.env.DB_DATA_INSERT_RETRIES_COUNT ?  parseInt(process.env.DB_DATA_INSERT_RETRIES_COUNT) : 4
  /** 
   * Waiting time between receiving the Ingestion API response and receiving the webhook message from Eventpublisher. The default is waitBeforeActionInSeconds value + 2 seconds.
   */
  public static readonly WEBHOOK_DATA_RECEIVED_WAITING_TIME:number = process.env.WEBHOOK_DATA_RECEIVED_WAITING_TIME ?  parseInt(process.env.WEBHOOK_DATA_RECEIVED_WAITING_TIME) * 1000 : 2 * 1000
  /** 
   * Retry count for getting webhook message from Eventpublisher. The default is 3.
   */
  public static readonly WEBHOOK_DATA_RECEIVED_RETRIES_COUNT:number = process.env.WEBHOOK_DATA_RECEIVED_RETRIES_COUNT ?  parseInt(process.env.WEBHOOK_DATA_RECEIVED_RETRIES_COUNT) : 3
  /** 
   * Waiting time between receiving the Ingestion API response and ensuring that the data was not sent to the webhook. The default is 10 seconds.
   */
  public static readonly WEBHOOK_DATA_NOT_RECEIVED_WAITING_TIME:number = process.env.WEBHOOK_DATA_NOT_RECEIVED_WAITING_TIME ?  parseInt(process.env.WEBHOOK_DATA_NOT_RECEIVED_WAITING_TIME) * 1000 : 10 * 1000
  public static readonly TEST_MAIL = 'test1@AssetMark.com'
  // Using it for identify test data for clean up
  public static readonly E2E_TEST_ITEM_TAG = 'EWM3_E2E_TEST'
  public static readonly API_TEST_ITEM_TAG = 'EWM3_API_TEST'
}
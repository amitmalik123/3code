import {PayloadTestCase, SourceSystem} from '../../types'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import {v4 as uuid} from 'uuid'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * {
 *   "SourceID": "F45DAF7F-F99A-4C26-BA14-15B28F77E6A0",
 *   "SourceSystem": "AMK",
 *   "Name": "Jerrell Minutola",
 *   "Email": "xxxx",
 *   "Roles": [
 *     {
 *       "TargetSourceID": "ADA1ND",
 *       "TargetSourceSystem": "AMK",
 *       "TargetType": "Organization",
 *       "Permission": "Modify"
 *     },
 *     {
 *       "TargetSourceID": "ADA1NE",
 *       "TargetSourceSystem": "AMK",
 *       "TargetType": "Organization",
 *       "Permission": "Modify"
 *     },
 *     {
 *       "TargetSourceID": "AGB1W8",
 *       "TargetSourceSystem": "AMK",
 *       "TargetType": "Organization",
 *       "Permission": "Modify"
 *     }
 *   ],
 *   "UpdateTimestamp": "2023-09-12T21:24:49.09"
 * }
 * ```
 *
 * */
export interface UpsertUserBody {
    SourceID:        string
    SourceSystem:    SourceSystem
    Name:            string
    Email?:           null | string // api avro schema has that value. DB avro schema and actual DB don't have email column.
    Roles:           Role[]
    UpdateTimestamp: Date
}

interface Role {
    GroupName?: string | null
    TargetSourceID:     string
    TargetSourceSystem: SourceSystem
    TargetType:         TargetType
    Permission:         Permission
}

enum Permission {
    MODIFY = 'Modify',
    READ = 'Read'
}

enum TargetType {
  ORGANIZATION = 'Organization',
  VIRTUAL_ACCOUNT = 'VirtualAccount',
  PRODUCT_FAMILY = 'ProductFamily',
  //INVESTOR_CONTRACT = 'InvestorContact' // this value is not presented in db validation schema. Outdated?
}

// Function to generate a random instance of UpsertUserBody
export function generateUpsertUserBody(testCase: PayloadTestCase): UpsertUserBody {
  const {useAllFields, nestedItemsTestCase = {
    floatReturnType: 'number',
    useAllFields: true
  }} = testCase
  return {
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    Name: faker.person.fullName(),
    //Email: useAllFields ? faker.internet.email() : defineNullableFields ? null : undefined,
    Roles: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 5}) }, () => generateRole(nestedItemsTestCase)),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
  }
}

function generateRole(testCase: PayloadTestCase): Role {
  const {useAllFields, defineNullableFields } = testCase
  return {
    GroupName: useAllFields ? faker.company.buzzPhrase() : defineNullableFields ? null : undefined,
    TargetSourceID: uuid(),
    TargetSourceSystem: SourceSystem.QA,
    TargetType: Random.getEnumValue(TargetType),
    Permission: Random.getEnumValue(Permission)
  }
}
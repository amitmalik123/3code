import {PayloadTestCase, SourceSystem} from '../../types'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import {v4 as uuid} from 'uuid'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 {
    "SourceID": "e6214a9d-35f8-46b8-97ca-dae4bdec6ad9",
    "SourceSystem": "ewm3_QA_source_system",
    "Name": "Jody Kuhn",
    "Roles": [
      {
        "GroupName": "e-enable wireless interfaces",
        "TargetSourceID": "b74ce41a-a061-4a0e-a1f4-db6e04aa5a60",
        "TargetSourceSystem": "ewm3_QA_source_system",
        "TargetType": "VirtualAccount",
        "Permission": "Modify"
      }
    ],
    "CustomAttributes": {
      "clutch": "offensive",
      "composite": "both"
    },
    "UpdateTimestamp": "2024-07-17T13:51:37.000Z"
  }
 * ```
 *
 * */
export interface UpsertUserBody {
    SourceID:        string
    SourceSystem:    SourceSystem
    Name:            string
    Email?:           null | string // api avro schema has that value. DB avro schema and actual DB don't have email column.
    Roles:           Role[]
    CustomAttributes: { [key: string]: string }
    UpdateTimestamp: Date
}

interface Role {
    GroupName?: string | null
    TargetSourceID:     string
    TargetSourceSystem: SourceSystem
    TargetType:         TargetType
    Permission:         Permission
}

enum Permission {
    MODIFY = 'Modify',
    READ = 'Read'
}

enum TargetType {
  ORGANIZATION = 'Organization',
  VIRTUAL_ACCOUNT = 'VirtualAccount',
  PRODUCT_FAMILY = 'ProductFamily',
  //INVESTOR_CONTRACT = 'InvestorContact' // this value is not presented in db validation schema. Outdated?
}

// Function to generate a random instance of UpsertUserBody
export function generateUpsertUserBody(testCase: PayloadTestCase): UpsertUserBody {
  const {useAllFields, nestedItemsTestCase = {
    floatReturnType: 'number',
    useAllFields: true
  }} = testCase
  return {
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    Name: faker.person.fullName(),
    //Email: useAllFields ? faker.internet.email() : defineNullableFields ? null : undefined,
    Roles: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 5}) }, () => generateRole(nestedItemsTestCase)),
    CustomAttributes: Random.generateRandomKeyValuePairs(),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
  }
}

function generateRole(testCase: PayloadTestCase): Role {
  const {useAllFields, defineNullableFields } = testCase
  return {
    GroupName: useAllFields ? faker.company.buzzPhrase() : defineNullableFields ? null : undefined,
    TargetSourceID: uuid(),
    TargetSourceSystem: SourceSystem.QA,
    TargetType: Random.getEnumValue(TargetType),
    Permission: Random.getEnumValue(Permission)
  }
}
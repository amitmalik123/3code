import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'
import {v4 as uuid} from 'uuid'

/**
 *
 * **Example**
 * ```
 * [
 *   {
 *     "GroupName": "Planner",
 *     "Permissions": [
 *       "dismantle"
 *     ],
 *     "UpdateTimestamp": "2024-02-26T20:40:45.000Z"
 *   },
 *   {
 *     "GroupName": "Manager",
 *     "Permissions": [],
 *     "UpdateTimestamp": "2024-02-26T20:40:45.000Z"
 *   },
 *   {
 *     "GroupName": "Consultant",
 *     "Permissions": [
 *       "parade",
 *       "sway"
 *     ],
 *     "UpdateTimestamp": "2024-02-26T20:40:45.000Z"
 *   }
 * ]
 * ```
 *
 * */
export interface UpsertUserGroupBody {
  GroupName: string
  Permissions: string[]
  UpdateTimestamp:    Date;
}

export function generateUpsertUserGroupBody(): UpsertUserGroupBody {
  return {
    GroupName: faker.person.jobType() + '_' + uuid(),
    Permissions: Array.from({ length: Random.getNumber(3) }, faker.word.verb),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
  }
}
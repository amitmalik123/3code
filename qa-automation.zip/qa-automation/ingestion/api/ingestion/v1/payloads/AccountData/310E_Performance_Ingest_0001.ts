import {
  Currency, PayloadTestCase,
  SourceSystem,
} from '../../types'
import {v4 as uuid} from 'uuid'
import {Random} from '../../../../../../utils/random'
import {faker} from '@faker-js/faker'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
  [
    {
      "SourceID": "48a88dff-c81e-4687-a001-482cb0828c6c",
      "SourceSystem": "ewm3_QA_source_system",
      "UpdateTimestamp": "2024-03-22T13:28:07.000Z",
      "PerformanceStrings": [
        {
          "StartDate": "2023-07-02T03:52:59.000Z",
          "EndDate": "2024-03-04T03:15:19.000Z",
          "StartMarketValue": "2390520.985536",
          "EndMarketValue": "-9247775.885303",
          "Currency": "USD",
          "GrossOfFeesPerformance": "856473.3624158520",
          "NetOfFeesPerformance": "-352649.6555143381",
          "Fees": "105522.539159",
          "Contributions": "-37789.471394",
          "StartAccruedValue": "-7073340.868117",
          "EndAccruedValue": "-6382345.845644"
        }
      ]
    }
  ]
 * ```
 *
 * */
export interface PerformanceIngestBody {
  SourceID: string
  SourceSystem: SourceSystem
  UpdateTimestamp: Date
  PerformanceStrings: PerformanceString[]
}

interface PerformanceString {
  StartDate: Date | string
  EndDate: Date | string
  StartMarketValue: string | number
  EndMarketValue: string | number
  Currency: Currency
  GrossOfFeesPerformance: string | number
  NetOfFeesPerformance: string | number
  Fees: string | number
  Contributions: string | number
  StartAccruedValue?: null | string | number
  EndAccruedValue?: null | string | number
}

export function generatePerformanceIngestBody(testCase: PayloadTestCase): PerformanceIngestBody {
  const {useAllFields, nestedItemsTestCase = {
    floatReturnType: 'number',
    useAllFields: true
  }} = testCase
  return {
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
    PerformanceStrings: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 5}) }, () => generatePerformanceString(nestedItemsTestCase))
  }
}

function generatePerformanceString(testCase: PayloadTestCase): PerformanceString {
  const {useAllFields, defineNullableFields, numberTestCase, floatReturnType: numberReturnType } = testCase
  return {
    StartDate: DateFormatters.removeMilliseconds(DateFormatters.setTimeTo0(faker.date.past())),
    EndDate: DateFormatters.removeMilliseconds(DateFormatters.setTimeTo0(faker.date.past())),
    StartMarketValue: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    EndMarketValue: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    Currency: Random.getEnumValue(Currency),
    GrossOfFeesPerformance: Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: numberReturnType}),
    NetOfFeesPerformance: Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: numberReturnType}),
    Fees: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    Contributions: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    StartAccruedValue: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    EndAccruedValue: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined
  }
}


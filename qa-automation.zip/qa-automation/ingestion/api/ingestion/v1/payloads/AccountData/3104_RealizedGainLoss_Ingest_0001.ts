import {Currency, PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * [
 *   {
 *     "SourceSystem": "ewm3_QA_source_system",
 *     "SourceID": "af76bb7d-6d4d-473b-8feb-4f289c16d369",
 *     "UpdateTimestamp": "2024-02-26T20:30:02.000Z",
 *     "RealizedGainsLosses": [
 *       {
 *         "Type": "Multi-Asset Securities",
 *         "PurchaseDate": "2023-10-12T21:00:00.000Z",
 *         "CostBasis": "6299711.750000",
 *         "Proceeds": "9106437.210000",
 *         "Currency": "USD",
 *         "Gain": "-2536281.080000",
 *         "Term": "Unknown",
 *         "Description": "Reactive responsive frame",
 *         "Ticker": "YNOE",
 *         "Cusip": null,
 *         "Units": "75100.154487"
 *       }
 *     ]
 *   }
 * ]
 * ```
 *
 * */
export interface IngestRealizedGainLossBody {
  SourceID: string // The unique ID (within the SourceSystem) of the account/sleeve/etc. providing this data
  SourceSystem: SourceSystem // The system providing the data
  UpdateTimestamp: Date // Timestamp of realized gain/loss update
  RealizedGainsLosses: RealizedGainLossItem[] // Zero or more realized gains/losses
}

export interface RealizedGainLossItem {
  Type: string // Type of holding (cash, equity, etc.)
  PurchaseDate?: Date | null // Date of purchase (null if not known)
  CostBasis?: string | number | null // Cost of asset (null if not known)
  Proceeds?: string | number | null // Proceeds from asset sale (null if not known)
  Currency: Currency // USD for dollars; other values TBD
  Gain?: string | number | null // Gain (positive) or loss (negative); null if not known
  Term: GainLossTerm // short or long
  Description: string // Description of the holding
  Ticker?: string | null // Ticker
  Cusip?: string | null // Cusip
  Units?: string | number | null // Units sold/disposed (null if not known or n/a)
  CustomAttributes: { [key: string]: string } // Additional source-specific fields associated with the realized gain/loss
}

export enum GainLossTerm {
  SHORT = 'Short',
  LONG = 'Long',
  UNKNOWN = 'Unknown'
}

export function generateIngestRealizedGainLossBody(testCase: PayloadTestCase): IngestRealizedGainLossBody {
  const {useAllFields, nestedItemsTestCase = {
    floatReturnType: 'number',
    useAllFields: true
  }} = testCase
  return {
    SourceSystem: SourceSystem.QA,
    SourceID: uuid(),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
    RealizedGainsLosses: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 5}) }, () => generateRealizedGainLossItem(nestedItemsTestCase)),
  }
}

function generateRealizedGainLossItem(testCase: PayloadTestCase): RealizedGainLossItem {
  const {useAllFields, defineNullableFields, numberTestCase, floatReturnType: numberReturnType } = testCase
  return {
    Type: faker.word.adjective(),
    PurchaseDate: useAllFields ? DateFormatters.setTimeTo0(faker.date.past()) : defineNullableFields ? null : undefined,
    CostBasis: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    Proceeds: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    Currency: Random.getEnumValue(Currency),
    Gain: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    Term: Random.getEnumValue(GainLossTerm),
    Description: faker.company.catchPhrase(),
    Ticker: useAllFields ? Random.getString(4).toUpperCase() : defineNullableFields ? null : undefined,
    Cusip: useAllFields ? Random.getAlphanumericString(9).toUpperCase() : defineNullableFields ? null : undefined,
    Units: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    CustomAttributes: Random.generateRandomKeyValuePairs()
  }
}
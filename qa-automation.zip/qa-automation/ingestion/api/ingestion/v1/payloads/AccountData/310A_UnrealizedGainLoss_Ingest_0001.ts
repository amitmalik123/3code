import {Currency, PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'
import {GainLossTerm} from './3104_RealizedGainLoss_Ingest_0001'

/**
 *
 * **Example**
 * ```
 * [
 *   {
 *     "SourceSystem": "ewm3_QA_source_system",
 *     "SourceID": "e9aba309-b3a3-4cc0-92ce-9539191081ed",
 *     "UpdateTimestamp": "2024-02-26T20:39:09.000Z",
 *     "UnrealizedGainsLosses": [
 *       {
 *         "Type": "Cash",
 *         "AcquisitionDate": null,
 *         "CostBasis": "-6596815.590000",
 *         "Gain": "-9702190.750000",
 *         "Currency": "USD",
 *         "Term": "Long",
 *         "Description": "Re-engineered maximized utilisation",
 *         "Ticker": "VRGK",
 *         "Cusip": "4OBXAKPUE",
 *         "Units": "730286.579915"
 *       }
 *     ]
 *   }
 * ]
 * ```
 *
 * */
export interface IngestUnrealizedGainLossBody {
  SourceID: string
  SourceSystem: SourceSystem
  UpdateTimestamp: Date
  UnrealizedGainsLosses: UnrealizedGainLoss[]
}

interface UnrealizedGainLoss {
  Type: string
  AcquisitionDate?: Date | null
  CostBasis?: string | number | null
  Gain?: string | number | null
  Currency: string
  Term: GainLossTerm
  Description: string
  Ticker?: string | null
  Cusip?: string | null
  Units?: string | number | null
  CustomAttributes: { [key: string]: string }
}

export function generateIngestUnrealizedGainLossBody(testCase: PayloadTestCase): IngestUnrealizedGainLossBody {
  const {useAllFields, nestedItemsTestCase = {
    floatReturnType: 'number',
    useAllFields: true
  }} = testCase
  return {
    SourceSystem: SourceSystem.QA,
    SourceID: uuid(),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
    UnrealizedGainsLosses: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 5}) }, () => generateUnrealizedGainLossItem(nestedItemsTestCase)),
  }
}

function generateUnrealizedGainLossItem(testCase: PayloadTestCase): UnrealizedGainLoss {
  const {useAllFields, defineNullableFields, numberTestCase, floatReturnType: numberReturnType } = testCase
  return {
    Type: faker.word.adjective(),
    AcquisitionDate: useAllFields ? DateFormatters.setTimeTo0(faker.date.past()) : defineNullableFields ? null : undefined,
    CostBasis: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    Gain: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    Currency: Random.getEnumValue(Currency),
    Term: Random.getEnumValue(GainLossTerm),
    Description: faker.company.catchPhrase(),
    Ticker: useAllFields ? Random.getString(4).toUpperCase() : defineNullableFields ? null : undefined,
    Cusip: useAllFields ? Random.getAlphanumericString(9).toUpperCase() : defineNullableFields ? null : undefined,
    Units: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    CustomAttributes: Random.generateRandomKeyValuePairs()
  }
}
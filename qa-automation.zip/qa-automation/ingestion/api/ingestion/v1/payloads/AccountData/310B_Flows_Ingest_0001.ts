import {Currency, PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 *  {
 *     "SourceID": "AC8BA4",
 *     "SourceSystem": "AMK",
 *     "Inflows": 0,
 *     "Outflows": -1900,
 *     "Fees": 0,
 *     "Currency": "USD",
 *     "FlowDate": "2015-06-24T00:00:00",
 *     "FlowDetails": [
 *       {
 *         "Type": "Outflow",
 *         "SubType": "W",
 *         "Amount": -1900
 *       }
 *     ],
 *     "UpdateTimestamp": "2023-09-04T14:09:38.07"
 *   }
 * ```
 *
 * */
export interface UpsertFlowsBody {
    SourceID:        string
    SourceSystem:    SourceSystem
    Inflows:         string | number
    Outflows:        string | number
    Fees:            string | number
    Currency:        Currency
    FlowDate:        Date
    FlowDetails?:     FlowDetail[] | null
    UpdateTimestamp: Date
}

interface FlowDetail {
    Type:    FlowType
    SubType?: string | null
    Amount:  string | number
}

enum FlowType {
    OUT_FLOW = 'Outflow',
    IN_FLOW = 'Inflow',
    FEE = 'Fee'
}

// Function to generate a random instance of generateUpsertFlowsBody
export function generateUpsertFlowsBody(testCase: PayloadTestCase): UpsertFlowsBody {
  const {useAllFields, defineNullableFields, numberTestCase, floatReturnType: numberReturnType, 
    nestedItemsTestCase = {
      floatReturnType: 'number',
      useAllFields: true
    }} = testCase
  
  return {
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    Inflows: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    Outflows: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    Fees: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    Currency: Random.getEnumValue(Currency),
    FlowDate: DateFormatters.setTimeTo0(faker.date.past()),
    FlowDetails: useAllFields ? Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 5}) }, () => generateFlowDetail(nestedItemsTestCase)) : defineNullableFields ? [] : undefined,
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()), //as of now time is not passing to DB
  }
}

function generateFlowDetail(testCase: PayloadTestCase): FlowDetail {
  const {useAllFields, defineNullableFields, numberTestCase, intReturnType} = testCase
  return {
    Type: Random.getEnumValue(FlowType),
    SubType: useAllFields ? faker.string.alpha().toUpperCase() : defineNullableFields ? null : undefined,
    Amount: Random.generateInt({testCase: numberTestCase, returnType: intReturnType}),
  }
}
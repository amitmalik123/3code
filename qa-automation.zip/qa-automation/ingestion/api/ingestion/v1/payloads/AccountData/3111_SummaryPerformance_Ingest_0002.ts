import {PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 *   {
 *   "TargetType": "Organization",
 *   "TargetSourceID": "C01772",
 *   "TargetSourceSystem": "AMK",
 *   "AsOfDate": "2023-07-28T00:00:00",
 *   "UpdateTimestamp": "2023-07-31T14:00:35.76",
 *   "SIPerformance": 4.8500,
 *   "YTDPerformance": 13.8000,
 *   "MTDPerformance": 2.8000,
 *   "OneYearPerformance": 10.5200,
 *   "TwoYearPerformance": -5.9200,
 *   "ThreeYearPerformance": 5.1000,
 *   "FiveYearPerformance": 2.9400,
 *   "TenYearPerformance": 3.6000,
 *   "NetInvestment": -24215.0300
 *   }
 * ```
 *
 * */
export interface UpsertSummaryPerformanceBody {
    TargetType:           TargetType
    TargetSourceID:       string
    TargetSourceSystem:   SourceSystem
    AsOfDate:             Date
    InceptionDate?:       Date | null
    UpdateTimestamp:      Date
    SIPerformance?:       string | number | null
    YTDPerformance?:      string | number | null
    MTDPerformance?:      string | number | null
    OneYearPerformance?:  string | number | null
    TwoYearPerformance?:  string | number | null
    ThreeYearPerformance?:string | number | null
    FiveYearPerformance?: string | number | null
    TenYearPerformance?:  string | number | null
    NetInvestment:        string | number
}

enum TargetType {
  ORGANIZATION = 'Organization',
  VIRTUAL_ACCOUNT = 'VirtualAccount',
  ACCOUNT_GROUP = 'AccountGroup'
}

// Function to generate a random instance of UpsertSummaryPerformanceBody
export function generateUpsertSummaryPerformanceBody(testCase: PayloadTestCase): UpsertSummaryPerformanceBody {
  const {useAllFields, defineNullableFields, numberTestCase, floatReturnType: numberReturnType } = testCase
  return {
    TargetType: Random.getEnumValue(TargetType),
    TargetSourceID: uuid(),
    TargetSourceSystem: SourceSystem.QA,
    AsOfDate: DateFormatters.setTimeTo0(faker.date.past()),
    InceptionDate: useAllFields ? DateFormatters.setTimeTo0(faker.date.past()) : defineNullableFields ? null : undefined,
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
    SIPerformance: useAllFields ? Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    YTDPerformance: useAllFields ? Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    MTDPerformance: useAllFields ? Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    OneYearPerformance: useAllFields ? Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    TwoYearPerformance: useAllFields ? Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    ThreeYearPerformance: useAllFields ? Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    FiveYearPerformance: useAllFields ? Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    TenYearPerformance: useAllFields ? Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    NetInvestment: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
  }
}
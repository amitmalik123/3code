import {PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * [
 *   {
 *     "SourceSystem": "ewm3_QA_source_system",
 *     "SourceID": "e9aba309-b3a3-4cc0-92ce-9539191081ed",
 *     "UpdateTimestamp": "2024-02-26T20:39:09.000Z",
 *     "UnrealizedGainsLosses": [
 *       {
 *         "Type": "Cash",
 *         "AcquisitionDate": null,
 *         "CostBasis": "-6596815.590000",
 *         "Gain": "-9702190.750000",
 *         "Currency": "USD",
 *         "Term": "Long",
 *         "Description": "Re-engineered maximized utilisation",
 *         "Ticker": "VRGK",
 *         "Cusip": "4OBXAKPUE",
 *         "Units": "730286.579915"
 *       }
 *     ]
 *   }
 * ]
 * ```
 *
 * */
export interface IngestNonfinancialDataBody {
  SourceID: string;
  SourceSystem: SourceSystem;
  UpdateTimestamp: Date; // Timestamp represented as milliseconds
  InterestedParties: InterestedParty[];
  BanksOfRecord: BankOfRecord[];
  AddressesOfRecord: AddressOfRecord[];
  SystematicTransactions: SystematicTransaction[];
  Tags: string[];
  CustomAttributes?: { [key: string]: string };
}
interface InterestedParty {
  Type: InterestedPartyType
  Name: string
  Address: string
  Allocation?: number | string | null // Allocation (for beneficiaries); 0 - 100
}
enum InterestedPartyType{
  PRIMARY = 'Primary',
  TRUSTEE = 'Trustee',
  JOINT = 'Joint',
  BENEFICIARY = 'Beneficiary',
  TRUSTOR = 'Trustor',
  GRANTOR = 'Grantor',
  MINOR = 'Minor'
}

interface BankOfRecord {
  Type: BankType
  Name: string
  Address: string
}

enum BankType{
  TBD = 'TBD'
}

interface AddressOfRecord {
  Type: AddressType
  Name: string
  Address: string
}

enum AddressType{
  TBD = 'TBD'
}

interface SystematicTransaction {
  Type: SystematicTransactionType
  Name: string
  Address: string
}

enum SystematicTransactionType{
  TBD = 'TBD'
}

export function generateIngestNonfinancialDataBody(testCase: PayloadTestCase): IngestNonfinancialDataBody {
  const { useAllFields, nestedItemsTestCase = {
    floatReturnType: 'number',
    useAllFields: true
  }} = testCase
  return {
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
    InterestedParties: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 5}) }, () => generateInterestedParty(nestedItemsTestCase)),
    BanksOfRecord: Array.from({ length: Random.getNumber(5) }, generateBanksOfRecord),
    AddressesOfRecord: Array.from({ length: Random.getNumber(5) }, generateAddressesOfRecord),
    SystematicTransactions: Array.from({ length: Random.getNumber(5) }, generateSystematicTransactions),
    Tags: Array.from({ length: Random.getNumber(3) }, faker.company.buzzNoun)
  }
}

function generateInterestedParty(testCase: PayloadTestCase) : InterestedParty {
  const {useAllFields, defineNullableFields, numberTestCase, intReturnType } = testCase
  return{
    Type: Random.getEnumValue(InterestedPartyType),
    Name: faker.company.name(),
    Address: faker.location.city() + ', ' + faker.location.streetAddress(),
    Allocation: useAllFields ? Random.generateInt({testCase: numberTestCase, returnType: intReturnType}) : defineNullableFields ? null : undefined,
  }
}

function generateBanksOfRecord() : BankOfRecord {
  return{
    Type: Random.getEnumValue(BankType),
    Name: faker.company.name(),
    Address: faker.location.city() + ', ' + faker.location.streetAddress(),
  }
}

function generateAddressesOfRecord() : AddressOfRecord {
  return{
    Type: Random.getEnumValue(AddressType),
    Name: faker.company.name(),
    Address: faker.location.city() + ', ' + faker.location.streetAddress(),
  }
}

function generateSystematicTransactions() : SystematicTransaction {
  return{
    Type: Random.getEnumValue(SystematicTransactionType),
    Name: faker.finance.transactionDescription(),
    Address: faker.location.city() + ', ' + faker.location.streetAddress(),
  }
}
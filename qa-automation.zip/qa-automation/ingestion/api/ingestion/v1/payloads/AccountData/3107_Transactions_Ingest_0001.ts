import {Currency, PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * [
 *   {
 *     "SourceSystem": "ewm3_QA_source_system",
 *     "SourceID": "b5727982-28b0-4287-9b03-debe6867c760",
 *     "Transactions": [
 *       {
 *         "Type": "Deposit",
 *         "Date": "2023-05-11T21:00:00.000Z",
 *         "Amount": "-7163736.890000",
 *         "Currency": "USD",
 *         "Description": "Customer-focused bifurcated instruction set",
 *         "SettlementDate": "2023-03-25T21:00:00.000Z",
 *         "Ticker": "FFIN",
 *         "Cusip": "XPTBVJZTB",
 *         "Units": "97028.687425",
 *         "SourceTransactionCode": null,
 *         "Proceeds": "274738.204434"
 *       }
 *     ]
 *   }
 * ]
 * ```
 *
 * */
export interface IngestTransactionsBody {
  SourceSystem: SourceSystem
  SourceID: string
  Transactions: Transaction[]
  //UpdateTimestamp: Date
}

interface Transaction {
  Type: TransactionType
  Date: Date // Date represented as UNIX timestamp
  Amount: string | number // Decimal representation
  Currency: Currency
  Description: string
  SettlementDate?: Date | null // Date represented as UNIX timestamp
  Ticker?: string | null
  Cusip?: string | null
  Units?: string | number // Decimal representation
  SourceTransactionCode?: string | null
  Proceeds?: string | number | null // Decimal representation
  CustomAttributes?: { [key: string]: string }
}

enum TransactionType {
  BUY = 'Buy',
  SELL = 'Sell',
  DELIVER = 'Deliver',
  RECEIVE = 'Receive',
  FEE = 'Fee',
  CAPITAL_GAIN_DISTRIBUTION = 'CapitalGainDistribution',
  RECEIPT_OF_CAPITAL = 'ReceiptOfCapital',
  DEPOSIT = 'Deposit',
  WITHDRAWAL = 'Withdrawal',
  OTHER = 'Other'

}
export function generateIngestTransactionsBody(testCase: PayloadTestCase): IngestTransactionsBody {
  const {useAllFields, nestedItemsTestCase = {
    floatReturnType: 'number',
    useAllFields: true
  }} = testCase
  return {
    SourceSystem: SourceSystem.QA,
    SourceID: uuid(),
    Transactions: Array.from({length: faker.number.int({min: useAllFields ? 1 : 0, max: 5})}, () => generateTransaction(nestedItemsTestCase)),
  }
}

function generateTransaction(testCase: PayloadTestCase): Transaction {
  const {useAllFields, defineNullableFields, numberTestCase, floatReturnType: numberReturnType } = testCase
  return {
    Type: Random.getEnumValue(TransactionType),
    Date: DateFormatters.setTimeTo0(faker.date.past()),
    Amount: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    Currency: Random.getEnumValue(Currency),
    Description: faker.company.catchPhrase(),
    SettlementDate: useAllFields ? DateFormatters.setTimeTo0(faker.date.past()) : defineNullableFields ? null : undefined,
    Ticker: useAllFields ? Random.getString(4).toUpperCase() : defineNullableFields ? null : undefined,
    Cusip: useAllFields ? Random.getAlphanumericString(9).toUpperCase() : defineNullableFields ? null : undefined,
    Units: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    SourceTransactionCode: useAllFields ? Random.getAlphanumericString(9).toUpperCase() : defineNullableFields ? null : undefined,
    Proceeds: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
  }
}
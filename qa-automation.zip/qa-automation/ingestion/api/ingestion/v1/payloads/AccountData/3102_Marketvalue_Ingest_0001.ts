import {Currency, PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * {
 *   "VirtualAccountID": "9E447B9B-5D30-4DAA-B61C-36D2E2CAF69D-000D",
 *   "SourceID": "3DZ|3DZ_VTIVX",
 *   "SourceSystem": "SFDC-AMRS",
 *   "Value": 1521.16,
 *   "Currency": "USD",
 *   "ValuationDate": "2020-03-31T00:00:00Z",
 *   "UpdateTimestamp": "2023-09-12T11:49:12Z"
 * }
 * ```
 *
 * */
export interface UpsertMarketValueBody {
    SourceID:         string
    SourceSystem:     SourceSystem
    Value:            string | number
    Currency:         Currency
    ValuationDate:    Date
    UpdateTimestamp:  Date
}

// Function to generate a random instance of UpsertMarketValueBody
export function generateUpsertMarketValueBody(testCase: PayloadTestCase): UpsertMarketValueBody {
  const {numberTestCase, floatReturnType: numberReturnType} = testCase
  return {
    SourceID:         uuid(),
    SourceSystem:     SourceSystem.QA,
    Value:            Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    Currency:         Random.getEnumValue(Currency),
    ValuationDate:    DateFormatters.setTimeTo0(faker.date.past()),
    UpdateTimestamp:  DateFormatters.setMillsTo0(new Date()),
  }
}
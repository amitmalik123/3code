import {PayloadTestCase, SourceSystem} from '../../types'
import {faker} from '@faker-js/faker'
import {v4 as uuid} from 'uuid'
import {Random} from '../../../../../../utils/random'
import {SourceAccount} from './310D_SourceAccount_Ingest_0002'
import {DateFormatters} from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * {
 *   "SourceID": "AI0UT6",
 *   "SourceSystem": "AMK",
 *   "ParentID": "CA6HA4",
 *   "ParentType": "Organization",
 *   "Name": "Dante Sherrick Tenants in Common",
 *   "Tags": [
 *     "Funding Met"
 *   ],
 *   "CustomAttributes": {
 *     "Custodian": "PRS",
 *     "accountType": "Corporate",
 *     "OpenDate": "20140221",
 *     "FundedDate": "20160108",
 *     "TerminationDate": "99999999"
 *   },
 *   "Restrictions": [],
 *   "Status": "Active",
 *   "LineOfBusiness": "Managed Assets",
 *   "TransactionMode": "VirtualAccount",
 *   "HoldingsMode": "VirtualAccount",
 *   "PerformanceMode": "VirtualAccount",
 *   "FlowsMode": "VirtualAccount",
 *   "MarketValuesMode": "VirtualAccount",
 *   "CustodialDataMode": "Exclusive",
 *   "AnalyticsDataSets": [],
 *   "SourceAccounts": [
 *     {
 *       "SourceSystem": "PRS",
 *       "SourceID": "BDC27D778"
 *     }
 *   ],
 *   "ProductSourceID": "NFESA3",
 *   "ProductSourceSystem": "AMK",
 *   "PlatformStartDate": "2014-02-21T00:00:00",
 *   "PlatformEndDate": null,
 *   "UpdateTimestamp": "2023-08-01T14:39:20.363"
 * }
 * ```
 *
 * */
export interface UpsertVirtualAccountBody {
  SourceID:            string;
  SourceSystem:        SourceSystem;
  ParentID?:            string;
  ParentType:          ParentType;
  Name:                string;
  Tags:                string[];
  CustomAttributes: { [key: string]: string }
  Restrictions:        string[];
  Status?:              AccountStatus | null;
  LineOfBusiness:      string;
  TransactionMode:     TransactionMode;
  HoldingsMode:        HoldingsMode;
  PerformanceMode:     PerformanceMode;
  FlowsMode:           FlowsMode;
  MarketValuesMode:    MarketValuesMode;
  CustodialDataMode:   CustodialDataMode;
  AnalyticsDataSets:   string[];
  SourceAccounts:      SourceAccount[];
  ProductSourceID?:     string | null;
  ProductSourceSystem?: SourceSystem | null;
  PlatformStartDate:   Date;
  PlatformEndDate?:     null | Date;
  ExpectedFundingAmount?: null | string | number
  ContainingVirtualAccountSourceSystem?: null | string
  ContainingVirtualAccountSourceID?: null | string
  StandingAllocation?: null | string | number
  Features?: null | { [key: string]: string }
  UpdateTimestamp:     Date;
}

export enum AccountStatus {
  PROPOSED = 'Proposed',
  PENDING = 'Pending',
  ACTIVE = 'Active'
}

enum ParentType {
  ORGANIZATION = 'Organization', 
  VIRTUAL_ACCOUNT = 'VirtualAccount'
}

 enum CustodialDataMode {
  EXCLUSIVE = 'Exclusive',
   POOLED = 'Pooled'
}

enum TransactionMode {
  VIRTUAL_ACCOUNT = 'VirtualAccount',
  CHILD_VIRTUAL_ACCOUNTS = 'ChildVirtualAccounts',
  SOURCE_ACCOUNTS_EXCLUSIVE = 'SourceAccountsExclusive',
  SOURCE_ACCOUNTS_POOLED = 'SourceAccountsPooled'
}

enum HoldingsMode {
  VIRTUAL_ACCOUNT = 'VirtualAccount',
  CHILD_VIRTUAL_ACCOUNTS = 'ChildVirtualAccounts',
  //SOURCE_ACCOUNTS = 'SourceAccounts'
}

enum PerformanceMode {
  VIRTUAL_ACCOUNT = 'VirtualAccount',
  CHILD_VIRTUAL_ACCOUNTS = 'ChildVirtualAccounts',
  // SourceAccounts and Computed not supported now
  // SOURCE_ACCOUNTS = 'SourceAccounts',
  // COMPUTED = 'Computed',
  NONE = 'None'
}

enum FlowsMode {
  VIRTUAL_ACCOUNT = 'VirtualAccount',
  CHILD_VIRTUAL_ACCOUNTS = 'ChildVirtualAccounts',
  //SOURCE_ACCOUNTS = 'SourceAccounts',
  //FROM_PERFORMANCE = 'FromPerformance',
  //FROM_TRANSACTIONS = 'FromTransactions', FromTransaction not supported now
  NONE = 'None'
}

enum MarketValuesMode {
  VIRTUAL_ACCOUNT = 'VirtualAccount',
  CHILD_VIRTUAL_ACCOUNTS = 'ChildVirtualAccounts',
  // SOURCE_ACCOUNTS = 'SourceAccounts',
  // FROM_PERFORMANCE = 'FromPerformance',
  // FROM_HOLDINGS = 'FromHoldings',
  // NONE = 'None'
}

// Function to generate a random instance of UpsertVirtualAccountBody
export function generateUpsertVirtualAccountBody(testCase: PayloadTestCase): UpsertVirtualAccountBody {
  const {useAllFields, defineNullableFields, numberTestCase, floatReturnType: numberReturnType } = testCase
  return {
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    ParentID: uuid(),
    ParentType: Random.getEnumValue(ParentType),
    Name: `${faker.person.fullName()} ${faker.word.adjective()}`,
    Tags: Array.from({ length: Random.getNumber(3) }, faker.company.buzzNoun),
    CustomAttributes: Random.generateRandomKeyValuePairs(),
    Restrictions: Array.from({ length: Random.getNumber(3) }, faker.word.verb),
    Status: useAllFields ? Random.getEnumValue(AccountStatus) : defineNullableFields ? null : undefined,
    LineOfBusiness: faker.company.buzzAdjective(),
    TransactionMode: Random.getEnumValue(TransactionMode),
    HoldingsMode: Random.getEnumValue(HoldingsMode),
    PerformanceMode: Random.getEnumValue(PerformanceMode),
    FlowsMode: Random.getEnumValue(FlowsMode),
    MarketValuesMode: Random.getEnumValue(MarketValuesMode),
    CustodialDataMode: Random.getEnumValue(CustodialDataMode),
    AnalyticsDataSets: Array.from({ length: Random.getNumber(3) }, faker.company.catchPhrase),
    SourceAccounts: Array.from({ length: Random.getNumber(3) }, generateSourceAccount),
    ProductSourceID: useAllFields ? uuid() : defineNullableFields ? null : undefined,
    ProductSourceSystem: useAllFields ?SourceSystem.QA : defineNullableFields ? null : undefined,
    PlatformStartDate: DateFormatters.setTimeTo0(faker.date.past()),
    PlatformEndDate: useAllFields ? DateFormatters.setTimeTo0(faker.date.past()) : defineNullableFields ? null : undefined,
    ExpectedFundingAmount: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    ContainingVirtualAccountSourceSystem: useAllFields ? SourceSystem.QA : defineNullableFields ? null : undefined,
    ContainingVirtualAccountSourceID: useAllFields ? uuid() : defineNullableFields ? null : undefined,
    StandingAllocation: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType})  : defineNullableFields ? null : undefined,
    Features: useAllFields ? Random.generateRandomKeyValuePairs() : defineNullableFields ? null : undefined,
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
  }
}

function generateSourceAccount(): SourceAccount {
  return {
    SourceSystem: Random.getString(3).toUpperCase(),
    SourceID: uuid()
  }
}
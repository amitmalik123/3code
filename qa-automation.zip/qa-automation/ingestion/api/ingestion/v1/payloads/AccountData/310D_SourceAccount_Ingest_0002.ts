import {
  PayloadTestCase,
  SourceSystem,
} from '../../types'
import {v4 as uuid} from 'uuid'
import {Random} from '../../../../../../utils/random'
import {faker} from '@faker-js/faker'
import { DateFormatters } from '../../../../../../utils/date-farmatters'
import {AccountStatus} from './310F_VirtualAccount_Upsert_0005'

/**
 *
 * **Example**
 * ```
 * {
 *   "SourceID": "Z6WLET",
 *   "SourceSystem": "AMK",
 *   "Name": "Daryl Sanker Corporate",
 *   "Tags": [
 *     ""
 *   ],
 *   "CustomAttributes": {
 *     "Custodian": "GNW",
 *     "accountType": "Corporate",
 *     "OpenDate": "20190425",
 *     "TerminationDate": "20190506"
 *   },
 *   "UpdateTimestamp": "2023-06-12T00:00:00"
 * }
 * ```
 *
 * */
export interface UpsertSourceAccountBody {
  SourceID:            string;
  SourceSystem:         SourceSystem;
  Type:                SourceAccountType;
  SubType:             string;
  Bank?:                null | string;
  BankAccountNumber?:   null | string;
  Status?:              AccountStatus | null;
  Name:                 string;
  Features?: null | {[key: string]: string}
  Tags:                 string[];
  CustomAttributes: {[key: string]: string}
  UpdateTimestamp:      Date;
  BankType?:            null | BankType;
}

export interface SourceAccount {
    SourceSystem: string;
    SourceID:     string;
}

enum SourceAccountType {
    CUSTODIAL = 'custodial',
    BANK = 'bank',
    CHECKING = 'checking'
}

enum SourceAccountSubtype {
    SOLE_PROPRIETOR = 'Sole Proprietor',
    INDIVIDUAL_IRA = 'Individual-IRA',
    _401K = '401k',
    _403B = '403b'
}

enum BankType {
    CUSTODIAN = 'Custodian',
    BANK = 'Bank',
    PLAN_SPONSOR = 'PlanSponsor',
    AGGREGATOR = 'Aggregator',
    OTHER = 'Other'
}

// Function to generate a random instance of UpsertSourceAccountBody
export function generateUpsertSourceAccountBody(testCase: PayloadTestCase): UpsertSourceAccountBody {
  const {useAllFields, defineNullableFields } = testCase
  return {
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    Type: Random.getEnumValue(SourceAccountType),
    SubType: Random.getEnumValue(SourceAccountSubtype),
    Bank: useAllFields ? faker.company.name() : defineNullableFields ? null : undefined,
    BankAccountNumber: useAllFields ? faker.finance.accountNumber() : defineNullableFields ? null : undefined,
    BankType: useAllFields ? Random.getEnumValue(BankType) : defineNullableFields ? null : undefined,
    Status: useAllFields ? Random.getEnumValue(AccountStatus) : defineNullableFields ? null : undefined,
    Features: useAllFields ? Random.generateRandomKeyValuePairs() : defineNullableFields ? null : undefined,
    Name: `${faker.person.fullName()} ${faker.word.adjective()}`,
    Tags: Array.from({ length: Random.getNumber(3) }, faker.company.buzzNoun),
    CustomAttributes: Random.generateRandomKeyValuePairs(),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
  }
}


import {Currency, PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * {
 *   "SourceId": "A06690",
 *   "SourceSystem": "AMK",
 *   "Holdings": [
 *     {
 *       "Type": "Multi-Asset Securities",
 *       "ValuationDate": "2023-07-31",
 *       "Value": 49.87,
 *       "SourceAccountID": "123",
 *       "Currency": "USD",
 *       "Description": "DIMENSIONAL U.S. EQUITY ETF",
 *       "Ticker": "DFUS",
 *       "Cusip": "25434V401",
 *       "Units": 759,
 *       "CustomAttributes": {
 *         "AssetClass": "Multi-Asset Securities",
 *         "SubAssetClass": "Multi-Asset Securities"
 *       }
 *     }
 *   ],
 *   "UpdateTimestamp": "2023-08-02 09:16:42.857"
 * }
 * ```
 *
 * */
export interface UpsertHoldingsBody {
    SourceID:        string;
    SourceSystem:    SourceSystem;
    Holdings:        Holding[];
    UpdateTimestamp: Date;
}

interface Holding {
    Type:             string
    ValuationDate:    string
    Value:            number | string
    SourceID?:         null | string
    SourceSystem?:     null | SourceSystem
    Currency:         Currency
    Description:      string
    Ticker?:           null | string
    Cusip?:            null | string
    Units:            number | string
    AssetClassWeights: AssetClassWeight[]
    Tags: string[]
    CustomAttributes: {[key: string]: string}
}

interface AssetClassWeight {
  Weight: string | number
  AssetClass: string[]
}

// Function to generate a random instance of UpsertHoldingsBody
export function generateUpsertHoldingsBody(testCase: PayloadTestCase): UpsertHoldingsBody {
  const {useAllFields, nestedItemsTestCase = {
    floatReturnType: 'number',
    useAllFields: true
  }} = testCase
  return {
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    Holdings: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 5}) }, () => generateHolding(nestedItemsTestCase)),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
  }
}

function generateHolding(testCase: PayloadTestCase): Holding {
  const {useAllFields, defineNullableFields, numberTestCase, floatReturnType: numberReturnType } = testCase
  return {
    Type: faker.word.adjective(),
    ValuationDate: DateFormatters.removeMilliseconds(DateFormatters.setTimeTo0(faker.date.past())),
    Value: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    SourceID: useAllFields ? uuid() : defineNullableFields ? null : undefined,
    SourceSystem: useAllFields ? SourceSystem.QA : defineNullableFields ? null : undefined,
    Currency: Random.getEnumValue(Currency),
    Description: faker.company.name(),
    Ticker: useAllFields ? Random.getString(4).toUpperCase() : defineNullableFields ? null : undefined,
    Cusip: useAllFields ? Random.getAlphanumericString(9).toUpperCase() : defineNullableFields ? null : undefined,
    Units: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    AssetClassWeights:  Array.from({ length: Random.getNumber(3) }, () => generateAssetClassWeight(testCase)),
    Tags: Array.from({ length: Random.getNumber(3) }, faker.word.noun),
    CustomAttributes: Random.generateRandomKeyValuePairs(),
  }
}

function generateAssetClassWeight(testCase: PayloadTestCase): AssetClassWeight {
  const {numberTestCase, floatReturnType} = testCase
  return {
    Weight: Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: floatReturnType}),
    AssetClass: Array.from({ length: Random.getNumber(3) }, faker.company.buzzNoun)
  }
}
import {PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {Random} from '../../../../../../utils/random'
import {faker} from '@faker-js/faker'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
  [
    {
      "SourceID": "c298987c-fbef-4c1e-aa32-f456ebb51f4e",
      "SourceSystem": "ewm3_QA_source_system",
      "ParentSourceSystem": "ewm3_QA_source_system_parent",
      "ParentSourceID": "f3583842-8827-42a1-acb2-501b9606805d",
      "ParentType": "Organization",
      "Name": "century",
      "Tags": ["lala"],
      "CustomAttributes": {
        "lumber": "dim",
        "colony": "cheery",
        "slip": "precious",
        "drapes": "trusting"
      },
      "Alternatives": [
        {
          "Name": "aid",
          "Portfolio": [
            {
              "ProductSourceID": "ewm3_QA_source_system_product",
              "ProductSourceSystem": "8c1db739-261c-44f6-bf25-c90b853478b1",
              "Name": "Multi-tiered well-modulated paradigm",
              "Amount": 4976222.967433
            }
          ]
        }
      ],
      "CreatedDate": "2023-08-12T00:00:00.000Z",
      "UpdateTimestamp": "2024-03-27T15:13:12.000Z"
    }
  ]
 * ```
 *
 * */
export interface ProposalUpsertBody {
  SourceID: string
  SourceSystem: SourceSystem
  ParentSourceSystem: string
  ParentSourceID: string
  ParentType: ParentType
  Name: string
  Tags: string[]
  CustomAttributes: { [key: string]: string }
  Alternatives: Alternative[]
  CreatedDate: Date
  UpdateTimestamp: Date
}

enum ParentType{
  ORGANIZATION = 'Organization',
  VIRTUAL_ACCOUNT = 'VirtualAccount'
}

interface Alternative {
  Name: string
  Portfolio: Investments[]
}

interface Investments {
  ProductSourceID: string
  ProductSourceSystem: string
  Name?: string | null
  Amount: number | string
}

export function generateProposalUpsertBody(testCase: PayloadTestCase): ProposalUpsertBody {
  const {useAllFields, nestedItemsTestCase = {
    floatReturnType: 'number',
    useAllFields: true
  }} = testCase
  return {
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    ParentSourceSystem: SourceSystem.QA+'_parent',
    ParentSourceID: uuid(),
    ParentType: Random.getEnumValue(ParentType),
    Name: faker.word.noun(),
    Tags: Array.from({ length: Random.getNumber(3) }, faker.word.adjective),
    CustomAttributes: Random.generateRandomKeyValuePairs(),
    Alternatives: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 3}) }, () => generateAlternative(nestedItemsTestCase)),
    CreatedDate: DateFormatters.setTimeTo0(faker.date.past()),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date())
  }
}

function generateAlternative(testCase: PayloadTestCase): Alternative {
  const {useAllFields} = testCase
  return {
    Name: faker.word.verb(),
    Portfolio: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 3}) }, () => generateInvestments(testCase)),
  }
}

function generateInvestments(testCase: PayloadTestCase): Investments {
  const {useAllFields, defineNullableFields, numberTestCase, floatReturnType: numberReturnType } = testCase
  return {
    ProductSourceID: SourceSystem.QA+'_product',
    ProductSourceSystem: uuid(),
    Name: useAllFields? faker.company.catchPhrase() : defineNullableFields ? null : undefined,
    Amount: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType})
  }
}


import {PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * {
 *     "SourceSystem": "AMK",
 *     "SourceID": "5418770",
 *     "ParentSourceID": "5418763",
 *     "UserItemID": "B048283452",
 *     "ItemType": "New Account Application",
 *     "Description": "New Account Application",
 *     "ExternalLink": null,
 *     "Status": "Completed",
 *     "StatusLabel": "Complete",
 *     "Associations": [
 *       {
 *         "Type": "Organization",
 *         "SourceID": "AGAR1C",
 *         "SourceSystem": "AMK",
 *         "ExternalLink": null
 *       },
 *       {
 *         "Type": "Organization",
 *         "SourceID": "CB4HN2",
 *         "SourceSystem": "AMK",
 *         "ExternalLink": null
 *       }
 *     ],
 *     "Notes": [
 *       {
 *         "Author": "tw_admin",
 *         "CreatedDateTime": "0001-01-01T00:00:00",
 *         "Message": "NoteId: 33321153 Containing potential PII data has been redacted"
 *       },
 *       {
 *         "Author": "tw_admin",
 *         "CreatedDateTime": "0001-01-01T00:00:00",
 *         "Message": "NoteId: 33321154 Containing potential PII data has been redacted"
 *       },
 *       {
 *         "Author": "tw_admin",
 *         "CreatedDateTime": "0001-01-01T00:00:00",
 *         "Message": "NoteId: 33321157 Containing potential PII data has been redacted"
 *       },
 *       {
 *         "Author": "Sarah.Pearlberg",
 *         "CreatedDateTime": "0001-01-01T00:00:00",
 *         "Message": "NoteId: 33324801 Containing potential PII data has been redacted"
 *       },
 *       {
 *         "Author": "Pramod.Tripathi",
 *         "CreatedDateTime": "0001-01-01T00:00:00",
 *         "Message": "NoteId: 33371290 Containing potential PII data has been redacted"
 *       },
 *       {
 *         "Author": "Pramod.Tripathi",
 *         "CreatedDateTime": "0001-01-01T00:00:00",
 *         "Message": "NoteId: 33371291 Containing potential PII data has been redacted"
 *       }
 *     ],
 *     "NextActions": [],
 *     "Attachments": [],
 *     "CloseTimestamp": "2019-04-09T10:01:00",
 *     "CreatedTimestamp": "2019-04-05T14:35:06",
 *     "UpdateTimestamp": "2023-08-17T16:10:00.387"
 *   }
 * ```
 *
 * */
export interface UpsertWorkItemBody {
    SourceSystem:     SourceSystem
    SourceID:         string
    ParentSourceID:   string
    UserItemID:       string
    ItemType:         string
    Description:      string
    ExternalLink?:    null | string
    Status:           WorkItemStatus
    StatusLabel?:     WorkItemStatusLabels | null
    Associations:     Association[]
    Notes:            Note[]
    NextActions:      NextAction[]
    Attachments:      Attachment[]
    CloseTimestamp?:  Date | null
    CreatedTimestamp: Date
    UpdateTimestamp:  Date
}

interface Association {
    Type:         AssociationType
    SourceID:     string
    SourceSystem: SourceSystem
    ExternalLink?: null | string
}

interface Note {
    Author:          string
    CreatedDateTime: string
    Message:         string
}

interface NextAction {
  ActionID: string
  Type: NextActionType
  Label: string
  FileType: string
}

interface Attachment {
  AttachmentID: string
  Description: string
  FileType: string
  Link: string
}

enum ItemType{
    NEW_ACCOUNT_APPLICATION = 'New Account Application'
}

enum AssociationType {
  ORGANIZATION = 'Organization',
  USER = 'User',
  VIRTUAL_ACCOUNT = 'VirtualAccount',
  SOURCE_ACCOUNT = 'SourceAccount',
  OTHER = 'Other'
}

enum WorkItemStatus {
  NEW = 'New',
  IN_PROGRESS = 'InProcess',
  AWAITING_ACTION = 'AwaitingAction',
  COMPLETED = 'Completed',
  CANCELLED = 'Cancelled'
}

enum WorkItemStatusLabels {
  NEW = 'New',
  IN_PROGRESS = 'In Process',
  AWAITING_ACTION = 'Awaiting Action',
  COMPLETED = 'Completed',
  CANCELLED = 'Cancelled'
}

enum NextActionType {
  BUTTON = 'Button',
  POST_RESPONSE = 'PostResponse',
  UPLOAD_DOCUMENT = 'UploadDocument'
}

// Function to generate a random instance of UpsertWorkItemBody
export function generateUpsertWorkItemBody(testCase: PayloadTestCase): UpsertWorkItemBody {
  const {useAllFields, defineNullableFields, 
    nestedItemsTestCase = {
      floatReturnType: 'number',
      useAllFields: true
    }} = testCase
  return {
    SourceSystem: SourceSystem.QA,
    SourceID: uuid(),
    ParentSourceID: uuid(),
    UserItemID: uuid(),
    ItemType: Random.getEnumValue(ItemType),
    Description: Random.getEnumValue(ItemType),
    ExternalLink: useAllFields ? faker.internet.url() : defineNullableFields ? null : undefined,
    Status: Random.getEnumValue(WorkItemStatus),
    StatusLabel: useAllFields ? Random.getEnumValue(WorkItemStatusLabels) : defineNullableFields ? null : undefined,
    Associations: Array.from({ length: Random.getNumber(3) }, () => generateAssociation(nestedItemsTestCase)),
    Notes: Array.from({ length: Random.getNumber(3) }, generateNote),
    NextActions: Array.from({ length: Random.getNumber(3) }, generateNextAction),
    Attachments: Array.from({ length: Random.getNumber(3) }, generateAttachment),
    CloseTimestamp: useAllFields ? DateFormatters.setMillsTo0(faker.date.past()) : defineNullableFields ? null : undefined,
    CreatedTimestamp: DateFormatters.setMillsTo0(faker.date.past()),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
  }
}

function generateAssociation(testCase: PayloadTestCase): Association {
  const {useAllFields, defineNullableFields} = testCase
  return {
    Type: Random.getEnumValue(AssociationType),
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    ExternalLink: useAllFields ? faker.internet.url() : defineNullableFields ? null : undefined
  }
}

function generateNote(): Note {
  return {
    Author: faker.internet.userName(),
    CreatedDateTime: DateFormatters.removeMilliseconds(faker.date.past()),
    Message: `NoteId: ${Random.getNumber(99999999)} ${faker.company.buzzPhrase()}`
  }
}

function generateNextAction(): NextAction {
  return {
    ActionID: uuid(),
    Type: Random.getEnumValue(NextActionType),
    Label: faker.internet.url(),
    FileType: faker.system.fileType()
  }
}

function generateAttachment(): Attachment {
  return {
    AttachmentID: uuid(),
    Description: faker.system.fileName(),
    FileType: faker.system.fileType(),
    Link: `${faker.internet.url()}/${uuid()}`
  }
}
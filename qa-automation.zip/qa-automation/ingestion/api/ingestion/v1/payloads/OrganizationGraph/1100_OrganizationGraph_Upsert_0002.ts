import {PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * {
 *   "OrganizationID": "7D32FC47-CEFF-41CB-ACDC-858FAB0BF474-000D",
 *   "ParentOrganizationID": null,
 *   "Ancestors": [],
 *   "Name": "Libby Wadlington",
 *   "PrimaryUserID": null,
 *   "Type": "AdvisorRepCode",
 *   "Subtype": null,
 *   "Tags": [],
 *   "CustomAttributes": {
 *     "isFeeAdmin": "true",
 *     "RequiresQuestionnaire": "0"
 *   },
 *   "SourceID": "AGACID",
 *   "SourceSystem": "AMK",
 *   "Contacts": [],
 *   "PlatformStartDate": "1970-01-01T00:00:00Z",
 *   "PlatformEndDate": null,
 *   "UpdateTimestamp": "2023-09-12T21:25:47Z"
 * }
 * ```
 *
 * */
export interface UpsertOrganizationBody {
  SourceID:             string;
  SourceSystem:         SourceSystem;
  ParentSourceID?:      string | null;
  Name:                 string;
  Type:                 OrganizationType;
  Subtype?:             string | null;
  Tags:                 string[];
  CustomAttributes:     CustomAttributes;
  PlatformStartDate:    Date;
  PlatformEndDate?:     Date | null;
  Contacts:             Contact[];
  UpdateTimestamp:      Date;
}

interface Contact {
  Type: string
  SourceSystem: string
  SourceID: string
}

interface CustomAttributes {
    isFeeAdmin:            string;
    RequiresQuestionnaire: string;
}

export enum OrganizationType {
  OSJ = 'OSJ',
  BROKER_DEALER = 'BrokerDealer',
  ADVISOR_REP_CODE = 'AdvisorRepCode',
  CLIENT_HOUSEHOLD = 'ClientHousehold',
  BRANCH_OFFICE = 'BranchOffice',
  FIRM = 'Firm',
  ASSET_MANAGER = 'AssetManager',
  RIA = 'RIA',
  TENANT_ROOT = 'TenantRoot',
  BROKER_DEALER_NETWORK = 'BrokerDealerNetwork',
  OTHER = 'Other'
}

// Function to generate a random instance of UpsertOrganizationBody
export function generateUpsertOrganizationBody(testCase: PayloadTestCase): UpsertOrganizationBody {
  const {useAllFields, defineNullableFields} = testCase
  return {
    SourceID:             uuid(),
    SourceSystem:         SourceSystem.QA,
    ParentSourceID:       uuid(),
    Name:                 faker.person.fullName(),
    Type:                 Random.getEnumValue(OrganizationType),
    Subtype:              useAllFields? faker.company.buzzAdjective() : defineNullableFields ? null : undefined,
    Tags:                 Array.from({ length: Random.getNumber(3) }, faker.word.adjective),
    CustomAttributes:     generateCustomAttributes(),
    Contacts:             Array.from({ length: Random.getNumber(3) }, generateContact),
    PlatformStartDate:    DateFormatters.setTimeTo0(faker.date.past()),
    PlatformEndDate:      useAllFields? DateFormatters.setTimeTo0(faker.date.past()): defineNullableFields ? null : undefined,
    UpdateTimestamp:      DateFormatters.setMillsTo0(new Date()),
  }
}

function generateContact(): Contact {
  return {
    Type: faker.word.noun(),
    SourceSystem: SourceSystem.QA,
    SourceID: uuid()
  }
}

function generateCustomAttributes(): CustomAttributes {
  return {
    isFeeAdmin: `${faker.datatype.boolean()}`,
    RequiresQuestionnaire: `${Random.getNumber(1)}`
  }
}
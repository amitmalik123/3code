import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import {DateFormatters} from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * ...
 * ```
 *
 * */
export interface IngestProductChangeActionBody {
  ActionID: string
  RequiredProductFeatures: string[]
  ProductPayloadName: string
  ProductPayloadValue: string
  SameProductRestriction: SameProductRestrictionType
  Tags: string[]
  CustomAttributes: {[key: string]: string}
  UpdateTimestamp: Date
}

enum SameProductRestrictionType{
  ALLOW = 'Allow',
  BLOCK_SELF = 'BlockSelf',
  BLOCK_SELF_AND_SIBLINGS = 'BlockSelfAndSiblings'
}

export function generateIngestProductChangeActionBody(): IngestProductChangeActionBody {
  return {
    ActionID: uuid(),
    RequiredProductFeatures: Array.from({ length: Random.getNumber(2) }, faker.word.noun),
    ProductPayloadName: faker.commerce.productName(),
    ProductPayloadValue: faker.commerce.productDescription(),
    SameProductRestriction: Random.getEnumValue(SameProductRestrictionType),
    Tags: Array.from({length: Random.getNumber(2)}, faker.word.adjective),
    CustomAttributes: Random.generateRandomKeyValuePairs(),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date())
  }
}

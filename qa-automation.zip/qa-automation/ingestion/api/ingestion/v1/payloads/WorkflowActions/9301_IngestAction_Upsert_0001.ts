import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import {DateFormatters} from '../../../../../../utils/date-farmatters'
import {PayloadTestCase} from '../../types'

/**
 *
 * **Example**
 * ```
 * ...
 * ```
 *
 * */
export interface IngestActionBody {
  ActionID: string
  ActionType: ActionType
  NavigationPath: string[]
  Name: string
  Description?: null | string
  Uri: string
  HttpMethod: string
  PayloadValues: {[key: string]: string}
  Availability: ActionTypeAvailability
  SupportsBulk: boolean
  IsDefaultAction: boolean
  Roles: string[]
  Tags: string[]
  CustomAttributes: {[key: string]: string}
  UpdateTimestamp: Date
}

enum ActionType{
  BASE = 'Base',
  FORM = 'Form',
  PRODUCT_CHANGE = 'ProductChange'
}

enum ActionTypeAvailability{
  ENABLED = 'Enabled',
  TEMPORARILY_UNAVAILABLE = 'TemporarilyUnavailable',
  DELETED = 'Deleted'
}

export function generateIngestActionBody(testCase: PayloadTestCase): IngestActionBody {
  const {useAllFields, defineNullableFields} = testCase
  return {
    ActionID: uuid(),
    ActionType: Random.getEnumValue(ActionType),
    NavigationPath: Array.from({ length: Random.getNumber(2) }, faker.word.noun),
    Name: faker.word.verb(),
    Description:  useAllFields ? faker.company.buzzPhrase() : defineNullableFields ? null : undefined,
    Uri: faker.internet.url(),
    HttpMethod: faker.internet.httpMethod(),
    PayloadValues: Random.generateRandomKeyValuePairs(),
    Availability: Random.getEnumValue(ActionTypeAvailability),
    SupportsBulk: faker.datatype.boolean(),
    IsDefaultAction: faker.datatype.boolean(),
    Roles: Array.from({length: Random.getNumber(2)}, faker.word.adverb),
    Tags: Array.from({length: Random.getNumber(2)}, faker.word.adjective),
    CustomAttributes: Random.generateRandomKeyValuePairs(),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date())
  }
}

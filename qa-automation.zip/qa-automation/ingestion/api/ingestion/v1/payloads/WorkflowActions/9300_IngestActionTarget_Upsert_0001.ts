import {PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import {DateFormatters} from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
[
  {
    "ActionID": null,
    "RequiredProductFeatures": [],
    "ProductPayloadName": "Tasty Plastic Cheese",
    "ProductPayloadValue": "New ABC 13 9370, 13.3, 5th Gen CoreA5-8250U, 8GB RAM, 256GB SSD, power UHD Graphics, OS 10 Home, OS Office A & J 2016",
    "SameProductRestriction": "Allow",
    "Tags": [
      "bland"
    ],
    "CustomAttributes": {
      "box": "jumbo",
      "dude": "those",
      "cave": "foolhardy"
    },
    "UpdateTimestamp": "2024-05-07T11:36:49.000Z"
  }
]
 * ```
 *
 * */
export interface IngestActionTargetBody {
  ActionID: string
  TargetSourceID: string
  TargetSourceSystem: SourceSystem
  TargetType: ActionTargetType
  PayloadValues: {[key: string]: string}
  Availability: ActionStatus
  Notices: Notice[]
  RequiredProductFeatures?: null | string[]
  RequiresSuitabilityCheck?: null | boolean
  MarketValueSource: MarketValueSourceType
  UseStandingAllocation: boolean
  Tags: string[]
  CustomAttributes: {[key: string]: string}
  UpdateTimestamp: Date
}

enum ActionTargetType{
  ORGANIZATION = 'Organization',
  VIRTUAL_ACCOUNT = 'VirtualAccount',
  SOURCE_ACCOUNT = 'SourceAccount'
}

enum ActionStatus{
  ENABLED = 'Enabled',
  TEMPORARILY_UNAVAILABLE = 'TemporarilyUnavailable',
  IN_PROGRESS = 'InProcess',
  DELETED = 'Deleted'
}

interface Notice {
  Message: string
  Type: NoticeType
  MustConfirm: boolean
}

enum NoticeType{
  INFORMATION = 'Information',
  WARNING = 'Warning',
  ERROR = 'Error'
}

enum MarketValueSourceType{
  ACTUAL = 'Actual',
  EXPECTED_FUNDING = 'ExpectedFunding'
}

export function generateIngestActionTargetBody(testCase: PayloadTestCase): IngestActionTargetBody {
  const {useAllFields, defineNullableFields} = testCase
  return {
    ActionID: uuid(),
    TargetSourceID: uuid(),
    TargetSourceSystem: SourceSystem.QA,
    TargetType: Random.getEnumValue(ActionTargetType),
    PayloadValues: Random.generateRandomKeyValuePairs(),
    Availability: Random.getEnumValue(ActionStatus),
    Notices: Array.from({length: Random.getNumber(5)}, generateNoticeItem),
    RequiredProductFeatures: useAllFields ? Array.from({length: Random.getNumber(2)}, faker.company.catchPhraseNoun) : defineNullableFields ? null : undefined,
    RequiresSuitabilityCheck: useAllFields ? faker.datatype.boolean() : defineNullableFields ? null : undefined,
    MarketValueSource: Random.getEnumValue(MarketValueSourceType),
    UseStandingAllocation: faker.datatype.boolean(),
    Tags: Array.from({length: Random.getNumber(2)}, faker.word.adjective),
    CustomAttributes: Random.generateRandomKeyValuePairs(),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date())
  }
}

function generateNoticeItem(): Notice {
  return {
    Message: faker.company.buzzPhrase(),
    Type: Random.getEnumValue(NoticeType),
    MustConfirm: faker.datatype.boolean()
  }
}
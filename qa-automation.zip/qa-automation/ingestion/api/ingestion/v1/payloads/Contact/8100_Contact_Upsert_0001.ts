import {PayloadTestCase, SourceSystem} from '../../types'
import {faker} from '@faker-js/faker'
import {v4 as uuid} from 'uuid'
import {Random} from '../../../../../../utils/random'
import {DateFormatters} from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * [
 *   {
 *     "SourceID": "13a00922-b7fb-4a9a-ad89-24f77b17eaa3",
 *     "SourceSystem": "ewm3_QA_source_system",
 *     "FamilyName": "Ritchie",
 *     "GivenNames": "Demario",
 *     "PreferredName": "Ralph Schneider",
 *     "Email": "Aimee75@hotmail.com",
 *     "Phone": "513.528.5189 x139",
 *     "Company": "Beier - Padberg",
 *     "Address": [
 *       "678 Stoltenberg Lights"
 *     ],
 *     "Tags": [
 *       "thorny",
 *       "live"
 *     ],
 *     "CustomAttributes": {
 *       "codon": "striking"
 *     },
 *     "UpdateTimestamp": "2024-04-30T12:49:49.000Z"
 *   }
 * ]
 * ```
 *
 * */
export interface ContactBody {
  SourceID: string; // The unique ID of this contact in the external source (CRM) system. Can be null for nodes not linked to an external source.
  SourceSystem: SourceSystem; // The ID of the external system if this node was imported. This will normally be set by the CRM sync mechanism.
  FamilyName: string; // Family or last name for the contact.
  GivenNames: string; // First/middle/etc. name(s) for the contact.
  PreferredName?: string | null; // What the contact prefers to be called (e.g. for an email, banner, etc.)
  Email?: string | null; // Contact's email address.
  Phone?: string | null; // Contact's phone number.
  Company?: string | null; // Contact's company.
  Address: string[]; // Address line(s).
  // City?: string | null; // City
  // StateOrProvince?: string | null; // State/province
  // Postal?: string | null; // Postal/zip code
  // Country?: string | null; // Country code (use std. ISO codes)
  Tags: string[]; // String tags associated with this contact. Canonical list/domain TBD
  CustomAttributes: { [key: string]: string }; // Additional fields associated with the contact
  UpdateTimestamp: Date; // Timestamp that org update is effective
}

export function generateContactBody(testCase: PayloadTestCase): ContactBody {
  const {useAllFields, defineNullableFields} = testCase
  return {
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    FamilyName: faker.person.lastName(),
    GivenNames: faker.person.firstName(),
    PreferredName: useAllFields ? faker.person.fullName() : defineNullableFields ? null : undefined,
    Email: useAllFields ? faker.internet.email() : defineNullableFields ? null : undefined,
    Phone: useAllFields ? faker.phone.number() : defineNullableFields ? null : undefined,
    Company: useAllFields ? faker.company.name() : defineNullableFields ? null : undefined,
    Address: Array.from({ length: Random.getNumber(3) }, faker.location.streetAddress),
    // City: useAllFields ? faker.location.city() : defineNullableFields ? null : undefined,
    // StateOrProvince: useAllFields ? faker.location.state() : defineNullableFields ? null : undefined,
    // Postal: useAllFields ? faker.location.zipCode() : defineNullableFields ? null : undefined,
    // Country: useAllFields ? faker.location.countryCode() : defineNullableFields ? null : undefined,
    Tags: Array.from({ length: Random.getNumber(3) }, faker.word.adjective),
    CustomAttributes: Random.generateRandomKeyValuePairs(),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date())
  }
}
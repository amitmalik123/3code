import {SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 *  {
 *     "SourceID": "BAYEQ",
 *     "SourceSystem": "AMK",
 *     "Name": "Brown Advisory",
 *     "Tags": [],
 *     "UpdateTimestamp": "2023-08-22T07:38:22.777"
 *   }
 * ```
 *
 * */
export interface UpsertInvestmentManagerBody {
    SourceID:        string;
    SourceSystem:    SourceSystem;
    Name:            string;
    Tags:            string[];
    UpdateTimestamp: Date;
}

// Function to generate a random instance of UpsertInvestmentManagerBody
export function generateUpsertInvestmentManagerBody(): UpsertInvestmentManagerBody {
  return {
    SourceID:        uuid(),
    SourceSystem:    SourceSystem.QA,
    Name:            faker.person.fullName(),
    Tags:            Array.from({ length: faker.number.int({min: 0, max: 3}) }, faker.company.buzzAdjective),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
  }
}
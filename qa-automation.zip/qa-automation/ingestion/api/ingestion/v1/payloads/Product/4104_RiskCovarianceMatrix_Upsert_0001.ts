import {faker} from '@faker-js/faker'
import { DateFormatters } from '../../../../../../utils/date-farmatters'
import {PayloadTestCase} from '../../types'
import {Random} from '../../../../../../utils/random'
import {v4 as uuid} from 'uuid'

/**
 *
 * **Example**
 * ```
[
  {
    "RiskCovarianceMatrixID": "0c794f1f-bbfc-4f67-914a-399debda085b",
    "CovarianceMatrix": [
      {
        "RowGroup": -2122698751,
        "ColumnGroup": 103647128,
        "Covariance": 3480965034104.535
      }
    ],
    "ProfileStandardDeviations": [
      {
        "Profile": 1431704066,
        "AnnualStandardDeviation": 59.083066
      }
    ],
    "UpdateTimestamp": "2024-05-07T10:23:28.000Z"
  }
]
 * ```
 *
 * */
export interface RiskCovarianceMatrixBody {
  RiskCovarianceMatrixID: string
  CovarianceMatrix: CovarianceValue[]
  ProfileStandardDeviations: ProfileStandardDeviation[]
  UpdateTimestamp: Date
}

interface CovarianceValue {
  RowGroup: number | string
  ColumnGroup: number | string
  Covariance: number | string
}

interface ProfileStandardDeviation {
  Profile: number | string,
  AnnualStandardDeviation: number | string
}

export function generateRiskCovarianceMatrixBody(testCase: PayloadTestCase): RiskCovarianceMatrixBody {
  const {useAllFields, nestedItemsTestCase = {
    floatReturnType: 'number',
    useAllFields: true
  }} = testCase
  return {
    RiskCovarianceMatrixID: uuid(),
    CovarianceMatrix: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 5}) }, () => generateCovarianceValueItem(nestedItemsTestCase)),
    ProfileStandardDeviations: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 5}) }, () => generateProfileStandardDeviationItem(nestedItemsTestCase)),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date())
  }
}

function generateCovarianceValueItem(testCase: PayloadTestCase): CovarianceValue {
  const {numberTestCase, floatReturnType, intReturnType} = testCase
  return {
    RowGroup: Random.generateInt({testCase: numberTestCase, returnType: intReturnType}),
    ColumnGroup: Random.generateInt({testCase: numberTestCase, returnType: intReturnType}),
    Covariance: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: floatReturnType})
  }
}

function generateProfileStandardDeviationItem(testCase: PayloadTestCase): ProfileStandardDeviation {
  const {numberTestCase, floatReturnType, intReturnType} = testCase
  return {
    Profile: Random.generateInt({testCase: numberTestCase, returnType: intReturnType}),
    AnnualStandardDeviation: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: floatReturnType})
  }
}
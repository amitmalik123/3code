import {SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * ...
 * ```
 *
 * */
export interface ProductAvailabilityBody {
  ProductGroups: string[]
  TargetSourceID: string
  TargetSourceSystem: SourceSystem
  TargetType: ActionTargetType
  Tags: string[]
  CustomAttributes: {[key: string]: string}
  UpdateTimestamp: Date
}

enum ActionTargetType{
  ORGANIZATION = 'Organization',
  // Following items are commented in message contract
  // VIRTUAL_ACCOUNT = 'VirtualAccount',
  // SOURCE_ACCOUNT = 'SourceAccount'
}

export function generateProductAvailabilityBody(): ProductAvailabilityBody {
  return {
    ProductGroups: Array.from({ length: Random.getNumber(2) }, faker.word.noun),
    TargetSourceID: uuid(),
    TargetSourceSystem: SourceSystem.QA,
    TargetType: Random.getEnumValue(ActionTargetType),
    Tags: Array.from({length: Random.getNumber(2)}, faker.word.adjective),
    CustomAttributes: Random.generateRandomKeyValuePairs(),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date())}
}
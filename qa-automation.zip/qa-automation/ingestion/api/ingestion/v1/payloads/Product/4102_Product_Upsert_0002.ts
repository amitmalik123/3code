import {Currency, PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {Random} from '../../../../../../utils/random'
import { faker} from '@faker-js/faker'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * {
 *   "SourceID": "SELMA3",
 *   "SourceSystem": "AMK",
 *   "Name": "GPS Select Multi-Asset Income, Profile 3, Moderate",
 *   "Profile": 3,
 *   "InvestmentManagerSourceID": "GFWM",
 *   "InvestmentManagerSourceSystem": "AMK",
 *   "ProductFamilySourceID": "GFWM",
 *   "ProductFamilySourceSystem": "AMK",
 *   "AllocationSets": [
 *     {
 *       "Name": "Investment Approach",
 *       "Allocations": [
 *         {
 *           "Name": "Core",
 *           "Weight": 85,
 *           "ID": null
 *         },
 *         {
 *           "Name": "Tactical Enhanced",
 *           "Weight": 0,
 *           "ID": null
 *         },
 *         {
 *           "Name": "Tactical Limit",
 *           "Weight": 15,
 *           "ID": null
 *         },
 *         {
 *           "Name": "Diversifying Equity",
 *           "Weight": 0,
 *           "ID": null
 *         },
 *         {
 *           "Name": "Diversifing Bonds",
 *           "Weight": 0,
 *           "ID": null
 *         },
 *         {
 *           "Name": "Additional Investments",
 *           "Weight": 0,
 *           "ID": null
 *         }
 *       ]
 *     }
 *   ],
 *   "Tags": [
 *     "MULTI"
 *   ],
 *   "CustomAttributes": {
 *     "overlay_model_code": "SELMA3",
 *     "overlay_program_code": "N ",
 *     "overlay_strategist_code": "GFWM"
 *   },
 *   "UpdateTimestamp": "2023-09-01T16:20:19.7"
 * }
 * ```
 *
 * */
export interface UpsertProductBody {
  SourceID:                      string
  SourceSystem:                  SourceSystem
  Name:                          string
  NavigationPath: string[]
  Profile?:                       null | number | string
  RiskCovarianceGroup?: null | number | string
  //AnnualStandardDeviation?: null | number | string
  InvestmentManagerSourceID?:     null | string
  InvestmentManagerSourceSystem?: null | SourceSystem
  ProductFamilySourceID?:         null | string
  ProductFamilySourceSystem?:     null | SourceSystem
  AllocationSets:                AllocationSet[]
  Groups: string[]
  //FeeGroup: string
  EnforcedInvestmentMinimum?: null | number | string
  DefaultFee?: null | number | string
  Features?: null | {[key: string]: string}
  DisplayInvestmentMinimum?: null | number | string
  RequiresSuitabilityCheck?: null | boolean
  Currency: Currency
  Tags:                          string[]
  CustomAttributes: {[key: string]: string}
  UpdateTimestamp:               Date;
}

export interface AllocationSet {
    Name:        AllocationSetName
    Allocations: Allocation[]
}

export interface Allocation {
    Name:   AllocationName
    Weight: number
    ID?:     string | null
}

export enum AllocationName {
    AdditionalInvestments = 'Additional Investments',
    Core = 'Core',
    DiversifyingBonds = 'Diversifying Bonds',
    DiversifyingEquity = 'Diversifying Equity',
    TacticalEnhanced = 'Tactical Enhanced',
    TacticalLimit = 'Tactical Limit',
}

export enum Tags {
    MULTI = 'MULTI',
    ETF = 'ETF',
    MF = 'MF',
    TAX_MANAGED = 'Tax Managed',
    ODMS = 'ODMS',
    CMSGP = 'CMSGP',
    GMS = 'GMS',
    IMA = 'IMA'
}

export enum AllocationSetName {
  HOLDING = 'Holding',
  ASSET_CLASS = 'Asset class',
  INVESTMENT_APPROACH = 'Investment Approach',
  STRATEGY = 'Strategy'
}

// Function to generate a random instance of UpsertProductBody
export function generateUpsertProductBody(testCase: PayloadTestCase): UpsertProductBody {
  const {useAllFields, defineNullableFields, numberTestCase, floatReturnType, intReturnType, 
    nestedItemsTestCase = {
      floatReturnType: 'number',
      useAllFields: true
    }} = testCase
  return {
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    Name: `${faker.person.lastName()} ${faker.word.adjective()} ${Random.getEnumValue(Tags)} ${Random.getEnumValue(AllocationName)}`,
    NavigationPath: Array.from({ length: Random.getNumber(2) }, faker.word.noun),
    Profile: useAllFields ? Random.generateInt({testCase: numberTestCase, returnType: intReturnType}) : defineNullableFields ? null : undefined,
    RiskCovarianceGroup: useAllFields ? Random.generateInt({testCase: numberTestCase, returnType: intReturnType}) : defineNullableFields ? null : undefined,
    //AnnualStandardDeviation: useAllFields ? Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    InvestmentManagerSourceID: useAllFields ? uuid() : defineNullableFields ? null : undefined,
    InvestmentManagerSourceSystem: useAllFields ? SourceSystem.QA : defineNullableFields ? null : undefined,
    ProductFamilySourceID: useAllFields ? uuid() : defineNullableFields ? null : undefined,
    ProductFamilySourceSystem: useAllFields ? SourceSystem.QA : defineNullableFields ? null : undefined,
    AllocationSets: Array.from({ length: Random.getNumber(2) }, () => generateAllocationSet(nestedItemsTestCase)),
    Groups: Array.from({ length: Random.getNumber(2) }, faker.word.noun),
    //FeeGroup: faker.company.buzzNoun(),
    EnforcedInvestmentMinimum: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: floatReturnType}) : defineNullableFields ? null : undefined,
    DefaultFee: useAllFields ? Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: floatReturnType}) : defineNullableFields ? null : undefined,
    Features: useAllFields ? Random.generateRandomKeyValuePairs() : defineNullableFields ? null : undefined,
    DisplayInvestmentMinimum: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: floatReturnType}) : defineNullableFields ? null : undefined,
    RequiresSuitabilityCheck:  useAllFields ? faker.datatype.boolean() : defineNullableFields ? null : undefined,
    Currency: Random.getEnumValue(Currency),
    Tags: Array.from({ length: Random.getNumber(2) }, generateTags),
    CustomAttributes: Random.generateRandomKeyValuePairs(),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
  }
}

function generateAllocationSet(testCase: PayloadTestCase): AllocationSet {
  const {useAllFields, defineNullableFields} = testCase
  const allocationNameArray : AllocationName[] = Object.values(AllocationName)
  const weightArray : number[] = Random.generateNumberArray(allocationNameArray.length, 100)
  const allocationArray : Allocation[] = []
  for (let i = 0; i < allocationNameArray.length; i++) {
    allocationArray.push(
      {
        Name:   allocationNameArray[i],
        Weight: weightArray[i],
        ID:     useAllFields? uuid() : defineNullableFields ? null : undefined
      }
    )
  }
  return {
    Name: Random.getEnumValue(AllocationSetName),
    Allocations: allocationArray
  }
}

function generateTags(): Tags {
  return Random.getEnumValue(Tags)
}
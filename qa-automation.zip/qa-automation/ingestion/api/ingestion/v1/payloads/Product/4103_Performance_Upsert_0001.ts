import {Currency, PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * [
 *   {
 *     "ProductID": "6d34eb18-81ea-418f-ad7a-646db814aba2",
 *     "UpdateTimestamp": "2024-02-26T20:42:16.000Z",
 *     "PerformanceStrings": [
 *       {
 *         "BeginDate": "2024-01-11T21:00:00.000Z",
 *         "EndDate": "2023-11-03T21:00:00.000Z",
 *         "BeginMarketValue": "-6909363.790000",
 *         "EndMarketValue": "-8618151.820000",
 *         "Currency": "TBD",
 *         "Performance": "-93.6500000000",
 *         "IsHypothetical": true
 *       }
 *     ]
 *   }
 * ]
 * ```
 *
 * */
export interface UpsertPerformanceBody {
  SourceID: string; // Unique ID of the product
  SourceSystem: SourceSystem
  UpdateTimestamp: Date; // Date of performance update (Timestamp represented as milliseconds)
  PerformanceStrings: PerformanceString[]; // Zero or more performance strings
}

interface PerformanceString {
  BeginDate: Date | string // Begin date of performance string interval (UNIX timestamp)
  EndDate: Date | string // End date of performance string interval (UNIX timestamp)
  BeginMarketValue: number | string // Market value at start of interval (for indexes)
  EndMarketValue: number | string // Market value at end of interval (for indexes)
  Currency: Currency // USD for dollars; other values TBD
  Performance: number | string // Benchmark/index performance
  IsHypothetical: boolean // True if this performance is hypothetical
}

export function generateUpsertProductPerformanceBody(testCase: PayloadTestCase): UpsertPerformanceBody {
  const {useAllFields, nestedItemsTestCase = {
    floatReturnType: 'number',
    useAllFields: true
  }} = testCase
  return {
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
    PerformanceStrings: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 5}) }, () => generatePerformanceString(nestedItemsTestCase)),
  }
}

function generatePerformanceString(testCase: PayloadTestCase): PerformanceString {
  const {numberTestCase, floatReturnType: numberReturnType } = testCase
  return {
    BeginDate: DateFormatters.removeMilliseconds(DateFormatters.setTimeTo0(faker.date.past())),
    EndDate: DateFormatters.removeMilliseconds(DateFormatters.setTimeTo0(faker.date.past())),
    BeginMarketValue: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    EndMarketValue: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    Currency: Random.getEnumValue(Currency),
    Performance: Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: numberReturnType}),
    IsHypothetical: faker.datatype.boolean()
  }
}
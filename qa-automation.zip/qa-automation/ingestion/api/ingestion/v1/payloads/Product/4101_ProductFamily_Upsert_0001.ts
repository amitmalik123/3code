import {PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 *   {
 *     "SourceID": "AAMEQ",
 *     "SourceSystem": "AMK",
 *     "Name": "Acadian Asset Management LLC",
 *     "Tags": [],
 *     "UpdateTimestamp": "2023-08-22T07:38:22.777"
 *   }
 * ```
 *
 * */
export interface UpsertProductFamilyBody {
    SourceID:        string;
    SourceSystem:    SourceSystem;
    Name:            string;
    InvestmentManagerSourceID?: null | string
    InvestmentManagerSourceSystem?: null | string
    Tags:            string[];
    UpdateTimestamp: Date;
}

// Function to generate a random instance of UpsertProductFamilyBody
export function generateUpsertProductFamilyBody(testCase: PayloadTestCase): UpsertProductFamilyBody {
  const {useAllFields, defineNullableFields} = testCase
  return {
    SourceID:        uuid(),
    SourceSystem:    SourceSystem.QA,
    Name:            `${faker.word.adjective()} ${faker.company.name()}`,
    InvestmentManagerSourceID: useAllFields ? uuid() : defineNullableFields ? null : undefined,
    InvestmentManagerSourceSystem: useAllFields ? SourceSystem.QA : defineNullableFields ? null : undefined,
    Tags:            Array.from({ length: faker.number.int({min: 0, max: 3}) }, faker.company.buzzAdjective),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
  }
}
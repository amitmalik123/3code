import {Currency, PayloadTestCase} from '../../types'
import {faker} from '@faker-js/faker'
import {v4 as uuid} from 'uuid'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 *   {
 *     "UserID": "AMK",
 *     "QualifyingAssets": 454.83,
 *     "Level": "A35592",
 *     "BenefitLevelEffectiveDate": "2023-01-01T00:00:00",
 *     "AssetLevelEffectiveDate": "2023-01-01T00:00:00",
 *     "ServiceTeam": "Advisory Fees",
 *     "AccommodationGranted": true,
 *     "GrossContributionsMTD": 454.83,
 *     "GrossContributionsQTD": 454.83,
 *     "GrossContributionsYTD": 454.83,
 *     "Currency": "2023-01-01T00:00:00",
 *     "UpdateTimestamp": "2023-01-01T00:00:00"
 *   }
 * ```
 *
 * */
export interface UpsertBenefitLevelBody {
    SourceID:        string //for some reason this value turns into userid in DB
    //SourceSystem:    SourceSystem.QA; // actually db does not have that column
    QualifyingAssets:          string | number
    Level:                     string
    BenefitLevelEffectiveDate: Date
    AssetLevelEffectiveDate:   Date
    ServiceTeam:               string
    AccommodationGranted:      boolean
    GrossContributionsMTD:     string | number
    GrossContributionsQTD:     string | number
    GrossContributionsYTD:     string | number
    Currency:                  Currency
    UpdateTimestamp:           Date
}

// Function to generate a random instance of UpsertBenefitLevelBody
export function generateUpsertBenefitLevelBody(testCase: PayloadTestCase): UpsertBenefitLevelBody {
  const {numberTestCase, floatReturnType: numberReturnType } = testCase
  return {
    SourceID: uuid(),
    //SourceSystem: SourceSystem.QA,
    QualifyingAssets: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    Level: faker.color.human(),
    BenefitLevelEffectiveDate: DateFormatters.setTimeTo0(faker.date.past()),
    AssetLevelEffectiveDate: DateFormatters.setTimeTo0(faker.date.past()),
    ServiceTeam: faker.color.human() + ' team',
    AccommodationGranted: faker.datatype.boolean(),
    GrossContributionsMTD: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    GrossContributionsQTD: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    GrossContributionsYTD: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    Currency: Random.getEnumValue(Currency),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
  }
}
import {Currency, PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * {
 *     "SourceSystem": "AMK",
 *     "SourceID": "16229173",
 *     "TargetSourceID": "A35592",
 *     "TargetSourceSystem": "AMK",
 *     "TargetType": "VirtualAccount",
 *     "Name": "Advisory Fees",
 *     "Amount": 454.83,
 *     "Basis": 253223.68,
 *     "Currency": "USD",
 *     "BilledDate": "2023-01-05T00:00:00",
 *     "StartBillingPeriod": "2023-01-01T00:00:00",
 *     "EndBillingPeriod": "2023-03-31T00:00:00",
 *     "UpdateTimestamp": "2023-05-24T00:00:00"
 *   }
 * ```
 *
 * */
export interface UpsertFeeBody {
    SourceSystem:       SourceSystem
    SourceID:           string
    TargetSourceID:     string
    TargetSourceSystem: SourceSystem
    TargetType:         TargetType
    Name:               FeeName
    Amount:             string | number
    Basis?:              string | number | null
    Currency:           Currency
    BilledDate:         Date
    StartBillingPeriod: Date
    EndBillingPeriod:   Date
    UpdateTimestamp:    Date
}

enum FeeName {
  ADVISOR_FEES = 'Advisor Fee',
  PLANNING_AND_CONSULTING = 'Planning and Consulting',
  FINANCIAL_PLANNING = 'Financial Planning',
  TRADE_COMMISSION = 'Trade Commission'
}

enum TargetType {
  VIRTUAL_ACCOUNT = 'VirtualAccount',
  ORGANIZATION = 'Organization'
}

// Function to generate a random instance of UpsertFeeBody
export function generateUpsertFeeBody(testCase: PayloadTestCase): UpsertFeeBody {
  const {useAllFields, defineNullableFields, numberTestCase, floatReturnType: numberReturnType } = testCase
  return {
    SourceSystem: SourceSystem.QA,
    SourceID: uuid(),
    TargetSourceID: uuid(),
    TargetSourceSystem: SourceSystem.QA,
    TargetType: Random.getEnumValue(TargetType),
    Name: Random.getEnumValue(FeeName),
    Amount: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    Basis: useAllFields ? Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}) : defineNullableFields ? null : undefined,
    Currency: Random.getEnumValue(Currency),
    BilledDate: DateFormatters.setTimeTo0(faker.date.past()),
    StartBillingPeriod: DateFormatters.setTimeTo0(faker.date.past()),
    EndBillingPeriod: DateFormatters.setTimeTo0(faker.date.past()),
    UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
  }
}
import { PayloadTestCase, SourceSystem} from '../../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../../utils/random'
import { DateFormatters } from '../../../../../../utils/date-farmatters'

/**
 *
 * **Example**
 * ```
 * [
 *   {
 *     "SourceID": "c1f48a2c-b378-486b-ad3c-9f2aad9d28f5",
 *     "SourceSystem": "ewm3_QA_source_system",
 *     "Name": "Function-based asymmetric instruction set",
 *     "Type": "cluttered",
 *     "StartDate": "2023-07-18T21:00:00.000Z",
 *     "StartValue": "-2033.099873",
 *     "TargetDate": "2024-04-02T21:00:00.000Z",
 *     "TargetValue": "7197649.816199",
 *     "PeriodicFlow": "-8933770.396508",
 *     "Periodicity": "Annually",
 *     "AnnualRateOfReturn": "-443.3678885135",
 *     "Investments": [
 *       "Refined Rubber Mouse",
 *       "Handmade Granite Table",
 *       "Small Soft Fish"
 *     ],
 *     "InvestmentsType": "VirtualAccount",
 *     "Tags": [
 *       "useful"
 *     ],
 *     "CustomAttributes": {
 *       "dam": "illustrious",
 *       "egg": "soulful",
 *       "mainland": "full",
 *       "cry": "fair",
 *       "senior": "well-documented"
 *     },
 *     "UpdateTimestamp": "2024-04-25T23:16:02.000Z"
 *   }
 * ]
 * ```
 *
 * */
export interface goalBody {
  SourceID: string // The unique ID of this goal in the source system.
  SourceSystem: SourceSystem // The ID of the external system if this goal was imported.
  Name: string // Name of the goal
  Type: string // Type of the goal ('retirement', etc.)
  StartDate: Date // Start date of the goal
  StartValue: string | number // Start value for the goal
  TargetDate: Date // Target/end date of the goal
  TargetValue: string | number // Target value for the goal
  PeriodicFlow: string | number// Contributions (positive) or withdrawals (negative)
  Periodicity: PeriodicityType // Period for PeriodicFlow
  AnnualRateOfReturn: string | number // Annualized rate of return of assets
  Investments: string[] // Investments of the goal
  InvestmentsType: InvestmentsType // Type of goal investments
  Tags: string[] // String tags associated with this goal
  CustomAttributes: {[key: string]: string} // Additional fields associated with the goal
  UpdateTimestamp: Date // Timestamp that goal update is effective
}

enum PeriodicityType {
  Monthly = 'Monthly',
  Quarterly = 'Quarterly',
  Annually = 'Annually',
}

enum InvestmentsType {
  VirtualAccount = 'VirtualAccount',
  Organization = 'Organization',
}

export function generateGoalBody(testCase: PayloadTestCase): goalBody {
  const { useAllFields, numberTestCase, floatReturnType: numberReturnType } = testCase
  
  return {
    SourceID: uuid(),
    SourceSystem: SourceSystem.QA,
    Name: faker.company.catchPhrase(),
    Type: faker.word.adjective(),
    StartDate: DateFormatters.setTimeTo0(faker.date.past()),
    StartValue: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    TargetDate: DateFormatters.setTimeTo0(faker.date.past()),
    TargetValue: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    PeriodicFlow: Random.generateNumberByPrecision({precision: 20, scale: 6, testCase: numberTestCase, returnType: numberReturnType}),
    Periodicity: Random.getEnumValue(PeriodicityType),
    AnnualRateOfReturn: Random.generateNumberByPrecision({precision: 16, scale: 10, testCase: numberTestCase, returnType: numberReturnType}),
    Investments: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 5}) }, faker.commerce.productName),
    InvestmentsType: Random.getEnumValue(InvestmentsType),
    Tags: Array.from({ length: faker.number.int({min: useAllFields ? 1 : 0, max: 3}) }, faker.word.adjective),
    CustomAttributes: Random.generateRandomKeyValuePairs(),UpdateTimestamp: DateFormatters.setMillsTo0(new Date()),
  }
}
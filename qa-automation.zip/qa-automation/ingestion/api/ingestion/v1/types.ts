import { BaseApiEndpoint } from '../../../../base/base-endpoint'
import { DbInfo } from '../../../../db/db-access-helpers'
import {NumberReturnTypeOptions, NumberTestCaseOptions} from '../../../../utils/random'

export interface IngestionProduceResponseBodyError {
    type:    string;
    title:   string;
    status:  number;
    traceId: string;
    errors?:  IngestionProduceErrors;
}

export interface IngestionProduceErrors {
    $?: string[];
    ''?: string[];
    data?: string[];
}

export enum SourceSystem {
    QA = 'ewm3_QA_source_system'
}

export enum Currency {
    USD = 'USD',
    TBD = 'TBD'
}

/**
 * Represents a payload test case configuration.
 */
export type PayloadTestCase = {
    /**
     * The number of items in the endpoint payload.
     */
    itemsCount?: number;

    /**
     * Indicates whether to use all fields in the test case.
     */
    useAllFields?: boolean;

    /**
     * Indicates whether to define nullable fields in the test case.
     */
    defineNullableFields?: boolean;

    /**
     * Options for number test cases.
     */
    numberTestCase?: NumberTestCaseOptions;

    /**
     * Options for float return type.
     */
    floatReturnType?: NumberReturnTypeOptions;

    /**
     * Options for integer return type.
     */
    intReturnType?: NumberReturnTypeOptions;

    /**
     * Nested payload test case configuration.
     */
    nestedItemsTestCase?: PayloadTestCase;

    /**
     * Extra query parameters that we need to pass to endpoint
     */
    queryParameters?: {[key: string]: string | number | boolean};
}

export interface HistorianDBOutput {
    messagekey: string,
    avromessage?: {type: 'Buffer', data: number[]},
    jsonmessage: null,
    schemaid: string,
    updatetimestamp: Date
}

export interface IngestionApiEndpoint extends BaseApiEndpoint {
  /**
   * Array of ingestion target DB info objects.
   * Contain some rules that help ingestion api tests understand how datra should be selected drom DB and compared
   */
  dbInfo: IngestionTargetDbInfo[]
  /**
   * Array of DB info with specific rules of ID generation.
   * **NOTE:** there can be several IDs in scope of 1 message item. It depends on avro DB schema
   */
  idGenerationDbInfo?: IdGenerationDbInfo[]
  /** Avro DB schema version */
  schemaid: string
  /**
   * Expected body to compare with historian DB output.
   * Should be generated from endpoint body
   */
  expectedHistorianData?: HistorianDBOutput[]
  /** Unique key that is used as main ID for ingestion message item */
  idKey: string
  /**
   * Array of keys(string/functions) that are required for historian DB messagekey column value generation
   */
  keysForMessageKeyGeneration: KeysForMessageKeyGeneration[]
}

export type KeysForMessageKeyGeneration = string | ((obj: Record<string, any>) => any);

export interface IngestionTargetDbInfo extends DbInfo {
  /** DB table name */
  tableName: string
  /** Field or fields array that can be used as a condition for building DB query */
  queryConditionField?: string | string[]
  /**
   * Distinct key - unique key in DB output/endpoint body.
   * Helps to compare DB output and endpoint body
   */
  distinctKey?: string
  /**
   * How to replace key names rules.
   * Used to match endpoint body data with DB output
   */
  keyReplacementRules?: { original: string; new: string} []
  /**
   * Array of keys that should be ignored.
   * Some keys from endpoint body can be not presented in DB output (according to avro schema output)
   */
  ignoreKeys?: string[]
  /** Array of keys that should not be null */
  notNullKeys?: string[]
  /**
   * Type of ingestion DB.
   * **NOTE:** Different DB types are validated in different way
   */
  dbType: DbType
}
export interface IdGenerationDbInfo extends IngestionTargetDbInfo {
  idGenerationRule: IdGenerationRule
  idKey: string
}
/** Types of DBs used in ingestion API tests */

export enum DbType {
  COMMAND = 'Command DB (main DB for data insert)',
  PUBLISH = 'Publish DB (secondary DB for data insert)',
  HISTORIAN_COMMAND = 'Command historian DB',
  HISTORIAN_PUBLISH = 'Publish historian DB',
  INGESTION_ID_GENERATION = 'Ingestion DB for ID generation'
}
/**
 * What key should be used instead of source and source id in ingestion DB query
 */

export interface IdGenerationRule {
  source?: string
  source_id?: string
}
export enum CommonIngestionKeys {
  SOURCE_ID = 'SourceID',
  SOURCE_SYSTEM = 'SourceSystem',
  SOURCE_ACCOUNT_ID = 'SourceAccountID',
  TARGET_SOURCE_ID = 'TargetSourceID',
  PRODUCT_ID = 'ProductID',
  UPDATE_TIMESTAMP = 'UpdateTimestamp',
  VIRTUAL_ACCOUNT_ID = 'VirtualAccountID',
  TARGET_ID = 'TargetID',
  TARGET_SOURCE_SYSTEM = 'TargetSourceSystem',
  ACTION_ID = 'ActionID',
}
export enum EmptyCase {
  NULL = 'null',
  UNDEFINED = 'undefined',
  EMPTY_STRING = 'empty string'
}


import { CommonIngestionKeys, DbType } from '../../../types'
import {generateUpsertProductPerformanceBody} from '../../../payloads/Product/4103_Performance_Upsert_0001'
import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class ProductPerformanceMessage extends BaseMessage{

  constructor() {
    super(
      'upsert-product-performance',
      [
        {
          dataBaseName: DbName.product,
          tableName: 'public.product_performance',
          dbType: DbType.COMMAND
        },
        getHistorianDbInfo('cmd.product_performance_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertProductPerformanceBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.PRODUCT_ID, historianMessageKeyUpdateTimestamp],
        schemaid: '0x40030001',
        distinctKey: CommonIngestionKeys.PRODUCT_ID,
      }
    )
    this.updateMainIdGenerationRule({idKey: CommonIngestionKeys.PRODUCT_ID})
  }

}
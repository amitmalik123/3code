import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import {generateRiskCovarianceMatrixBody} from '../../../payloads/Product/4104_RiskCovarianceMatrix_Upsert_0001'
import { DbType } from '../../../types'
import { DbName } from '../../../../../../../db/db-config'

export class RiskCovarianceMatrixMessage extends BaseMessage{

  constructor() {
    super(
      'upsert-riskcovariance',
      [
        {
          dataBaseName: DbName.product,
          tableName: 'public.riskcovariance',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.proposal,
          tableName: 'cmd.riskcovariance',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.riskcovariance_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateRiskCovarianceMatrixBody,
      {
        needToGenerateIdKeys: false,
        keysForMessageKeyGeneration: ['RiskCovarianceMatrixID', historianMessageKeyUpdateTimestamp],
        schemaid: '0x40040001',
        requiredFields: ['RiskCovarianceMatrixID'],
        distinctKey: 'RiskCovarianceMatrixID'
      }
    )
  }

}
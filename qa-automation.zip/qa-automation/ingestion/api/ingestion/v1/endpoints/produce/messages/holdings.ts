import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { CommonIngestionKeys, DbType } from '../../../types'
import {generateUpsertHoldingsBody} from '../../../payloads/AccountData/3101_Holdings_Ingest_0001'
import {BaseMessage} from '../base-message'
import { DbName } from '../../../../../../../db/db-config'

export class HoldingsMessage extends BaseMessage{

  constructor() {
    super(
      'holdings',
      [
        {
          dataBaseName: DbName.accountdata,
          tableName: 'cmd.holding',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.holding',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.holding',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.investorportal,
          tableName: 'cmd.holding',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.holding_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertHoldingsBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.VIRTUAL_ACCOUNT_ID, historianMessageKeyUpdateTimestamp],
        schemaid: '0x30010001'
      }
    )
    this.updateMainIdGenerationRule({idKey: CommonIngestionKeys.VIRTUAL_ACCOUNT_ID})
  }

}
import { CommonIngestionKeys, DbType } from '../../../types'
import {generateUpsertSourceAccountBody} from '../../../payloads/AccountData/310D_SourceAccount_Ingest_0002'
import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class SourceAccountMessage extends BaseMessage{

  constructor() {
    super(
      'sourceaccount',
      [
        {
          dataBaseName: DbName.accountdata,
          tableName: 'cmd.sourceaccount',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.sourceaccount',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.sourceaccount',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.investorportal,
          tableName: 'cmd.sourceaccount',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.sourceaccount_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertSourceAccountBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.SOURCE_ACCOUNT_ID, historianMessageKeyUpdateTimestamp],
        schemaid: '0x300D0002'
      }
    )
  }

}
import { CommonIngestionKeys, DbType } from '../../../types'
import {generateIngestTransactionsBody} from '../../../payloads/AccountData/3107_Transactions_Ingest_0001'
import {BaseMessage} from '../base-message'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class TransactionsMessage extends BaseMessage{

  constructor() {
    super(
      'transactions-data',
      [
        {
          dataBaseName: DbName.accountdata,
          tableName: 'cmd.transaction',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.transaction',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.transaction',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.transaction_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateIngestTransactionsBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.VIRTUAL_ACCOUNT_ID],
        schemaid: '0x30070001'
      }
    )
    this.updateMainIdGenerationRule({idKey: CommonIngestionKeys.VIRTUAL_ACCOUNT_ID})
  }

}
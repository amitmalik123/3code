import {BaseApiEndpoint, HttpMethod} from '../../../../../../base/base-endpoint'
import {OrganizationMessage} from './messages/organization'
import {VirtualAccountMessage} from './messages/virtual-account'
import {SourceAccountMessage} from './messages/source-account'
import {UserMessage} from './messages/user'
import {HoldingsMessage} from './messages/holdings'
import {MarketValueMessage} from './messages/market-value'
import {FeeMessage} from './messages/fee'
import {ProductMessage} from './messages/product'
import {BenefitLevelMessage} from './messages/benefit-level'
import {FlowsMessage} from './messages/flows'
import {SummaryPerformanceMessage} from './messages/summary-performance'
import {InvestmentManagerMessage} from './messages/investment-manager'
import {ProductFamilyMessage} from './messages/product-family'
import {WorkItemMessage} from './messages/work-item'
import {RealizedGainLossMessage} from './messages/realized-gain-loss'
import {TransactionsMessage} from './messages/transactions'
import {UnrealizedGainLossMessage} from './messages/unrealized-gain-loss'
import {NonFinancialDataMessage} from './messages/non-financial-data'
import {UserGroupMessage} from './messages/user-group'
import {ProductPerformanceMessage} from './messages/product-performance'
import {ActionTargetMessage} from './messages/action-target'
import {ActionMessage} from './messages/action'
import {ProductChangeActionMessage} from './messages/product-change-action'
import {RiskCovarianceMatrixMessage} from './messages/risk-covariance-matrix'
import {ProductAvailabilityMessage} from './messages/product-availability'
import { PerformanceMessage } from './messages/performance'
import { ProposalMessage } from './messages/proposal'
import {GoalMessage} from './messages/goal'
import {ContactMessage} from './messages/contact'

/**
 * Creates an endpoint configuration for producing data.
 *
 * @param {string | string[] | undefined} pathParameters - The path parameters for the endpoint.
 * @param {object[] | null} body - The body of the request.
 * @returns {BaseApiEndpoint} The configured endpoint object.
 */
export function createProduceEndpoint(pathParameters: string | string[] | undefined, body: object[] | null): BaseApiEndpoint {
  const route = '/ingestion/api/v1/produce'
  const title = `${pathParameters}`

  return {
    pathParameters,
    body,
    method: HttpMethod.PUT,
    route,
    title
  }
}

export class Produce {

  sampleEndpoint(pathParameter: string | string[] | undefined, body: object[] | null): BaseApiEndpoint {
    return createProduceEndpoint(pathParameter, body)
  }

  readonly organization = new OrganizationMessage()
  readonly virtualAccount = new VirtualAccountMessage()
  readonly sourceAccount = new SourceAccountMessage()
  readonly user = new UserMessage()
  readonly holdings = new HoldingsMessage()
  readonly marketValue = new MarketValueMessage()
  readonly fee = new FeeMessage()
  readonly product = new ProductMessage()
  readonly benefitLevel = new BenefitLevelMessage()
  readonly flows = new FlowsMessage()
  readonly summaryPerformance = new SummaryPerformanceMessage()
  readonly investmentManager = new InvestmentManagerMessage()
  readonly productFamily = new ProductFamilyMessage()
  readonly workItem = new WorkItemMessage()
  readonly realizedGainLoss = new RealizedGainLossMessage()
  readonly transactions = new TransactionsMessage()
  readonly unrealizedGainLoss = new UnrealizedGainLossMessage()
  readonly nonFinancialData = new NonFinancialDataMessage()
  readonly userGroup = new UserGroupMessage()
  readonly productPerformance = new ProductPerformanceMessage()
  readonly actionTarget = new ActionTargetMessage()
  readonly action = new ActionMessage()
  readonly productChangeAction = new ProductChangeActionMessage()
  readonly riskCovarianceMatrix = new RiskCovarianceMatrixMessage()
  readonly productAvailability = new ProductAvailabilityMessage()
  readonly performance = new PerformanceMessage()
  readonly proposal = new ProposalMessage()
  readonly goal = new GoalMessage()
  readonly contact = new ContactMessage()

}
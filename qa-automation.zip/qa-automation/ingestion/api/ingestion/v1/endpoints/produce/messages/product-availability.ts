import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import {generateProductAvailabilityBody} from '../../../payloads/Product/4105_ProductAvailability_Upsert_0001'
import { CommonIngestionKeys, DbType } from '../../../types'
import { DbName } from '../../../../../../../db/db-config'

export class ProductAvailabilityMessage extends BaseMessage{

  constructor() {
    super(
      'upsert-productavailability',
      [
        {
          dataBaseName: DbName.product,
          tableName: 'public.productavailability',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.proposal,
          tableName: 'cmd.productavailability',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.productavailability_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateProductAvailabilityBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.TARGET_ID, historianMessageKeyUpdateTimestamp],
        schemaid: '0x40050001',
        requiredFields: [CommonIngestionKeys.TARGET_SOURCE_SYSTEM, CommonIngestionKeys.TARGET_SOURCE_ID],
        distinctKey: CommonIngestionKeys.TARGET_SOURCE_ID
      }
    )
    this.updateMainIdGenerationRule({
      idKey: CommonIngestionKeys.TARGET_ID,
      idGenerationRule: {
        source: CommonIngestionKeys.TARGET_SOURCE_SYSTEM,
        source_id: CommonIngestionKeys.TARGET_SOURCE_ID
      }
    })
  }

}
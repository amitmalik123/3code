import {generateUpsertUserGroupBody} from '../../../payloads/Authorization/6102_Group_Ingest_0001'
import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { DbType } from '../../../types'
import { DbName } from '../../../../../../../db/db-config'

export class UserGroupMessage extends BaseMessage{

  constructor() {
    super(
      'upsert-usergroup',
      [
        {
          dataBaseName: DbName.auth,
          tableName: 'cmd.usergroup',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.usergroup',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.proposal,
          tableName: 'cmd.usergroup',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.product,
          tableName: 'public.usergroup',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.accountdata,
          tableName: 'cmd.usergroup',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.contact,
          tableName: 'cmd.usergroup',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.usergroup',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.worktracking,
          tableName: 'cmd.usergroup',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.feebilling,
          tableName: 'cmd.usergroup',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.organization,
          tableName: 'public.usergroup',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.investorportal,
          tableName: 'cmd.usergroup',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.usergroup_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertUserGroupBody,
      {
        needToGenerateIdKeys: false,
        keysForMessageKeyGeneration: ['GroupName', historianMessageKeyUpdateTimestamp],
        schemaid: '0x60020001',
        requiredFields: ['GroupName'],
        distinctKey: 'GroupName'
      }
    )
  }

}
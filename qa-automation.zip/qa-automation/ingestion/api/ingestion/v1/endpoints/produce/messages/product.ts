import { CommonIngestionKeys, DbType } from '../../../types'
import {generateUpsertProductBody} from '../../../payloads/Product/4102_Product_Upsert_0002'
import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class ProductMessage extends BaseMessage{

  constructor() {
    super(
      'upsert-product',
      [
        {
          dataBaseName: DbName.product,
          tableName: 'public.product',
          ignoreKeys: ['InvestmentManagerSourceID', 'InvestmentManagerSourceSystem', 'ProductFamilySourceID', 'ProductFamilySourceSystem'],
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.product',
          ignoreKeys: ['InvestmentManagerSourceID', 'InvestmentManagerSourceSystem', 'ProductFamilySourceID', 'ProductFamilySourceSystem'],
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.proposal,
          tableName: 'cmd.product',
          ignoreKeys: ['InvestmentManagerSourceID', 'InvestmentManagerSourceSystem', 'ProductFamilySourceID', 'ProductFamilySourceSystem'],
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.product',
          ignoreKeys: ['InvestmentManagerSourceID', 'InvestmentManagerSourceSystem', 'ProductFamilySourceID', 'ProductFamilySourceSystem'],
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.investorportal,
          tableName: 'cmd.product',
          ignoreKeys: ['InvestmentManagerSourceID', 'InvestmentManagerSourceSystem', 'ProductFamilySourceID', 'ProductFamilySourceSystem'],
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.product_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertProductBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.PRODUCT_ID, historianMessageKeyUpdateTimestamp],
        schemaid: '0x40020002'
      }
    )
    this.updateMainIdGenerationRule({idKey: CommonIngestionKeys.PRODUCT_ID}) 
    this.addIdGenerationRules([
      {
        idGenerationRule: {
          source: 'InvestmentManagerSourceSystem',
          source_id: 'InvestmentManagerSourceID'
        },
        idKey: 'InvestmentManagerID'
      },
      {
        idGenerationRule: {
          source: 'ProductFamilySourceSystem',
          source_id: 'ProductFamilySourceID'
        },
        idKey: 'ProductFamilyID'
      }
    ])
  }

}
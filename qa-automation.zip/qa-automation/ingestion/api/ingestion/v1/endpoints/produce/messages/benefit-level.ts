import { getHistorianDbInfo } from '../../../../utils'
import { CommonIngestionKeys, DbType } from '../../../types'
import {generateUpsertBenefitLevelBody} from '../../../payloads/AdvisorBenefits/FE00_BenefitLevel_Ingest_0001'
import {BaseMessage} from '../base-message'
import { DbName } from '../../../../../../../db/db-config'

export class BenefitLevelMessage extends BaseMessage{

  constructor() {
    super(
      'benefitlevel',
      [
        {
          dataBaseName: DbName.advisorbenefits,
          tableName: 'cmd.benefitlevel',
          keyReplacementRules: [
            {
              original: CommonIngestionKeys.SOURCE_ID,
              new: 'UserID'
            }
          ],
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.benefitlevel',
          keyReplacementRules: [
            {
              original: CommonIngestionKeys.SOURCE_ID,
              new: 'UserID'
            }
          ],
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.benefitlevel_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertBenefitLevelBody,
      {
        needToGenerateIdKeys: false,
        keysForMessageKeyGeneration: [CommonIngestionKeys.SOURCE_ID],
        schemaid: '0xFF000001',
        requiredFields: [CommonIngestionKeys.SOURCE_ID],
        distinctKey: 'UserID'
      }
    )
  }

}
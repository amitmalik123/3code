import { DbType } from '../../../types'
import {generateUpsertWorkItemBody} from '../../../payloads/WorkTracking/9100_WorkItem_Ingest_0001'
import {BaseMessage} from '../base-message'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class WorkItemMessage extends BaseMessage{

  constructor() {
    super(
      'workitem',
      [
        {
          dataBaseName: DbName.worktracking,
          tableName: 'cmd.workitem',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.workitem',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.investorportal,
          tableName: 'cmd.workitem',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.workitem_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertWorkItemBody,
      {
        keysForMessageKeyGeneration: ['WorkItemID'],
        schemaid: '0x90000003'
      }
    )

    this.updateMainIdGenerationRule({idKey: 'WorkItemID'}) 
    this.addIdGenerationRules({
      idGenerationRule: {
        source_id: 'ParentSourceID'
      },
      idKey: 'ParentWorkItemID'
    })
  }

}
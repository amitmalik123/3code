import { CommonIngestionKeys, DbType } from '../../../types'
import {generateIngestRealizedGainLossBody} from '../../../payloads/AccountData/3104_RealizedGainLoss_Ingest_0001'
import {BaseMessage} from '../base-message'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class RealizedGainLossMessage extends BaseMessage{

  constructor() {
    super(
      'realizedgainloss-data',
      [
        {
          dataBaseName: DbName.accountdata,
          tableName: 'cmd.realizedgainloss',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.realizedgainloss',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.realizedgainloss',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.realizedgainloss_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateIngestRealizedGainLossBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.SOURCE_ACCOUNT_ID],
        schemaid: '0x30040001'
      }
    )
  }

}
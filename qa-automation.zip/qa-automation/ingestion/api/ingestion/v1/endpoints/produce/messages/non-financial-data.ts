import { CommonIngestionKeys, DbType } from '../../../types'
import {generateIngestNonfinancialDataBody} from '../../../payloads/AccountData/3112_NonfinancialData_Ingest_0001'
import {BaseMessage} from '../base-message'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class NonFinancialDataMessage extends BaseMessage{

  constructor() {
    super(
      'nonfinancialdata',
      [
        {
          dataBaseName: DbName.accountdata,
          tableName: 'cmd.nonfinancialdata',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.nonfinancialdata',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.nonfinancialdata',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.nonfinancialdata_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateIngestNonfinancialDataBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.SOURCE_ACCOUNT_ID],
        schemaid: '0x30120001'
      }
    )
  }

}
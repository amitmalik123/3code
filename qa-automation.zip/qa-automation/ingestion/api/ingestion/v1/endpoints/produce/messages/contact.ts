import { DbType } from '../../../types'
import {BaseMessage} from '../base-message'
import { getHistorianDbInfo } from '../../../../utils'
import {generateContactBody} from '../../../payloads/Contact/8100_Contact_Upsert_0001'
import { DbName } from '../../../../../../../db/db-config'

export class ContactMessage extends BaseMessage{

  constructor() {
    super(
      'contact',
      [
        {
          dataBaseName: DbName.contact,
          tableName: 'cmd.contact',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.contact',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.contact',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.contact_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateContactBody,
      {
        keysForMessageKeyGeneration: ['ContactID'],
        schemaid: '0x80000001'
      }
    )

    this.updateMainIdGenerationRule({idKey: 'ContactID'})
  }

}
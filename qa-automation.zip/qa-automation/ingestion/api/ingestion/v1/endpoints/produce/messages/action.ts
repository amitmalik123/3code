import {BaseMessage} from '../base-message'
import { getHistorianDbInfo } from '../../../../utils'
import {generateIngestActionBody} from '../../../payloads/WorkflowActions/9301_IngestAction_Upsert_0001'
import { CommonIngestionKeys, DbType } from '../../../types'
import { DbName } from '../../../../../../../db/db-config'

export class ActionMessage extends BaseMessage{

  constructor() {
    super(
      'upsert_action',
      [
        {
          dataBaseName: DbName.worktracking,
          tableName: 'cmd.upsert_action',
          dbType: DbType.COMMAND
        },
        getHistorianDbInfo('cmd.upsert_action_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateIngestActionBody,
      {
        needToGenerateIdKeys: false,
        keysForMessageKeyGeneration: [CommonIngestionKeys.ACTION_ID],
        schemaid: '0x92010001',
        requiredFields: [CommonIngestionKeys.ACTION_ID],
        distinctKey: CommonIngestionKeys.ACTION_ID
      }
    )
  }

}
import { CommonIngestionKeys, DbType } from '../../../types'
import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { generatePerformanceIngestBody } from '../../../payloads/AccountData/310E_Performance_Ingest_0001'
import { DbName } from '../../../../../../../db/db-config'

export class PerformanceMessage extends BaseMessage{

  constructor() {
    super(
      'performance',
      [
        {
          dataBaseName: DbName.accountdata,
          tableName: 'cmd.performance',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.performance',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.performance',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.investorportal,
          tableName: 'cmd.performance',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.performance_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generatePerformanceIngestBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.VIRTUAL_ACCOUNT_ID, historianMessageKeyUpdateTimestamp],
        schemaid: '0x300E0001'
      }
    )
    this.updateMainIdGenerationRule({idKey: CommonIngestionKeys.VIRTUAL_ACCOUNT_ID})
  }

}
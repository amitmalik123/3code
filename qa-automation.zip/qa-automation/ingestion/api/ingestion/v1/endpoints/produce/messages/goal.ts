import { DbType } from '../../../types'
import {BaseMessage} from '../base-message'
import { getHistorianDbInfo } from '../../../../utils'
import {generateGoalBody} from '../../../payloads/Goal/8300_Goal_Upsert_0001'
import { DbName } from '../../../../../../../db/db-config'

export class GoalMessage extends BaseMessage{

  constructor() {
    super(
      'goal',
      [
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.goal',
          dbType: DbType.COMMAND
        },
        getHistorianDbInfo('cmd.goal_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateGoalBody,
      {
        keysForMessageKeyGeneration: ['GoalID'],
        schemaid: '0x82000001'
      }
    )
    this.updateMainIdGenerationRule({idKey: 'GoalID'})
  }

}
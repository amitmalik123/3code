import { CommonIngestionKeys, DbType } from '../../../types'
import {generateUpsertMarketValueBody} from '../../../payloads/AccountData/3102_Marketvalue_Ingest_0001'
import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class MarketValueMessage extends BaseMessage{

  constructor() {
    super(
      'marketvalue',
      [
        {
          dataBaseName: DbName.accountdata,
          tableName: 'cmd.marketvalue',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.marketvalue',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.proposal,
          tableName: 'cmd.marketvalue',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.marketvalue',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.investorportal,
          tableName: 'cmd.marketvalue',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.marketvalue_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertMarketValueBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.VIRTUAL_ACCOUNT_ID, historianMessageKeyUpdateTimestamp],
        schemaid: '0x30020001',
        requiredFields: [CommonIngestionKeys.SOURCE_SYSTEM, CommonIngestionKeys.SOURCE_ID, 'ValuationDate']
      }
    )
    this.updateMainIdGenerationRule({idKey: CommonIngestionKeys.VIRTUAL_ACCOUNT_ID})
  }

}
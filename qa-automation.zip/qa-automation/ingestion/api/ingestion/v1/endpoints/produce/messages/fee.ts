import { DbType } from '../../../types'
import {generateUpsertFeeBody} from '../../../payloads/FeeBilling/2100_Fee_Ingest_0001'
import {BaseMessage} from '../base-message'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class FeeMessage extends BaseMessage{

  constructor() {
    super(
      'fees',
      [
        {
          dataBaseName: DbName.feebilling,
          tableName: 'cmd.fee',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.fee',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.fee_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertFeeBody,
      {
        keysForMessageKeyGeneration: ['FeeID'],
        schemaid: '0x20000001'
      }
    )
    this.updateMainIdGenerationRule({idKey: 'FeeID'})
  }

}
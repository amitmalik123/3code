import { CommonIngestionKeys, DbType } from '../../../types'
import {generateUpsertVirtualAccountBody} from '../../../payloads/AccountData/310F_VirtualAccount_Upsert_0005'
import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class VirtualAccountMessage extends BaseMessage{

  constructor() {
    super(
      'upsert-virtualaccount',
      [
        {
          dataBaseName: DbName.accountdata,
          tableName: 'cmd.virtualaccount',
          ignoreKeys: ['ProductSourceID', 'ProductSourceSystem'],
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.virtualaccount',
          ignoreKeys: ['ProductSourceID', 'ProductSourceSystem'],
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.proposal,
          tableName: 'cmd.virtualaccount',
          ignoreKeys: ['ProductSourceID', 'ProductSourceSystem'],
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.virtualaccount',
          ignoreKeys: ['ProductSourceID', 'ProductSourceSystem'],
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.investorportal,
          tableName: 'cmd.virtualaccount',
          ignoreKeys: ['ProductSourceID', 'ProductSourceSystem'],
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.virtualaccount_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertVirtualAccountBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.VIRTUAL_ACCOUNT_ID, historianMessageKeyUpdateTimestamp],
        schemaid: '0x300F0005'
      }
    )
    this.updateMainIdGenerationRule({idKey: CommonIngestionKeys.VIRTUAL_ACCOUNT_ID})
    this.addIdGenerationRules([
      {
        idGenerationRule: {
          source_id: 'ParentID'
        },
        idKey: 'ParentID'
      },
      {
        idGenerationRule: {
          source: 'ProductSourceSystem',
          source_id: 'ProductSourceID'
        },
        idKey: 'ProductID'
      },
      {
        idGenerationRule: {
          source: 'ContainingVirtualAccountSourceSystem',
          source_id: 'ContainingVirtualAccountSourceID'
        },
        idKey: 'ContainingVirtualAccountID'
      }
    ])
  }

}
import { DbType } from '../../../types'
import {generateUpsertProductFamilyBody} from '../../../payloads/Product/4101_ProductFamily_Upsert_0001'
import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class ProductFamilyMessage extends BaseMessage{

  constructor() {
    super(
      'upsert-productfamily',
      [
        {
          dataBaseName: DbName.product,
          tableName: 'public.productfamily',
          ignoreKeys: ['InvestmentManagerSourceID', 'InvestmentManagerSourceSystem'],
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.productfamily',
          ignoreKeys: ['InvestmentManagerSourceID', 'InvestmentManagerSourceSystem'],
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.investorportal,
          tableName: 'cmd.productfamily',
          ignoreKeys: ['InvestmentManagerSourceID', 'InvestmentManagerSourceSystem'],
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.productfamily_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertProductFamilyBody,
      {
        keysForMessageKeyGeneration: ['ProductFamilyID', historianMessageKeyUpdateTimestamp],
        schemaid: '0x40010001'
      }
    )
    this.updateMainIdGenerationRule({idKey: 'ProductFamilyID'})
    this.addIdGenerationRules({
      idGenerationRule: {
        source: 'InvestmentManagerSourceSystem',
        source_id: 'InvestmentManagerSourceID'
      },
      idKey: 'InvestmentManagerID'
    })
  }

}
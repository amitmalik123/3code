import { CommonIngestionKeys, DbType } from '../../../types'
import {generateUpsertUserBody} from '../../../payloads/Authorization/6100_User_Ingest_0004'
import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class UserMessage extends BaseMessage{

  constructor() {
    super(
      'upsert-user',
      [
        {
          dataBaseName: DbName.auth,
          tableName: 'cmd.user',
          dbType: DbType.COMMAND
        },
        // todo: uncomment after ingestion api will push data to advisormetrics
        // {
        //   dataBaseName: DbName.advisormetrics,
        //   tableName: 'cmd.user',
        //   dbType: DbType.PUBLISH
        // },
        {
          dataBaseName: DbName.investorportal,
          tableName: 'cmd.user',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.user_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertUserBody,
      {
        needToGenerateIdKeys: false,
        keysForMessageKeyGeneration: [CommonIngestionKeys.SOURCE_ID, historianMessageKeyUpdateTimestamp],
        schemaid: '0x60000004'
      }
    )
  }

}
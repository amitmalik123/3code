import { CommonIngestionKeys, DbType } from '../../../types'
import {generateIngestUnrealizedGainLossBody} from '../../../payloads/AccountData/310A_UnrealizedGainLoss_Ingest_0001'
import {BaseMessage} from '../base-message'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class UnrealizedGainLossMessage extends BaseMessage{

  constructor() {
    super(
      'unrealizedgainloss',
      [
        {
          dataBaseName: DbName.accountdata,
          tableName: 'cmd.unrealizedgainloss',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.unrealizedgainloss',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.unrealizedgainloss',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.unrealizedgainloss_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateIngestUnrealizedGainLossBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.SOURCE_ACCOUNT_ID],
        schemaid: '0x300A0001'
      }
    )
  }

}
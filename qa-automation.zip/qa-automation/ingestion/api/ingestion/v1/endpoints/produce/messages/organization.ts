import { DbType } from '../../../types'
import {generateUpsertOrganizationBody} from '../../../payloads/OrganizationGraph/1100_OrganizationGraph_Upsert_0002'
import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class OrganizationMessage extends BaseMessage{

  constructor() {
    super(
      'upsert-organization',
      [
        {
          dataBaseName: DbName.organization,
          tableName: 'public.organization',
          ignoreKeys: ['ParentSourceID'],
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.organization',
          ignoreKeys: ['ParentSourceID'],
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.proposal,
          tableName: 'cmd.organization',
          ignoreKeys: ['ParentSourceID'],
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.organization',
          ignoreKeys: ['ParentSourceID'],
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.investorportal,
          tableName: 'cmd.organization',
          ignoreKeys: ['ParentSourceID'],
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.organization_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertOrganizationBody,
      {
        keysForMessageKeyGeneration: ['OrganizationID', historianMessageKeyUpdateTimestamp],
        schemaid: '0x10000002'
      }
    )

    this.updateMainIdGenerationRule({idKey: 'OrganizationID'}) 
    this.addIdGenerationRules({
      idGenerationRule: {
        source_id: 'ParentSourceID'
      },
      idKey: 'ParentOrganizationID'
    })
  }

}
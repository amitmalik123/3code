import { CommonIngestionKeys, DbType } from '../../../types'
import {generateUpsertFlowsBody} from '../../../payloads/AccountData/310B_Flows_Ingest_0001'
import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class FlowsMessage extends BaseMessage{

  constructor() {
    super(
      'flows',
      [
        {
          dataBaseName: DbName.accountdata,
          tableName: 'cmd.flows',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.flows',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.flows',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.flows_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertFlowsBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.VIRTUAL_ACCOUNT_ID, historianMessageKeyUpdateTimestamp],
        schemaid: '0x300B0001',
        requiredFields: [CommonIngestionKeys.SOURCE_SYSTEM, CommonIngestionKeys.SOURCE_ID, 'FlowDate']
      }
    )
    this.updateMainIdGenerationRule({idKey: CommonIngestionKeys.VIRTUAL_ACCOUNT_ID})
  }

}
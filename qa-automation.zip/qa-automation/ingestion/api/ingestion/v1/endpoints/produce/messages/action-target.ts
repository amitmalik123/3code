import { CommonIngestionKeys, DbType } from '../../../types'
import {BaseMessage} from '../base-message'
import { getHistorianDbInfo } from '../../../../utils'
import {generateIngestActionTargetBody} from '../../../payloads/WorkflowActions/9300_IngestActionTarget_Upsert_0001'
import { DbName } from '../../../../../../../db/db-config'

export class ActionTargetMessage extends BaseMessage{

  constructor() {
    super(
      'upsert_actiontarget',
      [
        {
          dataBaseName: DbName.worktracking,
          tableName: 'cmd.upsert_actiontarget',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.proposal,
          tableName: 'cmd.upsert_actiontarget',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.upsert_actiontarget_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateIngestActionTargetBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.ACTION_ID, CommonIngestionKeys.TARGET_ID],
        schemaid: '0x92000001',
        requiredFields: [CommonIngestionKeys.TARGET_SOURCE_SYSTEM, CommonIngestionKeys.TARGET_SOURCE_ID],
        distinctKey: CommonIngestionKeys.TARGET_SOURCE_ID
      }
    )
    this.updateMainIdGenerationRule({
      idKey: CommonIngestionKeys.TARGET_ID,
      idGenerationRule: {
        source: CommonIngestionKeys.TARGET_SOURCE_SYSTEM,
        source_id: CommonIngestionKeys.TARGET_SOURCE_ID
      }
    })
  }

}
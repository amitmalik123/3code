import { CommonIngestionKeys, DbType } from '../../../types'
import {generateUpsertSummaryPerformanceBody} from '../../../payloads/AccountData/3111_SummaryPerformance_Ingest_0002'
import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class SummaryPerformanceMessage extends BaseMessage{

  constructor() {
    super(
      'summaryperformance',
      [
        {
          dataBaseName: DbName.accountdata,
          tableName: 'cmd.summary_performance',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.summary_performance',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.goals,
          tableName: 'cmd.summary_performance',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.investorportal,
          tableName: 'cmd.summary_performance',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.summary_performance_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertSummaryPerformanceBody,
      {
        keysForMessageKeyGeneration: [CommonIngestionKeys.TARGET_ID, 'TargetType', historianMessageKeyUpdateTimestamp],
        schemaid: '0x30110002',
        requiredFields: [CommonIngestionKeys.TARGET_SOURCE_SYSTEM, CommonIngestionKeys.TARGET_SOURCE_ID],
        distinctKey: CommonIngestionKeys.TARGET_SOURCE_ID
      }
    )
    this.updateMainIdGenerationRule({
      idKey: CommonIngestionKeys.TARGET_ID,
      idGenerationRule: {
        source: CommonIngestionKeys.TARGET_SOURCE_SYSTEM,
        source_id: CommonIngestionKeys.TARGET_SOURCE_ID
      }
    })
  }

}
import { DbType } from '../../../types'
import {generateUpsertInvestmentManagerBody} from '../../../payloads/Product/4100_InvestmentManager_Upsert_0001'
import {BaseMessage} from '../base-message'
import { historianMessageKeyUpdateTimestamp } from '../../../../utils'
import { getHistorianDbInfo } from '../../../../utils'
import { DbName } from '../../../../../../../db/db-config'

export class InvestmentManagerMessage extends BaseMessage{

  constructor() {
    super(
      'upsert-investmentmanager',
      [
        {
          dataBaseName: DbName.product,
          tableName: 'public.investmentmanager',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.advisormetrics,
          tableName: 'cmd.investmentmanager',
          dbType: DbType.PUBLISH
        },
        {
          dataBaseName: DbName.investorportal,
          tableName: 'cmd.investmentmanager',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.investmentmanager_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateUpsertInvestmentManagerBody,
      {
        keysForMessageKeyGeneration: ['InvestmentManagerID', historianMessageKeyUpdateTimestamp],
        schemaid: '0x40000001'
      }
    )
    this.updateMainIdGenerationRule({idKey: 'InvestmentManagerID'})
  }

}
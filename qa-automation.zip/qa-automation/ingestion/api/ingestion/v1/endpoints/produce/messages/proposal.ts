import { DbType } from '../../../types'
import {BaseMessage} from '../base-message'
import { getHistorianDbInfo } from '../../../../utils'
import { generateProposalUpsertBody } from '../../../payloads/Proposal/8301_Proposal_Upsert_0001'
import { DbName } from '../../../../../../../db/db-config'

export class ProposalMessage extends BaseMessage{

  constructor() {
    super(
      'proposal',
      [
        {
          dataBaseName: DbName.proposal,
          tableName: 'cmd.proposal',
          dbType: DbType.COMMAND
        },
        getHistorianDbInfo('cmd.proposal_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateProposalUpsertBody,
      {
        keysForMessageKeyGeneration: ['ProposalID'],
        schemaid: '0x82010001'
      }
    )
    this.updateMainIdGenerationRule({idKey: 'ProposalID'}) 
    this.addIdGenerationRules({
      idGenerationRule: {
        source: 'ParentSourceSystem',
        source_id: 'ParentSourceID'
      },
      idKey: 'ParentID'
    })
  }

}
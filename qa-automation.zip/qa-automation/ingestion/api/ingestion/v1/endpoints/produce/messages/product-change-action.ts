import {BaseMessage} from '../base-message'
import { getHistorianDbInfo } from '../../../../utils'
import {
  generateIngestProductChangeActionBody
} from '../../../payloads/WorkflowActions/9302_IngestProductChangeAction_Upsert_0001'
import { CommonIngestionKeys, DbType } from '../../../types'
import { DbName } from '../../../../../../../db/db-config'

export class ProductChangeActionMessage extends BaseMessage{

  constructor() {
    super(
      'upsert_productchangeaction',
      [
        {
          dataBaseName: DbName.worktracking,
          tableName: 'cmd.upsert_productchangeaction',
          dbType: DbType.COMMAND
        },
        {
          dataBaseName: DbName.proposal,
          tableName: 'cmd.upsert_productchangeaction',
          dbType: DbType.PUBLISH
        },
        getHistorianDbInfo('cmd.upsert_productchangeaction_publish', DbType.HISTORIAN_PUBLISH)
      ],
      generateIngestProductChangeActionBody,
      {
        needToGenerateIdKeys: false,
        keysForMessageKeyGeneration: [CommonIngestionKeys.ACTION_ID],
        schemaid: '0x92020001',
        requiredFields: [CommonIngestionKeys.ACTION_ID],
        distinctKey: CommonIngestionKeys.ACTION_ID
      }
    )
  }

}
import {BaseApiClass, BaseApiEndpoint, HttpMethod} from '../../../../../base/base-endpoint'
import {IngestionConfig} from '../../../../service-data/config'
import {Produce} from './produce/produce'

export class IngestionV1 extends BaseApiClass{
  constructor(route: string = '/ingestion/api/v1', packagePath: string = 'ingestion/api/ingestion/v1') {
    super(route, packagePath)
  }
  public readonly produce: Produce = new Produce()

  public readonly auth: Auth = new Auth('', this.packagePath)
}

class Auth extends BaseApiClass{
  makeLogin : BaseApiEndpoint = {
    method: HttpMethod.POST,
    route: 'https://login.microsoftonline.com/ff93c4a0-f87d-46ad-b4be-3ee05cefec6b/oauth2/v2.0/token',
    extraHeaders: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    formData: {
      grant_type: 'client_credentials',
      client_id: IngestionConfig.INGESTION_CLIENT_ID,
      client_secret: IngestionConfig.INGESTION_CLIENT_SECRET,
      scope: IngestionConfig.INGESTION_SCOPE
    },
    title: 'Make Login'

  }
}

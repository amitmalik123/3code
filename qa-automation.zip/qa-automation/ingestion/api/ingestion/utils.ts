import { DbName } from '../../../db/db-config'
import { DateFormatters } from '../../../utils/date-farmatters'
import { CommonIngestionKeys, DbType, IngestionTargetDbInfo, KeysForMessageKeyGeneration } from './v1/types'

/**
 * Retrieves information about a historian database.
 *
 * @param tableName - The name of the table in the historian database.
 * @param dbType - The type of the database, either HISTORIAN_COMMAND or HISTORIAN_PUBLISH.
 * @returns An object containing information about the ingestion target database, including
 * the database name, table name, database type, distinct key, and not-null keys.
 */

export function getHistorianDbInfo(tableName: string, dbType: DbType.HISTORIAN_COMMAND | DbType.HISTORIAN_PUBLISH): IngestionTargetDbInfo {
  return {
    dataBaseName: DbName.historian,
    tableName,
    dbType,
    distinctKey: 'messagekey',
    notNullKeys: ['avromessage'],
  }
}/**
 * Modifies the 'UPDATE_TIMESTAMP' field of the given object by removing milliseconds and using default date format like "2024-07-17 23:15:47"
 * @param obj - The item from ingestion request body containing the 'UPDATE_TIMESTAMP' field.
 * @returns The modified timestamp without milliseconds.
 */

export function historianMessageKeyUpdateTimestamp(obj: any) {
  return DateFormatters.removeMilliseconds(obj[CommonIngestionKeys.UPDATE_TIMESTAMP], false)
}
/**
 * Builds a message key by concatenating values from the object based on the keys array.
 * @param obj - The item from ingestion request body containing keys from keyArr.
 * @param keyArr - An array of strings or functions for key modification.
 * @returns A concatenated string of values from the object, separated by underscores.
 */

export function buildMessageKey(obj: any, keyArr: KeysForMessageKeyGeneration[]) {
  return keyArr.map(key => {
    if (typeof key === 'string') {
      return obj[key]
    } else if (typeof key === 'function') {
      return key(obj)
    }
    return ''
  }).join('_')
}


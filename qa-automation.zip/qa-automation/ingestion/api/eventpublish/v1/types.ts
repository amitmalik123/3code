import {HttpMethod} from '../../../../base/base-endpoint'

export interface Subscriber {
  id?:                       string;
  authenticationAttributes: { [key: string]: string };
  authenticationScheme:     string | 'None';
  authenticationType:       string | 'None';
  baseUrl:                  string;
  customHeaders:            { [key: string]: string };
  name:                     string;
  subscriptions:            Subscription[];
}

export interface Subscription {
  id?:           string;
  subscriberID?: string;
  name:         string;
  parameters:   SubscriptionParameters;
}

export interface SubscriptionParameters {
  actionVerb:                HttpMethod;
  batchSize:                 number;
  messageTypes:              SubscriptionMessageType[] | string[];
  notification:              SubscriptionNotification;
  status:                    SubscriptionStatus;
  subscriptionType:          SubscriptionType;
  url:                       string;
  waitBeforeActionInSeconds: number;
}

export interface SubscriptionNotification {
  address:          string;
  notificationType: SubscriptionNotificationType;
}

export enum SubscriptionNotificationType {
  Email = 'Email',
}

export enum SubscriptionStatus {
  Active = 'Active',
  Disabled = 'Disabled',
  Failed = 'Failed',
}

export enum SubscriptionType {
  WebHook = 'WebHook',
}

export enum SubscriptionMessageType {
  BenefitLevel = 'BenefitLevel',
  UpsertProduct = 'UpsertProduct',
  UpsertGoal = 'UpsertGoal',
  Flows = 'Flows',
  MarketValue = 'Marketvalue',
  UpsertContact = 'UpsertContact',
  UpsertHoldings = 'UpsertHoldings',
  UpsertInvestmentManager = 'UpsertInvestmentManager',
  UpsertNonFinancialData = 'UpsertNonfinancialData',
  UpsertOrganization = 'UpsertOrganization',
  UpsertPerformance = 'UpsertPerformance',
  UpsertProductFamily = 'UpsertProductFamily',
  UpsertSourceAccount = 'UpsertSourceAccount',
  UpsertSummaryPerformance = 'UpsertSummaryPerformance',
  UpsertVirtualAccount = 'UpsertVirtualAccount',
  Fee = 'Fee',
  UpsertWorkItem = 'UpsertWorkItem',
  UpsertGroup = 'UpsertGroup',
  UpsertProposal = 'UpsertProposal',
  User = 'User'
}

import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Subscriber} from '../types'
import {Random} from '../../../../../utils/random'
import {generateEventPublishSubscription} from './subscription'
import { IngestionConfig } from '../../../../service-data/config'

export function generateEventPublishSubscriber(options?: { subscriberId?: string, generateSubscriptionsId?: boolean } ): Subscriber {
  return {
    id: options?.subscriberId,
    name: `${IngestionConfig.API_TEST_ITEM_TAG} subscriber name ${uuid()}`,
    baseUrl: faker.internet.url(),
    authenticationScheme: faker.word.noun(),
    authenticationType: faker.word.adjective(),
    authenticationAttributes: faker.datatype.boolean() ? Random.generateRandomKeyValuePairs() : {},
    customHeaders: faker.datatype.boolean() ? Random.generateRandomKeyValuePairs() : {},
    subscriptions: Array.from({length: faker.number.int({min: 1, max: 10})}, () => generateEventPublishSubscription(options))
  }
}

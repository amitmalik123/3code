import {
  Subscription,
  SubscriptionMessageType,
  SubscriptionNotification,
  SubscriptionNotificationType,
  SubscriptionParameters, SubscriptionStatus,
  SubscriptionType
} from '../types'
import {v4 as uuid} from 'uuid'
import {faker} from '@faker-js/faker'
import {Random} from '../../../../../utils/random'
import {HttpMethod} from '../../../../../base/base-endpoint'
import { IngestionConfig } from '../../../../service-data/config'

export function generateEventPublishSubscription(options?: { subscriberId?: string, generateSubscriptionsId?: boolean } ): Subscription {
  const { generateSubscriptionsId = false } = options ?? {}
  return {
    id: generateSubscriptionsId ? uuid() : undefined,
    subscriberID: options?.subscriberId,
    name: `${IngestionConfig.API_TEST_ITEM_TAG} subscription name ${uuid()}`,
    parameters: generateSubscriptionParameters()
  }
}

function generateSubscriptionParameters(): SubscriptionParameters {
  return {
    status: Random.getEnumValue(SubscriptionStatus),
    subscriptionType: Random.getEnumValue(SubscriptionType),
    messageTypes: Random.getEnumValuesArray(SubscriptionMessageType, faker.number.int({min: 1, max: 3})),
    actionVerb: Random.getEnumValue(HttpMethod),
    waitBeforeActionInSeconds: faker.number.int({min: 0, max: 60}),
    url: faker.internet.url({appendSlash: true}) + uuid(),
    batchSize: faker.number.int({min: 1, max: 500}),
    notification: generateSubscriptionNotification()
  }
}

function generateSubscriptionNotification(): SubscriptionNotification {
  return {
    notificationType: Random.getEnumValue(SubscriptionNotificationType),
    address: Random.getAlphanumericString(10) + faker.internet.email()
  }
}
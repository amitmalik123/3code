import {BaseApiClass, BaseApiEndpoint, HttpMethod} from '../../../../base/base-endpoint'
import {Subscriber, Subscription} from './types'
import {generateEventPublishSubscriber} from './payloads/subscriber'
import {generateEventPublishSubscription} from './payloads/subscription'
import {faker} from '@faker-js/faker'

export class EventPublishV1 extends BaseApiClass {

  constructor() {
    super('/eventpublish/subscriptions/api/v1', 'ingestion/api/eventpublish/v1')
  }

  public readonly subscriptions: Subscriptions = new Subscriptions(`${this.route}/subscriptions`, this.packagePath)
}
class Subscriptions extends BaseApiClass{

  getSubscribers(): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}/subscribers`,
      schema: this.getSchema('subscribers-array'),
      title: `Get subscribers list`
    }
  }

  postSubscribers(body: Subscriber | object = generateEventPublishSubscriber()): BaseApiEndpoint{
    return {
      method: HttpMethod.POST,
      route: `${this.route}/subscribers`,
      body,
      title: `Create new subscriber`
    }
  }

  getSubscriberById(subscriberId: string = '{subscriberID}'): BaseApiEndpoint {
    return {
      method: HttpMethod.GET,
      route: `${this.route}/subscribers`,
      pathParameters: subscriberId,
      schema: this.getSchema('subscriber'),
      title: `Get subscriber by id`
    }
  }

  putSubscriber(subscriberId: string = '{subscriberID}', body: Subscriber | object = generateEventPublishSubscriber({ subscriberId })): BaseApiEndpoint{
    return {
      method: HttpMethod.PUT,
      route: `${this.route}/subscribers`,
      pathParameters: subscriberId,
      body,
      title: `Update existing subscriber by id`
    }
  }

  deleteSubscriber(subscriberId: string = '{subscriberID}'): BaseApiEndpoint {
    return {
      method: HttpMethod.DELETE,
      route: `${this.route}/subscribers`,
      pathParameters: subscriberId,
      title: `Delete subscriber by id`
    }
  }

  getSubscriptionsArrayBySubscriberId(subscriberID: string = '{subscriberID}'): BaseApiEndpoint {
    const pathParameters = [subscriberID, 'subscriptions']
    return {
      method: HttpMethod.GET,
      route: `${this.route}/subscribers`,
      pathParameters,
      schema: this.getSchema('subscriptions-array'),
      title: `Get subscriptions array by subscriber's id`
    }
  }

  getSubscriptionBySubscriberId(subscriberId: string = '{subscriberID}', subscriptionId: string = '{subscriptionID}'): BaseApiEndpoint {
    const pathParameters = [subscriberId, 'subscriptions', subscriptionId]
    return {
      method: HttpMethod.GET,
      route: `${this.route}/subscribers`,
      pathParameters,
      schema: this.getSchema('subscription'),
      title: `Get subscription by subscriber's id`
    }
  }

  postSubscriptionsBySubscriberId(
    subscriberId: string = '{subscriberID}',
    body: Subscription[] | object = Array.from({length: faker.number.int({min: 1, max: 10})},
      () => generateEventPublishSubscription({ subscriberId }))): BaseApiEndpoint{
    const pathParameters = [subscriberId, 'subscriptions']
    return {
      method: HttpMethod.POST,
      route: `${this.route}/subscribers`,
      pathParameters,
      body,
      title: `Post subscriptions to existing subscriber by id`
    }
  }
}
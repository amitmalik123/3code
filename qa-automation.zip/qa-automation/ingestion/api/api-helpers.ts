import {BaseApiHelpers} from '../../base/base-api-helpers'
import {CommonIngestionKeys, IngestionProduceErrors, IngestionProduceResponseBodyError} from './ingestion/v1/types'
import {APIResponse, test} from '@playwright/test'
import { DbType } from './ingestion/v1/types'
import { IngestionTargetDbInfo } from './ingestion/v1/types'
import { IngestionApiEndpoint } from './ingestion/v1/types'
import { executeWithRetry, sleep } from '../../utils/generalUtils'
import { IngestionConfig } from '../service-data/config'
import { BaseMessage } from './ingestion/v1/endpoints/produce/base-message'
import { buildMessageKey } from './ingestion/utils'
import { expect } from '../../utils/playwright-expect-extension'
import DataTransformUtils from '../../utils/data-transform'
import { DBAccessHelpers } from '../../db/db-access-helpers'

export class IngestionApiHelpers extends BaseApiHelpers {

  async validateErrorResponse(response: APIResponse, errorText: string = response.statusText()) {
    await test.step(`Then: validate single error response body`, async () => {
      const responseBody: IngestionProduceResponseBodyError = await response.json()
      await this.generalValidateErrorResponse(response)
      expect(responseBody.title, 'Validate "status text"').toEqual(errorText)
    })
  }

  async validateMultipleErrorsResponse(response: APIResponse, errors?: IngestionProduceErrors) {
    await test.step(`Then: validate multiple error response body`, async () => {
      const responseBody: IngestionProduceResponseBodyError = await response.json()
      await this.generalValidateErrorResponse(response)
      expect(responseBody.title, 'Validate "status text"').toEqual('One or more validation errors occurred.')
      await test.step(`Then: validate error object`, async () => {
        if (errors){
          expect(responseBody.errors, 'Validate errors object').toEqual(errors)
        } else {
          expect(responseBody.errors, 'Expect errors object to be defined').toBeDefined()
        }
      })
    })
  }

  private async generalValidateErrorResponse(response: APIResponse) {
    await test.step(`Validate general error response body properties`, async () => {
      const responseBody: IngestionProduceResponseBodyError = await response.json()
      expect(responseBody.type, 'Expect "type" to be defined').toBeDefined()
      expect(responseBody.status, 'Validate "status code"').toEqual(response.status())
      expect(responseBody.traceId, 'Expect "traceId" to be defined').toBeDefined()
    })
  }

  /**
   * Get IDs values from ingestion DB to enrich endpoint data with IDs 
   * and complete endpoint.expectedHistorianData to test historian DB output
   * 
   * Enriching increses assert coverage + makes DB query faster because ID fields are indexed
   * 
   * @param endpoint - ingestion API endpoint that need to be enriched with info from ingestion DB
   */
  public async enrichEndpointData(endpoint: IngestionApiEndpoint){
    await test.step(`Enrich endpoint: "${endpoint.title}" (if it is required)`, async () => {
    
    type PlatFromCodeDbOutput = {
      source: string,
      source_id: string, 
      platform_code: string
    }
    const db = new DBAccessHelpers()
    if (endpoint.idGenerationDbInfo) {
      await test.step(`Generating ID keys data`, async () => {
   
        for (let i = 0; i < endpoint.idGenerationDbInfo!.length; i++) {
          const bodyEnrichingInfo = endpoint.idGenerationDbInfo![i]
          await test.step(`Generating ID key "${bodyEnrichingInfo.idKey}" using data from "${bodyEnrichingInfo.idGenerationRule.source}" and "${bodyEnrichingInfo.idGenerationRule.source_id}"`, async () => {
         
            const dbOutput: PlatFromCodeDbOutput[] = await db.getDataFromDB(bodyEnrichingInfo)
            for (const body of endpoint.body) {
              body[bodyEnrichingInfo.idKey] = dbOutput.find(item => item.source_id === body[bodyEnrichingInfo.idGenerationRule.source_id!])?.platform_code
            }
          })
        
        }

        // Update query condition fields for DBinfo object
        for (const dbInfo of endpoint.dbInfo) {
          dbInfo.queryConditionField = endpoint.idKey
        }
      })
    }

    // Generate expected historian data
    await test.step(`Generating historian DB output expected body`, async () => {
    
      endpoint.expectedHistorianData = []
      for (const body of endpoint.body) {

        endpoint.expectedHistorianData.push({
          messagekey: buildMessageKey(body, endpoint.keysForMessageKeyGeneration),
          jsonmessage: null,
          schemaid: endpoint.schemaid,
          updatetimestamp: body[CommonIngestionKeys.UPDATE_TIMESTAMP]
        })
      
      }
    })
    })

  }

  async assertResponseBodySuccess(response: APIResponse, successMessage = '"All messages processed"') {
    expect(await response.text(), `Assert success ingestion response body equals: ${successMessage}`).toEqual(successMessage)
  }

  /**
   * Async DB data presence assert
   * 
   * Goes to all passed dbInfo(target DBs) and validates data presence
   * 
   * @param message - ingestion api message
   * @param endpoint - ingestion api endpoint
   * @param dbInfo - target DB info array
   * @throws All target DB data compare errors
   */
  async assertDataInDB(message: BaseMessage, endpoint: IngestionApiEndpoint,  dbInfo: IngestionTargetDbInfo[]){
    const republish = endpoint?.queryParameters?.republish ?? false
    const asyncTasks = dbInfo.map(async dbInfoItem => {
      await test.step(`Assert that data is presented in DB: "${dbInfoItem.dataBaseName}"; Table: "${dbInfoItem.tableName}"`, async () => {
        const updatedDbInfo = message.rebuildDbInfo(endpoint.body, dbInfoItem)
        let dbOutput: object[] = []
        const db = new DBAccessHelpers()
        await executeWithRetry(async () => {
          await sleep(IngestionConfig.DB_DATA_INSERT_WAITING_TIME)
          dbOutput = await db.getDataFromDB(updatedDbInfo)
          // If republish query parameter was not passed
          // OR dbInfoItem.dbType is DbType.PUBLISH
          // Then comparing DB output in a regular way
          if ((!republish && dbInfoItem.dbType === DbType.COMMAND)  || dbInfoItem.dbType === DbType.PUBLISH){
            expect(dbOutput, `Expect DB: ${updatedDbInfo.dataBaseName} TABLE: ${updatedDbInfo.tableName} not to be empty`).not.toEqual([])

            await test.step(`Compare passed to ingestion response body with actual DB output`, async () => {
              const expected = await DataTransformUtils.modifyObjectArray(endpoint.body, {
                toLowerCase: true,
                keyReplacementRules: updatedDbInfo.keyReplacementRules,
                removeKeys: updatedDbInfo.ignoreKeys
              })
              expect(dbOutput,
                `Expect DB: ${updatedDbInfo.dataBaseName} TABLE: ${updatedDbInfo.tableName} to has all processed items`
              ).toContainArrayItems(expected, {
                distinctKey: updatedDbInfo.distinctKey?.toLocaleLowerCase(),
                notNullKeys: updatedDbInfo.notNullKeys
              })

            })

            if (updatedDbInfo.queryConditionField) expect( dbOutput.length,
              `Expect that count of DB: ${updatedDbInfo.dataBaseName} TABLE: ${updatedDbInfo.tableName} rows is the same that was passed to ingestion: "${endpoint.body.length}"`
            ).toEqual(endpoint.body.length)

          } else if (republish && dbInfoItem.dbType === DbType.COMMAND){
            // In case if republish === true and dbInfoItem.dbType === DbType.COMMAND
            // Then we need to make sure that data is not presented in Command DB
            expect(dbOutput, `Expect that command DB output is empty`).toEqual([])
          } else if (dbInfoItem.dbType === DbType.HISTORIAN_COMMAND || dbInfoItem.dbType === DbType.HISTORIAN_PUBLISH){

            expect(dbOutput, `Expect DB: ${updatedDbInfo.dataBaseName} TABLE: ${updatedDbInfo.tableName} not to be empty`).not.toEqual([])
            expect(dbOutput,
              `Expect DB: ${updatedDbInfo.dataBaseName} TABLE: ${updatedDbInfo.tableName} to has all processed items`
            ).toContainArrayItems(endpoint.expectedHistorianData!, {
              distinctKey: updatedDbInfo.distinctKey?.toLocaleLowerCase(),
              notNullKeys: updatedDbInfo.notNullKeys
            })
            expect( dbOutput.length,
              `Expect that count of DB: ${updatedDbInfo.dataBaseName} TABLE: ${updatedDbInfo.tableName} rows is the same that was passed to ingestion: "${endpoint.body.length}"`
            ).toEqual(endpoint.body.length)
            
          }
        }, IngestionConfig.DB_DATA_INSERT_RETRIES_COUNT)
      })
    })
    const results = await Promise.allSettled(asyncTasks)

    const errors = results
      .filter(result => result.status === 'rejected')
      .map(result => {
        const reason = (result as PromiseRejectedResult).reason
        return reason.message
      })

    if(errors.length > 0) throw new Error(errors.join('\n\n'))
  }
  
}
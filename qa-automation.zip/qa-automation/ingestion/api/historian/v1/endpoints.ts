
import { BaseApiClass, BaseApiEndpoint, HttpMethod } from '../../../../base/base-endpoint'
import { ReplayRequestBody, generateReplayRequestBody } from './payloads/replay'

export class HistorianV1 extends BaseApiClass {

  constructor() {
    super('/historian/api/v1', 'ingestion/api/historian/v1')
  }

  public readonly replay: Replay = new Replay(`${this.route}/replay`, this.packagePath)
}
class Replay extends BaseApiClass{

  /**
   * Replay a message to specific consumer group
   * 
   * @param messageName - message name to replay. Accepts the same message name value as ingestion api produce message endpoint
   * @param body - replay request body. By defatult generates random value
   * @returns {BaseApiEndpoint} historian replay by message name enpoint object
   */
  byMessageName(messageName: string = '{ingestion_api_message_name}', body: ReplayRequestBody | object = generateReplayRequestBody()): BaseApiEndpoint{
    return {
      method: HttpMethod.PUT,
      route: `${this.route}`,
      pathParameters: messageName,
      body,
      title: `Replay by message name`
    }
  }
}
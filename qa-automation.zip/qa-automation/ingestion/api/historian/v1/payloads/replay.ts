import { faker } from '@faker-js/faker'
import { Random } from '../../../../../utils/random'

export enum HistorianConsumerGroup {
  accountdata = 'accountdata',
  advisorbenefits = 'advisorbenefits',
  advisormetrics = 'advisormetrics',
  auth = 'auth',
  contact = 'contact',
  feebilling = 'feebilling',
  goals = 'goals',
  organization = 'organization',
  product = 'product',
  proposal = 'proposal',
  worktracking = 'worktracking'
}

export enum HistorianSuffix {
  publish = 'publish',
  command = 'command'
}

export interface ReplayRequestBody {
  /**
   * Intended consumer group. Usually match command/publish DB name
   * 
   * Example value: "product"
   */
  consumerGroup: string | HistorianConsumerGroup
  /**
   * Suffix to replay. publish/command 
   * 
   * Example value: "publish"
   */
  suffix: string | HistorianSuffix
  /**
   * Start date. In ISO format.
   * If null will replay from beginning to EndDate.
   * 
   * Example value: "2024-01-02T17:15:06.141Z"
   */
  startDate?: Date | null
  /**
   * End date. In ISO format.
   * If null will replay from StartDate until the end.
   * 
   * Example value: "2024-07-02T17:15:06.141Z"
   */
  endDate?: Date | null
}

export function generateReplayRequestBody(): ReplayRequestBody{
  return {
    consumerGroup: Random.getEnumValue(HistorianConsumerGroup),
    suffix: Random.getEnumValue(HistorianSuffix),
    startDate: faker.date.past(),
    endDate: faker.date.recent()
  }
}
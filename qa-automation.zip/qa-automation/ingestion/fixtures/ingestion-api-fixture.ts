import {type APIRequestContext, test as base, request} from '@playwright/test'
import {IngestionConfig} from '../service-data/config'

// Declare the types of your fixtures.
type MyFixtures = {
    ingestionRequestContext: APIRequestContext
    ingestionUnauthorizedContext: APIRequestContext
    ingestionExpiredTokenContext: APIRequestContext
}

const baseURL = process.env.INGESTION_API_BASE_URL ?? IngestionConfig.BASE_URL

export const test = base.extend<MyFixtures>({

  ingestionRequestContext: async ({ }, use) => {
    const context = await request.newContext({
      baseURL,
      timeout: IngestionConfig.API_RESPONSE_TIMEOUT,
      extraHTTPHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `${IngestionConfig.parseJsonWithToken(IngestionConfig.AUTH_API_PATH)}`,
      }
    })
    await use(context)
  },

  ingestionUnauthorizedContext: async ({ }, use) => {
    const context = await request.newContext({
      baseURL,
      timeout: IngestionConfig.API_RESPONSE_TIMEOUT,
      extraHTTPHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    })

    await use(context)
  },

  ingestionExpiredTokenContext: async ({ }, use) => {
    const context = await request.newContext({
      baseURL,
      timeout: IngestionConfig.API_RESPONSE_TIMEOUT,
      extraHTTPHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IjVCM25SeHRRN2ppOGVORGMzRnkwNUtmOTdaRSIsImtpZCI6IjVCM25SeHRRN2ppOGVORGMzRnkwNUtmOTdaRSJ9.eyJhdWQiOiJhcGk6Ly8xMWZlMjVjZC00MzZjLTQ3NTMtYTg3NS0yMDk0OGVkZjE0NWEiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mZjkzYzRhMC1mODdkLTQ2YWQtYjRiZS0zZWUwNWNlZmVjNmIvIiwiaWF0IjoxNzA1OTYxODQ1LCJuYmYiOjE3MDU5NjE4NDUsImV4cCI6MTcwNTk2NTc0NSwiYWlvIjoiRTJWZ1lLaSs5djlMV1VRWHo1RnIvUTI4cTVtaUFBPT0iLCJhcHBpZCI6IjEyMTgxZjRiLTRmOTEtNGE2OC1iMTAxLWQ4Mjc1NWE4OTk5NyIsImFwcGlkYWNyIjoiMSIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0L2ZmOTNjNGEwLWY4N2QtNDZhZC1iNGJlLTNlZTA1Y2VmZWM2Yi8iLCJvaWQiOiI5MjI3ZGY4Mi0wMGUwLTQwYTctOTIxNi1lZjczZGI1ZTdlYzYiLCJyaCI6IjAuQVhnQW9NU1RfMzM0clVhMHZqN2dYT19zYTgwbF9oRnNRMU5IcUhVZ2xJN2ZGRnA0QUFBLiIsInJvbGVzIjpbIkluZ2VzdGlvblVwbG9hZCJdLCJzdWIiOiI5MjI3ZGY4Mi0wMGUwLTQwYTctOTIxNi1lZjczZGI1ZTdlYzYiLCJ0aWQiOiJmZjkzYzRhMC1mODdkLTQ2YWQtYjRiZS0zZWUwNWNlZmVjNmIiLCJ1dGkiOiJ2eVppTmtQYVJrLTAxUzdfa1Y5YUFBIiwidmVyIjoiMS4wIn0.FxuuRpRgDocYniYDBe-x4djFZHm8cR0bx8cpKaEgkwgCwh1J5ftvfXC18H6kT54AN8EaGNuG8KN3AK_I6ZrBPkpAHnhctmTrysz2xzvjuZoKffyY-CaVoBcsp2ZTiPxgIt-QnjCSpGxj_AAsHdW4wdtNlI-_ojXClq5gvMEY3MjlmUY7w7u4eQux_BagvZK_kekv6EVMntNvUGwoEmIwsz9xnBhLl9O3_ZSvJ_gQoONEmP7VQP__FAuIr1wQnsCxGvrpzSMqqHd2UC2RgTmzJDaG9MQBAE6y92wwoIEeoMFoRSqWMLfxATrBh_un76VSgfGndSji6sa2fg4QmZGMKw'
      }
    })

    await use(context)
  },

})
export  *  from '@playwright/test'
import {type APIRequestContext, test} from '@playwright/test'
export abstract class BaseApiRequests {

  protected constructor(protected request: APIRequestContext) {
  }

  protected async getRequest(path: string, options?: Object) {
    return await test.step(`When: the user sends a GET request to "${path}"`, async () => {
      return await this.request.get(path, options)
    })
  }

  protected async postRequest(path: string, optionsOrBody?: Object) {
    return await test.step(`When: the user sends a POST request to "${path}"`, async () => {
      return await this.request.post(path, optionsOrBody)
    })
  }

  protected async putRequest(path: string, optionsOrBody?: Object) {
    return await test.step(`When: the user sends a PUT request to "${path}"`, async () => {
      return await this.request.put(path, optionsOrBody)
    })
  }

  protected async deleteRequest(path: string, optionsOrBody?: Object) {
    return await test.step(`When: the user sends a DELETE request to "${path}"`, async () => {
      return await this.request.delete(path, optionsOrBody)
    })
  }

  protected async patchRequest(path: string, optionsOrBody?: Object) {
    return await test.step(`When: the user sends a PATCH request to "${path}"`, async () => {
      return await this.request.patch(path, optionsOrBody)
    })
  }

}
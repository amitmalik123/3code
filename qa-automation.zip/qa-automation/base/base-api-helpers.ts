import {type APIRequestContext, APIResponse, expect, test} from '@playwright/test'
import {BaseApiEndpoint} from './base-endpoint'
import Ajv from 'ajv'
import addFormats from 'ajv-formats'
import { DateFormatters } from '../utils/date-farmatters'

export class BaseApiHelpers {
  private readonly ajv: Ajv
  constructor(protected request: APIRequestContext) {
    this.ajv = new Ajv({ allErrors: true })
    addFormats(this.ajv)
  }

  private async validateResponseStatusCode(statusCode: number, statusText: string, response: APIResponse) {
    await test.step(`Then: the user gets a response with a status code "${statusCode} ${statusText}"`, async () => {
      expect(response.status()).toEqual(statusCode)
      expect(response.statusText()).toEqual(statusText)
    })
  }

  public async makeRequest(endpoint: BaseApiEndpoint) {
    let route =
        endpoint.pathParameters
          ? Array.isArray(endpoint.pathParameters)
            ? `${endpoint.route}/${endpoint.pathParameters.join('/')}`
            : `${endpoint.route}/${endpoint.pathParameters}`
          : endpoint.route

    function buildQueryString(queryParameters: {[key: string]: string | number | boolean | string[]}): string {
      const queryStringParts: string[] = []

      for (const key in queryParameters) {
        if (Object.prototype.hasOwnProperty.call(queryParameters, key)) {
          const value = queryParameters[key]
          const encodedKey = encodeURIComponent(key)
          
          if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
            const encodedValue = encodeURIComponent(value.toString())
            queryStringParts.push(`${encodedKey}=${encodedValue}`)
          } else if (Array.isArray(value)) {
            const encodedValues = value.map((v) => encodeURIComponent(v.toString()))
            queryStringParts.push(...encodedValues.map((v) => `${encodedKey}=${v}`))
          }
        }
      }
      return queryStringParts.join('&')
    }
          
    // Add query param to route string
    route = endpoint.queryParameters ? `${route}?${buildQueryString(endpoint.queryParameters) }` : route

    return await test.step(`When: the user sends a ${endpoint.method} request to "${route}"`, async () => {
      await test.info().attach(`API Request "${endpoint.title}" details ${DateFormatters.getTime()}`,
        {
          body: JSON.stringify(endpoint, null, 2)
        }
      )
      const response = await this.request.fetch(route, {
        method: endpoint.method,
        headers: endpoint?.extraHeaders,
        data: endpoint?.body,
        form: endpoint?.formData,
      })
      let responseBody: string
      try {
        responseBody =  JSON.stringify(await response.json(), null, 2)
      } catch (error){
        responseBody =  await response.text()
      }
      if (responseBody){
        await test.info().attach(
          `API Response "${endpoint.title}" body ${DateFormatters.getTime()}`,
          {
            body: responseBody
          }
        )
      }
      return response
    })
  }

  validateJsonSchema(endpoint:BaseApiEndpoint, json: unknown) {
    const validate = this.ajv.compile(endpoint.schema)
    const isValid = validate(json)
    try{
      expect(isValid, 'Validating JSON body with JSON schema').toBeTruthy()
    } catch (error){
      console.error(validate.errors)
      throw new Error(error)
    }
  }

  async responseIs200(response: APIResponse) {
    await this.validateResponseStatusCode(200, 'OK', response)
  }

  async responseIs201(response: APIResponse) {
    await this.validateResponseStatusCode(201, 'Created', response)
  }

  async responseIs204(response: APIResponse) {
    await this.validateResponseStatusCode(204, 'No Content', response)
  }

  async responseIs207(response: APIResponse) {
    await this.validateResponseStatusCode(207, 'Multi-Status', response)
  }

  async responseIs400(response: APIResponse) {
    await this.validateResponseStatusCode(400, 'Bad Request', response)
  }

  async responseIs401(response: APIResponse) {
    await this.validateResponseStatusCode(401, 'Unauthorized', response)
  }

  async responseIs404(response: APIResponse) {
    await this.validateResponseStatusCode(404, 'Not Found', response)
  }

  async responseIs405(response: APIResponse) {
    await this.validateResponseStatusCode(405, 'Method Not Allowed', response)
  }

  async responseIs500(response: APIResponse) {
    await this.validateResponseStatusCode(500, 'Internal Server Error', response)
  }

  async responseBodyIsEmpty(response: APIResponse, emptyBody = '') {
    expect(await response.text(), 'Assert that response body is empty').toEqual(emptyBody)
  }

  async responseBodyContainsText(response: APIResponse, text: string) {
    expect(await response.text(), 'Assert that response body is empty').toContain(text)
  }

  async responseContainsData(validateDataArray: string[], response: APIResponse) {
    const responseBody = await response.json()
    await test.step(`Then: response body validation`, async () => {
      for (const validateData of validateDataArray) {
        await test.step(`Then: response contains value  "${validateData}"`, async () => {
          //todo: replace with normal
          const data = validateData.split(':')
          if (data.length>1){
            if(data[1].match('^(?:true|false|\\d)$')) data[1] = JSON.parse(data[1])
            expect(responseBody).toHaveProperty(data[0], data[1])
          } else expect(responseBody).toHaveProperty(data[0])
        })
      }
    })
  }

  async responseNotContainsData(validateDataArray: string[], response: APIResponse) {
    const responseBody = await response.json()
    await test.step(`Then: response body validation(does not contains value)`, async () => {
      for (const validateData of validateDataArray) {
        await test.step(`Then: response does not contain value  "${validateData}"`, async () => {
          //todo: replace with normal
          const data = validateData.split(':')
          if (data.length>1){
            if(data[1].match('^(?:true|false|\\d)$')) data[1] = JSON.parse(data[1])
            expect(responseBody).not.toHaveProperty(data[0], data[1])
          } else expect(responseBody).not.toHaveProperty(data[0])
        })
      }
    })
  }

  async responseBodyAndJsonAreEqual(response: APIResponse, json: object) {
    await test.step(`Then: comparing response body and expected JSON`, async () => {
      this.jsonsAreEqual(await response.json(), json)
    })
  }

  jsonsAreEqual(actualJson: object, expectedJson: object) {
    expect(actualJson,'Assert that JSONs are equal').toEqual(expectedJson)
  }

  async jsonContainsData(actualJson: any, expectedJson: any) {
    await test.step(`Then: comparing expected and actual JSON`, async () => {
      expect(actualJson).toEqual(expect.objectContaining(expectedJson))
    })
  }

  async arrayContainsData(actualArray: object[], expectedArray: object[]) {
    await test.step(`Then: comparing expected and actual Array`, async () => {
      expect(actualArray).toEqual(expect.arrayContaining(expectedArray))
    })
  }

}
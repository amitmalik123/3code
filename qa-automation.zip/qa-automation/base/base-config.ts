export abstract class BaseConfig {
  
  public static readonly BASE_URL = process.env['BASE_PAGE_' + (process.env.TARGET_ENV || 'dev').toUpperCase()]

  protected static PROJECT_NAME = 'base_project'
  public static readonly AUTH_FILES_PATH = 'playwright/.auth'

  public static browserStorageState(userName:string): string{
    return `${this.AUTH_FILES_PATH}/${this.PROJECT_NAME}_${userName}.json`
  }

  public static get AUTH_API_PATH():string {
    return `${this.AUTH_FILES_PATH}/${this.PROJECT_NAME}_token.json`
  }

  public static parseJsonWithToken(pathToTokenFile:string): string{
    const fs = require('fs')
    const jsonData = JSON.parse(fs.readFileSync(pathToTokenFile, 'utf-8'))
    return `Bearer ${jsonData.access_token}`
  }

  public static readonly ACTION_TIMEOUT_MEDIUM:number = 45 * 1000
  public static readonly ACTION_TIMEOUT_LONG:number = 60 * 1000
  public static readonly API_RESPONSE_TIMEOUT:number = 10 * 1000
}
import { Page, test } from '@playwright/test'

/**
   * This class is for common Browser metods like download and upload
   *
   */
export class BaseBrowserHelpers {
  constructor(private readonly page: Page) {
  }

  /**
   * Downloads a file triggered by a specified action and saves it with a unique timestamped filename.
   *
   * This method waits for a download event to be triggered by the provided function.
   * It then saves the downloaded file to a specified directory with a filename that includes a unique timestamp.
   *
   * @param trigger - A function that triggers the download event. This can be either synchronous or asynchronous.
   * @returns {Promise<string>} A promise that resolves to the file path where the downloaded file is saved.
   */
  async downloadFile(trigger: () => void | Promise<void>): Promise<string> {
    return await test.step('Verify export CSV file from Accounts tab', async () => {
      const timestamp = Date.now()

      // Start waiting for download before triggering. Note no await.
      const downloadPromise = this.page.waitForEvent('download')
      await trigger()
      const download = await downloadPromise

      const filePath = `./playwright/downloads/${timestamp}/` + download.suggestedFilename()
      await download.saveAs(filePath)

      return filePath
    })
  }
}

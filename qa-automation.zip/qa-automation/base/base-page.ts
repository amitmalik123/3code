import { Page } from '@playwright/test'

export abstract class BaseWebPage{

  protected constructor(public readonly page: Page, public readonly url: string) {    
  }

  async goto(url = '') {
    await this.page.goto(this.url + url)
    console.log(url);
  }

  async goBack() {
    await this.page.goBack()
  }

  async goForward() {
    await this.page.goForward()
  }

  async reload() {
    await this.page.reload()
  }

  abstract waitPageIsReady():void
 
}


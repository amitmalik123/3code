import * as fs from 'fs'

export enum HttpMethod{
  GET = 'GET',
  POST = 'POST',
  PUT = 'PUT',
  PATCH = 'PATCH',
  DELETE = 'DELETE',
  OPTIONS = 'OPTIONS',
  HEAD = 'HEAD'
}

export interface JsonSchema {
  type:                 string;
  properties:           any;
  additionalProperties: boolean;
  definitions?:          Definitions;
}

interface Definitions {
  schemas: any;
}

export interface BaseApiEndpoint{
  route: string
  title: string
  method: HttpMethod
  body?: any
  formData?: any
  pathParameters?: string | string[]
  queryParameters?: {[key: string]: string | number | boolean | string[]}
  extraHeaders?:{ [key: string]: string; }
  schema?: JsonSchema
}

export abstract class BaseApiClass{

  protected constructor(route: string, path:string) {
    this._route = route
    this._packagePath = path
  }

  private readonly _route : string
  private readonly _packagePath: string
  protected get packagePath(): string {
    return this._packagePath
  }

  protected get route(): string {
    return this._route
  }

  protected readFile(file: string) {
    return fs.readFileSync(`${this.packagePath}/schemas/${file}`, 'utf-8')
  }

  protected getSchema(schemaName: string): JsonSchema {
    const fileContent = this.readFile(`${schemaName}.json`)
    return this.handleExternalSchemaReferences(JSON.parse(fileContent))
  }

  /**
     * Some schemas have common sub schemas. They can be reused in several schemas.
     * In this case we use reference to external json file(schema).
     * But these references were ignored for schema validation see EWMPM-5171.
     * This function helps to replace external references with local.
     *
     * **SOURCE SCHEMA EXAMPLE:**
     * ```
     * {
     *     "type": "object",
     *     "properties": {
     *         "data": {
     *             "type": "array",
     *             "items": {
     *                 "$id": "some-external-schema.json"
     *             },
     *             "nullable": true
     *         }
     *     },
     *     "additionalProperties": false,
     *     "definitions": {
     *         "schemas": {}
     *     }
     * }
     * ```
     * **MODIFIED SCHEMA EXAMPLE:**
     * ```
     * {
     *     "type": "object",
     *     "properties": {
     *         "data": {
     *             "type": "array",
     *             "items": {
     *                 "required": [
     *                     "sourceSystem"
     *                 ],
     *                 "type": "object",
     *                 "properties": {
     *                     "sourceSystem": {
     *                         "type": "string"
     *                     }
     *                 },
     *                 "additionalProperties": false
     *             },
     *             "nullable": true
     *         }
     *     },
     *     "additionalProperties": false,
     *     "definitions": {
     *         "schemas": {
     *             "SourceAccount": {
     *                 "type": "object",
     *                 "properties": {
     *                     "sourceID": {
     *                         "type": "string",
     *                         "nullable": true
     *                     }
     *                 },
     *                 "additionalProperties": false
     *             }
     *         }
     *     }
     * }
     * ```
     * @param schema - json schema that has external json files references
     * @return JsonSchema - modified schema that with replaces external references with json local objects/references
     *
     * */
  protected handleExternalSchemaReferences(schema: JsonSchema):JsonSchema {
    const readFile = (file: string) => this.readFile(file)
    function replaceExternalReferencesWithLocal(obj: object) {
      for (const key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
          const value = obj[key]

          if (typeof value === 'object' && value !== null) {
            replaceExternalReferencesWithLocal(value as object)
          } else if (typeof value === 'string' && value.endsWith('.json')){
            //delete the object that had an external json reference
            delete obj[key]
            //extract schema from a file
            const externalJson: JsonSchema = JSON.parse(readFile(value?.toString()))
            replaceExternalReferencesWithLocal(externalJson)
            //Move all definitions.schemas objects from external to the source schema
            for (const key in externalJson?.definitions?.schemas) {
              if(!schema.definitions){
                schema.definitions = {schemas:{}}
              }
              schema.definitions.schemas[key] = externalJson.definitions.schemas[key]
            }
            //delete definitions object inside external json
            delete externalJson.definitions
            //replace object inside source schema with external json
            Object.assign(obj, externalJson)

          }
        }
      }
    }
  
    replaceExternalReferencesWithLocal(schema)
    return schema
  }
}
import { type Page , test} from '@playwright/test'

export class GeneralUtils {
  readonly page: Page

  constructor(page: Page) {
    this.page = page
  }

  public static convertDateToQuarterAndYear(dateString: string): string {
    const date = new Date(dateString)
    if (isNaN(date.getTime())) {
      return 'Invalid Date'
    }

    const quarter = Math.floor((date.getMonth() + 3) / 3)
    const year = date.getFullYear()

    return `Q${quarter} ${year}`
  }

  /**
 * Sorts an array of strings alphabetically
 * 
 * @param {string[]} values - The array of strings to be sorted
 * @returns {string[]} - The sorted array of strings
 */
  public static sortStringsAlphabetically(values: string[]): string[] {
    return values.sort((a, b) => a.localeCompare(b))
  }

  public static getCurrentQuarter(date = new Date()): string {
    const currentMonth = date.getMonth() + 1
    let currentQuarter = ''

    if (currentMonth >= 1 && currentMonth <= 3) {
      currentQuarter = 'Q1'
    } else if (currentMonth >= 4 && currentMonth <= 6) {
      currentQuarter = 'Q2'
    } else if (currentMonth >= 7 && currentMonth <= 9) {
      currentQuarter = 'Q3'
    } else {
      currentQuarter = 'Q4'
    }

    return currentQuarter

  }

  public static getCurrentYear(date = new Date()): string {
    return `${date.getFullYear()}`
  }

  public static getCurrentMonth(date = new Date()): string {
    const monthFormatter = new Intl.DateTimeFormat('en', { month: 'short' })
    const currentMonth = monthFormatter.format(date)
    return currentMonth.toUpperCase()
  }

  // Function to convert RGB to Hex
  async rgbToHex(rgb) {
    const rgbValues = rgb.match(/\d+/g) // Extract numeric values from the string
    if (rgbValues && rgbValues.length === 3) {
      const [r, g, b] = rgbValues.map(Number) // Convert to numbers

      return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`
    } else {
      throw new Error('Invalid RGB format')
    }
  }

  async switchToFrame(frameIndex){
    return this.page.frames()[frameIndex]
  }
  async getBackgroundColor(element) {
    const colorHandle = await element.evaluateHandle((elem) => {
      const style = getComputedStyle(elem)
      return style.backgroundColor
    })
    return await colorHandle.jsonValue()
  }

  async generateRandomString(length: number): Promise<string> {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    let randomString = ''
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * characters.length)
      randomString += characters.charAt(randomIndex)
    }
    return randomString
  }

  public static generateRandomAlphanumericString(length: number): string {
    const alphanumericChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    let randomString = ''

    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * alphanumericChars.length)
      randomString += alphanumericChars.charAt(randomIndex)
    }

    return randomString
  }

  /**
     * Converts date
     *
     * @param dataRaw - date in following format: "20200120"
     * @return string - converted date: "1/20/2020"
     * */
  public static convertDate(dataRaw: string){
    if(dataRaw || dataRaw!=''){
      // Parse the input date
      const year = dataRaw.slice(0, 4)
      const month = Number(dataRaw.slice(4, 6))
      const day = Number(dataRaw.slice(6, 8))

      // Format the date
      return `${month}/${day}/${year}`
    } else return ''
  }

  /**
     * Converts date
     *
     * @param inputDate - date in following format: "2020-05-30T00:00:00"
     * @return string - converted date: "5/30/2020"
     * */
  public static convertDateFormat(inputDate: string): string {
    if(inputDate || inputDate!='') {
      const date = new Date(inputDate)
      const month = date.getMonth() + 1 // Months are 0-based, so add 1
      const day = date.getDate()
      const year = date.getFullYear()

      return `${month}/${day}/${year}`
    } else return ''
  }

  /**
     * Normalizes currency value
     *
     * @param currencyValueRaw - number in following format: 524837.5800
     * @return string - normalized currency value: "$524,837.58"
     * */
  public static normalizeCurrencyValue(currencyValueRaw: number){
    if(currencyValueRaw){

      // Format value to usd
      return currencyValueRaw.toLocaleString('en-US', { style: 'currency', currency: 'USD' })
    }
    /* todo: In case, when value is 0, FE displays 0 instead of $0.00 it is a low priority bug.
         *  When bug will be resolved - remove following if
         */
    else if(currencyValueRaw === 0 || currencyValueRaw === 0.0) return '0'
    else return ''
  }

  /**
 * Normalizes the raw currency value into a formatted USD string
 * It accounts for a bug where a raw value of 0 doesn't convert properly by ensuring
 * that zero values are formatted correctly. If the value is falsey and not zero,
 * it returns an empty string
 *
 * @param {number} currencyValueRaw - The raw value to be formatted
 * @returns {string} Formatted currency value as a string in USD. Returns '$0.00' if the input is exactly 0,
 * or an empty string for null, undefined, or other falsey non-zero values
 */
  public static normalizeCurrencyValueWithout0Bug(currencyValueRaw: number){
    if(currencyValueRaw){
      // Format value to usd
      return currencyValueRaw.toLocaleString('en-US', { style: 'currency', currency: 'USD' })
    }
    else if(currencyValueRaw === 0 || currencyValueRaw === 0.0) return '$0.00'
    else return ''
  }

  /**
     * Normalizes currency from number to currency value with a specified number of decimal places
     *
     * @param currencyValueRaw - number in following format: 524837.5800
     * @param fractionDigits - number of decimal places
     * @return string - normalized currency value (fractionDigits = 2): "$524,837.58"
     * */

  public static normalizeCurrencyValueWithFraction(currencyValueRaw: number, fractionDigits: number = 2){
    if(currencyValueRaw){

      // Format value to usd
      return currencyValueRaw.toLocaleString('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: fractionDigits, maximumFractionDigits: fractionDigits })
    }
    /* todo: In case, when value is 0, FE displays 0 instead of $0.00 it is a low priority bug.
         *  When bug will be resolved - remove following if
         */
    else if(currencyValueRaw === 0 || currencyValueRaw === 0.0) return '$0'
    else return ''
  }

  /**
     * Normalizes percent value
     *
     * Substrings 0 in case when percent value has 0 in the end. For example "16.50%" -> "16.5%"
     *
     * @param floatValue - number in following format: 0.16560000000000000000 , 0.16500000000000000000
     * @param decimals
     * @return string - normalized currency value: "16.56%" , "16.5%"
     * */
  public static normalizePercentValue(floatValue: number, decimals:number = 2){
    if(floatValue) {
      let roundedValue = (floatValue * 100).toFixed(decimals)
      if (roundedValue.match(/\.\d0/))roundedValue = roundedValue.substring(0, roundedValue.length - 1)
      return roundedValue.replace(/\B(?=(\d{3})+(?!\d))/g, ',') + '%'
    } else if(floatValue === 0 || floatValue === 0.0) return '0.0%'
    else return ''
  }

  /**
     * Normalizes percent value. Always return percent with 2 decimals
     *
     * @param floatValue - number in following format: 0.16560000000000000000 , 0.16500000000000000000
     * @return string - normalized currency value: "16.56%" , "16.50%"
     * */
  public static normalizePercentValueAlwaysTwoDecimals(floatValue: number){
    if(floatValue) {
      const roundedValue = (floatValue * 100).toFixed(2)
      // Format float value to percent
      return roundedValue.replace(/\B(?=(\d{3})+(?!\d))/g, ',') + '%'
    } else if(floatValue === 0 || floatValue === 0.0) return '0.00%'
    else return ''
  }
  /**
     * Compare 2 arrays if any element equals.
     * @return boolean if there is no matching values true, if there is matching values false
     * */
  public static arraysHaveNoEqualValues(arr1:any[], arr2:any[]) {
    // Create a Set from the first array to check for uniqueness
    const set = new Set(arr1)

    // Iterate through the second array and check if any element is in the Set
    for (const value of arr2) {
      if (set.has(value)) {
        return false // Found an equal value
      }
    }

    return true // No equal values found
  }

  /**
     * Checks for sorting in an array.
     * @return boolean if the array is sorted true, if not false
     * */
  public static arrayIsAlphabeticallySorted(arr:string[]) {
    const sortedArray = arr.sort()
    if (JSON.stringify(sortedArray) === JSON.stringify(arr)) {
      return true // Array is sorted
    } else {
      return false // Array is NOT sorted
    }
  }

  /**
     * Extracts digits from string to array of numbers
     * @return number[] array of extracted numbers
     * */
  public static extractDigitsFromStringToArray(textWithDigits:string) {
    return textWithDigits.split(/\D+/).filter(part => part !== '').map(Number)
  }

  /**
     * Extracts digits from string to number
     * @return number extracted number
     * */
  public static extractDigitsFromString(textWithDigits:string) {
    return Number(this.extractDigitsFromStringToArray(textWithDigits).map(String).join(''))
  }

  /**
     * Generates random value
     *
     * @param limit - max value
     * @return number - some random value from 0 to limit
     * */
  public static getRandomNumber(limit: number): number {
    return Math.floor(Math.random() * limit)
  }

  public static getRandomEnumValue(yourEnum: any): any {
    return Object.values(yourEnum)[this.getRandomNumber(Object.values(yourEnum).length)]
  }

  /**
     * Removes spaces in the end of the string
     *
     * @param inputString - string with spaces as the last chars
     * @return string - input string without spaces in the end
     * */
  public static removeTrailingSpaces(inputString: string): string {
    let i = inputString.length - 1

    while (i >= 0 && inputString[i] === ' ') {
      i--
    }

    return inputString.slice(0, i + 1)
  }

  public static parseDollarAmountToFloat(dollarAmount: string): number {
    return parseFloat(dollarAmount.replace(/[^0-9.-]+/g, ''))
  }

  public static parseDollarAmountToInteger(dollarAmount: string): number {
    return Math.round(GeneralUtils.parseDollarAmountToFloat(dollarAmount))
  }

  public static parsePercentToFloat(percentValue: string): number {
    return parseFloat(percentValue.replace('%', '').replace(',',''))
  }

  public static parseApiPercentToFloat(percentValue: string): number {
    const resultPercent: number = +(+(percentValue)*100).toFixed(2)
    return resultPercent
  }

  public static extractSecondWord(str: string): string {
    const words = str.split(' ')
    if (words.length >= 2) {
      return words[1]
    }
    return ''
  }

  public static  parseDate(dateString: string): Date {
    // Define a regular expression to match "mm/DD/yyyy" format
    const mmddyyyyPattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/

    const match = dateString.match(mmddyyyyPattern)
    if (match) {
      const month = parseInt(match[1], 10)
      const day = parseInt(match[2], 10)
      const year = parseInt(match[3], 10)

      if (!isNaN(month) && !isNaN(day) && !isNaN(year)) {
        // Note: Months are 0-based in JavaScript Dates, so we subtract 1 from the month.
        return new Date(year, month - 1, day)
      }
    }

    // Throw error for invalid date formats
    throw new Error(`Date ${dateString} does not match pattern mm/DD/yyyy`)
  }

  public static boolToYesNo(bool: boolean|undefined|string): string {
    return bool? 'Yes' : 'No'
  }

  public static normalizeAssetAllocation(assetAllocations: any[]){
    const arr:string[] = []
    for (let i = 0; i < assetAllocations.length; i++) {
      arr.push(GeneralUtils.normalizePercentValue(assetAllocations[i].allocationWeight, 0))
    }
    return arr.join('\n')
  }

  public static  formatDateToYYYYMMDD(inputDate: Date): string {
    const year = inputDate.getFullYear().toString()
    const month = (inputDate.getMonth() + 1).toString().padStart(2, '0') // Months are zero-based
    const day = inputDate.getDate().toString().padStart(2, '0')

    return year + month + day
  }

  /**
     * Transform Date to string in format YYYY-MM-DD
     *
     * @param inputDate - Date
     * @return string - string with Date in format  YYYY-MM-DD
     * */  
  public static  formatDateToHyphenString(inputDate: Date): string {
    const year = inputDate.getFullYear().toString()
    const month = (inputDate.getMonth() + 1).toString().padStart(2, '0') // Months are zero-based
    const day = inputDate.getDate().toString().padStart(2, '0')

    return year + '-' + month + '-'  + day
  }

  public static constructResultString(inputString: string, parameterValues: Record<string, string>): string{
    Object.entries(parameterValues).forEach(([key, value]) => {
      const regex = new RegExp(`{${key}}`, 'g')
      inputString = inputString.replace(regex, value)
    })
    return inputString
  }

  /**
   * Get date of last completed quarter
   * @returns The date of last completed quarter
   *
   * */
  public static getLastQuarterEndDate() {
    const currentDate = new Date()

    let year = currentDate.getFullYear()
    const quarter = Math.floor((currentDate.getMonth() / 3))
    let month: number

    switch (quarter) {
    case 0: // Current date in Q1, last completed quarter was Q4 of previous year
      month = 11 // December of the previous year
      year--
      break
    case 1: // We are in Q2, last completed quarter was Q1
      month = 2 // March
      break
    case 2: // We are in Q3, last completed quarter was Q2
      month = 5 // June
      break
    case 3: // We are in Q4, last completed quarter was Q3
      month = 8 // September
      break
    }
    const lastDayOfQuarter = new Date(year, month + 1, 0).getDate()
    return new Date(year, month, lastDayOfQuarter).toISOString().split('T')[0]
  }

  /**
   * Get the year of a given date
   *
   * @param dateString - string with the date to be parsed
   * @returns the year of a given date
   *
   * */
  public static getYearFromDate(dateString: string) {
    return new Date(dateString).getFullYear()
  }

  /**
   * Sums the value of the market value by year
   *
   * @param data - JSON data with marketValue information
   * @return marketValuesByYear - JSON Object with the sum of marketValue by year in a '"year:sumValue"' structure
   *
   * */
  public static sumMarketValuesByYear(data: { marketValues: any[] }) {
    const marketValuesByYear = {}
    data.marketValues.forEach(marketValue => {
      const year = this.getYearFromDate(marketValue.date)
      if (!marketValuesByYear[year]) {
        marketValuesByYear[year] = 0
      }
      marketValuesByYear[year] += marketValue.marketValue
    })
    return marketValuesByYear
  }

  /**
   * Combine two arrays of same length into a new object with '"key":"value"' structure
   *
   * @param keys - string array with the desired keys
   * @param values - string array with the desired values
   * @return obj - New formed object with '"key":"value"' structure
   *
   * */
  public static combineArraysIntoObject(keys: string[], values: string | any[]) {
    if(keys.length !== values.length){
      throw new Error('The lengths of the input arrays must be the same.')
    }
    return keys.reduce((obj, key, index) => {
      obj[key] = values[index]
      return obj
    }, {})
  }

  /**
   * Format a string key pair object '"year":"sumValue"' with '$ sign',
   * fix the sum to 1 decimal point precision and adds 'k' to thousands and 'm' to millions
   *
   * @param inputObj - string object with the key pairs '"year:sumValue"'
   * @return formattedObj - string object with the key pairs '"year:sumValue"' with '$ sign' and 1 decimal point precision
   * */
  public static formatFinancialNumbers(inputObj: any) {
    const formattedObj = {}
    for (const year in inputObj) {
      const value = inputObj[year]
      let suffix = ''
      let formattedValue = 0
      if (value >= 1e6) {
        formattedValue = value / 1e6
        suffix = 'm'
      } else if (value >= 1e3) {
        formattedValue = value / 1e3
        suffix = 'k'
      } else {
        formattedValue = value
        suffix = ''
      }
      //TODO: Formatting rule: When decimal value of a number is equal 0, it should b suppressed (i.e. 25.0 -> 25)
      formattedObj[year] = `$${formattedValue.toFixed(1)}${suffix}`
    }
    return formattedObj
  }
  
  /**
   * Format a string with financial value starting with $ and ending with k, m, b,
   * multiplies the number according to postfix 'k' to thousands and 'm' to millions
   *
   * @param value - string object to return number value
   * @return formattedObj - number full value from string
   * */
  public static formatTextNumbers(value: string) {
    const key = value.slice(-1).toLowerCase()
    const number = parseFloat(value.replace(/[^\d.-]/g, ''))
    const mapToNumber = { 
      'k': 1e3,
      'm': 1e6,
      'b': 1e9,
      't': 1e12,
    }

    if (key in mapToNumber) {
      return (mapToNumber[key] * number)
    }

    return number
  }

  public static parseBoolean(value: string): boolean {
    const lowerCaseValue = value.toLowerCase()
    if (lowerCaseValue === 'true') {
      return true
    } else if (lowerCaseValue === 'false') {
      return false
    } else {
      throw new Error(`Invalid boolean string: ${value}`)
    }
  }

}

export function sleep(ms: number): Promise<void> {
  return test.step(`Sleep for ${ms} ms`, async () => {
    return new Promise(resolve => setTimeout(resolve, ms))
  })
}

export async function executeWithRetry(action: () => Promise<void> | void, retries: number): Promise<void> {
  await test.step(`Execute void with retries. Total retries: ${retries}`, async () => {
    let retriesLeft = retries
    let retryNumber: number = 1
    let latestError: any
    while (retriesLeft > 0) {
      try {
        await test.step(`Retry number: ${retryNumber}; Retries left: ${retriesLeft}`, async () => {
          await action()
        })
        return // If action succeeds, exit the function
      } catch (error: any) {
        latestError = error
        retryNumber++
        retriesLeft--
      }
    } throw latestError
  })
  
}


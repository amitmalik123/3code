export class DateFormatters{
  public static setMillsTo0(date: Date):Date{
    date.setMilliseconds(0)
    return date
  }
  
  public static setTimeTo0(date: Date):Date {
    date.setHours(0)
    date.setMinutes(0)
    date.setSeconds(0)
    date.setMilliseconds(0)
    return date
  }

  /**
   * Removes milliseconds from the given date and returns the formatted string.
   * @param date - The date object or string to be formatted.
   * @param useIsoFormat - Whether to use ISO format ("YYYY-MM-DDTHH:MM:SSZ"). Defaults to true.
   * @returns The formatted date string without milliseconds.
   * 
   * @example
   * // Returns "2024-07-17T23:15:47Z" (ISO format)
   * DateFormatters.removeMilliseconds(new Date("2024-07-17T23:15:47.123Z"));
   * 
   * @example
   * // Returns "2024-07-17 23:15:47" (default format)
   * DateFormatters.removeMilliseconds(new Date("2024-07-17T23:15:47.123Z"), false);
   */
  public static removeMilliseconds(date: Date | string, useIsoFormat: boolean = true): string {
    const dateWithMilliseconds = new Date(date)
    const dateWithoutMilliseconds = new Date(dateWithMilliseconds.getTime() - (dateWithMilliseconds.getTimezoneOffset() * 60000))

    const year = dateWithoutMilliseconds.getFullYear()
    const month = String(dateWithoutMilliseconds.getMonth() + 1).padStart(2, '0') // getMonth() returns 0-based month
    const day = String(dateWithoutMilliseconds.getDate()).padStart(2, '0')
    const hours = String(dateWithoutMilliseconds.getHours()).padStart(2, '0')
    const minutes = String(dateWithoutMilliseconds.getMinutes()).padStart(2, '0')
    const seconds = String(dateWithoutMilliseconds.getSeconds()).padStart(2, '0')

    if (useIsoFormat) {
      return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}Z`
    } else {
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
    }
  }

  public static getTime(date: Date = new Date()): string {

    const hours = String(date.getHours()).padStart(2, '0')
    const minutes = String(date.getMinutes()).padStart(2, '0')
    const seconds = String(date.getSeconds()).padStart(2, '0')
    const milliseconds = String(date.getMilliseconds()).padStart(3, '0')

    return `${hours}:${minutes}:${seconds}.${milliseconds}`
  }

  public static isValidISODate(date: Date | string): boolean {
    // Regex to match ISO 8601 date strings
    const regex = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z$/
    const dateString = date instanceof Date? date.toISOString() : date
    return regex.test(dateString)
  }
} 
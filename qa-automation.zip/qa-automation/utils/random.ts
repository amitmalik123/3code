import {faker} from '@faker-js/faker'

/**
 * Different test cases that can be executed with random numbers:
 * - 'max': Maximum value.
 * - 'min': Minimum value.
 * - 'random': Random value within the range (default).
 * - 'max+1': One greater than the maximum value.
 * - 'min-1': One less than the minimum value.
 * - '0': Zero value.
 */
export type NumberTestCaseOptions = 'max' | 'min' | 'random' | 'max+1' | 'min-1' | '0'

/**
 * Different TS types that can be used as a random numbers
 * - 'string': Returns the value as a string.
 * - 'number': Returns the value as a number (default).
 */
export type NumberReturnTypeOptions = 'string' | 'number'

export class Random {

  public static getString(length: number): string {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    let randomString = ''
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * characters.length)
      randomString += characters.charAt(randomIndex)
    }
    return randomString
  }

  public static getAlphanumericString(length: number): string {
    const alphanumericChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    let randomString = ''

    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * alphanumericChars.length)
      randomString += alphanumericChars.charAt(randomIndex)
    }

    return randomString
  }

  /**
     * Generates random value
     *
     * @param limit - max value
     * @return number - some random value from 0 to limit
     * */
  public static getNumber(limit: number): number {
    return Math.floor(Math.random() * limit)
  }

  public static getEnumValue(yourEnum: any): any {
    return Object.values(yourEnum)[this.getNumber(Object.values(yourEnum).length)]
  }

  public static getEnumValuesArray(yourEnum: any, count: number): any {
    const enumValuesArray = this.shuffleArray(Object.values(yourEnum))
    return count < enumValuesArray.length ? enumValuesArray.slice(0, count) : enumValuesArray
  }

  /**
   * Gets random value from an array.
   *
   * @template T - The type of elements in the array.
   * @param {T[]} arr - The array from which to get a value.
   * @returns {T} A value from the array selected by a random index.
   */
  public static getValueFromArray<T>(arr: T[]): T {
    return arr[this.getNumber(arr.length)]
  }

  public static generateNumberArray(parts: number, total: number): number[] {
    if (parts <= 0 || total <= 0) {
      throw new Error('Both "parts" and "total" parameters must be greater than zero.')
    }

    const array: number[] = []

    for (let i = 0; i < parts - 1; i++) {
      const randomValue = this.getNumber(total)
      array.push(randomValue)
      total -= randomValue
    }

    array.push(total) // Ensure the last number makes up for any rounding errors.

    return array
  }

  public static shuffleArray<T>(array: T[]): T[] {
    // Create a copy of the original array to avoid modifying the original array
    const newArray = array.slice()

    // Fisher-Yates shuffle algorithm
    for (let i = newArray.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [newArray[i], newArray[j]] = [newArray[j], newArray[i]]
    }

    return newArray
  }

  public static generateRandomKeyValuePairs(numPairs = faker.number.int({ min: 1, max: 5 })): {[key: string]: string} {
    const map: {[key: string]: string} = {}
    for (let i = 0; i < numPairs; i++) {
      map[faker.word.noun()] = faker.word.adjective() // Add key-value pair to map
    }
    return map
  }

  /**
   * Generates a number within the specified range with optional decimal places or based on a test case.
   *
   * @example
   * // Example 1: Generate a random number between 10 and 20 with 2 decimal places
   * const randomNum1 = Random.generateTestNumber({
   *   minNumber: 10,
   *   maxNumber: 20,
   *   decimalPlaces: 2,
   *   returnType: 'number',
   *   testCase: 'random'
   * });
   * // Returns a random number between 10 and 20 with 2 decimal places.
   * console.log(randomNum1) // Output example: 12.34
   *
   * // Example 2: Generate a random number between -1000 and 1000
   * const randomNum2 = Random.generateTestNumber({
   *   minNumber: -1000,
   *   returnType: 'string',
   *   testCase: 'min-1'
   * });
   * // Returns a min number - 1 (boundary test case) as a string.
   * console.log(randomNum2) // Output example: -1001
   *
   * // Example 3: Generate the number zero
   * const zeroNum = Random.generateTestNumber({
   *   returnType: 'number',
   *   testCase: '0'
   * });
   * // Returns the number zero.
   * console.log(randomNum1) // Output example: 0
   *
   * // Example 4: Generate a random number between 1 and 10,000 with 4 decimal places as a string
   * const randomNum3 = Random.generateTestNumber({
   *   minNumber: 1,
   *   maxNumber: 10000,
   *   decimalPlaces: 4,
   *   returnType: 'string',
   *   testCase: 'random'
   * });
   * // Returns a random number between 1 and 10,000 with 4 decimal places as a string.
   * console.log(randomNum1) // Output example: 5432.1234 (as a string)
   *
   * @param options An object containing required parameters:
   * @param options.minNumber The minimum value of the generated number (default: 0).
   * @param options.maxNumber The maximum value of the generated number (default: Number.MAX_SAFE_INTEGER).
   * @param options.decimalPlaces The number of decimal places (default: 0).
   * @param {NumberTestCaseOptions} options.testCase  The type of test case to generate.
   * @param {NumberReturnTypeOptions} options.returnType  The type of return value.
   *
   * @returns The generated number value as a string or a number based on the returnType parameter.
   */
  public static generateTestNumber(options?: {
    min?: number,
    max?: number,
    decimalPlaces?: number
    testCase?: NumberTestCaseOptions,
    returnType?: NumberReturnTypeOptions
  }): string | number {
    const {
      min = 0,
      max = Number.MAX_SAFE_INTEGER,
      decimalPlaces = 0,
      testCase = 'random',
      returnType = 'number'} = options || {}

    let maxNumber = max
    let minNumber = min

    // Adjust max and min values based on the test case
    switch (testCase){
    case ('0'):
      maxNumber = 0
      minNumber = 0
      break
    case ('max'):
      maxNumber = max
      minNumber = max
      break
    case ('min'):
      maxNumber = min
      minNumber = min
      break
    case ('max+1'):
      maxNumber = max + 1
      minNumber = maxNumber
      break
    case ('min-1'):
      minNumber = min - 1
      maxNumber = minNumber
      break
    }

    const finalNumber = decimalPlaces ?
      faker.number.float({
        min: minNumber,
        max: maxNumber,
        multipleOf: +`0.${'0'.repeat(decimalPlaces-1)}1`
      }):
      faker.number.int({
        min: minNumber,
        max: maxNumber,
      })
    // todo: update asserts (implement option to consider 1.9 and 1.900 as equal values) and remove the following function
    // In case when numbers are too big then decimal places are dropping/rounding/etc.
    // When number converted to string then decimals displayed as they are (no rounding)
    // Following function returns number with rounded decimal places + added missing decimal places as 0
    // If you use toFixed instead: number 79209657525642.9 -> string 79209657525642.912345
    // Example: number 79209657525642.9 -> string 79209657525642.900000
    function addDecimalPlaces(numberString: string, decimalPlaces: number): string {
      const [integerPart, decimalPart] = numberString.split('.')
      const paddedDecimalPart = (decimalPart || '').padEnd(decimalPlaces, '0')
      return `${integerPart}.${paddedDecimalPart}`
    }
    // Convert the number to a string if the type is 'string'
    if (returnType === 'string') {
      return decimalPlaces ? addDecimalPlaces(finalNumber.toString(), decimalPlaces) : finalNumber.toString()
    }

    return finalNumber
  }

  /**
   * Generates an integer value within the specified range or based on a test case.
   *
   * Default max/min values are aligned to C# integer boundary values
   *
   * @example
   * // Generate a random integer between -100 and 100
   * const randomInt = Random.generateInt({
   *   minNumber: -100,
   *   maxNumber: 100,
   *   testCase: 'random',
   *   returnType: 'number'
   * });
   * // Returns a random integer between -100 and 100.
   * console.log(randomNumber) // Output 51
   *
   * @param options An object containing optional parameters:
   * @param options.minNumber The minimum integer value (default: -2147483648).
   * @param options.maxNumber The maximum integer value (default: 2147483647).
   * @param {NumberTestCaseOptions} options.testCase  The type of test case to generate.
   * @param {NumberReturnTypeOptions} options.returnType  The type of return value.
   * @returns The generated integer value as a string or a number based on the returnType parameter.
   */
  public static generateInt(options?: {
    min?: number,
    max?: number,
    testCase?: NumberTestCaseOptions,
    returnType?: NumberReturnTypeOptions
  }): string | number {
    const { min = -2147483648, max = 2147483647, testCase,returnType} = options || {}
    return this.generateTestNumber({min, max, decimalPlaces: 0, testCase, returnType})
  }

  /**
   * Generates a number value with the specified precision and scale or based on a test case.
   *
   * @example
   * // Example 1: Generate a random number with precision 8 and scale 2
   * const randomNumber1 = Random.generateNumberByPrecision({
   *   precision: 8,
   *   scale: 2,
   *   testCase: 'random',
   *   returnType: 'string'
   * });
   * // Returns a string representation of a random number with 6 integer digits and 2 decimal places.
   * console.log(randomNumber1) // Output example 123456.12
   *
   * // Example 2: Generate a random number with precision 9
   * const randomNumber2 = Random.generateNumberByPrecision({
   *   precision: 9,
   *   testCase: 'random',
   * });
   * // Returns a random number with 9 integer digits.
   * console.log(randomNumber2) // Output example 123456789
   *
   * @param options An object containing required parameters:
   * @param options.precision The total number of digits in the generated number.
   * @param options.scale The number of decimal places (default: 0).
   * @param {NumberTestCaseOptions} options.testCase  The type of test case to generate.
   * @param {NumberReturnTypeOptions} options.returnType  The type of return value.
   *
   * @returns The generated number value as a string or a number based on the returnType parameter.
   *
   * @throws When the precision is less than 1 or if it's less than or equal to the scale.
   */
  public static generateNumberByPrecision(options: {
    precision: number,
    scale?: number,
    testCase?: NumberTestCaseOptions,
    returnType?: NumberReturnTypeOptions
  }): string | number {
    const {precision, scale = 0, testCase = 'random', returnType} = options

    // Assert that options are correct
    if(precision < 1) throw new Error(`Precision: '${precision}' can't be less then 1`)
    if(precision <= scale) throw new Error(`Precision: '${precision}' can't be less then or equal to scale: '${scale}'`)

    // Define max/min values
    const digitsCount = testCase === 'random' ?
      faker.number.int({min: 1, max: precision - scale}):
      precision - scale
    // Max number consists of '9' repeated digitsCount times
    const max = +'9'.repeat(digitsCount)
    const min = max * -1

    return this.generateTestNumber({ min, max, decimalPlaces: scale, testCase, returnType })
  }

}
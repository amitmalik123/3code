import { Locator, expect } from '@playwright/test'

type optionsType = { timeout?: number | undefined }

async function toHaveCss(cssName: string, cssValue: string, locator: Locator, options?: optionsType ) {
  await expect(locator, `Assert that element css property: '${cssName}' has value: '${cssValue}'`).toHaveCSS(cssName, cssValue, options)
} 

export class UiElementsStylesAssert {

  static async backgroundColor(color: string, locator: Locator, options?: optionsType) {
    await toHaveCss('background-color', color, locator, options)
  }

  static async fillColor(expectedRgbColor: string, locator: Locator, options?: optionsType) {
    await toHaveCss('fill', expectedRgbColor, locator, options)
  }

  static async borderBottomColor(color: string, locator: Locator, options?: optionsType) {
    await toHaveCss('border-bottom-color', color, locator, options)
  }

}

export class UiTextStylesAssert {
  static async fontWeight(text: Locator, expectedFont: string, options?: optionsType) {
    await toHaveCss('font-weight', expectedFont, text, options)
  }

  static async fontName(text: Locator, expectedFontName: string, options?: optionsType) {
    await toHaveCss('font-family', expectedFontName, text, options)
  }

  static async fontSize(text: Locator, expectedFontSize: string, options?: optionsType) {
    await toHaveCss('font-size', expectedFontSize, text, options)
  }

  static async fontColor(text: Locator, expectedFontColor: string, options?: optionsType) {
    await toHaveCss('color', expectedFontColor, text, options)
  }
}

import * as fs from 'fs'
import { parse } from 'csv-parse'
import test from '@playwright/test'

export abstract class CsvHelpers {

  /**
   * Parses a CSV file and converts it to an array of objects.
   *
   * This method reads a CSV file from the given file path, parses its content, and converts it into an array of objects.
   * The parsed data is then attached to the test report.
   *
   * @param {string} filePath - The path to the CSV file to be parsed.
   * @returns {Promise<any[]>} A promise that resolves to an array of objects representing the CSV data.
   */
  static async parseCsvToArray(filePath: string): Promise<any[]> {
    return await test.step('Parsing CSV file to array and attaching to report', async () => {
      return new Promise((resolve, reject) => {
        const csvFileData: any[] = []
        const parser = parse({ columns: true }, async (err, records) => {
          if (err) {
            reject(err)
          } else {
            csvFileData.push(...records)
            await test.info().attach('CSV File Data', {
              body: JSON.stringify(csvFileData, null, 2),
              contentType: 'application/json'
            })
            resolve(csvFileData)
          }
        })

        fs.createReadStream(filePath).pipe(parser)
      })
    })
  }
}

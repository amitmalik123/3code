import { test } from '@playwright/test'
import { DateFormatters } from './date-farmatters'

class DataTransformUtils {
  /**
   * Modifies a single object's keys based on provided options.
   *
   * @param obj - The object to modify
   * @param options - The modification options
   * @returns - The modified object
   */
  public static async modifyObject(obj: any, options: {
    toLowerCase?: boolean,
    keyReplacementRules?: { original: string, new: string }[],
    removeKeys?: string[],
    removeMillsForDates?: boolean
  }): Promise<object> {
    return await test.step(`Modify object`, async () => {
      if (typeof obj !== 'object' || obj === null) {
        return obj // If the input is not an object, return it as is
      }
  
      // Create a new object to store modified keys
      const newObj: any = {}
  
      // Iterate through each key-value pair of the object
      for (const key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
          if (options?.removeKeys?.includes(key)) {
            continue
          }
          let newKey = key
          if (options?.keyReplacementRules) {
            const value = options.keyReplacementRules?.find((replacement) => key === replacement.original)?.new
            newKey = value ?? newKey
          }
          if (options?.toLowerCase) newKey = newKey.toLowerCase()
          if (options?.removeMillsForDates && DateFormatters.isValidISODate(obj[key])) {
            obj[key] = DateFormatters.removeMilliseconds(obj[key])
          }
          newObj[newKey] = obj[key] // Assign value to the new key
        }
      }
  
      return newObj
    })
  }

  /**
   * Modifies an array of objects' keys based on provided options.
   *
   * @param arr - The array of objects to modify
   * @param options - The modification options
   * @returns - The modified array of objects
   */
  public static async modifyObjectArray(arr: any[], options: {
    toLowerCase?: boolean,
    keyReplacementRules?: { original: string, new: string }[],
    removeKeys?: string[],
    removeMillsForDates?: boolean
  }): Promise<object[]> {
    return await test.step(`Modify array of objects`, async () => {
      const modifiedArray = await Promise.all(arr.map(async (obj) => await DataTransformUtils.modifyObject(obj, options)))
      return modifiedArray
    })
  }
}

export default DataTransformUtils

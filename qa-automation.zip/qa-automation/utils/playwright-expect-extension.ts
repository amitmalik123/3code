import { expect as baseExpect } from '@playwright/test'

export { test } from '@playwright/test'

const greenANSI = '\x1b[32m'
const redANSI = '\x1b[91m'
const boldANSI = '\x1b[1m'
const resetANSI = '\x1b[0m'

/**
 * Generates formatted error text for expected and actual objects with colored output.
 *
 * @template T - The type of the objects.
 * @param {T} actual - The actual object.
 * @param {T} expected - The expected object.
 * @returns {string} - The formatted error text with the expected object in green and the actual object in red.
 */
function expectedAndActualToErrorText<T>(actual: T, expected: T): string{
  return `

${objectToErrorText(expected, 'Expected object', {objectNameBold: true})}

${objectToErrorText(actual, 'Actual object', {objectNameBold: true})}
        `
}

/**
 * Generates a formatted error text for a given object with optional bold and colored output.
 *
 * @template T - The type of the object.
 * @param {T} object - The object to format into error text.
 * @param {string} objectName - The name of the object to display in the error text.
 * @param {Object} [options] - Optional settings for formatting the output.
 * @param {boolean} [options.objectNameBold] - Whether to display the object name in bold.
 * @param {'red' | 'green' | 'default'} [options.textColor] - Color for the text output. Can be 'red', 'green', or 'default'.
 * @returns {string} - The formatted error text with optional bold and colored formatting.
 */
function objectToErrorText<T>(object: T, objectName: string, options?: { objectNameBold?: boolean, textColor?: 'red' | 'green' | 'default'}): string{
  const {
    objectNameBold = false , 
    textColor = objectName.toLocaleLowerCase().includes('expected') ? 'green' : 
      objectName.toLocaleLowerCase().includes('actual') ? 'red' : 
        'default'
  } = options || {}
  const boldCodeStart = objectNameBold ? boldANSI : ''
  const boldCodeEnd = objectNameBold ? resetANSI : ''
  let colorCodeStart = ''
  let colorCodeEnd = ''
  switch (textColor) {
  case 'red':
    colorCodeStart = redANSI
    colorCodeEnd = resetANSI
    break

  case 'green':
    colorCodeStart = greenANSI
    colorCodeEnd = resetANSI
    break
  
  default:
    break
  }
  const valueFromNewLine = typeof object !== 'string' && typeof object !== 'number' && typeof object !== 'boolean' && object !== null && object !== undefined
  return `${boldCodeStart}${objectName}:${boldCodeEnd} ${colorCodeStart}${valueFromNewLine ? '\n' : ''}${JSON.stringify(object, null, 2)}${colorCodeEnd}`
}

/**
   * Compares 2 any objects with each other
   * Actual object should contain all fields/arrays/subobjects from expected
   * @param actual - actual object
   * @param expected - expected object
   * @returns {comparePassed: boolean, resultsDescription: string[]} compare result true/false + description text
   */
function objectContains<T>(actual: T, expected: T): {comparePassed: boolean, resultsDescription: string[]} {
  const compareResults:string[] =[]

  function pushResults(expected: any, actual: any, comment?: string, addDefaultText: boolean = true)  {
    const defaultText = `
    ${objectToErrorText(expected, 'Expected value')}
    ${objectToErrorText(actual, 'Actual value')}
      `
    compareResults.push(`${comment ?? ''}\n${addDefaultText? defaultText: ''}`)
  }

  function compare(expected: any, actual: any, comment?: string)  {
    if (typeof expected !== typeof actual) {
      pushResults(expected, actual, `${comment? comment + ' -> ':'- '}Types are different
        
    ${objectToErrorText(typeof expected, 'Expected type')}
    ${objectToErrorText(typeof actual, 'Actual type')}
      `)
      return false
    }

    if (typeof expected !== 'object' || expected === null) {
      const bool = expected === actual
      if (!bool)pushResults(expected, actual, `${comment? comment + ' -> ':'- '}Values are not equal`)
      return bool
    }

    if (Array.isArray(expected)) {
      if (!Array.isArray(actual)){
        pushResults(expected, actual,`${comment? comment + ' -> ':'- '}Actual object is not an array`)
        return false
      }
      if (expected.length !== actual.length) {
        pushResults(expected, actual,
          `${comment? comment + ' -> ':'- '}Array length is different:

    ${objectToErrorText(expected.length, 'Expected length')}
    ${objectToErrorText(actual.length, 'Actual length')}`)
        return false
      }

      for (let i = 0; i < expected.length; i++) {
        if (!compare(expected[i], actual[i], 
          `${comment? comment + ' -> ':'- '}Array item #${i} does not match with the expected result`)) return false
      }

      return true
    }
    //Extract all keys from expected object
    const expectedKeys = Object.keys(expected)

    /*
      Both values null and {someBool: true, someString: 'abc'} are objects.
      That why "typeof expected !== typeof actual" can't see difference between types.
      So we assert that actual not null before comparing all expected keys
       */
    if(actual){
      //Assert that actual has all expected keys and each actual value is equal to the expected one
      expectedKeys.forEach( key => {
        //Assert that actual has expected key
        if(Object.prototype.hasOwnProperty.call(actual, key)){
          //if it has then comparing values
          compare(expected[key], actual[key], `${comment? comment + ' -> ':'- '}${objectToErrorText(key, 'Key', {textColor: 'green'})}`)
        } else {
          //if actual does not have expected key then pushing the error
          pushResults(expected, actual, `${comment? comment + ' -> ':'- '}${objectToErrorText(key, 'There is no actual key')}`, false)
          return false
        }
      })
      return compareResults.length === 0
    } else {
      //if actual is null then pushing the error
      pushResults(expected, actual, `${comment? comment + ' -> ':'- '}${objectToErrorText(actual, 'Actual is')}`)
      return false
    }
  }
  const comparePassed = compare(expected, actual)
  compareResults.push(expectedAndActualToErrorText(actual, expected))

  return {comparePassed, resultsDescription: compareResults}
  
}

export const expect = baseExpect.extend({
  /**
 * Validates that the given object contains exactly the expected keys.
 * 
 * @param actual - The object to validate.
 * @param expected - Excpected object or an array of expected keys
 */
  toHaveEqualObjectKeys(actual: any, expected: any | string []) {
    const assertionName = 'toHaveEqualObjectKeys'

    const actualKeys = Object.keys(actual).sort()
    const expectedKeys: any = []
    if (Array.isArray(expected) && expected.every(item => typeof item === 'string')) expectedKeys.push(...expected.sort())
    else expectedKeys.push(...Object.keys(expected).sort())

    const pass: boolean = expectedKeys.length === actualKeys.length && actualKeys.every(item => expectedKeys.includes(item))

    const message = pass
      ? () => this.utils.matcherHint(assertionName, undefined, undefined, { isNot: this.isNot }) +
          '\n\n' +
          'Actual object has all keys from expected object'
      : () =>  this.utils.matcherHint(assertionName, undefined, undefined, { isNot: this.isNot }) +
         '\n\n' +
          `${this.utils.printDiffOrStringify(expectedKeys, actualKeys, 'Expected keys', 'Received keys', true)}\n`

    return {
      message,
      pass,
      name: assertionName,
      expected,
      actual,
    }
  },

  /**
   * Compares 2 any objects with each other
   * Actual object should contain all fields/arrays/subobjects from expected
   */
  toContainObject(actual: any, expected: any) {
    const assertionName = 'toContainObject'
    const compareResult = objectContains(actual, expected)
    const compareResults:string[] = compareResult.resultsDescription
    const comparePassed = compareResult.comparePassed
    //return {comparePassed: compare(expected, actual), resultsDescription: compareResults}

    const message = comparePassed
      ? () => this.utils.matcherHint(assertionName, undefined, undefined, { isNot: this.isNot }) +
          '\n\n' +
          'Actual object contain all items from expected object'
      : () =>  this.utils.matcherHint(assertionName, undefined, undefined, { isNot: this.isNot }) +
          '\n\n' +
          compareResults.join('\n')

    return {
      message,
      pass: comparePassed,
      name: assertionName,
      expected,
      actual,
    }
  },

  /**
   * Checks if the `actual` array contains all items from the `expected` array with optional conditions.
   *
   * **IMPORTANT** Cases when actual array has more items/fields then expected array will be ignored
   * This method is applicable for ingestion API -> DB compare
   * Some DB columns values must be distinct and generated by ingestion API (instead of payload passing)
   * @param {any[]} actual - The array to check within.
   * @param {any[]} expected - The array of items to check for.
   * @param {Object} [options] - Optional conditions for the check.
   * @param {number} [options.timeout] - Optional timeout for the check.
   * @param {string} [options.distinctKey] - Optional key to ensure items are distinct.
   * @param {string[]} [options.notNullKeys] - Optional array of keys that should not be null.
  */
  toContainArrayItems(actual: any[], expected: any[], options?: { timeout?: number, distinctKey?: string, notNullKeys?: string[]}) {
    const assertionName = 'toContainArrayItems'
    const errorArray:string[] = []
    const passedItemsArray: string[] = []
    const distinctKey = options?.distinctKey
    //Making copy of passed objects
    // This is used to get rid of issues with skipping assert for custom classes e.g. Date
    // For example DB returns dates as objects, but usually dates ares intance of Date
    // such objects are not asserting and always return false true
    const expectedCopy: any[] = JSON.parse(JSON.stringify(expected))
    const actualCopy: any[] = JSON.parse(JSON.stringify(actual))
    
    function compareNotNull(actualItem: any): {comparePassed: boolean, resultsDescription: string[]}{
      let b = true
      const arr: string[] = []
      if(options?.notNullKeys){
        for (const notNullKey of options.notNullKeys) {
          if (Object.prototype.hasOwnProperty.call(actualItem, notNullKey)){
            if (!actualItem[notNullKey]){
              arr.push(`- Actual item key: ${redANSI}${notNullKey}${resetANSI} should not be null but it is: "${redANSI}${actualItem[notNullKey]}${resetANSI}"\n`)
              b = false
            }
          } else {
            arr.push(`- Actual item does not have key: ${redANSI}${notNullKey}${resetANSI} that should not be null\n`)
            b = false
          }
        } 
      } 
      return {comparePassed: b, resultsDescription: arr}
    } 

    let comparePassed = true
    //Make sure that all items from expected array exist in actual array
    for (let i = 0; i < expectedCopy.length; i++) {
      const delimeterText = [ 
        '__________________________________________________', 
        `\nExpected array index ${boldANSI}#${i}${resetANSI}: \n`
      ]
      const expectedItem = expectedCopy[i]

      const expectedItemErrorText = objectToErrorText(expectedItem, 'Expected item', {objectNameBold: true})
        
      //distinct key helps to find specific item that matches. Instead of comparing all to all
      if (distinctKey && !Object.prototype.hasOwnProperty.call(expectedItem, distinctKey)){
        errorArray.push(
          ...delimeterText,
          ...[`- The expected item does not contain the distinct key: ${greenANSI}${distinctKey}${resetANSI}\n`, expectedItemErrorText])
        comparePassed = false
      } else {
          
        const actualItem = distinctKey? 
          actualCopy.find((item) => expectedItem[distinctKey] === item[distinctKey]) :
          actualCopy.find((item) => objectContains(item, expectedItem).comparePassed)

        if(actualItem){
          const result = objectContains(actualItem, expectedItem)
          const notNullResult = compareNotNull(actualItem)
          // pushing the compare results in case of fail
          if(!result.comparePassed || !notNullResult.comparePassed){
            errorArray.push(
              ...delimeterText,
              ...notNullResult.resultsDescription,
              ...result.resultsDescription)
            comparePassed = false
          } else passedItemsArray.push(
            ...delimeterText,
            objectToErrorText(expectedItem, 'The expected item is present in the array')
          )
          if(!compareNotNull(actualItem)) comparePassed = false
        } else {
          const notFoundErrorText = distinctKey ? 
            `- No matching item found in the array with the key: ${greenANSI}"${distinctKey}"${resetANSI} and value: ${greenANSI}"${expectedItem[distinctKey]}"${resetANSI}\n` : 
            `- No matching item found in the array\n`
          errorArray.push(
            ...delimeterText,
            ...[notFoundErrorText, expectedItemErrorText])
          comparePassed = false
        }
      }
    }
    passedItemsArray.push(...[
      '\n__________________________________________________\n', 
      objectToErrorText(actualCopy, 'Actual array')
    ])

    const message: () => string = comparePassed
      ? () => this.utils.matcherHint(assertionName, undefined, undefined, { isNot: this.isNot }) +
          '\n\n' +
          'The actual array contains items from the expected array' + 
          '\n\n' +
          passedItemsArray.join('\n')
      : () =>  this.utils.matcherHint(assertionName, undefined, undefined, { isNot: this.isNot }) +
          '\n\n' +
          errorArray.join('\n')

    return {
      message,
      pass: comparePassed,
      name: assertionName,
      expected,
      actual,
    }
  },

  /**
 * Asserts whether an item with a distinct key exists in the given array.
 * 
 * @param {any[]} actual - The array in which to search for the expected item.
 * @param {any} expected - The item to find in the array.
 * @param {Object} options - Options object.
 * @param {string} options.distinctKey - The key used to uniquely identify the item in the array.
 * 
 * @example
 * // Assuming you have an array of objects and you want to check if a specific item exists based on a distinct key.
 * const actualArray = [{ id: 1, name: 'Alice' }, { id: 2, name: 'Bob' }]
 * const expectedItem = { id: 1, name: 'Alice' }
 * expect(actualArray).toFindItemByDistinctKey(expectedItem, { distinctKey: 'id' })
 * 
 */
  toFindItemByDistinctKey(actual: any[], expected: any, options: { distinctKey: string }) {
    const assertionName = 'toFindItemByDistinctKey'
    const errorArray:string[] = []
    const passedItemsArray: string[] = []
    const distinctKey = options?.distinctKey
    //Making copy of passed objects
    const expectedItem: any = JSON.parse(JSON.stringify(expected))
    const actualCopy: any[] = JSON.parse(JSON.stringify(actual))

    let comparePassed = true

    const expectedItemErrorText = objectToErrorText(expectedItem, 'Expected item', {objectNameBold: true})
        
    //distinct key helps to find specific item that matches. Instead of comparing all to all
    if (distinctKey && !Object.prototype.hasOwnProperty.call(expectedItem, distinctKey)){
      const output = [`- The expected item does not contain the distinct key: ${greenANSI}${distinctKey}${resetANSI}\n`, expectedItemErrorText]
      // Depending on the fact if current expect function is "not" or regular assert
      if (this.isNot) {
        comparePassed = true
        passedItemsArray.push(...output)
      } else {
        comparePassed = false
        errorArray.push(...output)
      }
    } else {
          
      const actualItem = actualCopy.find((item) => expectedItem[distinctKey] === item[distinctKey])

      if(actualItem){
        passedItemsArray.push(...[
          `- The item with the distinct key: ${greenANSI}"${distinctKey}"${resetANSI} and value: ${greenANSI}"${expectedItem[distinctKey]}"${resetANSI} was found in the actual array\n`,
          objectToErrorText(actualItem, 'Actual item', {objectNameBold: true})
        ])
        comparePassed = true
      } else {
        const notFoundErrorText = `- No matching item found in the array with the key: ${greenANSI}"${distinctKey}"${resetANSI} and value: ${greenANSI}"${expectedItem[distinctKey]}"${resetANSI}\n`
        errorArray.push(
          ...[notFoundErrorText, expectedItemErrorText])
        comparePassed = false
      }
    }

    const message: () => string = comparePassed
      ? () => this.utils.matcherHint(assertionName, undefined, undefined, { isNot: this.isNot }) +
          '\n\n' +
          passedItemsArray.join('\n')
      : () =>  this.utils.matcherHint(assertionName, undefined, undefined, { isNot: this.isNot }) +
          '\n\n' +
          errorArray.join('\n')

    return {
      message,
      pass: comparePassed,
      name: assertionName,
      expected,
      actual,
    }
  }

})
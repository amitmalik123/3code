
export class ComparisonTools{
  /**
     * Compare 2 numbers accurate to 4 decimal places. Consider numbers as equal in case of undefined or null values for both of them 
     * @return boolean if numbers are equal or not
     * */
  public static compareNumbers(num1: number | undefined | null, num2: number | undefined | null): boolean {
    if ((num1 === undefined || num1 === null) && (num2 === undefined || num2 === null)) {
      return true
    }
    if (num1 === undefined || num2 === undefined) {
      return false
    }
    if (num1 === null || num2 === null) {
      return false
    }
    return Number(num1.toFixed(4)) === Number(num2.toFixed(4)) 
  }

  /**
     * Compare 2 numbers accurate to 4 decimal places with permissible deviation.
     * @param num1 - 1-st number for comparison
     * @param num2 - 2-nd number for comparison
     * @param deviation - permissible deviation in fractions
     * @return boolean if numbers are equal or not
     * */
  public static compareNumbersWithDeviation(num1: number, num2: number, deviation: number): boolean {
    if (Number(num1.toFixed(4))===0){
      return Number(num1.toFixed(4)) === Number(num2.toFixed(4))
    }
    return Math.abs ((Number(num1.toFixed(4)) - Number(num2.toFixed(4)))/Number(num1.toFixed(4))) <= deviation
  }

  /**
     * Compare 2 strings. Consider numbers as equal in case of undefined or null values for both of them 
     * @return boolean if strings are equal or not
     * */
  public static compareStrings(str1: string | undefined | null, str2: string | undefined | null): boolean {
    if ((str1 === undefined || str1 === null) && (str2 === undefined || str2 === null)) {
      return true
    }
    if (str1 === undefined || str2 === undefined) {
      return false
    }
    if (str1 === null || str2 === null) {
      return false
    }
    return str1 === str2 
  }

  /**
     * Compare 2 dates in the diffrent format that are passed as a string. Consider dates as equal in case of undefined or null values for both of them 
     * @return boolean if dates are equal or not
     * */
  public static compareDates(date1: string | undefined | null, date2: string | undefined | null): boolean {
    if ((date1 === undefined || date1 === null) && (date2 === undefined || date2 === null)) {
      return true
    }
    if (date1 === undefined || date2 === undefined) {
      return false
    }
    if (date1 === null || date2 === null) {
      return false
    }
      
    const date1Iso = new Date(date1).toISOString().split('T')[0]
    const date2Iso = new Date(date2).toISOString().split('T')[0]
    return date1Iso === date2Iso 
  }

} 